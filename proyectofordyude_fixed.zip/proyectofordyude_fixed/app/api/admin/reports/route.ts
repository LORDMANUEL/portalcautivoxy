
/**
 * API Route para generación de reportes
 * 
 * Funcionalidades:
 * - GET: Obtener datos para reportes
 * - POST: Generar y exportar reportes
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const reportRequestSchema = z.object({
  type: z.enum(['connections', 'users', 'locations', 'portals', 'themes', 'system']),
  format: z.enum(['PDF', 'CSV', 'EXCEL', 'JSON']).default('PDF'),
  dateRange: z.object({
    from: z.string().datetime().optional(),
    to: z.string().datetime().optional()
  }).optional(),
  filters: z.object({
    locationIds: z.array(z.string()).optional(),
    portalTypes: z.array(z.string()).optional(),
    userTypes: z.array(z.string()).optional(),
    includeInactive: z.boolean().default(false)
  }).optional(),
  includeCharts: z.boolean().default(true),
  includeRawData: z.boolean().default(true)
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/reports
 * Obtener datos para reportes y estadísticas
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'dashboard'

    let reportData: any = {}

    switch (type) {
      case 'dashboard':
        // Estadísticas del dashboard
        const [
          totalUsers,
          activeConnections,
          totalLocations,
          activePortals,
          todayConnections,
          yesterdayConnections,
          topLocation,
          topPortal
        ] = await Promise.all([
          prisma.captiveUser.count(),
          prisma.captiveUser.count({ where: { isActive: true } }),
          prisma.location.count({ where: { isActive: true } }),
          prisma.portal.count({ where: { isActive: true } }),
          prisma.captiveUser.count({
            where: {
              connectedAt: {
                gte: new Date(new Date().setHours(0, 0, 0, 0))
              }
            }
          }),
          prisma.captiveUser.count({
            where: {
              connectedAt: {
                gte: new Date(new Date().setDate(new Date().getDate() - 1)),
                lt: new Date(new Date().setHours(0, 0, 0, 0))
              }
            }
          }),
          prisma.location.findFirst({
            include: {
              _count: {
                select: { portals: true }
              }
            },
            orderBy: {
              portals: { _count: 'desc' }
            }
          }),
          prisma.portal.findFirst({
            include: {
              _count: {
                select: { sessions: true }
              }
            },
            orderBy: {
              sessions: { _count: 'desc' }
            }
          })
        ])

        const connectionTrend = yesterdayConnections > 0 
          ? ((todayConnections - yesterdayConnections) / yesterdayConnections) * 100 
          : 100

        reportData = {
          totalUsers,
          activeConnections,
          totalLocations,
          activePortals,
          todayConnections,
          connectionTrend: Math.round(connectionTrend * 100) / 100,
          topLocation: topLocation?.name || 'N/A',
          topPortal: topPortal?.name || 'N/A'
        }
        break

      case 'connections':
        // Datos de conexiones por día de los últimos 7 días
        const sevenDaysAgo = new Date()
        sevenDaysAgo.setDate(new Date().getDate() - 7)

        const connectionsData = await prisma.captiveUser.groupBy({
          by: ['connectedAt'],
          where: {
            connectedAt: {
              gte: sevenDaysAgo
            }
          },
          _count: {
            id: true
          }
        })

        reportData = {
          connections: connectionsData
        }
        break

      case 'locations':
        // Estadísticas por ubicación
        const locationsData = await prisma.location.findMany({
          where: { isActive: true },
          include: {
            _count: {
              select: {
                portals: true,
                admins: true
              }
            }
          }
        })

        reportData = {
          locations: locationsData
        }
        break

      case 'portals':
        // Estadísticas por portal
        const portalsData = await prisma.portal.findMany({
          where: { isActive: true },
          include: {
            location: {
              select: {
                name: true,
                code: true
              }
            },
            _count: {
              select: {
                sessions: true
              }
            }
          }
        })

        reportData = {
          portals: portalsData
        }
        break

      default:
        reportData = { message: 'Tipo de reporte no válido' }
    }

    return NextResponse.json({
      success: true,
      data: reportData
    })

  } catch (error) {
    console.error('Error fetching report data:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/reports
 * Generar y exportar reportes
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = reportRequestSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { type, format, dateRange, filters, includeCharts, includeRawData } = validation.data

    // Construir filtros de fecha
    const dateFilter: any = {}
    if (dateRange?.from) {
      dateFilter.gte = new Date(dateRange.from)
    }
    if (dateRange?.to) {
      dateFilter.lte = new Date(dateRange.to)
    }

    let reportData: any = {}
    let fileName = `${type}_report_${new Date().toISOString().split('T')[0]}`

    // Generar datos según el tipo de reporte
    switch (type) {
      case 'connections':
        const connectionsWhere: any = {}
        if (Object.keys(dateFilter).length > 0) {
          connectionsWhere.connectedAt = dateFilter
        }

        reportData = await prisma.captiveUser.findMany({
          where: connectionsWhere,
          include: {
            logs: {
              take: 5,
              orderBy: { createdAt: 'desc' }
            }
          },
          orderBy: { connectedAt: 'desc' }
        })
        break

      case 'users':
        reportData = await prisma.admin.findMany({
          where: {
            ...(filters?.includeInactive ? {} : { isActive: true })
          },
          include: {
            roles: {
              include: {
                role: true
              }
            },
            location: true
          }
        })
        break

      case 'locations':
        reportData = await prisma.location.findMany({
          where: {
            ...(filters?.includeInactive ? {} : { isActive: true })
          },
          include: {
            portals: true,
            admins: true,
            _count: {
              select: {
                portals: true,
                admins: true,
                backups: true
              }
            }
          }
        })
        break

      case 'portals':
        reportData = await prisma.portal.findMany({
          where: {
            ...(filters?.includeInactive ? {} : { isActive: true }),
            ...(filters?.portalTypes?.length ? { type: { in: filters.portalTypes } } : {})
          },
          include: {
            location: true,
            sessions: {
              take: 10,
              orderBy: { startTime: 'desc' }
            },
            _count: {
              select: {
                sessions: true
              }
            }
          }
        })
        break

      default:
        return NextResponse.json(
          { success: false, message: 'Tipo de reporte no soportado' },
          { status: 400 }
        )
    }

    // Por ahora, devolver datos JSON
    // TODO: Implementar generación de PDF, CSV, Excel
    const response = {
      success: true,
      data: {
        type,
        format,
        fileName,
        generatedAt: new Date().toISOString(),
        recordCount: Array.isArray(reportData) ? reportData.length : 1,
        data: reportData,
        filters: {
          dateRange,
          ...filters
        }
      },
      message: `Reporte ${type} generado exitosamente`
    }

    return NextResponse.json(response)

  } catch (error) {
    console.error('Error generating report:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
