
import { Metadata } from 'next';
import { RssClient } from './_components/rss-client';

export const metadata: Metadata = {
  title: 'Gestión RSS - Admin Ford',
  description: 'Administrar feeds RSS del portal cautivo',
};

export default function AdminRssPage() {
  return <RssClient />;
}
