

import { Metadata } from 'next';
import { PortalClient } from './_components/portal-client';
import { prisma } from '@/lib/db';
import { notFound, redirect } from 'next/navigation';

interface PortalPageProps {
  params: {
    token: string;
  };
  searchParams: {
    theme?: string;
    colors?: string;
  };
}

/**
 * Página del portal cautivo con soporte para múltiples portales
 * Soporta diferentes tipos: Ford, QuickLane Truck, QuickLane Tegucigalpa, QuickLane SPS
 */
export default async function PortalPage({ params, searchParams }: PortalPageProps) {
  const { token } = params;

  try {
    // Buscar el token en la base de datos
    const portalToken = await prisma.portalToken.findUnique({
      where: { token }
    });

    // Si no existe el token, mostrar 404
    if (!portalToken) {
      notFound();
    }

    // Verificar si el token está activo
    if (!portalToken.isActive) {
      return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
          <div className="text-center p-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Portal No Disponible</h1>
            <p className="text-gray-600">Este portal ha sido desactivado temporalmente.</p>
          </div>
        </div>
      );
    }

    // Verificar fecha de expiración
    if (portalToken.expiresAt && new Date() > portalToken.expiresAt) {
      return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
          <div className="text-center p-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Portal Expirado</h1>
            <p className="text-gray-600">Este portal ha expirado el {portalToken.expiresAt.toLocaleDateString()}.</p>
          </div>
        </div>
      );
    }

    // Verificar límite de usos
    if (portalToken.maxUses && portalToken.currentUses >= portalToken.maxUses) {
      return (
        <div className="min-h-screen bg-gray-100 flex items-center justify-center">
          <div className="text-center p-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Portal Agotado</h1>
            <p className="text-gray-600">Este portal ha alcanzado su límite máximo de usos.</p>
          </div>
        </div>
      );
    }

    // Incrementar contador de usos
    await prisma.portalToken.update({
      where: { id: portalToken.id },
      data: { currentUses: { increment: 1 } }
    });

    // Obtener el tema asociado si existe
    let theme = null;
    if (portalToken.themeId) {
      theme = await prisma.theme.findUnique({
        where: { name: portalToken.themeId },
        include: { config: true }
      });
    }

    // Pasar los datos al componente cliente
    return (
      <PortalClient 
        portalToken={portalToken}
        theme={theme}
        searchParams={searchParams}
      />
    );

  } catch (error) {
    console.error('Error al cargar portal:', error);
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center p-8">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Error del Sistema</h1>
          <p className="text-gray-600">Ha ocurrido un error interno. Por favor, intenta más tarde.</p>
        </div>
      </div>
    );
  }
}

/**
 * Generar metadata dinámico basado en el tipo de portal
 */
export async function generateMetadata({ params }: PortalPageProps): Promise<Metadata> {
  const { token } = params;

  try {
    const portalToken = await prisma.portalToken.findUnique({
      where: { token }
    });

    if (!portalToken) {
      return {
        title: 'Portal No Encontrado - Ford Yude Canahuati',
        description: 'El portal solicitado no existe o ha sido desactivado.'
      };
    }

    // Metadata específica por tipo de portal
    const portalMetadata = {
      ford: {
        title: 'Portal Ford - Ford Yude Canahuati',
        description: 'Portal cautivo oficial de Ford Yude Canahuati. Accede a internet y descubre nuestros servicios.'
      },
      quicklane_truck: {
        title: 'Portal QuickLane Truck - Ford Yude Canahuati',
        description: 'Portal cautivo de QuickLane especializado en servicios para camiones y vehículos comerciales.'
      },
      quicklane_tegus: {
        title: 'Portal QuickLane Tegucigalpa - Ford Yude Canahuati',
        description: 'Portal cautivo de QuickLane en Tegucigalpa. Servicios rápidos y confiables para tu vehículo.'
      },
      quicklane_sps: {
        title: 'Portal QuickLane San Pedro Sula - Ford Yude Canahuati',
        description: 'Portal cautivo de QuickLane en San Pedro Sula. Mantenimiento express para tu Ford.'
      }
    };

    const metadata = portalMetadata[portalToken.portalType as keyof typeof portalMetadata] || 
      portalMetadata.ford;

    return {
      title: metadata.title,
      description: metadata.description,
      openGraph: {
        title: metadata.title,
        description: metadata.description,
        images: ['https://www.freepnglogos.com/uploads/large-ford-logo-0.png']
      }
    };
  } catch (error) {
    return {
      title: 'Portal Ford - Ford Yude Canahuati',
      description: 'Portal cautivo de Ford Yude Canahuati'
    };
  }
}
