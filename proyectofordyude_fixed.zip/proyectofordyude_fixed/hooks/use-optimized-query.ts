
"use client";

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

interface UseOptimizedQueryOptions<T> {
  queryKey: (string | number)[];
  queryFn: () => Promise<T>;
  enabled?: boolean;
  staleTime?: number;
  gcTime?: number;
  refetchInterval?: number;
  onSuccess?: (data: T) => void;
  onError?: (error: Error) => void;
}

export function useOptimizedQuery<T>({
  queryKey,
  queryFn,
  enabled = true,
  staleTime = 5 * 60 * 1000, // 5 minutos
  gcTime = 10 * 60 * 1000, // 10 minutos
  refetchInterval,
  onSuccess,
  onError,
}: UseOptimizedQueryOptions<T>) {
  return useQuery({
    queryKey,
    queryFn,
    enabled,
    staleTime,
    gcTime,
    refetchInterval,
    retry: (failureCount, error: any) => {
      if (error?.status === 404 || error?.status === 401) {
        return false;
      }
      return failureCount < 3;
    },
    meta: {
      onSuccess,
      onError,
    },
  });
}

interface UseOptimizedMutationOptions<TData, TVariables> {
  mutationFn: (variables: TVariables) => Promise<TData>;
  onSuccess?: (data: TData, variables: TVariables) => void;
  onError?: (error: Error, variables: TVariables) => void;
  invalidateQueries?: (string | number)[][];
  optimisticUpdate?: {
    queryKey: (string | number)[];
    updateFn: (old: any, variables: TVariables) => any;
  };
  successMessage?: string;
  errorMessage?: string;
}

export function useOptimizedMutation<TData, TVariables>({
  mutationFn,
  onSuccess,
  onError,
  invalidateQueries = [],
  optimisticUpdate,
  successMessage,
  errorMessage,
}: UseOptimizedMutationOptions<TData, TVariables>) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn,
    onMutate: async (variables) => {
      // Cancelar queries en curso
      if (optimisticUpdate) {
        await queryClient.cancelQueries({ queryKey: optimisticUpdate.queryKey });

        // Snapshot del valor anterior
        const previousData = queryClient.getQueryData(optimisticUpdate.queryKey);

        // Actualización optimista
        queryClient.setQueryData(
          optimisticUpdate.queryKey,
          (old: any) => optimisticUpdate.updateFn(old, variables)
        );

        return { previousData };
      }
    },
    onError: (error, variables, context) => {
      // Revertir la actualización optimista en caso de error
      if (optimisticUpdate && context?.previousData) {
        queryClient.setQueryData(optimisticUpdate.queryKey, context.previousData);
      }

      // Mostrar mensaje de error
      if (errorMessage) {
        toast.error(errorMessage);
      }

      onError?.(error as Error, variables);
    },
    onSuccess: (data, variables) => {
      // Invalidar queries relacionadas
      invalidateQueries.forEach((queryKey) => {
        queryClient.invalidateQueries({ queryKey });
      });

      // Mostrar mensaje de éxito
      if (successMessage) {
        toast.success(successMessage);
      }

      onSuccess?.(data, variables);
    },
    onSettled: () => {
      // Refetch queries después de la mutación
      if (optimisticUpdate) {
        queryClient.invalidateQueries({ queryKey: optimisticUpdate.queryKey });
      }
    },
  });
}

// Hook para invalidar múltiples queries
export function useInvalidateQueries() {
  const queryClient = useQueryClient();

  return (queryKeys: (string | number)[][]) => {
    queryKeys.forEach((queryKey) => {
      queryClient.invalidateQueries({ queryKey });
    });
  };
}

// Hook para prefetch de datos
export function usePrefetchQuery() {
  const queryClient = useQueryClient();

  return <T>(
    queryKey: (string | number)[],
    queryFn: () => Promise<T>,
    staleTime = 5 * 60 * 1000
  ) => {
    return queryClient.prefetchQuery({
      queryKey,
      queryFn,
      staleTime,
    });
  };
}
