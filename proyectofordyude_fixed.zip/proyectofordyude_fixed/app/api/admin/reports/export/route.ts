
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import ExcelJS from 'exceljs';
import jsPDF from 'jspdf';

export const dynamic = 'force-dynamic';

interface ExportRequest {
  format: 'pdf' | 'excel' | 'csv';
  filters: any;
  data: {
    dashboardStats: any;
    chartData: any;
  };
}

/**
 * Exportar reportes en diferentes formatos
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body: ExportRequest = await request.json();
    const { format, filters, data } = body;

    const timestamp = new Date().toISOString().split('T')[0];
    const filename = `reporte-ford-${timestamp}`;

    switch (format) {
      case 'csv':
        return await generateCSV(data, filename);
      case 'excel':
        return await generateExcel(data, filename);
      case 'pdf':
        return await generatePDF(data, filename);
      default:
        return NextResponse.json({ error: 'Formato no soportado' }, { status: 400 });
    }
  } catch (error) {
    console.error('Error exportando reporte:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * Genera reporte en formato CSV
 */
async function generateCSV(data: any, filename: string) {
  const { dashboardStats, chartData } = data;
  
  // Header del CSV
  let csv = 'Ford Yude Canahuati - Reporte de Portal Cautivo\n';
  csv += `Generado: ${new Date().toLocaleDateString()}\n\n`;
  
  // Estadísticas generales
  csv += 'ESTADISTICAS GENERALES\n';
  csv += 'Métrica,Valor\n';
  csv += `Conexiones Totales,${dashboardStats.totalConnections}\n`;
  csv += `Usuarios Activos,${dashboardStats.activeUsers}\n`;
  csv += `Sesión Promedio,${dashboardStats.averageSession} min\n`;
  csv += `Ubicación Top,${dashboardStats.topLocation}\n\n`;
  
  // Datos de conexiones
  csv += 'CONEXIONES POR DIA\n';
  csv += 'Fecha,Conexiones\n';
  chartData.connections?.forEach((item: any) => {
    csv += `${item.date},${item.connections}\n`;
  });
  
  csv += '\nCONEXIONES POR UBICACION\n';
  csv += 'Ubicación,Conexiones\n';
  chartData.locations?.forEach((item: any) => {
    csv += `${item.name},${item.connections}\n`;
  });

  const buffer = Buffer.from(csv, 'utf8');
  
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="${filename}.csv"`,
    },
  });
}

/**
 * Genera reporte en formato Excel
 */
async function generateExcel(data: any, filename: string) {
  const { dashboardStats, chartData } = data;
  
  const workbook = new ExcelJS.Workbook();
  
  // Hoja de estadísticas generales
  const statsSheet = workbook.addWorksheet('Estadísticas Generales');
  
  // Header
  statsSheet.addRow(['Ford Yude Canahuati - Reporte Portal Cautivo']);
  statsSheet.addRow([`Generado: ${new Date().toLocaleDateString()}`]);
  statsSheet.addRow([]);
  
  // Estadísticas
  statsSheet.addRow(['Métrica', 'Valor']);
  statsSheet.addRow(['Conexiones Totales', dashboardStats.totalConnections]);
  statsSheet.addRow(['Usuarios Activos', dashboardStats.activeUsers]);
  statsSheet.addRow(['Sesión Promedio (min)', dashboardStats.averageSession]);
  statsSheet.addRow(['Ubicación Top', dashboardStats.topLocation]);
  
  // Formato de header
  statsSheet.getRow(1).font = { bold: true, size: 14 };
  statsSheet.getRow(4).font = { bold: true };
  
  // Hoja de conexiones
  if (chartData.connections?.length > 0) {
    const connectionsSheet = workbook.addWorksheet('Conexiones por Día');
    connectionsSheet.addRow(['Fecha', 'Conexiones']);
    
    chartData.connections.forEach((item: any) => {
      connectionsSheet.addRow([item.date, item.connections]);
    });
    
    connectionsSheet.getRow(1).font = { bold: true };
  }
  
  // Hoja de ubicaciones
  if (chartData.locations?.length > 0) {
    const locationsSheet = workbook.addWorksheet('Conexiones por Ubicación');
    locationsSheet.addRow(['Ubicación', 'Conexiones']);
    
    chartData.locations.forEach((item: any) => {
      locationsSheet.addRow([item.name, item.connections]);
    });
    
    locationsSheet.getRow(1).font = { bold: true };
  }
  
  // Generar buffer
  const buffer = await workbook.xlsx.writeBuffer();
  
  return new NextResponse(buffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}.xlsx"`,
    },
  });
}

/**
 * Genera reporte en formato PDF
 */
async function generatePDF(data: any, filename: string) {
  const { dashboardStats, chartData } = data;
  
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(18);
  doc.text('Ford Yude Canahuati', 20, 20);
  doc.setFontSize(14);
  doc.text('Reporte Portal Cautivo', 20, 30);
  doc.setFontSize(10);
  doc.text(`Generado: ${new Date().toLocaleDateString()}`, 20, 40);
  
  // Estadísticas generales
  doc.setFontSize(12);
  doc.text('Estadísticas Generales', 20, 55);
  
  let yPos = 65;
  doc.setFontSize(10);
  doc.text(`Conexiones Totales: ${dashboardStats.totalConnections}`, 25, yPos);
  yPos += 10;
  doc.text(`Usuarios Activos: ${dashboardStats.activeUsers}`, 25, yPos);
  yPos += 10;
  doc.text(`Sesión Promedio: ${dashboardStats.averageSession} min`, 25, yPos);
  yPos += 10;
  doc.text(`Ubicación Top: ${dashboardStats.topLocation}`, 25, yPos);
  yPos += 20;
  
  // Conexiones por ubicación
  if (chartData.locations?.length > 0) {
    doc.setFontSize(12);
    doc.text('Conexiones por Ubicación', 20, yPos);
    yPos += 15;
    
    doc.setFontSize(10);
    chartData.locations.forEach((item: any) => {
      if (yPos > 280) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(`${item.name}: ${item.connections}`, 25, yPos);
      yPos += 8;
    });
  }
  
  // Generar buffer
  const pdfBuffer = Buffer.from(doc.output('arraybuffer'));
  
  return new NextResponse(pdfBuffer, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${filename}.pdf"`,
    },
  });
}
