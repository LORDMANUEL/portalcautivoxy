
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import dynamic from 'next/dynamic';

// Plotly para gráficos 3D avanzados
// @ts-ignore
const Plot = dynamic(() => import('react-plotly.js'), {
  ssr: false,
  loading: () => <div className="flex items-center justify-center h-64">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#003478]"></div>
  </div>
});

// Colores Ford oficiales para gráficos
const FORD_COLORS = [
  '#003478', // Ford Blue
  '#47A8E5', // Picton Blue  
  '#2A6BAC', // Lapis Lazuli
  '#133A7C', // Dark Cerulean
  '#081534', // Maastricht Blue
  '#FF6B35', // QuickLane Orange
  '#4ECDC4', // QuickLane Teal
  '#45B7D1'  // Light Blue
];

interface ChartProps {
  data: any[];
  title: string;
  description?: string;
}

/**
 * Gráfico de conexiones diarias con área sombreada
 */
export function ConnectionsAreaChart({ data, title, description }: ChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="connectionGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#003478" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#003478" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 10 }}
              tickLine={false}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis 
              tick={{ fontSize: 10 }}
              tickLine={false}
              label={{ 
                value: 'Conexiones', 
                angle: -90, 
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontSize: 11 }
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
              labelStyle={{ color: '#003478', fontWeight: 'bold' }}
            />
            <Area 
              type="monotone" 
              dataKey="connections" 
              stroke="#003478"
              strokeWidth={3}
              fill="url(#connectionGradient)"
              dot={{ fill: '#003478', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6, stroke: '#003478', strokeWidth: 2 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Gráfico de barras comparativo por ubicación
 */
export function LocationBarChart({ data, title, description }: ChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="location"
              tick={{ fontSize: 10 }}
              tickLine={false}
              angle={-45}
              textAnchor="end"
              height={80}
            />
            <YAxis 
              tick={{ fontSize: 10 }}
              tickLine={false}
              label={{ 
                value: 'Conexiones', 
                angle: -90, 
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontSize: 11 }
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Bar 
              dataKey="connections" 
              fill="#003478"
              radius={[4, 4, 0, 0]}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={FORD_COLORS[index % FORD_COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Gráfico de dona para distribución de dispositivos
 */
export function DeviceDistributionChart({ data, title, description }: ChartProps) {
  const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor={x > cx ? 'start' : 'end'} 
        dominantBaseline="central"
        fontSize={12}
        fontWeight="bold"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomLabel}
              outerRadius={100}
              innerRadius={40}
              fill="#003478"
              dataKey="value"
              stroke="#ffffff"
              strokeWidth={2}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={FORD_COLORS[index % FORD_COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              formatter={(value, name) => [`${value} conexiones`, name]}
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Legend 
              verticalAlign="bottom"
              height={36}
              wrapperStyle={{ fontSize: '11px', paddingTop: '20px' }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Gráfico de líneas múltiples para comparación de portales
 */
export function MultiPortalChart({ data, title, description }: ChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="date"
              tick={{ fontSize: 10 }}
              tickLine={false}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis 
              tick={{ fontSize: 10 }}
              tickLine={false}
              label={{ 
                value: 'Conexiones', 
                angle: -90, 
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontSize: 11 }
              }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Legend 
              verticalAlign="top"
              height={36}
              wrapperStyle={{ fontSize: '11px' }}
            />
            <Line 
              type="monotone" 
              dataKey="ford" 
              stroke="#003478"
              strokeWidth={3}
              dot={{ fill: '#003478', strokeWidth: 2, r: 4 }}
              name="Portal Ford"
            />
            <Line 
              type="monotone" 
              dataKey="quicklane_truck" 
              stroke="#FF6B35"
              strokeWidth={3}
              dot={{ fill: '#FF6B35', strokeWidth: 2, r: 4 }}
              name="QuickLane Truck"
            />
            <Line 
              type="monotone" 
              dataKey="quicklane_tegus" 
              stroke="#4ECDC4"
              strokeWidth={3}
              dot={{ fill: '#4ECDC4', strokeWidth: 2, r: 4 }}
              name="QuickLane Tegus"
            />
            <Line 
              type="monotone" 
              dataKey="quicklane_sps" 
              stroke="#45B7D1"
              strokeWidth={3}
              dot={{ fill: '#45B7D1', strokeWidth: 2, r: 4 }}
              name="QuickLane SPS"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Gráfico radar para análisis de rendimiento por horas
 */
export function HourlyPerformanceRadar({ data, title, description }: ChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart data={data} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
            <PolarGrid stroke="#f0f0f0" />
            <PolarAngleAxis 
              dataKey="hour" 
              tick={{ fontSize: 10 }}
              className="text-gray-600"
            />
            <PolarRadiusAxis 
              angle={90} 
              domain={[0, 'dataMax']} 
              tick={{ fontSize: 10 }}
              tickCount={4}
            />
            <Radar
              name="Conexiones"
              dataKey="connections"
              stroke="#003478"
              fill="#003478"
              fillOpacity={0.3}
              strokeWidth={2}
              dot={{ fill: '#003478', strokeWidth: 2, r: 3 }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Legend 
              verticalAlign="top"
              wrapperStyle={{ fontSize: '11px' }}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Gráfico 3D de superficie para análisis temporal avanzado
 */
export function Advanced3DSurfaceChart({ data, title, description }: ChartProps) {
  // Preparar datos para Plotly 3D
  const surfaceData: any = {
    x: data.map(d => d.hour),
    y: data.map(d => d.day),
    z: data.map(d => d.connections),
    type: 'surface' as const,
    colorscale: [
      [0, '#e8f4fd'],
      [0.25, '#47A8E5'],
      [0.5, '#2A6BAC'],
      [0.75, '#133A7C'],
      [1, '#003478']
    ],
    hovertemplate: 'Hora: %{x}<br>Día: %{y}<br>Conexiones: %{z}<extra></extra>',
    showscale: true,
    colorbar: {
      title: false,
      thickness: 8,
      len: 0.7,
    }
  };

  const layout: any = {
    title: false,
    scene: {
      xaxis: {
        title: 'Hora',
        showspikes: false,
        backgroundcolor: '#f8f9fa',
        showbackground: true,
        showgrid: true,
        gridcolor: '#e0e0e0'
      },
      yaxis: {
        title: 'Día',
        showspikes: false,
        backgroundcolor: '#f8f9fa',
        showbackground: true,
        showgrid: true,
        gridcolor: '#e0e0e0'
      },
      zaxis: {
        title: 'Conexiones',
        showspikes: false,
        backgroundcolor: '#f8f9fa',
        showbackground: true,
        showgrid: true,
        gridcolor: '#e0e0e0'
      },
      camera: {
        eye: { x: 1.25, y: 1.25, z: 1.25 }
      }
    },
    hovermode: 'closest',
    hoverlabel: {
      bgcolor: '#f8f9fa',
      font: { size: 13 },
      align: 'left'
    },
    margin: { l: 0, r: 0, t: 0, b: 0 }
  };

  const config: any = {
    responsive: true,
    displaylogo: false,
    modeBarButtonsToRemove: [
      "autoScale2d", "autoscale", "editInChartStudio", "editinchartstudio", 
      "hoverCompareCartesian", "hovercompare", "lasso", "lasso2d", "orbitRotation", 
      "orbitrotation", "pan", "pan2d", "pan3d", "resetSankeyGroup", "resetViewMap", 
      "resetViewMapbox", "resetViews", "resetcameradefault", "resetsankeygroup", 
      "select", "select2d", "sendDataToCloud", "senddatatocloud", "tableRotation", 
      "tablerotation", "toggleHover", "toggleSpikelines", "togglehover", 
      "togglespikelines", "zoom", "zoom2d", "zoom3d", "zoomIn2d", "zoomInGeo", 
      "zoomInMap", "zoomInMapbox", "zoomOut2d", "zoomOutGeo", "zoomOutMap", 
      "zoomOutMapbox", "zoomin", "zoomout"
    ]
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-96">
        <Plot
          data={[surfaceData]}
          layout={layout}
          config={config}
          style={{ width: '100%', height: '100%' }}
        />
      </div>
    </motion.div>
  );
}

/**
 * Gráfico de dispersión para análisis de correlación
 */
export function CorrelationScatterChart({ data, title, description }: ChartProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        {description && (
          <p className="text-sm text-gray-600 mt-1">{description}</p>
        )}
      </div>
      
      <div className="w-full h-80">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              type="number"
              dataKey="sessionDuration"
              name="Duración de Sesión"
              unit=" min"
              tick={{ fontSize: 10 }}
              tickLine={false}
              label={{ 
                value: 'Duración Sesión (min)', 
                position: 'insideBottom', 
                offset: -15,
                style: { textAnchor: 'middle', fontSize: 11 }
              }}
            />
            <YAxis 
              type="number"
              dataKey="pagesViewed"
              name="Páginas Vistas"
              unit=" páginas"
              tick={{ fontSize: 10 }}
              tickLine={false}
              label={{ 
                value: 'Páginas Vistas', 
                angle: -90, 
                position: 'insideLeft',
                style: { textAnchor: 'middle', fontSize: 11 }
              }}
            />
            <Tooltip 
              cursor={{ strokeDasharray: '3 3' }}
              formatter={(value, name) => [value, name]}
              labelFormatter={() => ''}
              contentStyle={{
                backgroundColor: '#f8f9fa',
                border: '1px solid #003478',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Scatter 
              name="Usuarios" 
              dataKey="pagesViewed" 
              fill="#003478"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={FORD_COLORS[index % FORD_COLORS.length]} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

/**
 * Hook para animaciones de contadores
 */
export function useCountUp(endValue: number, duration: number = 2000) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number;
    let animationFrame: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      setCount(Math.floor(progress * endValue));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [endValue, duration]);

  return count;
}

/**
 * Componente de métrica animada
 */
interface AnimatedMetricProps {
  title: string;
  value: number;
  suffix?: string;
  prefix?: string;
  icon?: React.ReactNode;
  color?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export function AnimatedMetric({ 
  title, 
  value, 
  suffix = '', 
  prefix = '', 
  icon, 
  color = '#003478',
  trend 
}: AnimatedMetricProps) {
  const animatedValue = useCountUp(value);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      className="bg-white p-6 rounded-lg shadow-lg border border-gray-200"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold" style={{ color }}>
            {prefix}{animatedValue.toLocaleString()}{suffix}
          </p>
          {trend && (
            <div className={`flex items-center mt-2 text-sm ${
              trend.isPositive ? 'text-green-600' : 'text-red-600'
            }`}>
              <span className="mr-1">
                {trend.isPositive ? '↗' : '↘'}
              </span>
              {Math.abs(trend.value)}%
            </div>
          )}
        </div>
        {icon && (
          <div className="text-4xl" style={{ color }}>
            {icon}
          </div>
        )}
      </div>
    </motion.div>
  );
}

