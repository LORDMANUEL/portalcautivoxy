
import { Metadata } from 'next';
import { UsersClient } from './_components/users-client';

export const metadata: Metadata = {
  title: 'Gestión de Usuarios - Admin Ford',
  description: 'Administrar usuarios conectados al portal cautivo',
};

export default function AdminUsersPage() {
  return <UsersClient />;
}
