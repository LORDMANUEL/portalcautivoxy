
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import archiver from 'archiver';

export const dynamic = 'force-dynamic';

/**
 * Obtener lista de backups
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const backups = await prisma.backup.findMany({
      include: {
        location: {
          select: {
            name: true,
            code: true
          }
        }
      },
      orderBy: {
        startedAt: 'desc'
      }
    });

    // Convertir BigInt a string para JSON
    const serializedBackups = backups.map((backup: any) => ({
      ...backup,
      fileSize: backup.fileSize?.toString() || null
    }));

    return NextResponse.json(serializedBackups);
  } catch (error) {
    console.error('Error al obtener backups:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * Crear nuevo backup
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, type, locationId, compressionType, isEncrypted, retentionDays } = body;

    // Crear registro de backup en base de datos
    const backup = await prisma.backup.create({
      data: {
        name,
        type: type || 'FULL',
        status: 'RUNNING',
        locationId: locationId || null,
        compressionType: compressionType || 'gzip',
        isAutomatic: false,
        isEncrypted: isEncrypted || false,
        retentionDays: parseInt(retentionDays) || 30,
        createdBy: session.user.id
      }
    });

    // Ejecutar backup en background
    generateBackupFile(backup.id, type, compressionType, isEncrypted);

    return NextResponse.json({ 
      message: 'Backup iniciado correctamente',
      backupId: backup.id 
    });
  } catch (error) {
    console.error('Error al crear backup:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * Genera el archivo de backup de forma asíncrona
 */
async function generateBackupFile(
  backupId: string, 
  type: string, 
  compressionType: string, 
  isEncrypted: boolean
) {
  try {
    const backupDir = '/home/ubuntu/proyectofordyude/backup';
    await fs.mkdir(backupDir, { recursive: true });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `backup-${timestamp}.sql`;
    const filepath = path.join(backupDir, filename);

    // Generar dump de PostgreSQL
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error('DATABASE_URL no configurada');
    }

    // Extraer parámetros de conexión
    const url = new URL(databaseUrl);
    const dbParams = {
      host: url.hostname,
      port: url.port || '5432',
      database: url.pathname.slice(1),
      username: url.username,
      password: url.password
    };

    // Ejecutar pg_dump
    const pgDumpProcess = spawn('pg_dump', [
      '-h', dbParams.host,
      '-p', dbParams.port,
      '-U', dbParams.username,
      '-d', dbParams.database,
      '--no-password',
      '--verbose',
      '--file', filepath
    ], {
      env: {
        ...process.env,
        PGPASSWORD: dbParams.password
      }
    });

    pgDumpProcess.on('close', async (code) => {
      try {
        if (code === 0) {
          // Backup exitoso, comprimir si es necesario
          let finalPath = filepath;
          let fileSize = (await fs.stat(filepath)).size;

          if (compressionType === 'gzip') {
            const gzipPath = `${filepath}.gz`;
            const gzipProcess = spawn('gzip', [filepath]);
            
            gzipProcess.on('close', async (gzipCode) => {
              if (gzipCode === 0) {
                finalPath = gzipPath;
                fileSize = (await fs.stat(gzipPath)).size;
              }
              
              // Actualizar registro en base de datos
              await prisma.backup.update({
                where: { id: backupId },
                data: {
                  status: 'COMPLETED',
                  filePath: finalPath,
                  fileSize: BigInt(fileSize),
                  completedAt: new Date()
                }
              });
            });
          } else {
            // Sin compresión
            await prisma.backup.update({
              where: { id: backupId },
              data: {
                status: 'COMPLETED',
                filePath: finalPath,
                fileSize: BigInt(fileSize),
                completedAt: new Date()
              }
            });
          }
        } else {
          // Error en backup
          await prisma.backup.update({
            where: { id: backupId },
            data: {
              status: 'FAILED',
              errorMessage: `pg_dump falló con código ${code}`,
              completedAt: new Date()
            }
          });
        }
      } catch (error) {
        console.error('Error procesando backup:', error);
        await prisma.backup.update({
          where: { id: backupId },
          data: {
            status: 'FAILED',
            errorMessage: error instanceof Error ? error.message : 'Error desconocido',
            completedAt: new Date()
          }
        });
      }
    });

    pgDumpProcess.on('error', async (error) => {
      console.error('Error ejecutando pg_dump:', error);
      await prisma.backup.update({
        where: { id: backupId },
        data: {
          status: 'FAILED',
          errorMessage: error.message,
          completedAt: new Date()
        }
      });
    });

  } catch (error) {
    console.error('Error generando backup:', error);
    await prisma.backup.update({
      where: { id: backupId },
      data: {
        status: 'FAILED',
        errorMessage: error instanceof Error ? error.message : 'Error desconocido',
        completedAt: new Date()
      }
    });
  }
}
