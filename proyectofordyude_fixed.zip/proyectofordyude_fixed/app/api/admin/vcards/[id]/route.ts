

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import QRCode from 'qrcode';

export const dynamic = 'force-dynamic';

/**
 * PUT /api/admin/vcards/[id]
 * Actualiza una vCard existente
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { advisorName, position, email, phone, company, address, website, photo } = body;

    if (!advisorName || !email) {
      return NextResponse.json({ error: 'Nombre y email son obligatorios' }, { status: 400 });
    }

    // Crear URL de contacto para QR (consistente con la creación)
    const contactUrl = `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/contact/${params.id}`;

    // Generar nuevo código QR que apunta a página web
    const qrCodeDataUrl = await QRCode.toDataURL(contactUrl, {
      width: 400,
      margin: 2,
      color: {
        dark: '#003478',
        light: '#FFFFFF'
      }
    });

    // Actualizar la vCard
    const vcard = await prisma.vCard.update({
      where: { id: params.id },
      data: {
        advisorName,
        position: position || null,
        email,
        phone: phone || null,
        company,
        address: address || null,
        website: website || null,
        photo: photo || null,
        qrCode: qrCodeDataUrl
      }
    });

    return NextResponse.json(vcard);
  } catch (error) {
    console.error('Error al actualizar vCard:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/vcards/[id]
 * Elimina una vCard
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    await prisma.vCard.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar vCard:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
