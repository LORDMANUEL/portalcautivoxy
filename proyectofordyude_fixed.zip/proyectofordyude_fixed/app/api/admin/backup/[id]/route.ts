
/**
 * API Route para gestión individual de backups
 * 
 * Funcionalidades:
 * - GET: Obtener backup específico
 * - DELETE: Eliminar backup
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { unlink } from 'fs/promises'

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/backup/[id]
 * Obtener backup específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const backup = await prisma.backup.findUnique({
      where: { id: params.id },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true
          }
        }
      }
    })

    if (!backup) {
      return NextResponse.json(
        { success: false, message: 'Backup no encontrado' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: {
        ...backup,
        fileSize: backup.fileSize?.toString() || null
      }
    })

  } catch (error) {
    console.error('Error fetching backup:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/backup/[id]
 * Eliminar backup y su archivo
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const backup = await prisma.backup.findUnique({
      where: { id: params.id }
    })

    if (!backup) {
      return NextResponse.json(
        { success: false, message: 'Backup no encontrado' },
        { status: 404 }
      )
    }

    // Eliminar archivo si existe
    if (backup.filePath) {
      try {
        await unlink(backup.filePath)
      } catch (error) {
        console.warn('Could not delete backup file:', error)
      }
    }

    // Eliminar registro de base de datos
    await prisma.backup.delete({
      where: { id: params.id }
    })

    return NextResponse.json({
      success: true,
      message: 'Backup eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error deleting backup:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
