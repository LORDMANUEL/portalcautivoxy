
/**
 * API Route para gestión individual de portales
 * 
 * Funcionalidades:
 * - GET: Obtener portal específico
 * - PUT: Actualizar portal
 * - DELETE: Eliminar portal
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const updatePortalSchema = z.object({
  name: z.string().min(2).optional(),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/).optional(),
  type: z.enum(['FORD', 'QUICKLANE_TRUCK', 'QUICKLANE_TEGUS', 'QUICKLANE_SPS']).optional(),
  brand: z.string().optional(),
  locationId: z.string().optional(),
  description: z.string().optional(),
  logoUrl: z.string().optional(),
  primaryColor: z.string().optional(),
  secondaryColor: z.string().optional(),
  themeId: z.string().optional(),
  welcomeTitle: z.string().optional(),
  welcomeMessage: z.string().optional(),
  customCss: z.string().optional(),
  customJs: z.string().optional(),
  isActive: z.boolean().optional(),
  metadata: z.record(z.any()).optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/portals/[id]
 * Obtener portal específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const portal = await prisma.portal.findUnique({
      where: { id: params.id },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true,
            type: true,
            city: true
          }
        },
        sessions: {
          take: 10,
          orderBy: { startTime: 'desc' },
          select: {
            id: true,
            deviceId: true,
            ipAddress: true,
            startTime: true,
            endTime: true,
            duration: true,
            isActive: true
          }
        },
        _count: {
          select: {
            sessions: true
          }
        }
      }
    })

    if (!portal) {
      return NextResponse.json(
        { success: false, message: 'Portal no encontrado' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: portal
    })

  } catch (error) {
    console.error('Error fetching portal:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/portals/[id]
 * Actualizar portal
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = updatePortalSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { slug, ...updateData } = validation.data

    // Verificar que el portal existe
    const existingPortal = await prisma.portal.findUnique({
      where: { id: params.id }
    })

    if (!existingPortal) {
      return NextResponse.json(
        { success: false, message: 'Portal no encontrado' },
        { status: 404 }
      )
    }

    // Verificar slug único (si se está cambiando)
    if (slug && slug !== existingPortal.slug) {
      const slugTaken = await prisma.portal.findUnique({
        where: { slug }
      })

      if (slugTaken) {
        return NextResponse.json(
          { success: false, message: 'Ya existe un portal con ese slug' },
          { status: 400 }
        )
      }
    }

    const portal = await prisma.portal.update({
      where: { id: params.id },
      data: {
        ...updateData,
        ...(slug && { slug })
      },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true,
            type: true
          }
        },
        _count: {
          select: {
            sessions: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: portal,
      message: 'Portal actualizado exitosamente'
    })

  } catch (error) {
    console.error('Error updating portal:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/portals/[id]
 * Eliminar portal (soft delete)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const portal = await prisma.portal.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            sessions: { where: { isActive: true } }
          }
        }
      }
    })

    if (!portal) {
      return NextResponse.json(
        { success: false, message: 'Portal no encontrado' },
        { status: 404 }
      )
    }

    // Advertir si hay sesiones activas
    if (portal._count.sessions > 0) {
      return NextResponse.json(
        { success: false, message: 'No se puede eliminar un portal que tiene sesiones activas' },
        { status: 400 }
      )
    }

    // Soft delete - marcar como inactive
    await prisma.portal.update({
      where: { id: params.id },
      data: { 
        isActive: false,
        updatedAt: new Date()
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Portal eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error deleting portal:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
