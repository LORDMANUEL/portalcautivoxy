

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET - Servir RSS embebido como página HTML
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    
    // Configuraciones del embed
    const theme = searchParams.get('theme') || 'light';
    const maxItems = parseInt(searchParams.get('maxItems') || '5');
    const showImages = searchParams.get('showImages') === 'true';
    const showDates = searchParams.get('showDates') === 'true';
    const showDescriptions = searchParams.get('showDescriptions') === 'true';
    const titleColor = searchParams.get('titleColor') || '#1f2937';
    const backgroundColor = searchParams.get('backgroundColor') || '#ffffff';
    const textColor = searchParams.get('textColor') || '#374151';
    const borderRadius = searchParams.get('borderRadius') || '8px';

    // Obtener feed y sus items
    const feed = await prisma.rssFeed.findUnique({
      where: { id: params.id },
      include: {
        items: {
          where: { isVisible: true },
          orderBy: { pubDate: 'desc' },
          take: maxItems
        }
      }
    });

    if (!feed || !feed.isActive) {
      return new NextResponse('Feed no encontrado o inactivo', { status: 404 });
    }

    // Generar HTML del embed
    const html = `
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${feed.title} - RSS Feed</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: ${backgroundColor};
            color: ${textColor};
            padding: 16px;
            line-height: 1.5;
        }
        
        .rss-container {
            max-width: 100%;
            overflow: hidden;
        }
        
        .rss-header {
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid ${theme === 'dark' ? '#374151' : '#e5e7eb'};
        }
        
        .rss-title {
            color: ${titleColor};
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 4px;
        }
        
        .rss-description {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .rss-item {
            margin-bottom: 16px;
            padding-bottom: 16px;
            border-bottom: 1px solid ${theme === 'dark' ? '#374151' : '#f3f4f6'};
        }
        
        .rss-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .item-header {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 8px;
        }
        
        .item-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
            flex-shrink: 0;
        }
        
        .item-content {
            flex: 1;
            min-width: 0;
        }
        
        .item-title {
            font-size: 16px;
            font-weight: 600;
            color: ${titleColor};
            text-decoration: none;
            display: block;
            margin-bottom: 4px;
        }
        
        .item-title:hover {
            opacity: 0.8;
        }
        
        .item-date {
            font-size: 12px;
            opacity: 0.7;
            margin-bottom: 8px;
        }
        
        .item-description {
            font-size: 14px;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .powered-by {
            margin-top: 16px;
            padding-top: 12px;
            border-top: 1px solid ${theme === 'dark' ? '#374151' : '#e5e7eb'};
            text-align: center;
            font-size: 11px;
            opacity: 0.6;
        }
        
        .powered-by a {
            color: #003478;
            text-decoration: none;
        }
        
        @media (max-width: 480px) {
            body {
                padding: 12px;
            }
            
            .item-header {
                flex-direction: column;
                gap: 8px;
            }
            
            .item-image {
                width: 100%;
                height: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="rss-container">
        <div class="rss-header">
            <div class="rss-title">${feed.title}</div>
            ${feed.description ? `<div class="rss-description">${feed.description}</div>` : ''}
        </div>
        
        <div class="rss-items">
            ${feed.items.map((item: any) => `
                <div class="rss-item">
                    <div class="item-header">
                        ${showImages && item.imageUrl ? `
                            <img src="${item.imageUrl}" alt="" class="item-image" loading="lazy">
                        ` : ''}
                        <div class="item-content">
                            <a href="${item.link}" target="_parent" class="item-title">
                                ${item.title}
                            </a>
                            ${showDates && item.pubDate ? `
                                <div class="item-date">
                                    ${new Date(item.pubDate).toLocaleDateString('es-ES', {
                                        year: 'numeric',
                                        month: 'short',
                                        day: 'numeric'
                                    })}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                    ${showDescriptions && item.description ? `
                        <div class="item-description">${item.description}</div>
                    ` : ''}
                </div>
            `).join('')}
        </div>
        
        <div class="powered-by">
            Powered by <a href="https://yudecanahuati.com" target="_parent">Ford Yude Canahuati</a>
        </div>
    </div>
</body>
</html>`;

    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'public, max-age=300', // Cache por 5 minutos
        'X-Frame-Options': 'ALLOWALL', // Permitir embebido en iframes
      },
    });
  } catch (error) {
    console.error('Error al generar RSS embebido:', error);
    return new NextResponse('Error interno del servidor', { status: 500 });
  }
}
