
'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, 
  X, 
  Check, 
  CheckCheck,
  AlertCircle,
  Info,
  CheckCircle,
  AlertTriangle,
  Users,
  Database,
  Wifi,
  Settings,
  Clock
} from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  time: string;
  read: boolean;
  category: 'system' | 'user' | 'portal' | 'backup';
}

export function NotificationDropdown() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Cerrar dropdown al hacer clic fuera
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Cargar notificaciones al montar el componente
  useEffect(() => {
    loadNotifications();
    
    // Actualizar notificaciones cada 30 segundos
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = async () => {
    try {
      // Simulación de notificaciones en tiempo real
      const mockNotifications: Notification[] = [
        {
          id: '1',
          title: 'Nuevo usuario conectado',
          message: 'Juan Pérez se conectó al portal Ford Tradicional',
          type: 'info',
          time: formatTimeAgo(2),
          read: false,
          category: 'user'
        },
        {
          id: '2',
          title: 'Backup completado',
          message: 'Backup automático de la base de datos realizado exitosamente',
          type: 'success',
          time: formatTimeAgo(45),
          read: false,
          category: 'backup'
        },
        {
          id: '3',
          title: 'Error de conexión temporal',
          message: 'Se detectó un problema temporal en el portal QuickLane Truck',
          type: 'warning',
          time: formatTimeAgo(180),
          read: false,
          category: 'portal'
        },
        {
          id: '4',
          title: 'Promoción activada',
          message: 'Nueva promoción "Día de la Madre" ha sido activada automáticamente',
          type: 'success',
          time: formatTimeAgo(1440),
          read: true,
          category: 'system'
        },
        {
          id: '5',
          title: 'Múltiples conexiones simultáneas',
          message: '15 usuarios conectados simultáneamente en los últimos 5 minutos',
          type: 'info',
          time: formatTimeAgo(300),
          read: true,
          category: 'portal'
        },
        {
          id: '6',
          title: 'Actualización de tema',
          message: 'Tema "Independencia" aplicado correctamente a todos los portales',
          type: 'success',
          time: formatTimeAgo(720),
          read: true,
          category: 'system'
        }
      ];
      
      setNotifications(mockNotifications);
      setUnreadCount(mockNotifications.filter(n => !n.read).length);
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const formatTimeAgo = (minutes: number): string => {
    if (minutes < 60) {
      return `${minutes} min${minutes !== 1 ? 's' : ''} ago`;
    } else if (minutes < 1440) {
      const hours = Math.floor(minutes / 60);
      return `${hours} hora${hours !== 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(minutes / 1440);
      return `${days} día${days !== 1 ? 's' : ''} ago`;
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const getTypeIcon = (type: Notification['type']) => {
    switch(type) {
      case 'success': return CheckCircle;
      case 'error': return AlertCircle;
      case 'warning': return AlertTriangle;
      default: return Info;
    }
  };

  const getCategoryIcon = (category: Notification['category']) => {
    switch(category) {
      case 'user': return Users;
      case 'backup': return Database;
      case 'portal': return Wifi;
      case 'system': return Settings;
      default: return Info;
    }
  };

  const getTypeColor = (type: Notification['type']) => {
    switch(type) {
      case 'success': return 'text-green-500';
      case 'error': return 'text-red-500';
      case 'warning': return 'text-orange-500';
      default: return 'text-blue-500';
    }
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors"
      >
        <Bell className="w-5 h-5 text-gray-600" />
        <AnimatePresence>
          {unreadCount > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium"
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </motion.span>
          )}
        </AnimatePresence>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 mt-2 w-96 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-96 overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-gray-200 bg-gray-50">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold text-gray-800 flex items-center">
                  <Bell className="w-5 h-5 mr-2" />
                  Notificaciones
                </h3>
                <div className="flex items-center space-x-2">
                  {unreadCount > 0 && (
                    <button 
                      onClick={markAllAsRead}
                      className="text-xs text-blue-600 hover:text-blue-800 font-medium transition-colors flex items-center"
                    >
                      <CheckCheck className="w-3 h-3 mr-1" />
                      Marcar todas como leídas
                    </button>
                  )}
                  <button 
                    onClick={() => setIsOpen(false)}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Lista de notificaciones */}
            <div className="max-h-64 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <Bell className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No hay notificaciones</p>
                </div>
              ) : (
                notifications.map((notification) => {
                  const TypeIcon = getTypeIcon(notification.type);
                  const CategoryIcon = getCategoryIcon(notification.category);
                  
                  return (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                        !notification.read ? 'bg-blue-50 border-l-4 border-l-blue-400' : ''
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 flex items-center space-x-1">
                          <TypeIcon className={`w-4 h-4 ${getTypeColor(notification.type)}`} />
                          <CategoryIcon className="w-3 h-3 text-gray-400" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {notification.title}
                            </p>
                            {!notification.read && (
                              <button
                                onClick={() => markAsRead(notification.id)}
                                className="ml-2 p-1 text-blue-600 hover:text-blue-800 transition-colors"
                                title="Marcar como leída"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                          <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center mt-2 text-xs text-gray-400">
                            <Clock className="w-3 h-3 mr-1" />
                            {notification.time}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-200 bg-gray-50">
              <button 
                className="w-full text-center text-sm text-blue-600 hover:text-blue-800 font-medium transition-colors"
                onClick={() => {
                  setIsOpen(false);
                  // Aquí se podría redirigir a una página completa de notificaciones
                }}
              >
                Ver todas las notificaciones
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
