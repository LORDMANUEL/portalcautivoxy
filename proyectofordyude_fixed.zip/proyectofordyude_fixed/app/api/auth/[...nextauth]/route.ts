
/**
 * API Route para NextAuth.js - Manejo de autenticación del Portal Ford Yude Canahuati
 * 
 * Este archivo configura los endpoints de autenticación de NextAuth.js.
 * Maneja todas las rutas de autenticación: /api/auth/signin, /api/auth/signout, 
 * /api/auth/callback, etc.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import NextAuth from 'next-auth';
import { authOptions } from '@/lib/auth';

/**
 * Handler principal de NextAuth que maneja todas las rutas de autenticación
 * 
 * Utiliza la configuración definida en @/lib/auth para:
 * - Procesar login/logout
 * - Manejar callbacks de autenticación
 * - Gestionar sesiones JWT
 * - Procesar proveedores de autenticación
 */
const handler = NextAuth(authOptions);

/**
 * Exportación de métodos HTTP para Next.js App Router
 * 
 * Next.js 13+ requiere exportar explícitamente cada método HTTP.
 * NextAuth necesita tanto GET como POST para funcionar correctamente.
 * 
 * @exports GET - Maneja requests GET (páginas de login, callbacks, etc.)
 * @exports POST - Maneja requests POST (envío de credenciales, logout, etc.)
 */
export { handler as GET, handler as POST };
