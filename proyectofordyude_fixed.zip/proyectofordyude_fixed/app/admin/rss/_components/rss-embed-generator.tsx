

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Code,
  Copy,
  Eye,
  Settings,
  Palette,
  Monitor,
  Smartphone,
  Tablet,
  ExternalLink
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface RssFeed {
  id: string;
  title: string;
  description?: string;
  url: string;
  isActive: boolean;
  category: string;
  itemCount: number;
}

interface EmbedConfig {
  feedId: string;
  theme: 'light' | 'dark' | 'ford';
  maxItems: number;
  showImages: boolean;
  showDates: boolean;
  showDescriptions: boolean;
  width: string;
  height: string;
  borderRadius: string;
  titleColor: string;
  backgroundColor: string;
  textColor: string;
}

interface RssEmbedGeneratorProps {
  feeds: RssFeed[];
}

const PRESET_THEMES = {
  light: {
    backgroundColor: '#ffffff',
    textColor: '#374151',
    titleColor: '#1f2937'
  },
  dark: {
    backgroundColor: '#1f2937',
    textColor: '#d1d5db',
    titleColor: '#f9fafb'
  },
  ford: {
    backgroundColor: '#003478',
    textColor: '#ffffff',
    titleColor: '#47A8E5'
  }
};

export function RssEmbedGenerator({ feeds }: RssEmbedGeneratorProps) {
  const [selectedFeed, setSelectedFeed] = useState<string>('');
  const [embedConfig, setEmbedConfig] = useState<EmbedConfig>({
    feedId: '',
    theme: 'light',
    maxItems: 5,
    showImages: true,
    showDates: true,
    showDescriptions: true,
    width: '100%',
    height: '400px',
    borderRadius: '8px',
    titleColor: '#1f2937',
    backgroundColor: '#ffffff',
    textColor: '#374151'
  });
  
  const [previewMode, setPreviewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Actualizar configuración cuando cambia el tema
  useEffect(() => {
    if (embedConfig.theme in PRESET_THEMES) {
      const theme = PRESET_THEMES[embedConfig.theme];
      setEmbedConfig(prev => ({
        ...prev,
        ...theme
      }));
    }
  }, [embedConfig.theme]);

  // Generar código iframe
  const generateIframeCode = () => {
    const baseUrl = window.location.origin;
    const queryParams = new URLSearchParams({
      theme: embedConfig.theme,
      maxItems: embedConfig.maxItems.toString(),
      showImages: embedConfig.showImages.toString(),
      showDates: embedConfig.showDates.toString(),
      showDescriptions: embedConfig.showDescriptions.toString(),
      titleColor: embedConfig.titleColor,
      backgroundColor: embedConfig.backgroundColor,
      textColor: embedConfig.textColor,
      borderRadius: embedConfig.borderRadius
    });

    return `<iframe 
  src="${baseUrl}/api/rss/${embedConfig.feedId}/embed?${queryParams}" 
  width="${embedConfig.width}" 
  height="${embedConfig.height}"
  frameborder="0"
  scrolling="auto"
  style="border-radius: ${embedConfig.borderRadius}; border: 1px solid #e5e7eb;">
</iframe>`;
  };

  // Generar link directo
  const generateDirectLink = () => {
    const baseUrl = window.location.origin;
    const queryParams = new URLSearchParams({
      theme: embedConfig.theme,
      maxItems: embedConfig.maxItems.toString(),
      showImages: embedConfig.showImages.toString(),
      showDates: embedConfig.showDates.toString(),
      showDescriptions: embedConfig.showDescriptions.toString(),
      titleColor: embedConfig.titleColor,
      backgroundColor: embedConfig.backgroundColor,
      textColor: embedConfig.textColor,
      borderRadius: embedConfig.borderRadius
    });

    return `${baseUrl}/api/rss/${embedConfig.feedId}/embed?${queryParams}`;
  };

  // Copiar al portapapeles
  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${type} copiado al portapapeles`);
    } catch (error) {
      toast.error('Error al copiar al portapapeles');
    }
  };

  const handleConfigChange = (key: keyof EmbedConfig, value: any) => {
    setEmbedConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const selectedFeedData = feeds.find(feed => feed.id === embedConfig.feedId);

  return (
    <div className="space-y-6">
      <FordCard className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-bold text-gray-800 flex items-center">
              <Code className="w-5 h-5 mr-2" />
              Generador de RSS Embebido
            </h3>
            <p className="text-gray-600">Genera códigos iframe y links para integrar RSS en otros sitios</p>
          </div>
          
          {embedConfig.feedId && (
            <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
              <DialogTrigger asChild>
                <FordButton variant="outline">
                  <Eye className="w-4 h-4 mr-2" />
                  Vista Previa
                </FordButton>
              </DialogTrigger>
              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>Vista Previa del RSS Embebido</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Controles de vista previa */}
                  <div className="flex items-center space-x-2">
                    <FordButton
                      size="sm"
                      variant={previewMode === 'desktop' ? 'primary' : 'outline'}
                      onClick={() => setPreviewMode('desktop')}
                    >
                      <Monitor className="w-4 h-4 mr-1" />
                      Desktop
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant={previewMode === 'tablet' ? 'primary' : 'outline'}
                      onClick={() => setPreviewMode('tablet')}
                    >
                      <Tablet className="w-4 h-4 mr-1" />
                      Tablet
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant={previewMode === 'mobile' ? 'primary' : 'outline'}
                      onClick={() => setPreviewMode('mobile')}
                    >
                      <Smartphone className="w-4 h-4 mr-1" />
                      Mobile
                    </FordButton>
                  </div>
                  
                  {/* Frame de vista previa */}
                  <div 
                    className={`mx-auto bg-gray-100 p-4 rounded-lg ${
                      previewMode === 'desktop' ? 'w-full max-w-4xl' : 
                      previewMode === 'tablet' ? 'w-96' : 'w-80'
                    }`}
                  >
                    <iframe
                      src={generateDirectLink()}
                      width="100%"
                      height={embedConfig.height}
                      frameBorder="0"
                      scrolling="auto"
                      className="rounded border"
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuración */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800 flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              Configuración
            </h4>
            
            {/* Selección de feed */}
            <div className="space-y-2">
              <Label>Feed RSS</Label>
              <Select 
                value={embedConfig.feedId} 
                onValueChange={(value) => handleConfigChange('feedId', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona un feed RSS" />
                </SelectTrigger>
                <SelectContent>
                  {feeds.filter(feed => feed.isActive).map(feed => (
                    <SelectItem key={feed.id} value={feed.id}>
                      <div className="flex items-center justify-between w-full">
                        <span>{feed.title}</span>
                        <Badge className="ml-2">{feed.itemCount} items</Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Configuraciones básicas */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tema</Label>
                <Select 
                  value={embedConfig.theme} 
                  onValueChange={(value: 'light' | 'dark' | 'ford') => handleConfigChange('theme', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Claro</SelectItem>
                    <SelectItem value="dark">Oscuro</SelectItem>
                    <SelectItem value="ford">Ford</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label>Máximo de Items</Label>
                <Input
                  type="number"
                  min="1"
                  max="20"
                  value={embedConfig.maxItems}
                  onChange={(e) => handleConfigChange('maxItems', parseInt(e.target.value))}
                />
              </div>
            </div>

            {/* Dimensiones */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Ancho</Label>
                <Input
                  value={embedConfig.width}
                  onChange={(e) => handleConfigChange('width', e.target.value)}
                  placeholder="100% o 400px"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Alto</Label>
                <Input
                  value={embedConfig.height}
                  onChange={(e) => handleConfigChange('height', e.target.value)}
                  placeholder="400px"
                />
              </div>
            </div>

            {/* Opciones de visualización */}
            <div className="space-y-3">
              <Label>Opciones de Visualización</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showImages"
                    checked={embedConfig.showImages}
                    onCheckedChange={(checked) => handleConfigChange('showImages', checked)}
                  />
                  <Label htmlFor="showImages">Mostrar imágenes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showDates"
                    checked={embedConfig.showDates}
                    onCheckedChange={(checked) => handleConfigChange('showDates', checked)}
                  />
                  <Label htmlFor="showDates">Mostrar fechas</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="showDescriptions"
                    checked={embedConfig.showDescriptions}
                    onCheckedChange={(checked) => handleConfigChange('showDescriptions', checked)}
                  />
                  <Label htmlFor="showDescriptions">Mostrar descripciones</Label>
                </div>
              </div>
            </div>
          </div>

          {/* Personalización */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-800 flex items-center">
              <Palette className="w-4 h-4 mr-2" />
              Personalización
            </h4>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label>Color de Fondo</Label>
                <div className="flex space-x-2">
                  <Input
                    type="color"
                    value={embedConfig.backgroundColor}
                    onChange={(e) => handleConfigChange('backgroundColor', e.target.value)}
                    className="w-12 h-10 p-1 border rounded"
                  />
                  <Input
                    value={embedConfig.backgroundColor}
                    onChange={(e) => handleConfigChange('backgroundColor', e.target.value)}
                    placeholder="#ffffff"
                    className="flex-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Color de Texto</Label>
                <div className="flex space-x-2">
                  <Input
                    type="color"
                    value={embedConfig.textColor}
                    onChange={(e) => handleConfigChange('textColor', e.target.value)}
                    className="w-12 h-10 p-1 border rounded"
                  />
                  <Input
                    value={embedConfig.textColor}
                    onChange={(e) => handleConfigChange('textColor', e.target.value)}
                    placeholder="#374151"
                    className="flex-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Color de Títulos</Label>
                <div className="flex space-x-2">
                  <Input
                    type="color"
                    value={embedConfig.titleColor}
                    onChange={(e) => handleConfigChange('titleColor', e.target.value)}
                    className="w-12 h-10 p-1 border rounded"
                  />
                  <Input
                    value={embedConfig.titleColor}
                    onChange={(e) => handleConfigChange('titleColor', e.target.value)}
                    placeholder="#1f2937"
                    className="flex-1"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Radio de Bordes</Label>
                <Input
                  value={embedConfig.borderRadius}
                  onChange={(e) => handleConfigChange('borderRadius', e.target.value)}
                  placeholder="8px"
                />
              </div>
            </div>
          </div>
        </div>
      </FordCard>

      {/* Códigos generados */}
      {embedConfig.feedId && selectedFeedData && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Código iframe */}
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-gray-800">Código iframe</h4>
              <FordButton
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(generateIframeCode(), 'Código iframe')}
              >
                <Copy className="w-4 h-4 mr-2" />
                Copiar
              </FordButton>
            </div>
            <Textarea
              value={generateIframeCode()}
              readOnly
              rows={8}
              className="font-mono text-sm"
            />
            <p className="text-xs text-gray-500 mt-2">
              Pega este código en tu sitio web donde quieras mostrar el feed RSS
            </p>
          </FordCard>

          {/* Link directo */}
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-gray-800">Link Directo</h4>
              <div className="flex space-x-2">
                <FordButton
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(generateDirectLink(), 'Link directo')}
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copiar
                </FordButton>
                <FordButton
                  size="sm"
                  variant="outline"
                  onClick={() => window.open(generateDirectLink(), '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Abrir
                </FordButton>
              </div>
            </div>
            <Textarea
              value={generateDirectLink()}
              readOnly
              rows={3}
              className="font-mono text-sm"
            />
            <p className="text-xs text-gray-500 mt-2">
              URL directa para integrar en aplicaciones o servicios externos
            </p>
            
            {/* Información del feed */}
            <div className="mt-4 p-3 bg-gray-50 rounded">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">Feed:</span>
                <span>{selectedFeedData.title}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">Items:</span>
                <span>{selectedFeedData.itemCount}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">Categoría:</span>
                <Badge variant="outline">{selectedFeedData.category}</Badge>
              </div>
            </div>
          </FordCard>
        </div>
      )}

      {!embedConfig.feedId && (
        <FordCard className="p-8 text-center">
          <Code className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">
            Selecciona un Feed RSS
          </h3>
          <p className="text-gray-500">
            Elige un feed RSS activo para generar códigos embebidos
          </p>
        </FordCard>
      )}
    </div>
  );
}
