

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET - Obtener promoción específica
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const promotion = await prisma.promotion.findUnique({
      where: { id: params.id }
    });

    if (!promotion) {
      return NextResponse.json(
        { error: 'Promoción no encontrada' },
        { status: 404 }
      );
    }

    return NextResponse.json(promotion);
  } catch (error) {
    console.error('Error al obtener promoción:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// PUT - Actualizar promoción
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const data = await request.json();
    
    // Verificar que existe la promoción
    const existingPromotion = await prisma.promotion.findUnique({
      where: { id: params.id }
    });

    if (!existingPromotion) {
      return NextResponse.json(
        { error: 'Promoción no encontrada' },
        { status: 404 }
      );
    }

    // Preparar datos para actualizar
    const updateData: any = {};
    
    if (data.title !== undefined) updateData.title = data.title.trim();
    if (data.description !== undefined) updateData.description = data.description?.trim() || null;
    if (data.imageUrl !== undefined) updateData.imageUrl = data.imageUrl?.trim() || null;
    if (data.type !== undefined) updateData.type = data.type;
    if (data.category !== undefined) updateData.category = data.category?.trim() || null;
    if (data.discount !== undefined) updateData.discount = data.discount ? parseFloat(data.discount) : null;
    if (data.price !== undefined) updateData.price = data.price ? parseFloat(data.price) : null;
    if (data.originalPrice !== undefined) updateData.originalPrice = data.originalPrice ? parseFloat(data.originalPrice) : null;
    if (data.validFrom !== undefined) updateData.validFrom = new Date(data.validFrom);
    if (data.validUntil !== undefined) updateData.validUntil = data.validUntil ? new Date(data.validUntil) : null;
    if (data.isActive !== undefined) updateData.isActive = data.isActive;
    if (data.isFeatured !== undefined) updateData.isFeatured = data.isFeatured;
    if (data.location !== undefined) updateData.location = data.location?.trim() || null;
    if (data.targetTheme !== undefined) updateData.targetTheme = data.targetTheme?.trim() || null;
    if (data.conditions !== undefined) updateData.conditions = data.conditions?.trim() || null;
    if (data.contactInfo !== undefined) updateData.contactInfo = data.contactInfo?.trim() || null;
    if (data.priority !== undefined) updateData.priority = parseInt(data.priority);

    // Actualizar promoción
    const promotion = await prisma.promotion.update({
      where: { id: params.id },
      data: updateData
    });

    return NextResponse.json(promotion);
  } catch (error) {
    console.error('Error al actualizar promoción:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// DELETE - Eliminar promoción
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Verificar que existe la promoción
    const existingPromotion = await prisma.promotion.findUnique({
      where: { id: params.id }
    });

    if (!existingPromotion) {
      return NextResponse.json(
        { error: 'Promoción no encontrada' },
        { status: 404 }
      );
    }

    // Eliminar promoción
    await prisma.promotion.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ message: 'Promoción eliminada exitosamente' });
  } catch (error) {
    console.error('Error al eliminar promoción:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
