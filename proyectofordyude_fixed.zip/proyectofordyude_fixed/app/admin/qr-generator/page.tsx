

import { Metadata } from 'next';
import { QRGeneratorClient } from './_components/qr-generator-client';

export const metadata: Metadata = {
  title: 'Generador QR/vCards - Administración Ford',
  description: 'Generar códigos QR y vCards para asesores de servicio Ford Yude Canahuati',
};

export default function QRGeneratorPage() {
  return <QRGeneratorClient />;
}
