
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  Download,
  Filter,
  Search,
  Calendar,
  MapPin,
  Smartphone,
  Monitor,
  Tablet,
  Globe,
  Clock,
  Eye,
  FileText,
  BarChart3,
  TrendingUp
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
// import { DatePickerWithRange } from '@/components/ui/date-range-picker';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { DateRange } from 'react-day-picker';

interface CaptiveUser {
  id: string;
  deviceId: string;
  ipAddress: string;
  userAgent: string;
  deviceName: string;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  email?: string;
  name?: string;
  phone?: string;
  company?: string;
  portal: string;
  theme: string;
  connectedAt: string;
  disconnectedAt?: string;
  sessionDuration?: number;
  location?: string;
  isActive: boolean;
  pagesViewed: number;
  formData?: {
    interests?: string[];
    visitReason?: string;
    contactPreference?: string;
    additionalInfo?: string;
  };
}

interface UserStats {
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  averageSession: number;
  topPortal: string;
  totalSessions: number;
  deviceBreakdown: {
    mobile: number;
    tablet: number;
    desktop: number;
  };
  popularTimes: Array<{
    hour: number;
    count: number;
  }>;
}

/**
 * Cliente para gestión de usuarios del portal cautivo
 * Reportes completos y análisis de datos de usuarios
 */
export function CaptiveUsersClient() {
  const [users, setUsers] = useState<CaptiveUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<CaptiveUser[]>([]);
  const [stats, setStats] = useState<UserStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  
  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [portalFilter, setPortalFilter] = useState('all');
  const [deviceFilter, setDeviceFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();

  useEffect(() => {
    fetchUsers();
    fetchStats();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [users, searchTerm, portalFilter, deviceFilter, statusFilter, dateRange]);

  /**
   * Obtiene usuarios del portal cautivo
   */
  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/admin/captive-users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      } else {
        toast.error('Error al cargar usuarios');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al cargar usuarios');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Obtiene estadísticas de usuarios
   */
  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/captive-users/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  /**
   * Filtra usuarios según criterios
   */
  const filterUsers = () => {
    let filtered = users;

    // Filtrar por búsqueda
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(user => 
        user.name?.toLowerCase().includes(search) ||
        user.email?.toLowerCase().includes(search) ||
        user.phone?.includes(search) ||
        user.company?.toLowerCase().includes(search) ||
        user.ipAddress.includes(search) ||
        user.deviceId.includes(search)
      );
    }

    // Filtrar por portal
    if (portalFilter !== 'all') {
      filtered = filtered.filter(user => user.portal === portalFilter);
    }

    // Filtrar por dispositivo
    if (deviceFilter !== 'all') {
      filtered = filtered.filter(user => user.deviceType === deviceFilter);
    }

    // Filtrar por estado
    if (statusFilter !== 'all') {
      if (statusFilter === 'active') {
        filtered = filtered.filter(user => user.isActive);
      } else {
        filtered = filtered.filter(user => !user.isActive);
      }
    }

    // Filtro por rango de fechas
    if (dateRange?.from && dateRange?.to) {
      filtered = filtered.filter(user => {
        const connectDate = new Date(user.connectedAt);
        return connectDate >= dateRange.from! && connectDate <= dateRange.to!;
      });
    }

    setFilteredUsers(filtered);
  };

  /**
   * Exporta datos de usuarios
   */
  const exportUsers = async (format: 'csv' | 'excel' | 'pdf') => {
    setExporting(true);
    try {
      const params = new URLSearchParams({
        format,
        search: searchTerm,
        portal: portalFilter,
        device: deviceFilter,
        status: statusFilter,
        ...(dateRange?.from && { dateFrom: dateRange.from.toISOString() }),
        ...(dateRange?.to && { dateTo: dateRange.to.toISOString() })
      });

      const response = await fetch(`/api/admin/captive-users/export?${params}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `usuarios-portal-${new Date().toISOString().split('T')[0]}.${format}`;
        a.click();
        window.URL.revokeObjectURL(url);
        
        toast.success(`Reporte ${format.toUpperCase()} descargado exitosamente`);
      } else {
        toast.error('Error al exportar datos');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al exportar datos');
    } finally {
      setExporting(false);
    }
  };

  /**
   * Obtiene icono para tipo de dispositivo
   */
  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'mobile': return Smartphone;
      case 'tablet': return Tablet;
      case 'desktop': return Monitor;
      default: return Monitor;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-ford-blue">Usuarios del Portal Cautivo</h1>
          <p className="text-gray-600 mt-2">
            Reportes y análisis de usuarios que se conectan al portal cautivo
          </p>
        </div>
        <div className="flex gap-2">
          <FordButton
            variant="outline"
            onClick={() => exportUsers('csv')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            CSV
          </FordButton>
          <FordButton
            variant="outline"
            onClick={() => exportUsers('excel')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            Excel
          </FordButton>
          <FordButton
            onClick={() => exportUsers('pdf')}
            disabled={exporting}
          >
            <FileText className="w-4 h-4 mr-2" />
            PDF
          </FordButton>
        </div>
      </div>

      {/* Estadísticas principales */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <FordCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-ford-blue" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Usuarios</p>
                <p className="text-2xl font-bold text-ford-blue">{stats.totalUsers.toLocaleString()}</p>
              </div>
            </div>
          </FordCard>

          <FordCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <Globe className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Usuarios Activos</p>
                <p className="text-2xl font-bold text-green-600">{stats.activeUsers.toLocaleString()}</p>
              </div>
            </div>
          </FordCard>

          <FordCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-orange-100 rounded-lg">
                <TrendingUp className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Nuevos Hoy</p>
                <p className="text-2xl font-bold text-orange-600">{stats.newUsersToday.toLocaleString()}</p>
              </div>
            </div>
          </FordCard>

          <FordCard className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Sesión Promedio</p>
                <p className="text-2xl font-bold text-purple-600">{stats.averageSession}min</p>
              </div>
            </div>
          </FordCard>
        </div>
      )}

      {/* Analytics Dashboard */}
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Resumen</TabsTrigger>
          <TabsTrigger value="devices">Dispositivos</TabsTrigger>
          <TabsTrigger value="portals">Portales</TabsTrigger>
          <TabsTrigger value="activity">Actividad</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Gráfico de dispositivos */}
            <FordCard className="p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Distribución por Dispositivos
              </h3>
              {stats && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Smartphone className="w-4 h-4 text-blue-500" />
                      <span>Móvil</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${(stats.deviceBreakdown.mobile / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-12 text-right">
                        {stats.deviceBreakdown.mobile}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Monitor className="w-4 h-4 text-green-500" />
                      <span>Desktop</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ width: `${(stats.deviceBreakdown.desktop / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-12 text-right">
                        {stats.deviceBreakdown.desktop}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Tablet className="w-4 h-4 text-orange-500" />
                      <span>Tablet</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-orange-500 h-2 rounded-full" 
                          style={{ width: `${(stats.deviceBreakdown.tablet / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600 w-12 text-right">
                        {stats.deviceBreakdown.tablet}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </FordCard>

            {/* Portal más popular */}
            <FordCard className="p-6">
              <h3 className="text-lg font-semibold mb-4">Portal Más Popular</h3>
              {stats && (
                <div className="text-center">
                  <div className="text-4xl font-bold text-ford-blue mb-2">
                    {stats.topPortal}
                  </div>
                  <p className="text-gray-600">
                    {Math.round((stats.totalSessions / stats.totalUsers) * 100)}% del tráfico total
                  </p>
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800">
                      Total de sesiones: {stats.totalSessions.toLocaleString()}
                    </p>
                  </div>
                </div>
              )}
            </FordCard>
          </div>
        </TabsContent>

        <TabsContent value="devices">
          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Análisis de Dispositivos</h3>
            <div className="space-y-4">
              {stats && Object.entries(stats.deviceBreakdown).map(([device, count]) => {
                const Icon = getDeviceIcon(device);
                const percentage = (count / stats.totalUsers) * 100;
                
                return (
                  <div key={device} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Icon className="w-6 h-6 text-ford-blue" />
                      <div>
                        <p className="font-medium capitalize">{device}</p>
                        <p className="text-sm text-gray-600">{count} usuarios</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{percentage.toFixed(1)}%</p>
                      <Progress value={percentage} className="w-20 h-2" />
                    </div>
                  </div>
                );
              })}
            </div>
          </FordCard>
        </TabsContent>

        <TabsContent value="portals">
          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Uso por Portal</h3>
            <p className="text-gray-600">Estadísticas de uso para cada portal cautivo configurado.</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="font-medium">Ford General</span>
                <Badge variant="default">Más Popular</Badge>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="font-medium">QuickLane Truck</span>
                <Badge variant="outline">Activo</Badge>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="font-medium">QuickLane Tegucigalpa</span>
                <Badge variant="outline">Activo</Badge>
              </div>
            </div>
          </FordCard>
        </TabsContent>

        <TabsContent value="activity">
          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Actividad Reciente</h3>
            <div className="space-y-3">
              {filteredUsers.slice(0, 10).map(user => (
                <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-ford-blue text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {user.name ? user.name.charAt(0).toUpperCase() : '?'}
                    </div>
                    <div>
                      <p className="font-medium">{user.name || 'Usuario Anónimo'}</p>
                      <p className="text-sm text-gray-600">{user.email || user.ipAddress}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      {new Date(user.connectedAt).toLocaleString()}
                    </p>
                    <Badge variant={user.isActive ? 'default' : 'secondary'}>
                      {user.isActive ? 'Activo' : 'Desconectado'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </FordCard>
        </TabsContent>
      </Tabs>

      {/* Filtros */}
      <FordCard className="p-6">
        <h3 className="text-lg font-semibold mb-4">Filtros de Búsqueda</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <Label>Buscar</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Nombre, email, IP..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div>
            <Label>Portal</Label>
            <Select value={portalFilter} onValueChange={setPortalFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los portales</SelectItem>
                <SelectItem value="ford-general">Ford General</SelectItem>
                <SelectItem value="quicklane-truck">QuickLane Truck</SelectItem>
                <SelectItem value="quicklane-tegus">QuickLane Tegus</SelectItem>
                <SelectItem value="quicklane-sps">QuickLane SPS</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Dispositivo</Label>
            <Select value={deviceFilter} onValueChange={setDeviceFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="mobile">Móvil</SelectItem>
                <SelectItem value="tablet">Tablet</SelectItem>
                <SelectItem value="desktop">Desktop</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Estado</Label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Activos</SelectItem>
                <SelectItem value="inactive">Desconectados</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mt-4">
          <Label>Rango de Fechas</Label>
          <Input
            type="date"
            className="w-full"
            placeholder="Filtro de fechas (próximamente)"
          />
        </div>
      </FordCard>

      {/* Tabla de usuarios */}
      <FordCard>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">
              Lista de Usuarios ({filteredUsers.length})
            </h3>
            <div className="flex gap-2">
              <FordButton variant="outline" size="sm">
                <Eye className="w-4 h-4 mr-2" />
                Ver Detalles
              </FordButton>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-3">Usuario</th>
                  <th className="text-left p-3">Dispositivo</th>
                  <th className="text-left p-3">Portal</th>
                  <th className="text-left p-3">Conexión</th>
                  <th className="text-left p-3">Duración</th>
                  <th className="text-left p-3">Estado</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.slice(0, 50).map(user => {
                  const DeviceIcon = getDeviceIcon(user.deviceType);
                  return (
                    <tr key={user.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{user.name || 'Anónimo'}</p>
                          <p className="text-sm text-gray-600">{user.email || user.ipAddress}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center space-x-2">
                          <DeviceIcon className="w-4 h-4 text-gray-500" />
                          <span className="capitalize">{user.deviceType}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline">{user.portal}</Badge>
                      </td>
                      <td className="p-3">
                        <div>
                          <p className="text-sm">
                            {new Date(user.connectedAt).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(user.connectedAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </td>
                      <td className="p-3">
                        {user.sessionDuration ? `${user.sessionDuration}min` : '-'}
                      </td>
                      <td className="p-3">
                        <Badge variant={user.isActive ? 'default' : 'secondary'}>
                          {user.isActive ? 'Activo' : 'Desconectado'}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No se encontraron usuarios con los filtros aplicados</p>
            </div>
          )}
        </div>
      </FordCard>
    </div>
  );
}
