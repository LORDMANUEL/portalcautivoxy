
'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { Eye, EyeOff, Lock, User, Shield } from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { toast } from 'react-hot-toast';
import Link from 'next/link';

/**
 * Componente de login para administradores del portal Ford Yude Canahuati
 * Maneja la autenticación de usuarios admin con validación y navegación segura
 * 
 * @returns JSX Element del formulario de login con interfaz Ford corporativa
 */
export function AdminLoginClient() {
  // Hook de navegación de Next.js para redirección segura
  const router = useRouter();
  
  // Estado del formulario de login
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  
  // Estado de visibilidad de contraseña
  const [showPassword, setShowPassword] = useState(false);
  
  // Estado de carga durante autenticación
  const [isLoading, setIsLoading] = useState(false);

  /**
   * Maneja el envío del formulario de login
   * Autentica al usuario usando NextAuth y redirige al dashboard
   * 
   * @param e - Evento del formulario
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Intento de autenticación con NextAuth
      const result = await signIn('credentials', {
        username: formData.username,
        password: formData.password,
        redirect: false,
      });

      if (result?.error) {
        toast.error('Credenciales inválidas');
      } else {
        toast.success('Login exitoso');
        // Redirección segura usando Next.js router
        router.push('/admin/dashboard');
      }
    } catch (error) {
      console.error('Error durante login:', error);
      toast.error('Error al iniciar sesión');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Maneja los cambios en los campos de entrada del formulario
   * Actualiza el estado del formulario de manera controlada
   * 
   * @param e - Evento de cambio del input
   */
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#003478] flex items-center justify-center">
        <LoadingSpinner size="lg" message="Autenticando..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#003478] to-[#133A7C] flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Logo Section */}
        <div className="text-center mb-8">
          <motion.div
            className="relative w-24 h-24 mx-auto mb-4"
            whileHover={{ scale: 1.05 }}
          >
            <Image
              src="https://static.vecteezy.com/system/resources/previews/019/909/675/large_2x/ford-transparent-ford-free-free-png.png"
              alt="Ford Logo"
              width={96}
              height={96}
              className="object-contain"
            />
          </motion.div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Panel de Administración
          </h1>
          <p className="text-blue-200">
            Ford Yude Canahuati - Portal Cautivo
          </p>
        </div>

        {/* Login Form */}
        <FordCard className="p-8 glass-effect">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-[#003478] rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Acceso Seguro</h2>
              <p className="text-sm text-gray-600">Administradores autorizados</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Usuario
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  required
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent transition-all"
                  placeholder="admin"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  required
                  className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent transition-all"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                  )}
                </button>
              </div>
            </div>

            <FordButton
              type="submit"
              size="lg"
              className="w-full"
              isLoading={isLoading}
            >
              <Shield className="w-5 h-5 mr-2" />
              Iniciar Sesión
            </FordButton>
          </form>

          <div className="mt-6 space-y-4">
            {/* Link de recuperación */}
            <div className="text-center">
              <Link 
                href="/admin/forgot-password"
                className="text-sm text-[#003478] hover:text-[#133A7C] font-medium hover:underline transition-colors"
              >
                ¿Olvidaste tu contraseña?
              </Link>
            </div>

            {/* Credenciales demo */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="text-center">
                <p className="text-xs font-medium text-blue-800 mb-1">Credenciales de Demo</p>
                <p className="text-xs text-blue-600">
                  Usuario: <code className="bg-blue-100 px-1 rounded font-mono">admin</code>
                </p>
                <p className="text-xs text-blue-600">
                  Contraseña: <code className="bg-blue-100 px-1 rounded font-mono">admin123</code>
                </p>
              </div>
            </div>

            <div className="text-center">
              <p className="text-xs text-gray-500">
                🔒 Portal seguro con autenticación avanzada
              </p>
            </div>
          </div>
        </FordCard>

        {/* Security Info */}
        <motion.div
          className="mt-6 text-center text-blue-200 text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <p>🔒 Conexión SSL/TLS segura</p>
          <p className="text-xs mt-1">
            Todos los datos están encriptados y protegidos
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
