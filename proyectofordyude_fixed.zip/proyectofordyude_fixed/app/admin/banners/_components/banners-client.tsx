
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import {
  Plus,
  Upload,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Calendar,
  BarChart3,
  ExternalLink,
  Save,
  X,
  AlertTriangle
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { toast } from 'react-hot-toast';

interface Banner {
  id: string;
  title: string;
  description?: string;
  imageUrl: string;
  linkUrl?: string;
  position: 'TOP' | 'MIDDLE' | 'BOTTOM' | 'SIDEBAR';
  isActive: boolean;
  displayOrder: number;
  targetTheme?: string;
  startDate?: Date;
  endDate?: Date;
  clickCount: number;
  impressions: number;
  createdAt: Date;
}

export function BannersClient() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBanners();
  }, []);

  const loadBanners = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockBanners: Banner[] = [
      {
        id: '1',
        title: 'Nueva Ford F-150 2025',
        description: 'Descubre la pickup más poderosa de América',
        imageUrl: 'https://i.ytimg.com/vi/xrrrpZhBlDc/maxresdefault.jpg',
        linkUrl: 'https://ford.com/f150',
        position: 'TOP',
        isActive: true,
        displayOrder: 1,
        clickCount: 245,
        impressions: 1890,
        createdAt: new Date()
      },
      {
        id: '2',
        title: 'Servicio Ford Verano',
        description: 'Prepara tu Ford para las aventuras de verano',
        imageUrl: 'https://automundo.com.ar/wp-content/uploads/2024/12/Verano-2025-Ford-3.jpeg',
        linkUrl: '#',
        position: 'MIDDLE',
        isActive: true,
        displayOrder: 2,
        targetTheme: 'summer',
        startDate: new Date('2024-06-01'),
        endDate: new Date('2024-09-30'),
        clickCount: 156,
        impressions: 967,
        createdAt: new Date()
      },
      {
        id: '3',
        title: 'Ford Yude Canahuati 50 Años',
        description: 'Celebramos medio siglo de excelencia en Honduras',
        imageUrl: 'https://iconosmag.com/wp-content/uploads/2024/06/portada-desfile-agas-yude-ford-honduras-2024-1.jpg',
        position: 'BOTTOM',
        isActive: false,
        displayOrder: 3,
        clickCount: 89,
        impressions: 432,
        createdAt: new Date()
      }
    ];
    
    setBanners(mockBanners);
    setLoading(false);
  };

  const handleCreateBanner = () => {
    const newBanner: Banner = {
      id: 'new',
      title: '',
      description: '',
      imageUrl: '',
      linkUrl: '',
      position: 'TOP',
      isActive: true,
      displayOrder: banners.length + 1,
      clickCount: 0,
      impressions: 0,
      createdAt: new Date()
    };
    
    setEditingBanner(newBanner);
    setIsCreating(true);
  };

  const handleEditBanner = (banner: Banner) => {
    setEditingBanner({ ...banner });
    setIsCreating(false);
  };

  const handleSaveBanner = async () => {
    if (!editingBanner) return;
    
    if (!editingBanner.title || !editingBanner.imageUrl) {
      toast.error('Título e imagen son requeridos');
      return;
    }
    
    try {
      if (isCreating) {
        const newBanner = {
          ...editingBanner,
          id: Date.now().toString(),
          createdAt: new Date()
        };
        setBanners(prev => [...prev, newBanner]);
        toast.success('Banner creado exitosamente');
      } else {
        setBanners(prev => prev.map(banner =>
          banner.id === editingBanner.id ? editingBanner : banner
        ));
        toast.success('Banner actualizado exitosamente');
      }
      
      setEditingBanner(null);
      setIsCreating(false);
    } catch (error) {
      toast.error('Error al guardar banner');
    }
  };

  const handleToggleBanner = async (bannerId: string) => {
    try {
      setBanners(prev => prev.map(banner =>
        banner.id === bannerId
          ? { ...banner, isActive: !banner.isActive }
          : banner
      ));
      
      toast.success('Estado del banner actualizado');
    } catch (error) {
      toast.error('Error al actualizar banner');
    }
  };

  const handleDeleteBanner = async (bannerId: string) => {
    if (!confirm('¿Estás seguro de eliminar este banner?')) return;
    
    try {
      setBanners(prev => prev.filter(banner => banner.id !== bannerId));
      toast.success('Banner eliminado');
    } catch (error) {
      toast.error('Error al eliminar banner');
    }
  };

  const getPositionColor = (position: string) => {
    switch (position) {
      case 'TOP': return 'bg-blue-100 text-blue-800';
      case 'MIDDLE': return 'bg-green-100 text-green-800';
      case 'BOTTOM': return 'bg-orange-100 text-orange-800';
      case 'SIDEBAR': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCTR = (clicks: number, impressions: number) => {
    if (impressions === 0) return '0.0%';
    return ((clicks / impressions) * 100).toFixed(1) + '%';
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
          <div className="h-10 bg-gray-300 rounded w-32 animate-pulse" />
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-64 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Banners</h1>
          <p className="text-gray-600">
            {banners.length} banners • {banners.filter(b => b.isActive).length} activos
          </p>
        </div>
        <FordButton onClick={handleCreateBanner}>
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Banner
        </FordButton>
      </div>

      {/* Banners Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banners.map((banner, index) => (
          <motion.div
            key={banner.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <FordCard className="overflow-hidden" hover>
              {/* Banner Image */}
              <div className="relative h-48">
                <Image
                  src={banner.imageUrl}
                  alt={banner.title}
                  fill
                  className="object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getPositionColor(banner.position)}`}>
                    {banner.position}
                  </span>
                </div>
                <div className="absolute top-3 right-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    banner.isActive
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {banner.isActive ? 'Activo' : 'Inactivo'}
                  </span>
                </div>
                
                {!banner.isActive && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                    <EyeOff className="w-8 h-8 text-white" />
                  </div>
                )}
              </div>

              {/* Banner Info */}
              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-bold text-gray-800 line-clamp-1">{banner.title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {banner.description || 'Sin descripción'}
                  </p>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-3 text-center bg-gray-50 rounded-lg p-3">
                  <div>
                    <div className="text-lg font-bold text-[#003478]">{banner.clickCount}</div>
                    <div className="text-xs text-gray-600">Clicks</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-green-600">{banner.impressions}</div>
                    <div className="text-xs text-gray-600">Impresiones</div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>CTR: {getCTR(banner.clickCount, banner.impressions)}</span>
                  {banner.targetTheme && (
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                      {banner.targetTheme}
                    </span>
                  )}
                </div>

                {/* Schedule Info */}
                {banner.startDate && banner.endDate && (
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <Calendar className="w-3 h-3" />
                    <span>
                      {banner.startDate.toLocaleDateString()} - {banner.endDate.toLocaleDateString()}
                    </span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex space-x-1">
                    <FordButton 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleEditBanner(banner)}
                    >
                      <Edit className="w-4 h-4" />
                    </FordButton>
                    
                    {banner.linkUrl && (
                      <FordButton variant="ghost" size="sm">
                        <ExternalLink className="w-4 h-4" />
                      </FordButton>
                    )}
                    
                    <FordButton 
                      variant="ghost" 
                      size="sm"
                      onClick={() => handleDeleteBanner(banner.id)}
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </FordButton>
                  </div>
                  
                  <FordButton
                    variant={banner.isActive ? "outline" : "primary"}
                    size="sm"
                    onClick={() => handleToggleBanner(banner.id)}
                  >
                    {banner.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </FordButton>
                </div>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {banners.length === 0 && (
        <FordCard className="p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            No hay banners configurados
          </h3>
          <p className="text-gray-600 mb-4">
            Crea tu primer banner promocional para mostrar en el portal.
          </p>
          <FordButton onClick={handleCreateBanner}>
            <Plus className="w-4 h-4 mr-2" />
            Crear Banner
          </FordButton>
        </FordCard>
      )}

      {/* Edit/Create Banner Modal */}
      {editingBanner && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">
                  {isCreating ? 'Crear Nuevo Banner' : `Editar Banner: ${editingBanner.title}`}
                </h2>
                <button
                  onClick={() => {
                    setEditingBanner(null);
                    setIsCreating(false);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Título *
                  </label>
                  <input
                    type="text"
                    value={editingBanner.title}
                    onChange={(e) => setEditingBanner(prev => 
                      prev ? {...prev, title: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="Título del banner"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descripción
                  </label>
                  <textarea
                    value={editingBanner.description || ''}
                    onChange={(e) => setEditingBanner(prev => 
                      prev ? {...prev, description: e.target.value} : null
                    )}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="Descripción del banner (opcional)"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL de Imagen *
                  </label>
                  <input
                    type="url"
                    value={editingBanner.imageUrl}
                    onChange={(e) => setEditingBanner(prev => 
                      prev ? {...prev, imageUrl: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="https://..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL de Enlace
                  </label>
                  <input
                    type="url"
                    value={editingBanner.linkUrl || ''}
                    onChange={(e) => setEditingBanner(prev => 
                      prev ? {...prev, linkUrl: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="https://... (opcional)"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Posición
                    </label>
                    <select
                      value={editingBanner.position}
                      onChange={(e) => setEditingBanner(prev => 
                        prev ? {...prev, position: e.target.value as any} : null
                      )}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    >
                      <option value="TOP">Superior</option>
                      <option value="MIDDLE">Medio</option>
                      <option value="BOTTOM">Inferior</option>
                      <option value="SIDEBAR">Sidebar</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tema Específico
                    </label>
                    <select
                      value={editingBanner.targetTheme || ''}
                      onChange={(e) => setEditingBanner(prev => 
                        prev ? {...prev, targetTheme: e.target.value || undefined} : null
                      )}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    >
                      <option value="">Todos los temas</option>
                      <option value="default">Default</option>
                      <option value="summer">Verano</option>
                      <option value="mother">Día de la Madre</option>
                      <option value="independence">Independencia</option>
                      <option value="xmas">Navidad</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={editingBanner.isActive}
                    onChange={(e) => setEditingBanner(prev => 
                      prev ? {...prev, isActive: e.target.checked} : null
                    )}
                    className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                  />
                  <label htmlFor="isActive" className="text-sm text-gray-700">
                    Banner activo
                  </label>
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6 pt-6 border-t">
                <FordButton
                  variant="outline"
                  onClick={() => {
                    setEditingBanner(null);
                    setIsCreating(false);
                  }}
                >
                  Cancelar
                </FordButton>
                <FordButton onClick={handleSaveBanner}>
                  <Save className="w-4 h-4 mr-2" />
                  {isCreating ? 'Crear Banner' : 'Guardar Cambios'}
                </FordButton>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
