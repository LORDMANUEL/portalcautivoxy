
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  MapPin,
  Users,
  BarChart3,
  Download,
  Filter,
  Calendar,
  TrendingUp,
  Building,
  ArrowLeft
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { toast } from 'sonner';
import Link from 'next/link';
import { DateRange } from 'react-day-picker';

// Importar gráficos dinámicamente
import dynamic from 'next/dynamic';
const LocationBarChart = dynamic(() => import('../../_components/enhanced-charts').then(mod => ({ default: mod.LocationBarChart })), {
  ssr: false,
  loading: () => <div className="h-64 flex items-center justify-center"><LoadingSpinner /></div>
});

interface CityData {
  city: string;
  totalUsers: number;
  activeUsers: number;
  avgSessionTime: number;
  topLocation: string;
  connectionTrend: number;
  demographics: {
    mobile: number;
    desktop: number;
    tablet: number;
  };
}

/**
 * Reporte de usuarios por ciudad
 * Análisis detallado de conexiones por ubicación geográfica
 */
export function ByCityClient() {
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [cityData, setCityData] = useState<CityData[]>([]);
  const [selectedCity, setSelectedCity] = useState('ALL_CITIES');
  const [dateRange, setDateRange] = useState<DateRange>({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    to: new Date()
  });

  useEffect(() => {
    fetchCityData();
  }, [selectedCity, dateRange]);

  const fetchCityData = async () => {
    setLoading(true);
    try {
      // Simular API call - en producción sería una llamada real
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockData: CityData[] = [
        {
          city: 'San Pedro Sula',
          totalUsers: 2450,
          activeUsers: 380,
          avgSessionTime: 28,
          topLocation: 'Showroom SPS',
          connectionTrend: 12.5,
          demographics: { mobile: 65, desktop: 25, tablet: 10 }
        },
        {
          city: 'Tegucigalpa',
          totalUsers: 1890,
          activeUsers: 290,
          avgSessionTime: 32,
          topLocation: 'Showroom Tegus',
          connectionTrend: 8.3,
          demographics: { mobile: 58, desktop: 32, tablet: 10 }
        },
        {
          city: 'La Ceiba',
          totalUsers: 850,
          activeUsers: 125,
          avgSessionTime: 25,
          topLocation: 'Servicio La Ceiba',
          connectionTrend: -2.1,
          demographics: { mobile: 72, desktop: 20, tablet: 8 }
        },
        {
          city: 'Choluteca',
          totalUsers: 420,
          activeUsers: 65,
          avgSessionTime: 22,
          topLocation: 'QuickLane Choluteca',
          connectionTrend: 15.7,
          demographics: { mobile: 78, desktop: 15, tablet: 7 }
        }
      ];

      setCityData(mockData);
    } catch (error) {
      toast.error('Error al cargar datos por ciudad');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format: 'pdf' | 'excel' | 'csv') => {
    setExporting(true);
    try {
      const response = await fetch('/api/admin/reports/by-city/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ format, cityData, filters: { selectedCity, dateRange } })
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `reporte-ciudades-${new Date().toISOString().split('T')[0]}.${format === 'excel' ? 'xlsx' : format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success(`Reporte ${format.toUpperCase()} descargado correctamente`);
      } else {
        throw new Error('Error en exportación');
      }
    } catch (error) {
      toast.error(`Error al exportar ${format.toUpperCase()}`);
    } finally {
      setExporting(false);
    }
  };

  const chartData = cityData.map(city => ({
    name: city.city,
    connections: city.totalUsers,
    active: city.activeUsers
  }));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando reporte por ciudad..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/admin/reports">
            <FordButton variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a Reportes
            </FordButton>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <MapPin className="w-8 h-8 text-[#003478]" />
              Reporte por Ciudad
            </h1>
            <p className="text-gray-600 mt-1">
              Análisis detallado de usuarios por ubicación geográfica
            </p>
          </div>
        </div>

        <div className="flex space-x-2">
          <FordButton
            variant="outline"
            onClick={() => handleExport('pdf')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            PDF
          </FordButton>
          <FordButton
            variant="outline"
            onClick={() => handleExport('excel')}
            disabled={exporting}
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            Excel
          </FordButton>
          <FordButton
            variant="outline"
            onClick={() => handleExport('csv')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            CSV
          </FordButton>
        </div>
      </div>

      {/* Filtros */}
      <FordCard className="p-6">
        <div className="flex items-center space-x-4 mb-4">
          <Filter className="w-5 h-5 text-[#003478]" />
          <h3 className="text-lg font-semibold text-gray-800">Filtros</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Ciudad</label>
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL_CITIES">Todas las ciudades</SelectItem>
                <SelectItem value="sps">San Pedro Sula</SelectItem>
                <SelectItem value="tegus">Tegucigalpa</SelectItem>
                <SelectItem value="ceiba">La Ceiba</SelectItem>
                <SelectItem value="choluteca">Choluteca</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Rango de Fechas</label>
            <DateRangePicker
              value={dateRange}
              onChange={setDateRange}
            />
          </div>
        </div>
      </FordCard>

      {/* Métricas por ciudad */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cityData.map((city, index) => (
          <motion.div
            key={city.city}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <FordCard className="p-6 hover:shadow-lg transition-all duration-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-800">{city.city}</h3>
                <Building className="w-6 h-6 text-[#003478]" />
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Total Usuarios</span>
                  <span className="font-bold text-gray-800">{city.totalUsers.toLocaleString()}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Activos</span>
                  <span className="font-bold text-blue-600">{city.activeUsers}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Sesión Promedio</span>
                  <span className="font-bold text-gray-800">{city.avgSessionTime} min</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tendencia</span>
                  <div className={`flex items-center ${city.connectionTrend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    <TrendingUp className={`w-3 h-3 mr-1 ${city.connectionTrend < 0 ? 'rotate-180' : ''}`} />
                    <span className="text-sm font-medium">{Math.abs(city.connectionTrend)}%</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-gray-200">
                  <span className="text-xs text-gray-500">Top: {city.topLocation}</span>
                </div>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {/* Gráfico de barras */}
      <FordCard className="p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Comparativo de Conexiones por Ciudad
        </h3>
        <div className="h-64">
          <LocationBarChart
            data={chartData}
            title=""
            description=""
          />
        </div>
      </FordCard>

      {/* Tabla detallada */}
      <FordCard className="p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Detalle por Ciudad
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Ciudad</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Total Usuarios</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Activos</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Sesión Prom.</th>
                <th className="text-center py-3 px-4 font-medium text-gray-700">Móvil %</th>
                <th className="text-center py-3 px-4 font-medium text-gray-700">Desktop %</th>
                <th className="text-right py-3 px-4 font-medium text-gray-700">Tendencia</th>
              </tr>
            </thead>
            <tbody>
              {cityData.map((city, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-800">{city.city}</td>
                  <td className="py-3 px-4 text-right">{city.totalUsers.toLocaleString()}</td>
                  <td className="py-3 px-4 text-right text-blue-600">{city.activeUsers}</td>
                  <td className="py-3 px-4 text-right">{city.avgSessionTime} min</td>
                  <td className="py-3 px-4 text-center">{city.demographics.mobile}%</td>
                  <td className="py-3 px-4 text-center">{city.demographics.desktop}%</td>
                  <td className={`py-3 px-4 text-right font-medium ${city.connectionTrend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {city.connectionTrend > 0 ? '+' : ''}{city.connectionTrend}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </FordCard>
    </div>
  );
}
