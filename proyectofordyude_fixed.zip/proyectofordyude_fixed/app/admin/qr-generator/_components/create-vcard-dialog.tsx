
/**
 * Diálogo para Crear vCard
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

'use client'

import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { QrCode, User, Mail, Phone, Building, MapPin, Globe } from 'lucide-react'

const createVCardSchema = z.object({
  advisorName: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  position: z.string().optional(),
  email: z.string().email('Email inválido'),
  phone: z.string().optional(),
  company: z.string().default('Ford Yude Canahuati'),
  address: z.string().optional(),
  website: z.string().url('URL inválida').optional().or(z.literal('')),
  photo: z.string().optional()
})

type CreateVCardForm = z.infer<typeof createVCardSchema>

interface CreateVCardDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: () => void
}

export default function CreateVCardDialog({
  open,
  onOpenChange,
  onSuccess
}: CreateVCardDialogProps) {
  const [loading, setLoading] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch
  } = useForm<CreateVCardForm>({
    resolver: zodResolver(createVCardSchema),
    defaultValues: {
      company: 'Ford Yude Canahuati'
    }
  })

  const handleClose = () => {
    reset({
      company: 'Ford Yude Canahuati'
    })
    onOpenChange(false)
  }

  const onSubmit = async (data: CreateVCardForm) => {
    try {
      setLoading(true)

      const response = await fetch('/api/admin/qr-generator', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...data,
          website: data.website || undefined
        })
      })

      const result = await response.json()

      if (result.success) {
        toast.success('vCard y código QR creados exitosamente')
        onSuccess()
        handleClose()
      } else {
        toast.error(result.message || 'Error al crear vCard')
      }
    } catch (error) {
      console.error('Error creating vCard:', error)
      toast.error('Error al crear vCard')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Crear Nueva vCard
          </DialogTitle>
          <DialogDescription>
            Crea una nueva vCard para un asesor y genera automáticamente su código QR.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Información Personal */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <User className="h-5 w-5" />
              Información Personal
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Nombre */}
              <div className="space-y-2">
                <Label htmlFor="advisorName">Nombre Completo *</Label>
                <Input
                  id="advisorName"
                  {...register('advisorName')}
                  placeholder="Ej: Juan Carlos Mendoza"
                  disabled={loading}
                />
                {errors.advisorName && (
                  <p className="text-sm text-red-600">{errors.advisorName.message}</p>
                )}
              </div>

              {/* Posición */}
              <div className="space-y-2">
                <Label htmlFor="position">Posición/Cargo</Label>
                <Input
                  id="position"
                  {...register('position')}
                  placeholder="Ej: Asesor de Ventas Senior"
                  disabled={loading}
                />
                {errors.position && (
                  <p className="text-sm text-red-600">{errors.position.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Información de Contacto */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Información de Contacto
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  placeholder="juan.mendoza@ford.com.hn"
                  disabled={loading}
                />
                {errors.email && (
                  <p className="text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              {/* Teléfono */}
              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  id="phone"
                  {...register('phone')}
                  placeholder="+504 9999-1234"
                  disabled={loading}
                />
                {errors.phone && (
                  <p className="text-sm text-red-600">{errors.phone.message}</p>
                )}
              </div>
            </div>

            {/* Website */}
            <div className="space-y-2">
              <Label htmlFor="website">Sitio Web</Label>
              <Input
                id="website"
                {...register('website')}
                placeholder="https://ford.com.hn"
                disabled={loading}
              />
              {errors.website && (
                <p className="text-sm text-red-600">{errors.website.message}</p>
              )}
            </div>
          </div>

          {/* Información de la Empresa */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Building className="h-5 w-5" />
              Información de la Empresa
            </h3>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Empresa */}
              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  {...register('company')}
                  placeholder="Ford Yude Canahuati"
                  disabled={loading}
                />
                {errors.company && (
                  <p className="text-sm text-red-600">{errors.company.message}</p>
                )}
              </div>

              {/* Dirección */}
              <div className="space-y-2">
                <Label htmlFor="address">Dirección</Label>
                <Textarea
                  id="address"
                  {...register('address')}
                  placeholder="Blvd. Suyapa, Tegucigalpa, Honduras"
                  disabled={loading}
                  rows={2}
                />
                {errors.address && (
                  <p className="text-sm text-red-600">{errors.address.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Vista Previa */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium mb-3">Vista Previa de la vCard:</h4>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-gray-400" />
                <span>{watch('advisorName') || 'Nombre del asesor'}</span>
                {watch('position') && (
                  <span className="text-gray-500">- {watch('position')}</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-gray-400" />
                <span>{watch('email') || 'email@ejemplo.com'}</span>
              </div>
              {watch('phone') && (
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <span>{watch('phone')}</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-gray-400" />
                <span>{watch('company') || 'Ford Yude Canahuati'}</span>
              </div>
              {watch('address') && (
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-gray-400" />
                  <span>{watch('address')}</span>
                </div>
              )}
              {watch('website') && (
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-gray-400" />
                  <span>{watch('website')}</span>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-[#003478] hover:bg-[#002856]"
            >
              {loading ? 'Creando...' : 'Crear vCard y QR'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
