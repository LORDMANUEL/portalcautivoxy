

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  QrCode,
  Download,
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  Globe,
  Plus,
  Edit,
  Trash2,
  Eye,
  Search,
  Copy,
  ExternalLink
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import Image from 'next/image';

interface VCard {
  id: string;
  advisorName: string;
  position: string;
  email: string;
  phone: string;
  company: string;
  address: string;
  website: string;
  photo: string;
  qrCode: string;
  isActive: boolean;
  downloadCount: number;
  createdAt: string;
  updatedAt: string;
}

interface VCardFormData {
  advisorName: string;
  position: string;
  email: string;
  phone: string;
  company: string;
  address: string;
  website: string;
  photo: string;
}

/**
 * Cliente para generar códigos QR y vCards de asesores de servicio
 * Permite crear, editar y gestionar vCards con códigos QR
 */
export function QRGeneratorClient() {
  const [vcards, setVcards] = useState<VCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVCard, setEditingVCard] = useState<VCard | null>(null);
  const [generating, setGenerating] = useState(false);
  const [isQRModalOpen, setIsQRModalOpen] = useState(false);
  const [selectedQR, setSelectedQR] = useState<VCard | null>(null);

  // Formulario de datos de vCard
  const [formData, setFormData] = useState<VCardFormData>({
    advisorName: '',
    position: '',
    email: '',
    phone: '',
    company: 'Ford Yude Canahuati',
    address: 'San Pedro Sula, Honduras',
    website: 'https://www.yudecanahuati.com',
    photo: ''
  });

  useEffect(() => {
    fetchVCards();
  }, []);

  /**
   * Obtiene todas las vCards existentes
   */
  const fetchVCards = async () => {
    try {
      const response = await fetch('/api/admin/vcards');
      if (response.ok) {
        const data = await response.json();
        setVcards(data);
      } else {
        toast.error('Error al cargar las vCards');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Maneja los cambios en el formulario
   */
  const handleInputChange = (field: keyof VCardFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  /**
   * Genera o actualiza una vCard con su código QR
   */
  const handleSaveVCard = async () => {
    if (!formData.advisorName || !formData.email) {
      toast.error('Nombre y email son obligatorios');
      return;
    }

    setGenerating(true);
    try {
      const url = editingVCard ? `/api/admin/vcards/${editingVCard.id}` : '/api/admin/vcards';
      const method = editingVCard ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.success(editingVCard ? 'vCard actualizada correctamente' : 'vCard creada correctamente');
        setIsModalOpen(false);
        setEditingVCard(null);
        resetForm();
        fetchVCards();
      } else {
        toast.error('Error al guardar la vCard');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setGenerating(false);
    }
  };

  /**
   * Abre el modal para editar una vCard existente
   */
  const handleEditVCard = (vcard: VCard) => {
    setEditingVCard(vcard);
    setFormData({
      advisorName: vcard.advisorName,
      position: vcard.position || '',
      email: vcard.email,
      phone: vcard.phone || '',
      company: vcard.company,
      address: vcard.address || '',
      website: vcard.website || '',
      photo: vcard.photo || ''
    });
    setIsModalOpen(true);
  };

  /**
   * Elimina una vCard
   */
  const handleDeleteVCard = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar esta vCard?')) return;

    try {
      const response = await fetch(`/api/admin/vcards/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('vCard eliminada correctamente');
        fetchVCards();
      } else {
        toast.error('Error al eliminar la vCard');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Muestra el código QR para copiar/descargar
   */
  const handleShowQR = (vcard: VCard) => {
    setSelectedQR(vcard);
    setIsQRModalOpen(true);
  };

  /**
   * Descarga el código QR
   */
  const handleDownloadQR = async (vcard: VCard) => {
    try {
      const response = await fetch(`/api/admin/vcards/${vcard.id}/download`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `qr-${vcard.advisorName.replace(/\s+/g, '-').toLowerCase()}.png`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        
        // Incrementar contador de descargas
        fetchVCards();
      } else {
        toast.error('Error al descargar el QR');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Copia la URL del código QR al portapapeles
   */
  const handleCopyQRUrl = async (vcard: VCard) => {
    try {
      await navigator.clipboard.writeText(vcard.qrCode || '');
      toast.success('URL del QR copiada al portapapeles');
    } catch (error) {
      toast.error('Error al copiar URL');
    }
  };

  /**
   * Resetea el formulario
   */
  const resetForm = () => {
    setFormData({
      advisorName: '',
      position: '',
      email: '',
      phone: '',
      company: 'Ford Yude Canahuati',
      address: 'San Pedro Sula, Honduras',
      website: 'https://www.yudecanahuati.com',
      photo: ''
    });
  };

  // Filtrar vCards por término de búsqueda
  const filteredVCards = vcards.filter(vcard =>
    vcard.advisorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vcard.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vcard.position?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando generador QR..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con título y acciones */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <QrCode className="w-8 h-8 text-[#003478]" />
            Generador QR/vCards
          </h1>
          <p className="text-gray-600 mt-1">
            Genera códigos QR y vCards para asesores de servicio
          </p>
        </div>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <FordButton 
              onClick={() => {
                setEditingVCard(null);
                resetForm();
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nueva vCard
            </FordButton>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingVCard ? 'Editar vCard' : 'Nueva vCard'}
              </DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="advisorName">Nombre del Asesor *</Label>
                <Input
                  id="advisorName"
                  value={formData.advisorName}
                  onChange={(e) => handleInputChange('advisorName', e.target.value)}
                  placeholder="Juan Pérez"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="position">Posición</Label>
                <Input
                  id="position"
                  value={formData.position}
                  onChange={(e) => handleInputChange('position', e.target.value)}
                  placeholder="Asesor de Servicio"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="juan.perez@yudecanahuati.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="+504 2222-2222"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  value={formData.company}
                  onChange={(e) => handleInputChange('company', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Sitio Web</Label>
                <Input
                  id="website"
                  value={formData.website}
                  onChange={(e) => handleInputChange('website', e.target.value)}
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="address">Dirección</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  rows={2}
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="photo">URL de Foto</Label>
                <Input
                  id="photo"
                  value={formData.photo}
                  onChange={(e) => handleInputChange('photo', e.target.value)}
                  placeholder="https://i.pinimg.com/originals/18/2f/88/182f8808370d31f470ea4b59c7afeafb.jpg"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <FordButton
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingVCard(null);
                  resetForm();
                }}
              >
                Cancelar
              </FordButton>
              <FordButton onClick={handleSaveVCard} disabled={generating}>
                {generating ? (
                  <LoadingSpinner size="sm" message="Generando..." />
                ) : (
                  <>
                    <QrCode className="w-4 h-4 mr-2" />
                    {editingVCard ? 'Actualizar' : 'Generar vCard'}
                  </>
                )}
              </FordButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Buscador */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Buscar vCards..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Lista de vCards */}
      {filteredVCards.length === 0 ? (
        <FordCard className="text-center py-12">
          <QrCode className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            {searchTerm ? 'No se encontraron vCards' : 'No hay vCards creadas'}
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm
              ? 'Intenta con otros términos de búsqueda'
              : 'Crea tu primera vCard para comenzar'
            }
          </p>
        </FordCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVCards.map((vcard) => (
            <motion.div
              key={vcard.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="group"
            >
              <FordCard className="h-full hover:shadow-lg transition-all duration-200">
                <div className="p-6">
                  {/* Header con foto y info básica */}
                  <div className="flex items-start space-x-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-[#003478] flex items-center justify-center text-white font-bold text-lg">
                      {vcard.photo ? (
                        <Image
                          src={vcard.photo}
                          alt={vcard.advisorName}
                          width={48}
                          height={48}
                          className="rounded-full object-cover"
                        />
                      ) : (
                        vcard.advisorName.charAt(0)
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 truncate">
                        {vcard.advisorName}
                      </h3>
                      <p className="text-sm text-gray-600 truncate">
                        {vcard.position || 'Asesor de Servicio'}
                      </p>
                      <p className="text-xs text-gray-500 truncate">
                        {vcard.email}
                      </p>
                    </div>
                  </div>

                  {/* Información de contacto */}
                  <div className="space-y-2 mb-4">
                    {vcard.phone && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="w-4 h-4 mr-2" />
                        <span className="truncate">{vcard.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center text-sm text-gray-600">
                      <Building className="w-4 h-4 mr-2" />
                      <span className="truncate">{vcard.company}</span>
                    </div>
                    {vcard.address && (
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="w-4 h-4 mr-2" />
                        <span className="truncate">{vcard.address}</span>
                      </div>
                    )}
                  </div>

                  {/* Estadísticas */}
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                    <span>{vcard.downloadCount} descargas</span>
                    <span className={`px-2 py-1 rounded-full ${
                      vcard.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {vcard.isActive ? 'Activa' : 'Inactiva'}
                    </span>
                  </div>

                  {/* Acciones */}
                  <div className="flex space-x-2">
                    <FordButton
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => handleShowQR(vcard)}
                    >
                      <QrCode className="w-4 h-4 mr-1" />
                      Ver QR
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditVCard(vcard)}
                    >
                      <Edit className="w-4 h-4" />
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteVCard(vcard.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </FordButton>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          ))}
        </div>
      )}

      {/* Modal para mostrar código QR */}
      <Dialog open={isQRModalOpen} onOpenChange={setIsQRModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-[#003478]" />
              Código QR - {selectedQR?.advisorName}
            </DialogTitle>
          </DialogHeader>

          {selectedQR && (
            <div className="space-y-4 py-4">
              {/* Imagen del QR */}
              <div className="flex justify-center">
                <div className="p-4 bg-white border-2 border-gray-200 rounded-lg">
                  {selectedQR.qrCode ? (
                    <Image
                      src={selectedQR.qrCode}
                      alt={`QR Code - ${selectedQR.advisorName}`}
                      width={200}
                      height={200}
                      className="rounded"
                    />
                  ) : (
                    <div className="w-48 h-48 bg-gray-200 flex items-center justify-center rounded">
                      <QrCode className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                </div>
              </div>

              {/* Información del contacto */}
              <div className="text-center space-y-2">
                <h3 className="font-semibold text-gray-800">{selectedQR.advisorName}</h3>
                <p className="text-sm text-gray-600">{selectedQR.position}</p>
                <p className="text-sm text-gray-500">{selectedQR.email}</p>
              </div>

              {/* URL del QR para copiar */}
              {selectedQR.qrCode && (
                <div className="space-y-2">
                  <Label>URL del Código QR:</Label>
                  <div className="flex space-x-2">
                    <Input
                      value={selectedQR.qrCode}
                      readOnly
                      className="text-xs"
                    />
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleCopyQRUrl(selectedQR)}
                    >
                      <Copy className="w-4 h-4" />
                    </FordButton>
                  </div>
                </div>
              )}

              {/* Acciones */}
              <div className="flex space-x-2">
                <FordButton
                  className="flex-1"
                  variant="outline"
                  onClick={() => handleDownloadQR(selectedQR)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Descargar PNG
                </FordButton>
                {selectedQR.qrCode && (
                  <FordButton
                    className="flex-1"
                    onClick={() => window.open(selectedQR.qrCode, '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Abrir QR
                  </FordButton>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
