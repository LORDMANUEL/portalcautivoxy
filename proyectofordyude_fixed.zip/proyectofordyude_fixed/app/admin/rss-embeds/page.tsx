

import { Metadata } from 'next';
import { RssEmbedsClient } from './_components/rss-embeds-client';

export const metadata: Metadata = {
  title: 'RSS Embebidos - Ford Admin',
  description: 'Generador de códigos iframe y links embebidos para RSS feeds',
};

export default function RssEmbedsPage() {
  return <RssEmbedsClient />;
}
