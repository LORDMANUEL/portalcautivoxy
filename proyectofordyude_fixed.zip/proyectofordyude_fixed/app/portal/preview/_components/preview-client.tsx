
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { 
  Wifi, 
  Car, 
  Wrench, 
  Clock, 
  MapPin, 
  Phone, 
  Mail,
  Globe,
  Zap,
  Building,
  ArrowLeft,
  Palette,
  Eye
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { fordAssets } from '@/lib/ford-assets';

interface PreviewClientProps {
  searchParams: {
    theme?: string;
    colors?: string;
  };
}

interface ThemeColors {
  primary: string;
  secondary: string;
  accent: string;
}

/**
 * Vista previa de temas en tiempo real
 * Muestra cómo se vería el portal con el tema aplicado
 */
export function PreviewClient({ searchParams }: PreviewClientProps) {
  const [themeColors, setThemeColors] = useState<ThemeColors>({
    primary: '#003478',
    secondary: '#FFFFFF',
    accent: '#47A8E5'
  });

  const [isPreviewMode, setIsPreviewMode] = useState(true);

  useEffect(() => {
    // Parsear colores desde URL
    if (searchParams.colors) {
      try {
        const colors = JSON.parse(decodeURIComponent(searchParams.colors));
        setThemeColors(colors);
      } catch (error) {
        console.error('Error parsing colors:', error);
      }
    }
  }, [searchParams.colors]);

  return (
    <div 
      className="min-h-screen"
      style={{ 
        background: `linear-gradient(135deg, ${themeColors.primary}15, ${themeColors.secondary}15)`,
      }}
    >
      {/* Banner de Vista Previa */}
      <div 
        className="bg-black bg-opacity-90 text-white px-4 py-2 text-center sticky top-0 z-50"
      >
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center space-x-2">
            <Eye className="w-4 h-4" />
            <span className="text-sm font-medium">Vista Previa de Tema</span>
            {searchParams.theme && (
              <span className="text-xs text-gray-300">- {searchParams.theme}</span>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-xs">
              <Palette className="w-3 h-3" />
              <div 
                className="w-3 h-3 rounded-full border border-white"
                style={{ backgroundColor: themeColors.primary }}
              />
              <div 
                className="w-3 h-3 rounded-full border border-white"
                style={{ backgroundColor: themeColors.accent }}
              />
            </div>
            <button
              onClick={() => window.close()}
              className="text-xs hover:text-red-300"
            >
              Cerrar Preview
            </button>
          </div>
        </div>
      </div>

      {/* Contenido del Portal */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Logo y bienvenida principal */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center mb-6">
            <Image
              src={fordAssets.logos.official_transparent[0].url}
              alt="Ford Logo"
              width={120}
              height={120}
              className="object-contain filter drop-shadow-lg"
            />
          </div>
          
          <h1 
            className="text-4xl font-bold mb-2" 
            style={{ color: themeColors.primary }}
          >
            Portal Ford Preview
          </h1>
          <p className="text-xl text-gray-600 mb-4">
            Vista previa del tema personalizado
          </p>
          <div className="flex items-center justify-center space-x-2 text-gray-600">
            <Wifi className="w-5 h-5" />
            <span>WiFi Gratuito Disponible</span>
          </div>
        </motion.div>

        {/* Grid principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulario de conexión */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <FordCard className="p-8">
                <div className="flex items-center mb-6">
                  <Car 
                    className="w-8 h-8 mr-3" 
                    style={{ color: themeColors.primary }} 
                  />
                  <h2 className="text-2xl font-bold text-gray-800">
                    Conectarse a WiFi
                  </h2>
                </div>

                <p className="text-gray-600 mb-6">
                  Complete el formulario para acceder a internet gratuito en nuestro showroom Ford.
                </p>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="preview-name">Nombre Completo *</Label>
                      <Input
                        id="preview-name"
                        placeholder="Tu nombre completo"
                        className="focus:border-opacity-50"
                        style={{ 
                          '--tw-ring-color': themeColors.primary,
                          borderColor: `${themeColors.primary}30`
                        } as any}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="preview-email">Email *</Label>
                      <Input
                        id="preview-email"
                        type="email"
                        placeholder="tu@email.com"
                        className="focus:border-opacity-50"
                        style={{ 
                          '--tw-ring-color': themeColors.primary,
                          borderColor: `${themeColors.primary}30`
                        } as any}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="preview-phone">Teléfono</Label>
                    <Input
                      id="preview-phone"
                      placeholder="+504 0000-0000"
                      className="focus:border-opacity-50"
                      style={{ 
                        '--tw-ring-color': themeColors.primary,
                        borderColor: `${themeColors.primary}30`
                      } as any}
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox id="preview-terms" />
                    <Label htmlFor="preview-terms" className="text-sm">
                      Acepto los términos y condiciones de uso
                    </Label>
                  </div>

                  <FordButton 
                    className="w-full mt-6"
                    style={{ 
                      backgroundColor: themeColors.primary,
                      borderColor: themeColors.primary
                    }}
                  >
                    <Wifi className="w-4 h-4 mr-2" />
                    Conectar a WiFi
                  </FordButton>
                </div>
              </FordCard>
            </motion.div>
          </div>

          {/* Información lateral */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <FordCard className="p-6">
                <h3 
                  className="text-lg font-bold mb-4" 
                  style={{ color: themeColors.primary }}
                >
                  Nuestros Servicios
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: `${themeColors.accent}20` }}
                    >
                      <Car className="w-5 h-5" style={{ color: themeColors.accent }} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Venta de Vehículos</h4>
                      <p className="text-sm text-gray-600">Nuevos y seminuevos</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: `${themeColors.accent}20` }}
                    >
                      <Wrench className="w-5 h-5" style={{ color: themeColors.accent }} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Servicio Técnico</h4>
                      <p className="text-sm text-gray-600">Mantenimiento profesional</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: `${themeColors.accent}20` }}
                    >
                      <Zap className="w-5 h-5" style={{ color: themeColors.accent }} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">QuickLane</h4>
                      <p className="text-sm text-gray-600">Servicio express</p>
                    </div>
                  </div>
                </div>
              </FordCard>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <FordCard className="p-6">
                <h3 
                  className="text-lg font-bold mb-4" 
                  style={{ color: themeColors.primary }}
                >
                  Contacto
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" style={{ color: themeColors.accent }} />
                    <span>+504 2555-0000</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Mail className="w-4 h-4" style={{ color: themeColors.accent }} />
                    <span>info@yudecanahuati.com</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" style={{ color: themeColors.accent }} />
                    <span>San Pedro Sula, Honduras</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Globe className="w-4 h-4" style={{ color: themeColors.accent }} />
                    <span>www.yudecanahuati.com</span>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          </div>
        </div>

        {/* Footer informativo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-12 pt-8 border-t border-gray-200"
        >
          <p className="text-sm text-gray-500">
            Esta es una vista previa del tema. Los colores y estilos se aplicarán cuando guarde la configuración.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
