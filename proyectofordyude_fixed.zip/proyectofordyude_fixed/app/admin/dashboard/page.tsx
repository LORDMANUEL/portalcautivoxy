
import { Metadata } from 'next';
import { DashboardClient } from './_components/dashboard-client';

export const metadata: Metadata = {
  title: 'Dashboard - Administración Ford',
  description: 'Panel principal de administración del portal cautivo Ford Yude Canahuati',
};

export default function AdminDashboardPage() {
  return <DashboardClient />;
}
