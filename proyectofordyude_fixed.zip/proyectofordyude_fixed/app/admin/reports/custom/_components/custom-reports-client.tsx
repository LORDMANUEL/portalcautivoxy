
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Settings,
  Plus,
  Download,
  Filter,
  Calendar,
  BarChart3,
  PieChart,
  LineChart,
  Users,
  MapPin,
  Clock,
  ArrowLeft,
  Play,
  Save,
  Trash2,
  Edit
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DateRangePicker } from '@/components/ui/date-range-picker';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Link from 'next/link';
import { DateRange } from 'react-day-picker';

interface CustomReport {
  id: string;
  name: string;
  description: string;
  chartType: 'bar' | 'line' | 'pie' | 'table';
  dataSource: string;
  filters: {
    dateRange: DateRange;
    locations: string[];
    portals: string[];
    deviceTypes: string[];
    userTypes: string[];
  };
  metrics: string[];
  groupBy: string;
  isActive: boolean;
  createdAt: string;
  lastRun: string;
}

interface ReportBuilder {
  name: string;
  description: string;
  chartType: 'bar' | 'line' | 'pie' | 'table';
  dataSource: string;
  metrics: string[];
  groupBy: string;
  filters: {
    locations: string[];
    portals: string[];
    deviceTypes: string[];
    dateRange: DateRange;
  };
}

/**
 * Reportes personalizados con constructor visual
 * Permite crear reportes dinámicos con filtros avanzados
 */
export function CustomReportsClient() {
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState<CustomReport[]>([]);
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<CustomReport | null>(null);
  const [runningReport, setRunningReport] = useState<string | null>(null);

  const [reportBuilder, setReportBuilder] = useState<ReportBuilder>({
    name: '',
    description: '',
    chartType: 'bar',
    dataSource: 'connections',
    metrics: ['count'],
    groupBy: 'date',
    filters: {
      locations: [],
      portals: [],
      deviceTypes: [],
      dateRange: {
        from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        to: new Date()
      } as DateRange
    }
  });

  const chartTypes = [
    { value: 'bar', label: 'Gráfico de Barras', icon: BarChart3 },
    { value: 'line', label: 'Gráfico de Líneas', icon: LineChart },
    { value: 'pie', label: 'Gráfico Circular', icon: PieChart },
    { value: 'table', label: 'Tabla', icon: Settings }
  ];

  const dataSources = [
    { value: 'connections', label: 'Conexiones de Usuario' },
    { value: 'sessions', label: 'Sesiones de Portal' },
    { value: 'devices', label: 'Tipos de Dispositivo' },
    { value: 'locations', label: 'Ubicaciones' },
    { value: 'logs', label: 'Logs del Sistema' }
  ];

  const availableMetrics = [
    { value: 'count', label: 'Conteo Total' },
    { value: 'unique_users', label: 'Usuarios Únicos' },
    { value: 'avg_session_time', label: 'Tiempo Promedio de Sesión' },
    { value: 'total_time', label: 'Tiempo Total' },
    { value: 'conversion_rate', label: 'Tasa de Conversión' }
  ];

  const groupByOptions = [
    { value: 'date', label: 'Por Fecha' },
    { value: 'location', label: 'Por Ubicación' },
    { value: 'portal_type', label: 'Por Tipo de Portal' },
    { value: 'device_type', label: 'Por Dispositivo' },
    { value: 'hour', label: 'Por Hora del Día' }
  ];

  useEffect(() => {
    fetchCustomReports();
  }, []);

  const fetchCustomReports = async () => {
    setLoading(true);
    try {
      // Simular API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockReports: CustomReport[] = [
        {
          id: '1',
          name: 'Conexiones por Ubicación - Semanal',
          description: 'Análisis semanal de conexiones por ubicación con comparativo',
          chartType: 'bar',
          dataSource: 'connections',
          filters: {
            dateRange: { from: new Date(), to: new Date() },
            locations: ['sps', 'tegus'],
            portals: ['ford'],
            deviceTypes: ['mobile', 'desktop'],
            userTypes: ['all']
          },
          metrics: ['count', 'unique_users'],
          groupBy: 'location',
          isActive: true,
          createdAt: '2024-01-10',
          lastRun: '2024-01-15'
        },
        {
          id: '2',
          name: 'Tendencia de Dispositivos Móviles',
          description: 'Evolución del uso de dispositivos móviles en los últimos 3 meses',
          chartType: 'line',
          dataSource: 'devices',
          filters: {
            dateRange: { from: new Date(), to: new Date() },
            locations: [],
            portals: [],
            deviceTypes: ['mobile'],
            userTypes: []
          },
          metrics: ['count', 'conversion_rate'],
          groupBy: 'date',
          isActive: true,
          createdAt: '2024-01-08',
          lastRun: '2024-01-14'
        }
      ];

      setReports(mockReports);
    } catch (error) {
      toast.error('Error al cargar reportes personalizados');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveReport = async () => {
    if (!reportBuilder.name) {
      toast.error('El nombre del reporte es obligatorio');
      return;
    }

    try {
      // Simular guardar reporte
      const newReport: CustomReport = {
        id: Date.now().toString(),
        ...reportBuilder,
        filters: {
          ...reportBuilder.filters,
          userTypes: []
        },
        isActive: true,
        createdAt: new Date().toISOString(),
        lastRun: new Date().toISOString()
      };

      setReports(prev => [newReport, ...prev]);
      setIsBuilderOpen(false);
      resetBuilder();
      toast.success('Reporte personalizado guardado correctamente');
    } catch (error) {
      toast.error('Error al guardar el reporte');
    }
  };

  const handleRunReport = async (reportId: string) => {
    setRunningReport(reportId);
    try {
      // Simular ejecución de reporte
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Actualizar última ejecución
      setReports(prev => prev.map(report => 
        report.id === reportId 
          ? { ...report, lastRun: new Date().toISOString() }
          : report
      ));
      
      toast.success('Reporte ejecutado correctamente');
    } catch (error) {
      toast.error('Error al ejecutar el reporte');
    } finally {
      setRunningReport(null);
    }
  };

  const handleDeleteReport = async (reportId: string) => {
    if (!confirm('¿Estás seguro de eliminar este reporte?')) return;

    try {
      setReports(prev => prev.filter(report => report.id !== reportId));
      toast.success('Reporte eliminado correctamente');
    } catch (error) {
      toast.error('Error al eliminar el reporte');
    }
  };

  const resetBuilder = () => {
    setReportBuilder({
      name: '',
      description: '',
      chartType: 'bar',
      dataSource: 'connections',
      metrics: ['count'],
      groupBy: 'date',
      filters: {
        locations: [],
        portals: [],
        deviceTypes: [],
        dateRange: {
          from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          to: new Date()
        } as DateRange
      }
    });
  };

  const getChartIcon = (type: string) => {
    const chart = chartTypes.find(c => c.value === type);
    const IconComponent = chart?.icon || BarChart3;
    return <IconComponent className="w-4 h-4" />;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando reportes personalizados..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/admin/reports">
            <FordButton variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a Reportes
            </FordButton>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <Settings className="w-8 h-8 text-[#003478]" />
              Reportes Personalizados
            </h1>
            <p className="text-gray-600 mt-1">
              Crea y configura reportes dinámicos con filtros avanzados
            </p>
          </div>
        </div>

        <Dialog open={isBuilderOpen} onOpenChange={setIsBuilderOpen}>
          <DialogTrigger asChild>
            <FordButton onClick={() => setEditingReport(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Reporte
            </FordButton>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingReport ? 'Editar Reporte' : 'Constructor de Reportes'}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Información Básica</TabsTrigger>
                <TabsTrigger value="data">Fuente de Datos</TabsTrigger>
                <TabsTrigger value="filters">Filtros</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="report-name">Nombre del Reporte *</Label>
                    <Input
                      id="report-name"
                      value={reportBuilder.name}
                      onChange={(e) => setReportBuilder(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Análisis de conexiones por ubicación"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="chart-type">Tipo de Gráfico</Label>
                    <Select
                      value={reportBuilder.chartType}
                      onValueChange={(value) => setReportBuilder(prev => ({ ...prev, chartType: value as 'bar' | 'line' | 'pie' | 'table' }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {chartTypes.map((chart) => {
                          const IconComponent = chart.icon;
                          return (
                            <SelectItem key={chart.value} value={chart.value}>
                              <div className="flex items-center space-x-2">
                                <IconComponent className="w-4 h-4" />
                                <span>{chart.label}</span>
                              </div>
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={reportBuilder.description}
                    onChange={(e) => setReportBuilder(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe el propósito y contenido de este reporte"
                    rows={3}
                  />
                </div>
              </TabsContent>

              <TabsContent value="data" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Fuente de Datos</Label>
                    <Select
                      value={reportBuilder.dataSource}
                      onValueChange={(value) => setReportBuilder(prev => ({ ...prev, dataSource: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {dataSources.map((source) => (
                          <SelectItem key={source.value} value={source.value}>
                            {source.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Agrupar Por</Label>
                    <Select
                      value={reportBuilder.groupBy}
                      onValueChange={(value) => setReportBuilder(prev => ({ ...prev, groupBy: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {groupByOptions.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Métricas a Incluir</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {availableMetrics.map((metric) => (
                      <div key={metric.value} className="flex items-center space-x-2">
                        <Checkbox
                          id={metric.value}
                          checked={reportBuilder.metrics.includes(metric.value)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setReportBuilder(prev => ({
                                ...prev,
                                metrics: [...prev.metrics, metric.value]
                              }));
                            } else {
                              setReportBuilder(prev => ({
                                ...prev,
                                metrics: prev.metrics.filter(m => m !== metric.value)
                              }));
                            }
                          }}
                        />
                        <Label htmlFor={metric.value} className="text-sm">
                          {metric.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="filters" className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Rango de Fechas</Label>
                    <DateRangePicker
                      value={reportBuilder.filters.dateRange}
                      onChange={(dateRange) => 
                        setReportBuilder(prev => ({
                          ...prev,
                          filters: { ...prev.filters, dateRange }
                        }))
                      }
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Ubicaciones</Label>
                      <div className="space-y-2">
                        {['sps', 'tegus', 'ceiba'].map((location) => (
                          <div key={location} className="flex items-center space-x-2">
                            <Checkbox
                              id={location}
                              checked={reportBuilder.filters.locations.includes(location)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setReportBuilder(prev => ({
                                    ...prev,
                                    filters: {
                                      ...prev.filters,
                                      locations: [...prev.filters.locations, location]
                                    }
                                  }));
                                } else {
                                  setReportBuilder(prev => ({
                                    ...prev,
                                    filters: {
                                      ...prev.filters,
                                      locations: prev.filters.locations.filter(l => l !== location)
                                    }
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={location} className="text-sm capitalize">
                              {location === 'sps' ? 'San Pedro Sula' : location === 'tegus' ? 'Tegucigalpa' : 'La Ceiba'}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Tipos de Portal</Label>
                      <div className="space-y-2">
                        {['ford', 'quicklane_truck', 'quicklane_tegus', 'quicklane_sps'].map((portal) => (
                          <div key={portal} className="flex items-center space-x-2">
                            <Checkbox
                              id={portal}
                              checked={reportBuilder.filters.portals.includes(portal)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setReportBuilder(prev => ({
                                    ...prev,
                                    filters: {
                                      ...prev.filters,
                                      portals: [...prev.filters.portals, portal]
                                    }
                                  }));
                                } else {
                                  setReportBuilder(prev => ({
                                    ...prev,
                                    filters: {
                                      ...prev.filters,
                                      portals: prev.filters.portals.filter(p => p !== portal)
                                    }
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={portal} className="text-sm">
                              {portal.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-end space-x-2 pt-4">
              <FordButton
                variant="outline"
                onClick={() => {
                  setIsBuilderOpen(false);
                  resetBuilder();
                }}
              >
                Cancelar
              </FordButton>
              <FordButton onClick={handleSaveReport}>
                <Save className="w-4 h-4 mr-2" />
                Guardar Reporte
              </FordButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de reportes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {reports.map((report, index) => (
          <motion.div
            key={report.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <FordCard className="p-6 h-full">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  {getChartIcon(report.chartType)}
                  <div>
                    <h3 className="font-bold text-gray-800">{report.name}</h3>
                    <p className="text-sm text-gray-600">{report.description}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Badge variant={report.isActive ? 'default' : 'secondary'}>
                    {report.isActive ? 'Activo' : 'Inactivo'}
                  </Badge>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Fuente:</span>
                  <span className="font-medium">{dataSources.find(s => s.value === report.dataSource)?.label}</span>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Métricas:</span>
                  <span className="font-medium">{report.metrics.length} métricas</span>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Última ejecución:</span>
                  <span className="font-medium">{new Date(report.lastRun).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <FordButton
                  size="sm"
                  onClick={() => handleRunReport(report.id)}
                  disabled={runningReport === report.id}
                  className="flex-1"
                >
                  {runningReport === report.id ? (
                    <LoadingSpinner size="sm" />
                  ) : (
                    <Play className="w-4 h-4 mr-2" />
                  )}
                  Ejecutar
                </FordButton>
                
                <FordButton
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setEditingReport(report);
                    setIsBuilderOpen(true);
                  }}
                >
                  <Edit className="w-4 h-4" />
                </FordButton>
                
                <FordButton
                  size="sm"
                  variant="outline"
                  onClick={() => handleDeleteReport(report.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </FordButton>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {reports.length === 0 && (
        <FordCard className="text-center py-12">
          <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            No hay reportes personalizados
          </h3>
          <p className="text-gray-500 mb-4">
            Crea tu primer reporte personalizado para comenzar
          </p>
          <FordButton onClick={() => setIsBuilderOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Crear Primer Reporte
          </FordButton>
        </FordCard>
      )}
    </div>
  );
}
