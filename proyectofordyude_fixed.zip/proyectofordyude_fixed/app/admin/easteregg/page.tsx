

import { Metadata } from 'next';
import { EasterEggClient } from './_components/easter-egg-client';

export const metadata: Metadata = {
  title: 'Easter Egg - Administración Ford',
  description: 'Funcionalidad especial oculta para administradores Ford Yude Canahuati',
};

export default function EasterEggPage() {
  return <EasterEggClient />;
}
