
/**
 * Diálogo para Editar vCard
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

'use client'

import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { QrCode, User, Mail, Phone, Building, MapPin, Globe, RefreshCw } from 'lucide-react'

const editVCardSchema = z.object({
  advisorName: z.string().min(2, 'Nombre debe tener al menos 2 caracteres').optional(),
  position: z.string().optional(),
  email: z.string().email('Email inválido').optional(),
  phone: z.string().optional(),
  company: z.string().optional(),
  address: z.string().optional(),
  website: z.string().url('URL inválida').optional().or(z.literal('')),
  photo: z.string().optional(),
  isActive: z.boolean().optional()
})

type EditVCardForm = z.infer<typeof editVCardSchema>

interface VCard {
  id: string
  advisorName: string
  position?: string
  email: string
  phone?: string
  company: string
  address?: string
  website?: string
  photo?: string
  qrCode?: string
  isActive: boolean
  downloadCount: number
  createdAt: string
  updatedAt: string
}

interface EditVCardDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  vcard: VCard
  onSuccess: () => void
}

export default function EditVCardDialog({
  open,
  onOpenChange,
  vcard,
  onSuccess
}: EditVCardDialogProps) {
  const [loading, setLoading] = useState(false)
  const [regeneratingQR, setRegeneratingQR] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch
  } = useForm<EditVCardForm>({
    resolver: zodResolver(editVCardSchema)
  })

  const isActive = watch('isActive')

  useEffect(() => {
    if (vcard && open) {
      reset({
        advisorName: vcard.advisorName,
        position: vcard.position || '',
        email: vcard.email,
        phone: vcard.phone || '',
        company: vcard.company,
        address: vcard.address || '',
        website: vcard.website || '',
        photo: vcard.photo || '',
        isActive: vcard.isActive
      })
    }
  }, [vcard, open, reset])

  const handleClose = () => {
    reset()
    onOpenChange(false)
  }

  const onSubmit = async (data: EditVCardForm) => {
    try {
      setLoading(true)

      // Preparar datos para actualización
      const updateData: any = {}
      
      if (data.advisorName !== vcard.advisorName) updateData.advisorName = data.advisorName
      if (data.position !== (vcard.position || '')) updateData.position = data.position || undefined
      if (data.email !== vcard.email) updateData.email = data.email
      if (data.phone !== (vcard.phone || '')) updateData.phone = data.phone || undefined
      if (data.company !== vcard.company) updateData.company = data.company
      if (data.address !== (vcard.address || '')) updateData.address = data.address || undefined
      if (data.website !== (vcard.website || '')) updateData.website = data.website || undefined
      if (data.photo !== (vcard.photo || '')) updateData.photo = data.photo || undefined
      if (data.isActive !== vcard.isActive) updateData.isActive = data.isActive

      // Solo enviar la request si hay cambios
      if (Object.keys(updateData).length === 0) {
        toast('No se detectaron cambios')
        handleClose()
        return
      }

      const response = await fetch(`/api/admin/qr-generator/${vcard.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      })

      const result = await response.json()

      if (result.success) {
        toast.success('vCard actualizada exitosamente')
        onSuccess()
        handleClose()
      } else {
        toast.error(result.message || 'Error al actualizar vCard')
      }
    } catch (error) {
      console.error('Error updating vCard:', error)
      toast.error('Error al actualizar vCard')
    } finally {
      setLoading(false)
    }
  }

  const handleRegenerateQR = async () => {
    if (!confirm('¿Estás seguro de que deseas regenerar el código QR? Esto actualizará la imagen del código QR con los datos actuales.')) {
      return
    }

    try {
      setRegeneratingQR(true)

      // Primero guardar los cambios actuales
      const currentData = watch()
      await onSubmit(currentData)

      toast.success('Código QR regenerado exitosamente')
    } catch (error) {
      console.error('Error regenerating QR:', error)
      toast.error('Error al regenerar código QR')
    } finally {
      setRegeneratingQR(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Editar vCard
          </DialogTitle>
          <DialogDescription>
            Modifica la información de la vCard de {vcard?.advisorName}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Estado de la vCard */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <Label htmlFor="isActive" className="text-base font-medium">
                Estado de la vCard
              </Label>
              <p className="text-sm text-gray-600">
                {isActive ? 'vCard activa y disponible para descarga' : 'vCard desactivada'}
              </p>
            </div>
            <Switch
              id="isActive"
              checked={isActive}
              onCheckedChange={(checked) => setValue('isActive', checked)}
              disabled={loading}
            />
          </div>

          {/* Información Personal */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <User className="h-5 w-5" />
              Información Personal
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Nombre */}
              <div className="space-y-2">
                <Label htmlFor="advisorName">Nombre Completo</Label>
                <Input
                  id="advisorName"
                  {...register('advisorName')}
                  placeholder="Ej: Juan Carlos Mendoza"
                  disabled={loading}
                />
                {errors.advisorName && (
                  <p className="text-sm text-red-600">{errors.advisorName.message}</p>
                )}
              </div>

              {/* Posición */}
              <div className="space-y-2">
                <Label htmlFor="position">Posición/Cargo</Label>
                <Input
                  id="position"
                  {...register('position')}
                  placeholder="Ej: Asesor de Ventas Senior"
                  disabled={loading}
                />
                {errors.position && (
                  <p className="text-sm text-red-600">{errors.position.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Información de Contacto */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Información de Contacto
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  placeholder="juan.mendoza@ford.com.hn"
                  disabled={loading}
                />
                {errors.email && (
                  <p className="text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              {/* Teléfono */}
              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  id="phone"
                  {...register('phone')}
                  placeholder="+504 9999-1234"
                  disabled={loading}
                />
                {errors.phone && (
                  <p className="text-sm text-red-600">{errors.phone.message}</p>
                )}
              </div>
            </div>

            {/* Website */}
            <div className="space-y-2">
              <Label htmlFor="website">Sitio Web</Label>
              <Input
                id="website"
                {...register('website')}
                placeholder="https://ford.com.hn"
                disabled={loading}
              />
              {errors.website && (
                <p className="text-sm text-red-600">{errors.website.message}</p>
              )}
            </div>
          </div>

          {/* Información de la Empresa */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Building className="h-5 w-5" />
              Información de la Empresa
            </h3>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Empresa */}
              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  {...register('company')}
                  placeholder="Ford Yude Canahuati"
                  disabled={loading}
                />
                {errors.company && (
                  <p className="text-sm text-red-600">{errors.company.message}</p>
                )}
              </div>

              {/* Dirección */}
              <div className="space-y-2">
                <Label htmlFor="address">Dirección</Label>
                <Textarea
                  id="address"
                  {...register('address')}
                  placeholder="Blvd. Suyapa, Tegucigalpa, Honduras"
                  disabled={loading}
                  rows={2}
                />
                {errors.address && (
                  <p className="text-sm text-red-600">{errors.address.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Estadísticas */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-medium mb-2">Estadísticas de la vCard:</h4>
            <div className="text-sm text-gray-600 space-y-1">
              <p>Descargas totales: <span className="font-medium">{vcard.downloadCount}</span></p>
              <p>Creada: <span className="font-medium">{new Date(vcard.createdAt).toLocaleDateString('es-ES')}</span></p>
              <p>Última actualización: <span className="font-medium">{new Date(vcard.updatedAt).toLocaleDateString('es-ES')}</span></p>
              {vcard.qrCode && (
                <p className="text-green-600">✓ Código QR generado</p>
              )}
            </div>
          </div>

          <DialogFooter className="flex flex-col gap-2 sm:flex-row">
            <div className="flex gap-2 flex-1">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={loading || regeneratingQR}
              >
                Cancelar
              </Button>
              {vcard.qrCode && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleRegenerateQR}
                  disabled={loading || regeneratingQR}
                >
                  {regeneratingQR ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Regenerando QR...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Regenerar QR
                    </>
                  )}
                </Button>
              )}
            </div>
            <Button
              type="submit"
              disabled={loading || regeneratingQR}
              className="bg-[#003478] hover:bg-[#002856]"
            >
              {loading ? 'Guardando...' : 'Guardar Cambios'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
