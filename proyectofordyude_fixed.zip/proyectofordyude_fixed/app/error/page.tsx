
import { Metadata } from 'next';
import { ErrorClient } from './_components/error-client';

export const metadata: Metadata = {
  title: 'Error - Ford Yude Canahuati',
  description: 'Ha ocurrido un error en el portal cautivo de Ford Yude Canahuati.',
};

export default function ErrorPage() {
  return <ErrorClient />;
}
