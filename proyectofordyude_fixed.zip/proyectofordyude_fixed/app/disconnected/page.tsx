
import { Metadata } from 'next';
import { DisconnectedClient } from './_components/disconnected-client';

export const metadata: Metadata = {
  title: 'Desconectado - Ford Yude Canahuati',
  description: 'Has sido desconectado del WiFi de Ford Yude Canahuati.',
};

export default function DisconnectedPage() {
  return <DisconnectedClient />;
}
