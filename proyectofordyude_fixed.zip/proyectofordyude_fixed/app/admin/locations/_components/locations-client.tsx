

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  MapPin,
  Plus,
  Edit,
  Trash2,
  Wifi,
  Building,
  Car,
  Wrench,
  Home,
  Eye,
  EyeOff,
  Search,
  Filter,
  MoreVertical,
  Calendar,
  Globe,
  Zap,
  Signal,
  Router
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface Location {
  id: string;
  name: string;
  code: string;
  type: string;
  address: string | null;
  city: string | null;
  country: string;
  latitude: number | null;
  longitude: number | null;
  description: string | null;
  iconName: string;
  iconColor: string;
  isActive: boolean;
  routerConfig: any;
  metadata: any;
  createdAt: string;
  updatedAt: string;
  _count?: {
    portals: number;
    backups: number;
    admins: number;
  };
}

interface LocationFormData {
  name: string;
  code: string;
  type: string;
  address: string;
  city: string;
  country: string;
  latitude: string;
  longitude: string;
  description: string;
  iconName: string;
  iconColor: string;
  isActive: boolean;
  routerConfig: {
    ssid: string;
    password: string;
    ipRange: string;
    dnsServers: string[];
    captivePortalUrl: string;
  };
}

// Tipos de ubicaciones con iconos
const locationTypes = [
  { value: 'SHOWROOM', label: 'Showroom', icon: Building, color: '#003478' },
  { value: 'SERVICE', label: 'Servicio', icon: Wrench, color: '#FF6B35' },
  { value: 'QUICKLANE', label: 'QuickLane', icon: Zap, color: '#4ECDC4' },
  { value: 'OFFICE', label: 'Oficina', icon: Home, color: '#45B7D1' },
];

// Iconos disponibles para ubicaciones
const availableIcons = [
  'building', 'car', 'wrench', 'home', 'zap', 'wifi', 'router', 'signal',
  'map-pin', 'globe', 'eye', 'settings', 'users', 'shield'
];

// Colores predefinidos
const availableColors = [
  '#003478', '#FF6B35', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
  '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE'
];

/**
 * Cliente para gestión de ubicaciones y routers
 * Permite gestionar salas, ubicaciones y configuraciones de red
 */
export function LocationsClient() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingLocation, setEditingLocation] = useState<Location | null>(null);
  const [saving, setSaving] = useState(false);

  // Formulario de ubicación
  const [formData, setFormData] = useState<LocationFormData>({
    name: '',
    code: '',
    type: 'SHOWROOM',
    address: '',
    city: 'San Pedro Sula',
    country: 'Honduras',
    latitude: '',
    longitude: '',
    description: '',
    iconName: 'building',
    iconColor: '#003478',
    isActive: true,
    routerConfig: {
      ssid: '',
      password: '',
      ipRange: '192.168.1.0/24',
      dnsServers: ['8.8.8.8', '8.8.4.4'],
      captivePortalUrl: ''
    }
  });

  useEffect(() => {
    fetchLocations();
  }, []);

  /**
   * Obtiene todas las ubicaciones
   */
  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/admin/locations');
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      } else {
        toast.error('Error al cargar las ubicaciones');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Maneja los cambios en el formulario
   */
  const handleInputChange = (field: string, value: string | boolean | object) => {
    if (field.startsWith('routerConfig.')) {
      const configField = field.split('.')[1];
      setFormData(prev => ({
        ...prev,
        routerConfig: {
          ...prev.routerConfig,
          [configField]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  /**
   * Guarda o actualiza una ubicación
   */
  const handleSaveLocation = async () => {
    if (!formData.name || !formData.code) {
      toast.error('Nombre y código son obligatorios');
      return;
    }

    setSaving(true);
    try {
      const url = editingLocation 
        ? `/api/admin/locations/${editingLocation.id}` 
        : '/api/admin/locations';
      const method = editingLocation ? 'PUT' : 'POST';

      const payload = {
        ...formData,
        latitude: formData.latitude ? parseFloat(formData.latitude) : null,
        longitude: formData.longitude ? parseFloat(formData.longitude) : null,
        routerConfig: formData.routerConfig
      };

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(editingLocation ? 'Ubicación actualizada correctamente' : 'Ubicación creada correctamente');
        setIsModalOpen(false);
        setEditingLocation(null);
        resetForm();
        fetchLocations();
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || 'Error al guardar la ubicación');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setSaving(false);
    }
  };

  /**
   * Abre el modal para editar una ubicación
   */
  const handleEditLocation = (location: Location) => {
    setEditingLocation(location);
    setFormData({
      name: location.name,
      code: location.code,
      type: location.type,
      address: location.address || '',
      city: location.city || 'San Pedro Sula',
      country: location.country,
      latitude: location.latitude?.toString() || '',
      longitude: location.longitude?.toString() || '',
      description: location.description || '',
      iconName: location.iconName,
      iconColor: location.iconColor,
      isActive: location.isActive,
      routerConfig: location.routerConfig || {
        ssid: '',
        password: '',
        ipRange: '192.168.1.0/24',
        dnsServers: ['8.8.8.8', '8.8.4.4'],
        captivePortalUrl: ''
      }
    });
    setIsModalOpen(true);
  };

  /**
   * Elimina una ubicación
   */
  const handleDeleteLocation = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar esta ubicación?')) return;

    try {
      const response = await fetch(`/api/admin/locations/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Ubicación eliminada correctamente');
        fetchLocations();
      } else {
        toast.error('Error al eliminar la ubicación');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Activa/desactiva una ubicación
   */
  const handleToggleLocation = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/locations/${id}/toggle`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        toast.success(`Ubicación ${!isActive ? 'activada' : 'desactivada'} correctamente`);
        fetchLocations();
      } else {
        toast.error('Error al cambiar el estado de la ubicación');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Navega al portal de la ubicación
   */
  const handleViewPortal = (location: Location) => {
    if (!location.isActive) {
      toast.error('Esta ubicación está desactivada');
      return;
    }

    // Mapear tipo de ubicación a tipo de portal
    const portalTypeMap: { [key: string]: string } = {
      'SHOWROOM': 'ford',
      'SERVICE': 'ford', 
      'QUICKLANE': 'quicklane_sps',
      'OFFICE': 'ford'
    };

    // Determinar el tipo de portal basado en el código y tipo de ubicación
    let portalType = portalTypeMap[location.type] || 'ford';
    
    // Casos especiales basados en código de ubicación
    if (location.code.toLowerCase().includes('truck')) {
      portalType = 'quicklane_truck';
    } else if (location.code.toLowerCase().includes('tegus') || location.code.toLowerCase().includes('tgu')) {
      portalType = 'quicklane_tegus';
    } else if (location.type === 'QUICKLANE' && location.code.toLowerCase().includes('sps')) {
      portalType = 'quicklane_sps';
    }

    // Construir URL del portal - usar token basado en ubicación
    const portalToken = `${portalType}_${location.code.toLowerCase().replace(/\s+/g, '_')}`;
    const portalUrl = `/portal/${portalToken}`;
    
    // Abrir portal en nueva pestaña
    window.open(portalUrl, '_blank');
    
    toast.success(`Abriendo portal: ${location.name}`);
  };

  /**
   * Resetea el formulario
   */
  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      type: 'SHOWROOM',
      address: '',
      city: 'San Pedro Sula',
      country: 'Honduras',
      latitude: '',
      longitude: '',
      description: '',
      iconName: 'building',
      iconColor: '#003478',
      isActive: true,
      routerConfig: {
        ssid: '',
        password: '',
        ipRange: '192.168.1.0/24',
        dnsServers: ['8.8.8.8', '8.8.4.4'],
        captivePortalUrl: ''
      }
    });
  };

  /**
   * Obtiene el icono del tipo de ubicación
   */
  const getLocationTypeIcon = (type: string) => {
    const locationType = locationTypes.find(lt => lt.value === type);
    return locationType?.icon || Building;
  };

  /**
   * Obtiene el color del tipo de ubicación
   */
  const getLocationTypeColor = (type: string) => {
    const locationType = locationTypes.find(lt => lt.value === type);
    return locationType?.color || '#003478';
  };

  // Filtrar ubicaciones
  const filteredLocations = locations.filter(location => {
    const matchesSearch = location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         location.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         location.city?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === '' || filterType === 'ALL_TYPES' || location.type === filterType;
    
    return matchesSearch && matchesType;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando ubicaciones..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con controles */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <MapPin className="w-8 h-8 text-[#003478]" />
            Ubicaciones/Routers
          </h1>
          <p className="text-gray-600 mt-1">
            Gestiona ubicaciones, salas y configuraciones de red
          </p>
        </div>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <FordButton 
              onClick={() => {
                setEditingLocation(null);
                resetForm();
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nueva Ubicación
            </FordButton>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingLocation ? 'Editar Ubicación' : 'Nueva Ubicación'}
              </DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              {/* Información básica */}
              <div className="space-y-2">
                <Label htmlFor="name">Nombre de la Ubicación *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Showroom San Pedro Sula"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="code">Código *</Label>
                <Input
                  id="code"
                  value={formData.code}
                  onChange={(e) => handleInputChange('code', e.target.value)}
                  placeholder="SPS"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Tipo de Ubicación</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => handleInputChange('type', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {locationTypes.map((type) => {
                      const IconComponent = type.icon;
                      return (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex items-center space-x-2">
                            <IconComponent className="w-4 h-4" style={{ color: type.color }} />
                            <span>{type.label}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">Ciudad</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => handleInputChange('city', e.target.value)}
                  placeholder="San Pedro Sula"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="address">Dirección</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange('address', e.target.value)}
                  placeholder="Col. Los Andes, 3era Avenida"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="latitude">Latitud</Label>
                <Input
                  id="latitude"
                  value={formData.latitude}
                  onChange={(e) => handleInputChange('latitude', e.target.value)}
                  placeholder="15.5040"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="longitude">Longitud</Label>
                <Input
                  id="longitude"
                  value={formData.longitude}
                  onChange={(e) => handleInputChange('longitude', e.target.value)}
                  placeholder="-88.0253"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Descripción de la ubicación..."
                  rows={2}
                />
              </div>

              {/* Personalización visual */}
              <div className="space-y-2">
                <Label htmlFor="iconName">Icono</Label>
                <Select
                  value={formData.iconName}
                  onValueChange={(value) => handleInputChange('iconName', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {availableIcons.map((iconName) => (
                      <SelectItem key={iconName} value={iconName}>
                        {iconName.charAt(0).toUpperCase() + iconName.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="iconColor">Color del Icono</Label>
                <div className="flex space-x-2">
                  <Input
                    id="iconColor"
                    type="color"
                    value={formData.iconColor}
                    onChange={(e) => handleInputChange('iconColor', e.target.value)}
                    className="w-16 h-10"
                  />
                  <Select
                    value={formData.iconColor}
                    onValueChange={(value) => handleInputChange('iconColor', value)}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableColors.map((color) => (
                        <SelectItem key={color} value={color}>
                          <div className="flex items-center space-x-2">
                            <div 
                              className="w-4 h-4 rounded-full border border-gray-300"
                              style={{ backgroundColor: color }}
                            />
                            <span>{color}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Configuración de router */}
              <div className="md:col-span-2">
                <Label className="text-sm font-medium mb-3 block">
                  Configuración de Router/Red
                </Label>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ssid">SSID (Red WiFi)</Label>
                    <Input
                      id="ssid"
                      value={formData.routerConfig.ssid}
                      onChange={(e) => handleInputChange('routerConfig.ssid', e.target.value)}
                      placeholder="Ford_WiFi_SPS"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Contraseña WiFi</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.routerConfig.password}
                      onChange={(e) => handleInputChange('routerConfig.password', e.target.value)}
                      placeholder="Password123"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ipRange">Rango de IPs</Label>
                    <Input
                      id="ipRange"
                      value={formData.routerConfig.ipRange}
                      onChange={(e) => handleInputChange('routerConfig.ipRange', e.target.value)}
                      placeholder="192.168.1.0/24"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="captivePortalUrl">URL Portal Cautivo</Label>
                    <Input
                      id="captivePortalUrl"
                      value={formData.routerConfig.captivePortalUrl}
                      onChange={(e) => handleInputChange('routerConfig.captivePortalUrl', e.target.value)}
                      placeholder="https://portal.yudecanahuati.com"
                    />
                  </div>
                </div>
              </div>

              {/* Estado activo */}
              <div className="flex items-center space-x-2 md:col-span-2">
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => handleInputChange('isActive', checked)}
                />
                <Label htmlFor="isActive">Ubicación Activa</Label>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <FordButton
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingLocation(null);
                  resetForm();
                }}
              >
                Cancelar
              </FordButton>
              <FordButton onClick={handleSaveLocation} disabled={saving}>
                {saving ? (
                  <LoadingSpinner size="sm" message="Guardando..." />
                ) : (
                  <>
                    <MapPin className="w-4 h-4 mr-2" />
                    {editingLocation ? 'Actualizar' : 'Crear Ubicación'}
                  </>
                )}
              </FordButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar ubicaciones..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filtrar por tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL_TYPES">Todos los tipos</SelectItem>
            {locationTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Lista de ubicaciones */}
      {filteredLocations.length === 0 ? (
        <FordCard className="text-center py-12">
          <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            {searchTerm || filterType ? 'No se encontraron ubicaciones' : 'No hay ubicaciones configuradas'}
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm || filterType
              ? 'Intenta con otros filtros de búsqueda'
              : 'Crea tu primera ubicación para comenzar'
            }
          </p>
        </FordCard>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredLocations.map((location) => {
            const TypeIcon = getLocationTypeIcon(location.type);
            const typeColor = getLocationTypeColor(location.type);
            
            return (
              <motion.div
                key={location.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="group"
              >
                <FordCard className="h-full hover:shadow-lg transition-all duration-200">
                  <div className="p-6">
                    {/* Header con icono y acciones */}
                    <div className="flex items-start justify-between mb-4">
                      <div 
                        className="flex items-center space-x-3 cursor-pointer hover:opacity-80 transition-opacity"
                        onClick={() => handleViewPortal(location)}
                        title={`Click para abrir portal de ${location.name}`}
                      >
                        <div 
                          className="w-12 h-12 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: `${location.iconColor}20`, border: `2px solid ${location.iconColor}` }}
                        >
                          <TypeIcon className="w-6 h-6" style={{ color: location.iconColor }} />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-800 flex items-center">
                            {location.name}
                            {location.isActive && (
                              <Globe className="w-4 h-4 ml-2 text-blue-500" />
                            )}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {location.code}
                            {location.isActive && (
                              <span className="ml-2 text-blue-500 text-xs">• Click para ver portal</span>
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Badge 
                          className={`${location.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}
                        >
                          {location.isActive ? 'Activa' : 'Inactiva'}
                        </Badge>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <FordButton size="sm" variant="ghost">
                              <MoreVertical className="w-4 h-4" />
                            </FordButton>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem 
                              onClick={() => handleViewPortal(location)}
                              className="text-blue-600 font-medium"
                            >
                              <Globe className="w-4 h-4 mr-2" />
                              Ver Portal
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditLocation(location)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleToggleLocation(location.id, location.isActive)}
                            >
                              {location.isActive ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                              {location.isActive ? 'Desactivar' : 'Activar'}
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteLocation(location.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    {/* Información de ubicación */}
                    <div className="space-y-2 mb-4">
                      <Badge style={{ backgroundColor: `${typeColor}20`, color: typeColor }}>
                        {locationTypes.find(t => t.value === location.type)?.label || location.type}
                      </Badge>
                      
                      {location.city && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Globe className="w-4 h-4 mr-2" />
                          <span>{location.city}, {location.country}</span>
                        </div>
                      )}
                      
                      {location.address && (
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span className="truncate">{location.address}</span>
                        </div>
                      )}

                      {location.routerConfig?.ssid && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Wifi className="w-4 h-4 mr-2" />
                          <span className="truncate">{location.routerConfig.ssid}</span>
                        </div>
                      )}
                    </div>

                    {/* Descripción */}
                    {location.description && (
                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                        {location.description}
                      </p>
                    )}

                    {/* Estadísticas */}
                    {location._count && (
                      <div className="grid grid-cols-3 gap-2 mb-4">
                        <div className="text-center p-2 bg-gray-50 rounded-lg">
                          <p className="text-xs text-gray-500">Portales</p>
                          <p className="font-semibold text-gray-800">{location._count.portals}</p>
                        </div>
                        <div className="text-center p-2 bg-gray-50 rounded-lg">
                          <p className="text-xs text-gray-500">Backups</p>
                          <p className="font-semibold text-gray-800">{location._count.backups}</p>
                        </div>
                        <div className="text-center p-2 bg-gray-50 rounded-lg">
                          <p className="text-xs text-gray-500">Admins</p>
                          <p className="font-semibold text-gray-800">{location._count.admins}</p>
                        </div>
                      </div>
                    )}

                    {/* Fecha de creación */}
                    <div className="pt-4 border-t border-gray-100">
                      <div className="flex items-center text-xs text-gray-500">
                        <Calendar className="w-3 h-3 mr-1" />
                        Creada: {new Date(location.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </FordCard>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
