
/**
 * API Route para gestión de backups del sistema
 * 
 * Funcionalidades:
 * - GET: Listar backups existentes
 * - POST: Crear nuevo backup
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'
import { exec } from 'child_process'
import { promisify } from 'util'
import { writeFile, mkdir, stat } from 'fs/promises'
import { join } from 'path'
import archiver from 'archiver'
import { createWriteStream } from 'fs'

const execAsync = promisify(exec)

const createBackupSchema = z.object({
  name: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  type: z.enum(['FULL', 'PARTIAL', 'INCREMENTAL']).default('FULL'),
  locationId: z.string().optional(),
  compressionType: z.enum(['gzip', 'zip', 'none']).default('gzip'),
  isEncrypted: z.boolean().default(false),
  retentionDays: z.number().min(1).max(365).default(30),
  includeTables: z.array(z.string()).optional(),
  excludeTables: z.array(z.string()).optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/backup
 * Obtener lista de backups
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1', 10)
    const pageSize = parseInt(searchParams.get('pageSize') || '20', 10)
    const status = searchParams.get('status') || ''
    const type = searchParams.get('type') || ''

    const skip = (page - 1) * pageSize

    // Construir filtros
    const where: any = {}
    
    if (status) {
      where.status = status
    }

    if (type) {
      where.type = type
    }

    const [backups, total] = await Promise.all([
      prisma.backup.findMany({
        where,
        skip,
        take: pageSize,
        include: {
          location: {
            select: {
              id: true,
              name: true,
              code: true
            }
          }
        },
        orderBy: [
          { startedAt: 'desc' }
        ]
      }),
      prisma.backup.count({ where })
    ])

    // Convertir BigInt a string para JSON
    const safeBackups = backups.map((backup: any) => ({
      ...backup,
      fileSize: backup.fileSize?.toString() || null
    }))

    return NextResponse.json({
      success: true,
      data: safeBackups,
      meta: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize)
      }
    })

  } catch (error) {
    console.error('Error fetching backups:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/backup
 * Crear nuevo backup
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = createBackupSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const backupConfig = validation.data

    // Crear entrada de backup en base de datos
    const backup = await prisma.backup.create({
      data: {
        name: backupConfig.name,
        type: backupConfig.type,
        status: 'RUNNING',
        locationId: backupConfig.locationId || null,
        compressionType: backupConfig.compressionType,
        isAutomatic: false,
        isEncrypted: backupConfig.isEncrypted,
        retentionDays: backupConfig.retentionDays,
        createdBy: session.user.id,
        metadata: {
          includeTables: backupConfig.includeTables,
          excludeTables: backupConfig.excludeTables,
          requestedBy: session.user.name || session.user.email || 'Admin'
        }
      }
    })

    // Ejecutar backup en background
    executeBackup(backup.id, backupConfig).catch(error => {
      console.error('Background backup failed:', error)
      // Actualizar estado del backup a FAILED
      prisma.backup.update({
        where: { id: backup.id },
        data: {
          status: 'FAILED',
          errorMessage: error.message,
          completedAt: new Date()
        }
      }).catch(console.error)
    })

    return NextResponse.json({
      success: true,
      data: {
        ...backup,
        fileSize: backup.fileSize?.toString() || null
      },
      message: 'Backup iniciado exitosamente'
    }, { status: 201 })

  } catch (error) {
    console.error('Error creating backup:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * Ejecutar backup en background
 */
async function executeBackup(backupId: string, config: any) {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
    const fileName = `backup_${timestamp}.sql`
    
    // Crear directorio de backups si no existe
    const backupDir = join(process.cwd(), 'backups')
    try {
      await mkdir(backupDir, { recursive: true })
    } catch (error) {
      // Directorio ya existe
    }

    const filePath = join(backupDir, fileName)

    // Obtener configuración de base de datos
    const databaseUrl = process.env.DATABASE_URL
    if (!databaseUrl) {
      throw new Error('DATABASE_URL no configurada')
    }

    // Parsear URL de base de datos
    const dbUrl = new URL(databaseUrl)
    const dbName = dbUrl.pathname.slice(1)
    const host = dbUrl.hostname
    const port = dbUrl.port || '5432'
    const username = dbUrl.username
    const password = dbUrl.password

    // Comando pg_dump
    let pgDumpCommand = `PGPASSWORD="${password}" pg_dump -h ${host} -p ${port} -U ${username} -d ${dbName} --no-password --verbose`

    // Aplicar filtros si existen
    if (config.includeTables && config.includeTables.length > 0) {
      pgDumpCommand += ` ${config.includeTables.map((table: string) => `-t ${table}`).join(' ')}`
    }

    if (config.excludeTables && config.excludeTables.length > 0) {
      pgDumpCommand += ` ${config.excludeTables.map((table: string) => `-T ${table}`).join(' ')}`
    }

    pgDumpCommand += ` > ${filePath}`

    // Ejecutar backup
    await execAsync(pgDumpCommand)

    // Comprimir si es necesario
    let finalFilePath = filePath
    if (config.compressionType === 'gzip') {
      await execAsync(`gzip ${filePath}`)
      finalFilePath = `${filePath}.gz`
    } else if (config.compressionType === 'zip') {
      const zipPath = `${filePath}.zip`
      await new Promise<void>((resolve, reject) => {
        const output = createWriteStream(zipPath)
        const archive = archiver('zip', { zlib: { level: 9 } })
        
        output.on('close', resolve)
        archive.on('error', reject)
        
        archive.pipe(output)
        archive.file(filePath, { name: fileName })
        archive.finalize()
      })
      finalFilePath = zipPath
    }

    // Obtener tamaño del archivo
    const stats = await stat(finalFilePath)
    
    // Actualizar backup en base de datos
    await prisma.backup.update({
      where: { id: backupId },
      data: {
        status: 'COMPLETED',
        filePath: finalFilePath,
        fileSize: BigInt(stats.size),
        completedAt: new Date()
      }
    })

  } catch (error) {
    console.error('Backup execution failed:', error)
    throw error
  }
}
