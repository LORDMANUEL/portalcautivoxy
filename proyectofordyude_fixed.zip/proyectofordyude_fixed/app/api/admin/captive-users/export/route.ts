
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


/**
 * GET - Exporta datos de usuarios en diferentes formatos
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const format = searchParams.get('format') || 'csv';

    // Datos simulados para export
    const userData = [
      ['Usuario', 'Email', 'Portal', 'Dispositivo', 'Fecha Conexión', 'Duración (min)', 'Estado'],
      ['Usuario 1', 'usuario1@email.com', 'Ford General', 'mobile', '2025-01-15', '25', 'Desconectado'],
      ['Usuario 2', '', 'QuickLane Truck', 'desktop', '2025-01-15', '18', 'Activo'],
      ['Usuario 3', 'usuario3@email.com', 'QuickLane Tegus', 'tablet', '2025-01-14', '32', 'Desconectado']
    ];

    if (format === 'csv') {
      const csvContent = userData
        .map(row => row.map(cell => `"${cell}"`).join(','))
        .join('\n');

      return new NextResponse(csvContent, {
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename="usuarios-portal.csv"'
        }
      });
    }

    if (format === 'excel') {
      // Simulación de Excel (en realidad sería un CSV con headers especiales)
      const excelContent = userData
        .map(row => row.join('\t'))
        .join('\n');

      return new NextResponse(excelContent, {
        headers: {
          'Content-Type': 'application/vnd.ms-excel',
          'Content-Disposition': 'attachment; filename="usuarios-portal.xls"'
        }
      });
    }

    if (format === 'pdf') {
      // Simulación de PDF (texto plano)
      const pdfContent = `
REPORTE DE USUARIOS DEL PORTAL CAUTIVO
======================================

Fecha de generación: ${new Date().toLocaleDateString()}
Total de usuarios: ${userData.length - 1}

${userData.map(row => row.join(' | ')).join('\n')}

---
Generado por Ford Yude Canahuati Portal Admin
      `.trim();

      return new NextResponse(pdfContent, {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': 'attachment; filename="usuarios-portal.pdf"'
        }
      });
    }

    return NextResponse.json({ error: 'Formato no soportado' }, { status: 400 });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
