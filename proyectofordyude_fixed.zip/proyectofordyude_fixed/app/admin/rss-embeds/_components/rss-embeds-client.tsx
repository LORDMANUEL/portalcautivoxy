

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Code, Rss } from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { RssEmbedGenerator } from '../../rss/_components/rss-embed-generator';

interface RssFeed {
  id: string;
  title: string;
  description?: string;
  url: string;
  isActive: boolean;
  category: string;
  itemCount: number;
}

export function RssEmbedsClient() {
  const [feeds, setFeeds] = useState<RssFeed[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeeds();
  }, []);

  const loadFeeds = async () => {
    setLoading(true);
    
    // Simulate API call - En el futuro, esto se conectará a la API real
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockFeeds: RssFeed[] = [
      {
        id: '1',
        title: 'Noticias Ford Global',
        description: 'Últimas noticias y novedades de Ford a nivel mundial',
        url: 'https://media.ford.com/rss/releases.xml',
        isActive: true,
        category: 'ford',
        itemCount: 15
      },
      {
        id: '2',
        title: 'Ford Honduras Noticias',
        description: 'Noticias locales de Ford Honduras',
        url: 'https://example.com/ford-honduras.xml',
        isActive: true,
        category: 'local',
        itemCount: 8
      },
      {
        id: '3',
        title: 'Noticias Automotrices',
        description: 'Últimas tendencias del sector automotriz',
        url: 'https://example.com/automotive-news.xml',
        isActive: true,
        category: 'automotive',
        itemCount: 12
      }
    ];
    
    setFeeds(mockFeeds);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-64 animate-pulse" />
        </div>
        <div className="h-96 bg-gray-200 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
      >
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center">
            <Code className="w-7 h-7 mr-3 text-[#003478]" />
            RSS Embebidos
          </h1>
          <p className="text-gray-600">
            Genera códigos iframe y links embebidos para integrar RSS feeds en otros sitios web
          </p>
        </div>
      </motion.div>

      {/* Información */}
      <FordCard className="p-6">
        <div className="flex items-start space-x-4">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 bg-[#003478] bg-opacity-10 rounded-lg flex items-center justify-center">
              <Rss className="w-6 h-6 text-[#003478]" />
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">¿Qué son los RSS Embebidos?</h3>
            <p className="text-gray-600 mb-4">
              Los RSS embebidos te permiten mostrar automáticamente las últimas noticias de tus feeds RSS 
              en cualquier sitio web. Simplemente copia el código iframe generado y pégalo en tu sitio.
            </p>
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <span className="flex items-center">
                <Code className="w-4 h-4 mr-1" />
                Código iframe personalizable
              </span>
              <span>Diseño responsive</span>
              <span>Actualización automática</span>
            </div>
          </div>
        </div>
      </FordCard>

      {/* Generador de embebidos */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <RssEmbedGenerator feeds={feeds} />
      </motion.div>
    </div>
  );
}
