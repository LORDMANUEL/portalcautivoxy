
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart3,
  Download,
  Filter,
  Calendar,
  MapPin,
  Smartphone,
  Clock,
  Users,
  TrendingUp,
  FileText,
  Table
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import {
  ConnectionsAreaChart,
  LocationBarChart,
  DeviceDistributionChart,
  MultiPortalChart,
  HourlyPerformanceRadar,
  Advanced3DSurfaceChart,
  CorrelationScatterChart,
  AnimatedMetric
} from './enhanced-charts';

interface ReportFilters {
  dateFrom: Date;
  dateTo: Date;
  location?: string;
  portalType?: string;
  deviceType?: string;
}

export function ReportsClient() {
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  
  const [dashboardStats, setDashboardStats] = useState({
    totalConnections: 0,
    activeUsers: 0,
    averageSession: 0,
    topLocation: ''
  });
  
  const [chartData, setChartData] = useState({
    connections: [] as any[],
    locations: [] as any[],
    devices: [] as any[],
    portals: [] as any[],
    hourly: [] as any[],
    surface3d: [] as any[],
    correlation: [] as any[]
  });

  const [filters, setFilters] = useState<ReportFilters>({
    dateFrom: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    dateTo: new Date(),
    location: 'ALL_LOCATIONS',
    portalType: 'ALL_PORTALS',
    deviceType: ''
  });

  useEffect(() => {
    fetchReportsData();
  }, [filters]);

  const fetchReportsData = async () => {
    setLoading(true);
    try {
      const [statsResponse, chartsResponse] = await Promise.all([
        mockStatsAPI(),
        mockChartsAPI()
      ]);

      setDashboardStats(statsResponse);
      setChartData(chartsResponse);
    } catch (error) {
      toast.error('Error al cargar datos de reportes');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const mockStatsAPI = async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return {
      totalConnections: 15420,
      activeUsers: 342,
      averageSession: 28,
      topLocation: 'San Pedro Sula'
    };
  };

  const mockChartsAPI = async () => {
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const connections = Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString('es'),
      connections: Math.floor(Math.random() * 200) + 100,
      formattedDate: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString('es')
    }));

    const locations = [
      { location: 'San Pedro Sula', connections: 4250 },
      { location: 'Tegucigalpa', connections: 3850 },
      { location: 'La Ceiba', connections: 2100 },
      { location: 'QuickLane SPS', connections: 3200 },
      { location: 'QuickLane Tegus', connections: 2020 }
    ];

    const devices = [
      { name: 'Mobile', value: 8500, percentage: 55 },
      { name: 'Desktop', value: 4200, percentage: 27 },
      { name: 'Tablet', value: 2720, percentage: 18 }
    ];

    const portals = Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000).toLocaleDateString('es'),
      ford: Math.floor(Math.random() * 150) + 80,
      quicklane_truck: Math.floor(Math.random() * 100) + 40,
      quicklane_tegus: Math.floor(Math.random() * 80) + 30,
      quicklane_sps: Math.floor(Math.random() * 120) + 50
    }));

    const hourly = Array.from({ length: 24 }, (_, i) => ({
      hour: `${i}:00`,
      connections: Math.floor(Math.random() * 100) + 20
    }));

    const surface3d = Array.from({ length: 7 }, (_, day) =>
      Array.from({ length: 24 }, (_, hour) => ({
        day: day + 1,
        hour: hour,
        connections: Math.floor(Math.random() * 150) + 50
      }))
    ).flat();

    const correlation = Array.from({ length: 100 }, () => ({
      sessionDuration: Math.floor(Math.random() * 60) + 5,
      pagesViewed: Math.floor(Math.random() * 20) + 1
    }));

    return {
      connections,
      locations,
      devices,
      portals,
      hourly,
      surface3d,
      correlation
    };
  };

  const handleExportPDF = async () => {
    setExporting('pdf');
    try {
      const response = await fetch('/api/admin/reports/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          format: 'pdf',
          filters,
          data: { dashboardStats, chartData }
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `reporte-ford-${new Date().toISOString().split('T')[0]}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Reporte PDF descargado correctamente');
      } else {
        throw new Error('Error en la exportación');
      }
    } catch (error) {
      toast.error('Error al exportar PDF');
    } finally {
      setExporting(null);
    }
  };

  const handleExportExcel = async () => {
    setExporting('excel');
    try {
      const response = await fetch('/api/admin/reports/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          format: 'excel',
          filters,
          data: { dashboardStats, chartData }
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `reporte-ford-${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Reporte Excel descargado correctamente');
      } else {
        throw new Error('Error en la exportación');
      }
    } catch (error) {
      toast.error('Error al exportar Excel');
    } finally {
      setExporting(null);
    }
  };

  const handleExportCSV = async () => {
    setExporting('csv');
    try {
      const response = await fetch('/api/admin/reports/export', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          format: 'csv',
          filters,
          data: { dashboardStats, chartData }
        }),
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `reporte-ford-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Reporte CSV descargado correctamente');
      } else {
        throw new Error('Error en la exportación');
      }
    } catch (error) {
      toast.error('Error al exportar CSV');
    } finally {
      setExporting(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando reportes..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <BarChart3 className="w-8 h-8 text-[#003478]" />
            Reportes Interactivos
          </h1>
          <p className="text-gray-600 mt-1">
            Análisis completo de datos del portal cautivo Ford
          </p>
        </div>

        <div className="flex space-x-2">
          <FordButton
            variant="outline"
            onClick={handleExportPDF}
            disabled={!!exporting}
          >
            {exporting === 'pdf' ? (
              <LoadingSpinner size="sm" />
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                PDF
              </>
            )}
          </FordButton>
          
          <FordButton
            variant="outline"
            onClick={handleExportExcel}
            disabled={!!exporting}
          >
            {exporting === 'excel' ? (
              <LoadingSpinner size="sm" />
            ) : (
              <>
                <Table className="w-4 h-4 mr-2" />
                Excel
              </>
            )}
          </FordButton>
          
          <FordButton
            variant="outline"
            onClick={handleExportCSV}
            disabled={!!exporting}
          >
            {exporting === 'csv' ? (
              <LoadingSpinner size="sm" />
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                CSV
              </>
            )}
          </FordButton>
        </div>
      </div>

      <FordCard className="p-6">
        <div className="flex items-center space-x-4 mb-4">
          <Filter className="w-5 h-5 text-[#003478]" />
          <h3 className="text-lg font-semibold text-gray-800">Filtros de Análisis</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="space-y-2">
            <Label>Ubicación</Label>
            <Select
              value={filters.location}
              onValueChange={(value) => setFilters(prev => ({ ...prev, location: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todas las ubicaciones" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL_LOCATIONS">Todas las ubicaciones</SelectItem>
                <SelectItem value="sps">San Pedro Sula</SelectItem>
                <SelectItem value="tegus">Tegucigalpa</SelectItem>
                <SelectItem value="ceiba">La Ceiba</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Tipo de Portal</Label>
            <Select
              value={filters.portalType}
              onValueChange={(value) => setFilters(prev => ({ ...prev, portalType: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Todos los portales" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL_PORTALS">Todos los portales</SelectItem>
                <SelectItem value="ford">Portal Ford</SelectItem>
                <SelectItem value="quicklane_truck">QuickLane Truck</SelectItem>
                <SelectItem value="quicklane_tegus">QuickLane Tegus</SelectItem>
                <SelectItem value="quicklane_sps">QuickLane SPS</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </FordCard>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatedMetric
          title="Conexiones Totales"
          value={dashboardStats.totalConnections}
          icon={<Users />}
          trend={{ value: 12.5, isPositive: true }}
        />
        <AnimatedMetric
          title="Usuarios Activos"
          value={dashboardStats.activeUsers}
          icon={<TrendingUp />}
          color="#47A8E5"
          trend={{ value: 8.3, isPositive: true }}
        />
        <AnimatedMetric
          title="Sesión Promedio"
          value={dashboardStats.averageSession}
          suffix=" min"
          icon={<Clock />}
          color="#2A6BAC"
          trend={{ value: 4.7, isPositive: false }}
        />
        <AnimatedMetric
          title="Ubicación Top"
          value={4250}
          icon={<MapPin />}
          color="#133A7C"
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">General</TabsTrigger>
          <TabsTrigger value="locations">Ubicaciones</TabsTrigger>
          <TabsTrigger value="devices">Dispositivos</TabsTrigger>
          <TabsTrigger value="portals">Portales</TabsTrigger>
          <TabsTrigger value="advanced">Avanzado</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ConnectionsAreaChart
              data={chartData.connections}
              title="Conexiones Diarias"
              description="Tendencia de conexiones en los últimos 30 días"
            />
            <LocationBarChart
              data={chartData.locations}
              title="Conexiones por Ubicación"
              description="Distribución de conexiones por sucursal"
            />
          </div>
        </TabsContent>

        <TabsContent value="locations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <LocationBarChart
              data={chartData.locations}
              title="Análisis Detallado por Ubicación"
              description="Comparativo de rendimiento entre sucursales"
            />
            <HourlyPerformanceRadar
              data={chartData.hourly}
              title="Rendimiento por Horas"
              description="Patrón de conexiones durante el día"
            />
          </div>
        </TabsContent>

        <TabsContent value="devices" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DeviceDistributionChart
              data={chartData.devices}
              title="Distribución de Dispositivos"
              description="Tipos de dispositivos más utilizados"
            />
            <CorrelationScatterChart
              data={chartData.correlation}
              title="Correlación Sesión vs Páginas"
              description="Relación entre duración de sesión y páginas visitadas"
            />
          </div>
        </TabsContent>

        <TabsContent value="portals" className="space-y-6">
          <MultiPortalChart
            data={chartData.portals}
            title="Comparativo de Portales Múltiples"
            description="Rendimiento de Ford vs QuickLane portales"
          />
        </TabsContent>

        <TabsContent value="advanced" className="space-y-6">
          <Advanced3DSurfaceChart
            data={chartData.surface3d}
            title="Análisis 3D Temporal"
            description="Vista tridimensional de conexiones por día y hora"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
