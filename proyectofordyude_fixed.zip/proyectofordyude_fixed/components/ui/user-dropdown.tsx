
'use client';

import { useState, useEffect, useRef } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Settings, 
  LogOut, 
  ChevronDown, 
  UserCog,
  Shield,
  Clock,
  Activity
} from 'lucide-react';

export function UserDropdown() {
  const { data: session } = useSession();
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [userStats, setUserStats] = useState({
    lastLogin: new Date().toLocaleString(),
    activeSession: '2h 34m',
    role: 'Super Admin'
  });
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Cerrar dropdown al hacer clic fuera
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = async () => {
    try {
      await signOut({ callbackUrl: '/admin/login' });
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  if (!session?.user) return null;

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 transition-colors"
      >
        <div className="w-8 h-8 bg-[#003478] rounded-full flex items-center justify-center">
          <span className="text-white text-sm font-bold">
            {session.user.name?.charAt(0)?.toUpperCase() || 'A'}
          </span>
        </div>
        <div className="text-left hidden md:block">
          <div className="text-sm font-medium text-gray-700">
            {session.user.name || 'Administrador'}
          </div>
          <div className="text-xs text-gray-500">{userStats.role}</div>
        </div>
        <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 mt-2 w-72 bg-white border border-gray-200 rounded-lg shadow-lg z-50"
          >
            {/* Header del usuario */}
            <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-[#003478] to-[#47A8E5]">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-white text-lg font-bold">
                    {session.user.name?.charAt(0)?.toUpperCase() || 'A'}
                  </span>
                </div>
                <div className="text-white">
                  <div className="font-medium">{session.user.name || 'Administrador'}</div>
                  <div className="text-sm text-blue-100">{session.user.email}</div>
                  <div className="text-xs text-blue-200 flex items-center mt-1">
                    <Shield className="w-3 h-3 mr-1" />
                    {userStats.role}
                  </div>
                </div>
              </div>
            </div>

            {/* Estadísticas del usuario */}
            <div className="p-4 border-b border-gray-100 bg-gray-50">
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <div>
                    <div className="text-gray-500">Último acceso</div>
                    <div className="font-medium text-gray-700">{userStats.lastLogin}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-green-500" />
                  <div>
                    <div className="text-gray-500">Sesión activa</div>
                    <div className="font-medium text-green-600">{userStats.activeSession}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Opciones del menú */}
            <div className="p-2">
              <button 
                onClick={() => {
                  setIsOpen(false);
                  router.push('/admin/profile');
                }}
                className="w-full flex items-center space-x-3 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <User className="w-4 h-4" />
                <span>Mi Perfil</span>
              </button>
              
              <button 
                onClick={() => {
                  setIsOpen(false);
                  router.push('/admin/user-settings');
                }}
                className="w-full flex items-center space-x-3 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <UserCog className="w-4 h-4" />
                <span>Configuración de Usuario</span>
              </button>
              
              <button 
                onClick={() => {
                  setIsOpen(false);
                  router.push('/admin/settings');
                }}
                className="w-full flex items-center space-x-3 px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Settings className="w-4 h-4" />
                <span>Configuraciones</span>
              </button>
              
              <hr className="my-2" />
              
              <button 
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Cerrar Sesión</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
