
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const accessPoints = await prisma.accessPoint.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(accessPoints);
  } catch (error) {
    console.error('Error fetching access points:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, ipAddress, macAddress, location, description, imageUrl } = body;

    if (!name?.trim() || !ipAddress?.trim()) {
      return NextResponse.json({ error: 'Nombre e IP son requeridos' }, { status: 400 });
    }

    const accessPoint = await prisma.accessPoint.create({
      data: {
        name: name.trim(),
        ipAddress: ipAddress.trim(),
        macAddress: macAddress?.trim() || null,
        location: location?.trim() || null,
        description: description?.trim() || null,
        imageUrl: imageUrl?.trim() || null,
      },
    });

    return NextResponse.json(accessPoint, { status: 201 });
  } catch (error) {
    console.error('Error creating access point:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
