
'use client';

import { motion } from 'framer-motion';
import { HTMLAttributes, forwardRef } from 'react';
import { cn } from '@/lib/utils';

interface FordCardProps extends HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'blue' | 'glass';
  hover?: boolean;
}

export const FordCard = forwardRef<HTMLDivElement, FordCardProps>(
  ({ className, variant = 'default', hover = true, children, ...props }, ref) => {
    const baseClasses = 'rounded-lg shadow-md transition-all duration-300';
    
    const variants = {
      default: 'bg-white border border-gray-200',
      blue: 'bg-[#003478] text-white',
      glass: 'bg-white/80 backdrop-blur-sm border border-white/20'
    };

    const hoverClasses = hover ? 'hover:shadow-xl hover:-translate-y-1' : '';

    const cardContent = (
      <div
        ref={ref}
        className={cn(baseClasses, variants[variant], hoverClasses, className)}
        {...props}
      >
        {children}
      </div>
    );

    return hover ? (
      <motion.div
        whileHover={{ y: -4, scale: 1.02 }}
        transition={{ duration: 0.2 }}
      >
        {cardContent}
      </motion.div>
    ) : cardContent;
  }
);

FordCard.displayName = 'FordCard';
