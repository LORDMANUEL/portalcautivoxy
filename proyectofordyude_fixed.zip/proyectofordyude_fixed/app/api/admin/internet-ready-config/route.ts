
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


// Configuración personalizable para la página "Ya tienes Internet"
const mockConfig = {
  title: '¡Ya tienes Internet!',
  subtitle: 'Bienvenido a Ford Yude Canahuati',
  message: 'Tu conexión está lista. Explora nuestros servicios y mantente conectado con nosotros.',
  backgroundColor: '#F8FAFC',
  textColor: '#1E293B',
  accentColor: '#003478',
  logoUrl: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
  bannerImages: [
    {
      url: 'https://designcollaborative.com/wp-content/uploads/2021/11/Schmidt_Ford-Dealership_1.jpg',
      title: 'Showroom Ford Moderno',
      description: 'Visita nuestras instalaciones de clase mundial'
    },
    {
      url: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
      title: 'Ford F-150 2025',
      description: 'Descubre la nueva generación de pickups'
    },
    {
      url: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
      title: 'Servicio QuickLane',
      description: 'Mantenimiento express sin cita previa'
    },
    {
      url: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
      title: 'Celebración Aniversario',
      description: 'Años de excelencia automotriz en Honduras'
    }
  ],
  socialLinks: [
    {
      platform: 'Facebook',
      url: 'https://facebook.com/fordyudecanahuati',
      icon: 'facebook'
    },
    {
      platform: 'Instagram',
      url: 'https://instagram.com/fordyudecanahuati',
      icon: 'instagram'
    },
    {
      platform: 'YouTube',
      url: 'https://youtube.com/fordyudecanahuati',
      icon: 'youtube'
    }
  ],
  quickActions: [
    {
      title: 'Agendar Cita',
      description: 'Programa tu servicio',
      url: 'https://fordyude.com/citas',
      icon: 'clock',
      color: '#22C55E'
    },
    {
      title: 'Ver Vehículos',
      description: 'Catálogo completo',
      url: 'https://fordyude.com/vehiculos',
      icon: 'car',
      color: '#3B82F6'
    },
    {
      title: 'Servicios',
      description: 'Mantenimiento y reparación',
      url: 'https://fordyude.com/servicios',
      icon: 'wrench',
      color: '#F59E0B'
    },
    {
      title: 'Contacto',
      description: 'Habla con nosotros',
      url: 'https://fordyude.com/contacto',
      icon: 'phone',
      color: '#EF4444'
    },
    {
      title: 'QuickLane',
      description: 'Servicio express',
      url: 'https://fordyude.com/quicklane',
      icon: 'zap',
      color: '#FF6600'
    },
    {
      title: 'Repuestos',
      description: 'Partes originales Ford',
      url: 'https://fordyude.com/repuestos',
      icon: 'wrench',
      color: '#8B5CF6'
    },
    {
      title: 'Financiamiento',
      description: 'Opciones de crédito',
      url: 'https://fordyude.com/financiamiento',
      icon: 'shield',
      color: '#06B6D4'
    },
    {
      title: 'Ubicaciones',
      description: 'Encuentra nuestras sucursales',
      url: 'https://fordyude.com/ubicaciones',
      icon: 'mapPin',
      color: '#84CC16'
    }
  ],
  promotions: [
    {
      title: 'Ofertas Especiales Ford',
      description: 'Descuentos exclusivos en vehículos nuevos. Financiamiento con tasas preferenciales.',
      imageUrl: 'https://vehicle-images.dealerinspire.com/stock-images/ford/39cad4a9d232ab0d0238f6978baae254.png',
      url: 'https://fordyude.com/ofertas',
      isActive: true
    },
    {
      title: 'Programa de Lealtad Ford',
      description: 'Beneficios exclusivos para clientes Ford. Descuentos en servicios y repuestos.',
      imageUrl: 'https://i.pinimg.com/originals/bd/73/7b/bd737ba02050aa1b08a6901addd69883.jpg',
      url: 'https://fordyude.com/lealtad',
      isActive: true
    },
    {
      title: 'QuickLane Express',
      description: 'Mantenimiento rápido sin cita previa. Cambio de aceite en 15 minutos.',
      imageUrl: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
      url: 'https://fordyude.com/quicklane',
      isActive: true
    },
    {
      title: 'Aniversario Yude',
      description: 'Celebra con nosotros años de excelencia. Ofertas especiales por tiempo limitado.',
      imageUrl: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
      url: 'https://fordyude.com/aniversario',
      isActive: true
    }
  ],
  customContent: {
    showWeather: true,
    showNews: true,
    showPromotions: true,
    showSocialMedia: true,
    showContact: true
  },
  lastUpdated: new Date().toISOString()
};

/**
 * GET - Obtiene configuración de internet-ready
 */
export async function GET(request: NextRequest) {
  try {
    return NextResponse.json(mockConfig);
  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

/**
 * POST - Actualiza configuración de internet-ready
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const updates = await request.json();
    
    // Simular actualización de configuración
    const updatedConfig = {
      ...mockConfig,
      ...updates,
      lastUpdated: new Date().toISOString()
    };

    return NextResponse.json({
      success: true,
      message: 'Configuración actualizada exitosamente',
      config: updatedConfig
    });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
