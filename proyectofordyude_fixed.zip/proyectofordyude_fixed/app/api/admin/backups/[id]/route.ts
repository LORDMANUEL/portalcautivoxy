
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { promises as fs } from 'fs';

export const dynamic = 'force-dynamic';

/**
 * Eliminar backup
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    // Buscar el backup
    const backup = await prisma.backup.findUnique({
      where: { id }
    });

    if (!backup) {
      return NextResponse.json({ error: 'Backup no encontrado' }, { status: 404 });
    }

    // Eliminar archivo físico si existe
    if (backup.filePath) {
      try {
        await fs.unlink(backup.filePath);
      } catch (error) {
        console.warn('No se pudo eliminar el archivo de backup:', error);
      }
    }

    // Eliminar registro de base de datos
    await prisma.backup.delete({
      where: { id }
    });

    return NextResponse.json({ message: 'Backup eliminado correctamente' });
  } catch (error) {
    console.error('Error al eliminar backup:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
