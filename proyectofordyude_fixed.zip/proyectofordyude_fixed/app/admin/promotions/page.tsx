

import { Metadata } from 'next';
import { PromotionsClient } from './_components/promotions-client';

export const metadata: Metadata = {
  title: 'Promociones - Ford Admin',
  description: 'Gestión de promociones y ofertas especiales',
};

export default function PromotionsPage() {
  return <PromotionsClient />;
}
