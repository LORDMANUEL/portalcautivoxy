
/**
 * API Route para restablecimiento de contraseñas de administradores
 * Portal Ford Yude Canahuati
 * 
 * Este endpoint maneja el proceso de cambio de contraseña después de la
 * validación de preguntas de seguridad. Implementa un sistema demo
 * para desarrollo y testing.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';

/**
 * Fuerza el renderizado dinámico para evitar cache en este endpoint sensible
 * Asegura que cada request sea procesado en tiempo real
 */
export const dynamic = 'force-dynamic';

/**
 * Endpoint POST para restablecer contraseña de administrador
 * 
 * Procesa el cambio de contraseña después de validar:
 * - Token de recuperación válido (demo)
 * - Existencia del usuario
 * - Validez de la nueva contraseña
 * 
 * @param request - Request object con token, username y newPassword
 * @returns Promise<NextResponse> - Respuesta JSON con resultado de la operación
 * 
 * @example
 * POST /api/admin/reset-password
 * {
 *   "token": "demo-reset-token",
 *   "username": "admin",
 *   "newPassword": "nueva123"
 * }
 */
export async function POST(request: NextRequest) {
  try {
    // Extracción de datos del request body
    const { token, username, newPassword } = await request.json();

    /**
     * Validación de token demo
     * 
     * NOTA: En producción se debería implementar:
     * - Tokens con expiración temporal
     * - Hash del token en base de datos
     * - Rate limiting por IP
     * - Validación adicional de seguridad
     */
    if (token !== 'demo-reset-token') {
      return NextResponse.json(
        { error: 'Token inválido o expirado' },
        { status: 400 }
      );
    }

    /**
     * Verificación de existencia del usuario administrador
     * Busca por username en la tabla admin
     */
    const admin = await prisma.admin.findUnique({
      where: { username }
    });

    if (!admin) {
      return NextResponse.json(
        { error: 'Usuario no encontrado' },
        { status: 404 }
      );
    }

    /**
     * Validación de robustez de la nueva contraseña
     * Requisitos mínimos: al menos 6 caracteres
     * 
     * NOTA: En producción se recomienda validaciones más estrictas:
     * - Mínimo 8 caracteres
     * - Al menos una mayúscula, minúscula y número
     * - Caracteres especiales
     */
    if (!newPassword || newPassword.length < 6) {
      return NextResponse.json(
        { error: 'La contraseña debe tener al menos 6 caracteres' },
        { status: 400 }
      );
    }

    /**
     * Hash seguro de la nueva contraseña usando bcrypt
     * Salt rounds: 12 (nivel de seguridad alto)
     */
    const hashedPassword = await bcrypt.hash(newPassword, 12);

    /**
     * Actualización de la contraseña en base de datos
     * También actualiza el timestamp de modificación
     */
    await prisma.admin.update({
      where: { username },
      data: { 
        password: hashedPassword,
        updatedAt: new Date()
      }
    });

    /**
     * Registro de auditoría en logs del sistema
     * Importante para trazabilidad de seguridad
     */
    await prisma.log.create({
      data: {
        userType: 'ADMIN',
        action: 'PASSWORD_RESET',
        description: `Contraseña restablecida para el usuario: ${username}`,
        ipAddress: request.headers.get('x-forwarded-for') || 'unknown',
        userAgent: request.headers.get('user-agent') || 'unknown',
        severity: 'INFO'
      }
    });

    // Respuesta exitosa
    return NextResponse.json({
      message: 'Contraseña actualizada exitosamente'
    });

  } catch (error) {
    // Logging de errores para debugging
    console.error('Error al restablecer contraseña:', error);
    
    // Respuesta genérica de error para no exponer detalles internos
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
