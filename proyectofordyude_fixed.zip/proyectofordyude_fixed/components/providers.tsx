
"use client";

import { ThemeProvider } from "@/components/theme-provider";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import { Toaster } from "sonner";

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Cache por 5 minutos por defecto
            staleTime: 5 * 60 * 1000,
            // Cache en segundo plano por 10 minutos
            gcTime: 10 * 60 * 1000,
            // Reintentar en caso de error
            retry: (failureCount, error: any) => {
              // No reintentar para errores 404 o de autenticación
              if (error?.status === 404 || error?.status === 401) {
                return false;
              }
              // Reintentar hasta 3 veces para otros errores
              return failureCount < 3;
            },
            // Refetch cuando la ventana recibe focus
            refetchOnWindowFocus: true,
            // Refetch cuando se reconecta
            refetchOnReconnect: true,
          },
          mutations: {
            // Reintentar mutaciones fallidas una vez
            retry: 1,
          },
        },
      })
  );

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider
        attribute="class"
        defaultTheme="system"
        enableSystem
        disableTransitionOnChange={false}
      >
        {children}
        <Toaster 
          position="top-right"
          expand={true}
          richColors
          closeButton
          toastOptions={{
            duration: 4000,
            className: "glass border-border",
          }}
        />
      </ThemeProvider>
      
      {/* Mostrar DevTools solo en desarrollo */}
      {process.env.NODE_ENV === 'development' && (
        <div id="react-query-devtools">
          {/* DevTools se cargarán dinámicamente si están disponibles */}
        </div>
      )}
    </QueryClientProvider>
  );
}
