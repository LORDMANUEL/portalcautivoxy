

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Link2,
  Plus,
  Edit,
  Trash2,
  Copy,
  ExternalLink,
  QrCode,
  Eye,
  MapPin,
  Palette,
  Calendar,
  Users,
  BarChart3
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';

interface PortalToken {
  id: string;
  token: string;
  name: string;
  description: string;
  themeId: string;
  portalType: string;
  isActive: boolean;
  maxUses: number | null;
  currentUses: number;
  expiresAt: string | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface PortalTokenFormData {
  name: string;
  description: string;
  themeId: string;
  portalType: string;
  isActive: boolean;
  maxUses: string;
  expiresAt: string;
}

// Tipos de portales disponibles
const portalTypes = [
  { value: 'ford', label: 'Portal Ford Tradicional', color: '#003478' },
  { value: 'quicklane_truck', label: 'QuickLane Truck', color: '#FF6B35' },
  { value: 'quicklane_tegus', label: 'QuickLane Tegucigalpa', color: '#4ECDC4' },
  { value: 'quicklane_sps', label: 'QuickLane San Pedro Sula', color: '#45B7D1' },
];

// Temas disponibles
const themes = [
  { value: 'default', label: 'Tema Por Defecto' },
  { value: 'mother', label: 'Día de la Madre' },
  { value: 'woman', label: 'Día de la Mujer' },
  { value: 'man', label: 'Día del Hombre' },
  { value: 'independence', label: 'Independencia Honduras' },
  { value: 'xmas', label: 'Navidad' },
  { value: 'summer', label: 'Verano' },
];

/**
 * Cliente para gestionar enlaces de portales cautivos
 * Permite crear tokens únicos para diferentes portales y temas
 */
export function PortalLinksClient() {
  const [tokens, setTokens] = useState<PortalToken[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingToken, setEditingToken] = useState<PortalToken | null>(null);
  const [generating, setGenerating] = useState(false);

  // Formulario de datos del token
  const [formData, setFormData] = useState<PortalTokenFormData>({
    name: '',
    description: '',
    themeId: 'default',
    portalType: 'ford',
    isActive: true,
    maxUses: '',
    expiresAt: ''
  });

  useEffect(() => {
    fetchTokens();
  }, []);

  /**
   * Obtiene todos los tokens de portales
   */
  const fetchTokens = async () => {
    try {
      const response = await fetch('/api/admin/portal-tokens');
      if (response.ok) {
        const data = await response.json();
        setTokens(data);
      } else {
        toast.error('Error al cargar los tokens');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Maneja los cambios en el formulario
   */
  const handleInputChange = (field: keyof PortalTokenFormData, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  /**
   * Genera o actualiza un token de portal
   */
  const handleSaveToken = async () => {
    if (!formData.name) {
      toast.error('El nombre es obligatorio');
      return;
    }

    setGenerating(true);
    try {
      const url = editingToken ? `/api/admin/portal-tokens/${editingToken.id}` : '/api/admin/portal-tokens';
      const method = editingToken ? 'PUT' : 'POST';

      const payload = {
        ...formData,
        maxUses: formData.maxUses ? parseInt(formData.maxUses) : null,
        expiresAt: formData.expiresAt || null
      };

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(editingToken ? 'Token actualizado correctamente' : 'Token creado correctamente');
        setIsModalOpen(false);
        setEditingToken(null);
        resetForm();
        fetchTokens();
      } else {
        toast.error('Error al guardar el token');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setGenerating(false);
    }
  };

  /**
   * Abre el modal para editar un token existente
   */
  const handleEditToken = (token: PortalToken) => {
    setEditingToken(token);
    setFormData({
      name: token.name,
      description: token.description || '',
      themeId: token.themeId || 'default',
      portalType: token.portalType,
      isActive: token.isActive,
      maxUses: token.maxUses?.toString() || '',
      expiresAt: token.expiresAt ? new Date(token.expiresAt).toISOString().split('T')[0] : ''
    });
    setIsModalOpen(true);
  };

  /**
   * Elimina un token
   */
  const handleDeleteToken = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este token?')) return;

    try {
      const response = await fetch(`/api/admin/portal-tokens/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Token eliminado correctamente');
        fetchTokens();
      } else {
        toast.error('Error al eliminar el token');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Copia el enlace del portal al portapapeles
   */
  const handleCopyLink = async (token: string) => {
    const url = `${window.location.origin}/portal/${token}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success('Enlace copiado al portapapeles');
    } catch (error) {
      toast.error('Error al copiar el enlace');
    }
  };

  /**
   * Abre el portal en nueva pestaña
   */
  const handleOpenPortal = (token: string) => {
    const url = `${window.location.origin}/portal/${token}`;
    window.open(url, '_blank');
  };

  /**
   * Resetea el formulario
   */
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      themeId: 'default',
      portalType: 'ford',
      isActive: true,
      maxUses: '',
      expiresAt: ''
    });
  };

  /**
   * Obtiene el color del tipo de portal
   */
  const getPortalTypeColor = (type: string) => {
    return portalTypes.find(pt => pt.value === type)?.color || '#003478';
  };

  /**
   * Obtiene el label del tipo de portal
   */
  const getPortalTypeLabel = (type: string) => {
    return portalTypes.find(pt => pt.value === type)?.label || type;
  };

  /**
   * Obtiene el label del tema
   */
  const getThemeLabel = (themeId: string) => {
    return themes.find(t => t.value === themeId)?.label || 'Tema Desconocido';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando portales..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con título y acciones */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <Link2 className="w-8 h-8 text-[#003478]" />
            Links Portales Cautivos
          </h1>
          <p className="text-gray-600 mt-1">
            Gestiona enlaces para múltiples portales Ford y QuickLane
          </p>
        </div>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <FordButton 
              onClick={() => {
                setEditingToken(null);
                resetForm();
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Token
            </FordButton>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingToken ? 'Editar Token' : 'Nuevo Token de Portal'}
              </DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="name">Nombre del Token *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Portal Ford Promocional"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Portal para campaña promocional de primavera"
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="portalType">Tipo de Portal</Label>
                <Select
                  value={formData.portalType}
                  onValueChange={(value) => handleInputChange('portalType', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {portalTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center space-x-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: type.color }}
                          />
                          <span>{type.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="themeId">Tema</Label>
                <Select
                  value={formData.themeId}
                  onValueChange={(value) => handleInputChange('themeId', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {themes.map((theme) => (
                      <SelectItem key={theme.value} value={theme.value}>
                        {theme.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxUses">Máximo de Usos</Label>
                <Input
                  id="maxUses"
                  type="number"
                  value={formData.maxUses}
                  onChange={(e) => handleInputChange('maxUses', e.target.value)}
                  placeholder="Dejar vacío para ilimitado"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="expiresAt">Fecha de Expiración</Label>
                <Input
                  id="expiresAt"
                  type="date"
                  value={formData.expiresAt}
                  onChange={(e) => handleInputChange('expiresAt', e.target.value)}
                />
              </div>

              <div className="flex items-center space-x-2 md:col-span-2">
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => handleInputChange('isActive', checked)}
                />
                <Label htmlFor="isActive">Token Activo</Label>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <FordButton
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingToken(null);
                  resetForm();
                }}
              >
                Cancelar
              </FordButton>
              <FordButton onClick={handleSaveToken} disabled={generating}>
                {generating ? (
                  <LoadingSpinner size="sm" message="Generando..." />
                ) : (
                  <>
                    <Link2 className="w-4 h-4 mr-2" />
                    {editingToken ? 'Actualizar' : 'Generar Token'}
                  </>
                )}
              </FordButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de tokens */}
      {tokens.length === 0 ? (
        <FordCard className="text-center py-12">
          <Link2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            No hay tokens de portal
          </h3>
          <p className="text-gray-500 mb-4">
            Crea tu primer token para comenzar
          </p>
        </FordCard>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {tokens.map((token) => (
            <motion.div
              key={token.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="group"
            >
              <FordCard className="h-full hover:shadow-lg transition-all duration-200">
                <div className="p-6">
                  {/* Header con tipo de portal */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div 
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: getPortalTypeColor(token.portalType) }}
                      />
                      <div>
                        <h3 className="font-semibold text-gray-800">
                          {token.name}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {getPortalTypeLabel(token.portalType)}
                        </p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      token.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {token.isActive ? 'Activo' : 'Inactivo'}
                    </span>
                  </div>

                  {/* Descripción */}
                  {token.description && (
                    <p className="text-sm text-gray-600 mb-4">
                      {token.description}
                    </p>
                  )}

                  {/* Información del token */}
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Palette className="w-4 h-4 mr-2" />
                      <span>Tema: {getThemeLabel(token.themeId)}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Users className="w-4 h-4 mr-2" />
                      <span>
                        Usos: {token.currentUses}
                        {token.maxUses ? ` / ${token.maxUses}` : ' (ilimitado)'}
                      </span>
                    </div>
                    {token.expiresAt && (
                      <div className="flex items-center text-sm text-gray-600">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>
                          Expira: {new Date(token.expiresAt).toLocaleDateString()}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Token único */}
                  <div className="bg-gray-50 rounded-lg p-3 mb-4">
                    <Label className="text-xs text-gray-500 mb-1 block">Token:</Label>
                    <div className="flex items-center justify-between">
                      <code className="text-sm font-mono text-gray-800 truncate">
                        {token.token}
                      </code>
                      <FordButton
                        size="sm"
                        variant="ghost"
                        onClick={() => handleCopyLink(token.token)}
                      >
                        <Copy className="w-4 h-4" />
                      </FordButton>
                    </div>
                  </div>

                  {/* Acciones */}
                  <div className="flex space-x-2">
                    <FordButton
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => handleOpenPortal(token.token)}
                    >
                      <ExternalLink className="w-4 h-4 mr-1" />
                      Abrir
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleCopyLink(token.token)}
                    >
                      <Copy className="w-4 h-4" />
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleEditToken(token)}
                    >
                      <Edit className="w-4 h-4" />
                    </FordButton>
                    <FordButton
                      size="sm"
                      variant="outline"
                      onClick={() => handleDeleteToken(token.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </FordButton>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
