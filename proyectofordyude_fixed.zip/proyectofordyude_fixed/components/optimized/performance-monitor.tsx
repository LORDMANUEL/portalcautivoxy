
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Clock, Database, Wifi } from "lucide-react";

interface PerformanceMetrics {
  loadTime: number;
  fcp: number; // First Contentful Paint
  lcp: number; // Largest Contentful Paint
  cls: number; // Cumulative Layout Shift
  fid: number; // First Input Delay
  connectionType: string;
  memory: number;
}

export function PerformanceMonitor() {
  const [metrics, setMetrics] = useState<PerformanceMetrics | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Solo mostrar en desarrollo
    if (process.env.NODE_ENV !== 'development') return;

    const measurePerformance = () => {
      // Web Vitals básicos
      const navigation = performance.getEntriesByType('navigation')[0] as any;
      const paint = performance.getEntriesByType('paint');
      
      const fcp = paint.find(entry => entry.name === 'first-contentful-paint')?.startTime || 0;
      
      // Calcular tiempo de carga usando datos disponibles
      const loadTime = navigation?.loadEventEnd && navigation?.fetchStart 
        ? navigation.loadEventEnd - navigation.fetchStart 
        : 0;
      
      // Simulación de métricas (en producción usarías bibliotecas como web-vitals)
      const newMetrics: PerformanceMetrics = {
        loadTime,
        fcp,
        lcp: fcp + Math.random() * 1000, // Simulado
        cls: Math.random() * 0.1, // Simulado
        fid: Math.random() * 100, // Simulado
        connectionType: (navigator as any)?.connection?.effectiveType || 'unknown',
        memory: (performance as any)?.memory?.usedJSHeapSize || 0,
      };
      
      setMetrics(newMetrics);
    };

    // Medir después de que la página esté completamente cargada
    if (document.readyState === 'complete') {
      measurePerformance();
    } else {
      window.addEventListener('load', measurePerformance);
    }

    return () => window.removeEventListener('load', measurePerformance);
  }, []);

  if (!metrics || process.env.NODE_ENV !== 'development') return null;

  const getScoreColor = (value: number, thresholds: [number, number]) => {
    if (value <= thresholds[0]) return "bg-green-500";
    if (value <= thresholds[1]) return "bg-yellow-500";
    return "bg-red-500";
  };

  const formatBytes = (bytes: number) => {
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
  };

  return (
    <>
      <Button
        onClick={() => setIsVisible(!isVisible)}
        className="fixed bottom-4 right-4 z-50 rounded-full h-12 w-12 p-0"
        variant="outline"
      >
        <Activity className="h-5 w-5" />
      </Button>

      {isVisible && (
        <Card className="fixed bottom-20 right-4 z-50 w-80 animate-slide-in-right">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Métricas de Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Tiempo de carga</span>
              </div>
              <Badge variant="outline">
                {(metrics.loadTime / 1000).toFixed(2)}s
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">FCP</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className={`w-2 h-2 rounded-full ${getScoreColor(metrics.fcp, [1800, 3000])}`}
                />
                <Badge variant="outline">
                  {(metrics.fcp / 1000).toFixed(2)}s
                </Badge>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">LCP</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className={`w-2 h-2 rounded-full ${getScoreColor(metrics.lcp, [2500, 4000])}`}
                />
                <Badge variant="outline">
                  {(metrics.lcp / 1000).toFixed(2)}s
                </Badge>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">CLS</span>
              </div>
              <div className="flex items-center gap-2">
                <div 
                  className={`w-2 h-2 rounded-full ${getScoreColor(metrics.cls, [0.1, 0.25])}`}
                />
                <Badge variant="outline">
                  {metrics.cls.toFixed(3)}
                </Badge>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wifi className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Conexión</span>
              </div>
              <Badge variant="outline">
                {metrics.connectionType}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Memoria</span>
              </div>
              <Badge variant="outline">
                {formatBytes(metrics.memory)}
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}
