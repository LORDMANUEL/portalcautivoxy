

import { Metadata } from 'next';
import { PortalLinksClient } from './_components/portal-links-client';

export const metadata: Metadata = {
  title: 'Links Portales Cautivos - Administración Ford',
  description: 'Gestión de enlaces para múltiples portales cautivos Ford y QuickLane',
};

export default function PortalLinksPage() {
  return <PortalLinksClient />;
}
