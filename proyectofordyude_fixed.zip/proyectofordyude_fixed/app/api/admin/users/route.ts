
/**
 * API Route para gestión de usuarios administradores
 * 
 * Funcionalidades:
 * - GET: Listar usuarios con paginación y filtros
 * - POST: Crear nuevo usuario administrador
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Prisma } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

export const dynamic = 'force-dynamic';

// Validación para crear usuario
const createUserSchema = z.object({
  username: z.string().min(3, 'Username debe tener al menos 3 caracteres'),
  email: z.string().email('Email inválido').optional(),
  name: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  password: z.string().min(6, 'Password debe tener al menos 6 caracteres'),
  locationId: z.string().optional(),
  roles: z.array(z.string()).default([])
})


/**
 * GET /api/admin/users
 * Obtener lista de usuarios con paginación
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1', 10)
    const pageSize = parseInt(searchParams.get('pageSize') || '10', 10)
    const search = searchParams.get('search') || ''
    const locationId = searchParams.get('locationId') || ''

    const skip = (page - 1) * pageSize

    // Construir filtros
    const where: any = {}
    
    if (search) {
      where.OR = [
        { username: { contains: search, mode: 'insensitive' } },
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (locationId) {
      where.locationId = locationId
    }

    const [users, total] = await Promise.all([
      prisma.admin.findMany({
        where,
        skip,
        take: pageSize,
        include: {
          location: {
            select: {
              id: true,
              name: true,
              code: true
            }
          },
          roles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                  displayName: true,
                  priority: true
                }
              }
            }
          }
        },
        orderBy: [
          { isActive: 'desc' },
          { createdAt: 'desc' }
        ]
      }),
      prisma.admin.count({ where })
    ])

    // Remover passwords de la respuesta
    const safeUsers = users.map((user: any) => {
      const { password, ...safeUser } = user
      return safeUser
    })

    return NextResponse.json({
      success: true,
      data: safeUsers,
      meta: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize)
      }
    })

  } catch (error) {
    console.error('Error fetching users:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/users
 * Crear nuevo usuario administrador
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    
    // Validar datos
    const validation = createUserSchema.safeParse(body)
    
    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { username, email, name, password, locationId, roles } = validation.data

    // Verificar si el username ya existe
    const existingUser = await prisma.admin.findUnique({
      where: { username }
    })

    if (existingUser) {
      return NextResponse.json(
        { success: false, message: 'El username ya existe' },
        { status: 400 }
      )
    }

    // Verificar si el email ya existe (si se proporciona)
    if (email) {
      const existingEmail = await prisma.admin.findFirst({
        where: { email }
      })

      if (existingEmail) {
        return NextResponse.json(
          { success: false, message: 'El email ya existe' },
          { status: 400 }
        )
      }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Crear usuario en transacción
    const newUser = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // Crear usuario
      const user = await tx.admin.create({
        data: {
          username,
          email,
          name,
          password: hashedPassword,
          locationId: locationId || null,
          isActive: true
        }
      })

      // Asignar roles si se proporcionaron
      if (roles && roles.length > 0) {
        await tx.adminRole.createMany({
          data: roles.map(roleId => ({
            adminId: user.id,
            roleId,
            assignedBy: session.user.id
          }))
        })
      }

      return user
    })

    // Obtener usuario completo con relaciones
    const userWithRoles = await prisma.admin.findUnique({
      where: { id: newUser.id },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true
          }
        },
        roles: {
          include: {
            role: {
              select: {
                id: true,
                name: true,
                displayName: true,
                priority: true
              }
            }
          }
        }
      }
    })

    // Remover password
    const { password: _, ...safeUser } = userWithRoles || {}

    return NextResponse.json({
      success: true,
      data: safeUser,
      message: 'Usuario creado exitosamente'
    }, { status: 201 })

  } catch (error) {
    console.error('Error creating user:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
