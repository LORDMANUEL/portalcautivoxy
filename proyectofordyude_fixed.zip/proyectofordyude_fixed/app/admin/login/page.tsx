
import { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { AdminLoginClient } from './_components/admin-login-client';

export const metadata: Metadata = {
  title: 'Administración - Login | Ford Yude Canahuati',
  description: 'Panel de administración del portal cautivo Ford Yude Canahuati',
};

export default async function AdminLoginPage() {
  const session = await getServerSession(authOptions);
  
  if (session) {
    redirect('/admin/dashboard');
  }

  return <AdminLoginClient />;
}
