
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  Wifi,
  Clock,
  BarChart3,
  TrendingUp,
  Activity,
  Globe,
  Shield,
  Calendar,
  Download
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import dynamic from 'next/dynamic';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend
} from 'recharts';

interface DashboardStats {
  totalUsers: number;
  activeConnections: number;
  avgSessionTime: number;
  totalSessions: number;
  dataTransferred: string;
  topTheme: string;
}

interface ActivityItem {
  id: string;
  type: 'connection' | 'disconnection' | 'admin';
  message: string;
  timestamp: Date;
  user?: string;
}

export function DashboardClient() {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    activeConnections: 0,
    avgSessionTime: 0,
    totalSessions: 0,
    dataTransferred: '0 GB',
    topTheme: 'default'
  });

  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading dashboard data
    const loadDashboardData = async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setStats({
        totalUsers: Math.floor(Math.random() * 500) + 200,
        activeConnections: Math.floor(Math.random() * 50) + 10,
        avgSessionTime: Math.floor(Math.random() * 60) + 30,
        totalSessions: Math.floor(Math.random() * 2000) + 1000,
        dataTransferred: `${(Math.random() * 100 + 50).toFixed(1)} GB`,
        topTheme: 'summer'
      });

      setRecentActivity([
        {
          id: '1',
          type: 'connection',
          message: 'Nuevo usuario conectado desde dispositivo móvil',
          timestamp: new Date(),
          user: 'Usuario #1234'
        },
        {
          id: '2',
          type: 'admin',
          message: 'Configuración de tema actualizada',
          timestamp: new Date(Date.now() - 300000),
          user: 'Admin'
        },
        {
          id: '3',
          type: 'disconnection',
          message: 'Usuario desconectado después de 45 minutos',
          timestamp: new Date(Date.now() - 600000),
          user: 'Usuario #1230'
        }
      ]);

      setLoading(false);
    };

    loadDashboardData();
  }, []);

  // Chart data for recharts
  const connectionsData = [
    { day: 'Lun', connections: 45 },
    { day: 'Mar', connections: 52 },
    { day: 'Mié', connections: 38 },
    { day: 'Jue', connections: 65 },
    { day: 'Vie', connections: 72 },
    { day: 'Sáb', connections: 85 },
    { day: 'Dom', connections: 90 }
  ];

  const themesData = [
    { name: 'Default', value: 35, fill: '#003478' },
    { name: 'Verano', value: 25, fill: '#f59e0b' },
    { name: 'Navidad', value: 20, fill: '#dc2626' },
    { name: 'Madre', value: 12, fill: '#ff69b4' },
    { name: 'Independencia', value: 8, fill: '#059669' }
  ];



  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="h-80 bg-gray-200 rounded-lg animate-pulse" />
          <div className="h-80 bg-gray-200 rounded-lg animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Usuarios Totales</p>
                <p className="text-3xl font-bold text-[#003478]">{stats.totalUsers.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-[#003478]" />
              </div>
            </div>
            <div className="flex items-center mt-2 text-sm">
              <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
              <span className="text-green-500">+12%</span>
              <span className="text-gray-600 ml-1">vs. mes anterior</span>
            </div>
          </FordCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Conectados Ahora</p>
                <p className="text-3xl font-bold text-green-600">{stats.activeConnections}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Wifi className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="flex items-center mt-2 text-sm">
              <Activity className="w-4 h-4 text-blue-500 mr-1" />
              <span className="text-gray-600">En tiempo real</span>
            </div>
          </FordCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tiempo Promedio</p>
                <p className="text-3xl font-bold text-orange-600">{stats.avgSessionTime}m</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <div className="flex items-center mt-2 text-sm">
              <Calendar className="w-4 h-4 text-purple-500 mr-1" />
              <span className="text-gray-600">Sesión promedio</span>
            </div>
          </FordCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Datos Transferidos</p>
                <p className="text-3xl font-bold text-purple-600">{stats.dataTransferred}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Globe className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="flex items-center mt-2 text-sm">
              <BarChart3 className="w-4 h-4 text-indigo-500 mr-1" />
              <span className="text-gray-600">Último mes</span>
            </div>
          </FordCard>
        </motion.div>
      </div>

      {/* Charts Section */}
      <div className="grid lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Conexiones por Día</h3>
              <FordButton variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </FordButton>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={connectionsData}>
                  <XAxis 
                    dataKey="day" 
                    tickLine={false} 
                    tick={{ fontSize: 10 }} 
                  />
                  <YAxis 
                    tickLine={false} 
                    tick={{ fontSize: 10 }} 
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#003478', 
                      color: '#fff', 
                      border: 'none', 
                      borderRadius: '4px' 
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="connections" 
                    stroke="#003478" 
                    strokeWidth={2}
                    fill="#003478"
                    fillOpacity={0.1}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </FordCard>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800">Temas Populares</h3>
              <FordButton variant="outline" size="sm">
                Ver Todo
              </FordButton>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={themesData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                  >
                    {themesData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#003478', 
                      color: '#fff', 
                      border: 'none', 
                      borderRadius: '4px' 
                    }} 
                  />
                  <Legend 
                    verticalAlign="bottom" 
                    height={36}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </FordCard>
        </motion.div>
      </div>

      {/* Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <FordCard className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-gray-800">Actividad Reciente</h3>
            <FordButton variant="outline" size="sm">
              Ver Todos los Logs
            </FordButton>
          </div>
          
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <motion.div
                key={activity.id}
                className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: 0.7 + index * 0.1 }}
              >
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'connection' ? 'bg-green-500' :
                  activity.type === 'disconnection' ? 'bg-red-500' : 'bg-blue-500'
                }`} />
                <div className="flex-1">
                  <p className="text-sm text-gray-800">{activity.message}</p>
                  <p className="text-xs text-gray-500">
                    {activity.user} • {activity.timestamp.toLocaleTimeString('es-HN')}
                  </p>
                </div>
                <div className={`p-2 rounded-full ${
                  activity.type === 'connection' ? 'bg-green-100' :
                  activity.type === 'disconnection' ? 'bg-red-100' : 'bg-blue-100'
                }`}>
                  {activity.type === 'connection' ? (
                    <Wifi className="w-4 h-4 text-green-600" />
                  ) : activity.type === 'disconnection' ? (
                    <Users className="w-4 h-4 text-red-600" />
                  ) : (
                    <Shield className="w-4 h-4 text-blue-600" />
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </FordCard>
      </motion.div>
    </div>
  );
}
