

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * PUT /api/admin/locations/[id]/toggle
 * Activa/desactiva una ubicación
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { isActive } = body;

    const location = await prisma.location.update({
      where: { id: params.id },
      data: { isActive },
      include: {
        _count: {
          select: {
            portals: true,
            backups: true,
            admins: true
          }
        }
      }
    });

    return NextResponse.json(location);
  } catch (error) {
    console.error('Error al cambiar estado de ubicación:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
