

import { Metadata } from 'next';
import { BackupClient } from './_components/backup-client';

export const metadata: Metadata = {
  title: 'Backup BD - Administración Ford',
  description: 'Generador automático de backup de base de datos Ford Yude Canahuati',
};

export default function BackupPage() {
  return <BackupClient />;
}
