
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';

import { writeFile, mkdir } from 'fs/promises';

import { join } from 'path';

import { existsSync } from 'fs';


/**
 * POST - Sube archivos de imagen
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const category = formData.get('category') as string || 'general';

    if (!file) {
      return NextResponse.json({ error: 'No se proporcionó archivo' }, { status: 400 });
    }

    // Validar tipo de archivo
    if (!file.type.startsWith('image/')) {
      return NextResponse.json({ error: 'El archivo debe ser una imagen' }, { status: 400 });
    }

    // Validar tamaño (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: 'El archivo es demasiado grande (máximo 10MB)' }, { status: 400 });
    }

    // Crear directorio si no existe
    const uploadDir = join(process.cwd(), 'public', 'uploads', 'images', category);
    if (!existsSync(uploadDir)) {
      await mkdir(uploadDir, { recursive: true });
    }

    // Generar nombre único para el archivo
    const timestamp = Date.now();
    const originalName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
    const fileName = `${timestamp}_${originalName}`;
    const filePath = join(uploadDir, fileName);

    // Guardar archivo
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);
    await writeFile(filePath, buffer);

    // URL pública del archivo
    const fileUrl = `/uploads/images/${category}/${fileName}`;

    // Simular respuesta de imagen creada
    const imageResponse = {
      id: timestamp.toString(),
      name: originalName,
      originalName: file.name,
      url: fileUrl,
      thumbnailUrl: fileUrl,
      size: file.size,
      mimeType: file.type,
      category,
      tags: [],
      alt: originalName.replace(/\.[^/.]+$/, ''),
      description: '',
      isPublic: true,
      isFeatured: false,
      uploadedBy: session.user?.email || 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: {
        width: null,
        height: null,
        usage: ['portal'],
        portal: null,
        theme: null
      }
    };

    return NextResponse.json({
      success: true,
      message: 'Imagen subida exitosamente',
      image: imageResponse
    });

  } catch (error) {
    console.error('Error subiendo imagen:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
