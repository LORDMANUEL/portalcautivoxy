

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/themes
 * Obtiene todos los temas disponibles con sus configuraciones
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const themes = await prisma.theme.findMany({
      include: {
        config: true
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(themes);
  } catch (error) {
    console.error('Error al obtener temas:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * POST /api/admin/themes
 * Crea un nuevo tema
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { 
      name, 
      displayName, 
      description, 
      primaryColor, 
      secondaryColor, 
      accentColor,
      backgroundImage,
      logoImage,
      customCss,
      customJs,
      config 
    } = body;

    if (!name || !displayName) {
      return NextResponse.json({ error: 'Nombre y nombre para mostrar son obligatorios' }, { status: 400 });
    }

    const theme = await prisma.theme.create({
      data: {
        name,
        displayName,
        description: description || null,
        primaryColor: primaryColor || '#003478',
        secondaryColor: secondaryColor || '#FFFFFF',
        accentColor: accentColor || null,
        backgroundImage: backgroundImage || null,
        logoImage: logoImage || null,
        customCss: customCss || null,
        customJs: customJs || null,
        isActive: true,
        config: config ? {
          create: config
        } : undefined
      },
      include: {
        config: true
      }
    });

    return NextResponse.json(theme);
  } catch (error) {
    console.error('Error al crear tema:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
