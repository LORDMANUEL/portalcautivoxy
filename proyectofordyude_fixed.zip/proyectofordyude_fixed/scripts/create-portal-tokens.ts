
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function createPortalTokens() {
  console.log('🔧 Creando tokens de portal para testing...');

  const portalTokens = [
    {
      token: 'demo-ford-portal',
      name: 'Portal Ford Demo',
      description: 'Portal cautivo principal de Ford Yude Canahuati',
      portalType: 'ford',
      isActive: true,
      createdBy: 'system'
    },
    {
      token: 'demo-quicklane-truck',
      name: 'Portal QuickLane Truck',
      description: 'Portal QuickLane especializado en camiones',
      portalType: 'quicklane_truck',
      isActive: true,
      createdBy: 'system'
    },
    {
      token: 'demo-quicklane-tegus',
      name: 'Portal QuickLane Tegucigalpa',
      description: 'Portal QuickLane para Tegucigalpa',
      portalType: 'quicklane_tegus',
      isActive: true,
      createdBy: 'system'
    },
    {
      token: 'demo-quicklane-sps',
      name: 'Portal QuickLane San Pedro Sula',
      description: 'Portal QuickLane para San Pedro Sula',
      portalType: 'quicklane_sps',
      isActive: true,
      createdBy: 'system'
    }
  ];

  for (const tokenData of portalTokens) {
    try {
      // Verificar si ya existe
      const existing = await prisma.portalToken.findUnique({
        where: { token: tokenData.token }
      });

      if (existing) {
        console.log(`✅ Token ${tokenData.token} ya existe`);
        continue;
      }

      // Crear nuevo token
      const created = await prisma.portalToken.create({
        data: tokenData
      });

      console.log(`✅ Creado token: ${created.token} (${created.portalType})`);
    } catch (error) {
      console.error(`❌ Error creando token ${tokenData.token}:`, error);
    }
  }

  console.log('\n🎯 Tokens de portal disponibles para testing:');
  console.log('📱 Ford: http://localhost:3000/portal/demo-ford-portal');
  console.log('🚛 QuickLane Truck: http://localhost:3000/portal/demo-quicklane-truck');
  console.log('📍 QuickLane Tegus: http://localhost:3000/portal/demo-quicklane-tegus');
  console.log('🏢 QuickLane SPS: http://localhost:3000/portal/demo-quicklane-sps');
}

async function main() {
  try {
    await createPortalTokens();
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
