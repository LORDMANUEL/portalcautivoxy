
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Save,
  Eye,
  RefreshCw,
  Palette,
  Type,
  Image as ImageIcon,
  Settings,
  Globe,
  Plus,
  Trash2,
  Edit3,
  ExternalLink
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Image from 'next/image';

interface InternetReadyConfig {
  title: string;
  subtitle: string;
  message: string;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  logoUrl: string;
  bannerImages: Array<{
    url: string;
    title: string;
    description: string;
  }>;
  socialLinks: Array<{
    platform: string;
    url: string;
    icon: string;
  }>;
  quickActions: Array<{
    title: string;
    description: string;
    url: string;
    icon: string;
    color: string;
  }>;
  promotions: Array<{
    title: string;
    description: string;
    imageUrl: string;
    url: string;
    isActive: boolean;
  }>;
  customContent: {
    showWeather: boolean;
    showNews: boolean;
    showPromotions: boolean;
    showSocialMedia: boolean;
    showContact: boolean;
  };
}

/**
 * Editor para personalizar la página "Ya tienes Internet"
 * Permite configurar textos, colores, imágenes y funcionalidades
 */
export function InternetReadyEditorClient() {
  const [config, setConfig] = useState<InternetReadyConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  // Estados para modales
  const [showImageModal, setShowImageModal] = useState(false);
  const [showActionModal, setShowActionModal] = useState(false);
  const [showPromotionModal, setShowPromotionModal] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  // Estados temporales para formularios
  const [tempImage, setTempImage] = useState({ url: '', title: '', description: '' });
  const [tempAction, setTempAction] = useState({ title: '', description: '', url: '', icon: 'clock', color: '#3B82F6' });
  const [tempPromotion, setTempPromotion] = useState({ title: '', description: '', imageUrl: '', url: '', isActive: true });

  const iconOptions = [
    { value: 'clock', label: 'Reloj' },
    { value: 'car', label: 'Auto' },
    { value: 'wrench', label: 'Herramienta' },
    { value: 'phone', label: 'Teléfono' },
    { value: 'mail', label: 'Email' },
    { value: 'mapPin', label: 'Ubicación' },
    { value: 'shield', label: 'Escudo' },
    { value: 'zap', label: 'Rayo' }
  ];

  const colorOptions = [
    '#3B82F6', '#22C55E', '#F59E0B', '#EF4444', 
    '#8B5CF6', '#06B6D4', '#84CC16', '#FF6600'
  ];

  useEffect(() => {
    fetchConfig();
  }, []);

  /**
   * Obtiene configuración actual
   */
  const fetchConfig = async () => {
    try {
      const response = await fetch('/api/admin/internet-ready-config');
      if (response.ok) {
        const data = await response.json();
        setConfig(data);
      } else {
        toast.error('Error al cargar configuración');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al cargar configuración');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Guarda configuración
   */
  const saveConfig = async () => {
    if (!config) return;

    setSaving(true);
    try {
      const response = await fetch('/api/admin/internet-ready-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });

      if (response.ok) {
        toast.success('Configuración guardada exitosamente');
      } else {
        toast.error('Error al guardar configuración');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al guardar configuración');
    } finally {
      setSaving(false);
    }
  };

  /**
   * Actualiza configuración
   */
  const updateConfig = (updates: Partial<InternetReadyConfig>) => {
    if (!config) return;
    setConfig(prev => ({ ...prev!, ...updates }));
  };

  /**
   * Añade nueva imagen de banner
   */
  const addBannerImage = () => {
    if (!config || !tempImage.url || !tempImage.title) return;

    const newImages = [...config.bannerImages];
    if (editingIndex !== null) {
      newImages[editingIndex] = tempImage;
    } else {
      newImages.push(tempImage);
    }

    updateConfig({ bannerImages: newImages });
    setTempImage({ url: '', title: '', description: '' });
    setShowImageModal(false);
    setEditingIndex(null);
    toast.success(editingIndex !== null ? 'Imagen actualizada' : 'Imagen añadida');
  };

  /**
   * Elimina imagen de banner
   */
  const removeBannerImage = (index: number) => {
    if (!config) return;
    const newImages = config.bannerImages.filter((_, i) => i !== index);
    updateConfig({ bannerImages: newImages });
    toast.success('Imagen eliminada');
  };

  /**
   * Añade nueva acción rápida
   */
  const addQuickAction = () => {
    if (!config || !tempAction.title || !tempAction.url) return;

    const newActions = [...config.quickActions];
    if (editingIndex !== null) {
      newActions[editingIndex] = tempAction;
    } else {
      newActions.push(tempAction);
    }

    updateConfig({ quickActions: newActions });
    setTempAction({ title: '', description: '', url: '', icon: 'clock', color: '#3B82F6' });
    setShowActionModal(false);
    setEditingIndex(null);
    toast.success(editingIndex !== null ? 'Acción actualizada' : 'Acción añadida');
  };

  /**
   * Elimina acción rápida
   */
  const removeQuickAction = (index: number) => {
    if (!config) return;
    const newActions = config.quickActions.filter((_, i) => i !== index);
    updateConfig({ quickActions: newActions });
    toast.success('Acción eliminada');
  };

  /**
   * Añade nueva promoción
   */
  const addPromotion = () => {
    if (!config || !tempPromotion.title || !tempPromotion.imageUrl) return;

    const newPromotions = [...config.promotions];
    if (editingIndex !== null) {
      newPromotions[editingIndex] = tempPromotion;
    } else {
      newPromotions.push(tempPromotion);
    }

    updateConfig({ promotions: newPromotions });
    setTempPromotion({ title: '', description: '', imageUrl: '', url: '', isActive: true });
    setShowPromotionModal(false);
    setEditingIndex(null);
    toast.success(editingIndex !== null ? 'Promoción actualizada' : 'Promoción añadida');
  };

  /**
   * Elimina promoción
   */
  const removePromotion = (index: number) => {
    if (!config) return;
    const newPromotions = config.promotions.filter((_, i) => i !== index);
    updateConfig({ promotions: newPromotions });
    toast.success('Promoción eliminada');
  };

  /**
   * Abre vista previa
   */
  const openPreview = () => {
    window.open('/portal/internet-ready', '_blank');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!config) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-ford-blue">Editor Internet-Ready</h1>
          <p className="text-gray-600 mt-2">
            Personaliza la página "Ya tienes Internet" para los usuarios conectados
          </p>
        </div>
        <div className="flex gap-2">
          <FordButton
            variant="outline"
            onClick={openPreview}
          >
            <Eye className="w-4 h-4 mr-2" />
            Vista Previa
          </FordButton>
          <FordButton
            onClick={saveConfig}
            disabled={saving}
          >
            {saving ? (
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Guardar Cambios
          </FordButton>
        </div>
      </div>

      {/* Editor */}
      <Tabs defaultValue="basic" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">Básico</TabsTrigger>
          <TabsTrigger value="design">Diseño</TabsTrigger>
          <TabsTrigger value="images">Imágenes</TabsTrigger>
          <TabsTrigger value="actions">Acciones</TabsTrigger>
          <TabsTrigger value="promotions">Promociones</TabsTrigger>
        </TabsList>

        {/* Configuración básica */}
        <TabsContent value="basic" className="space-y-6">
          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Textos Principales</h3>
            <div className="space-y-4">
              <div>
                <Label>Título Principal</Label>
                <Input
                  value={config.title}
                  onChange={(e) => updateConfig({ title: e.target.value })}
                  placeholder="¡Ya tienes Internet!"
                />
              </div>

              <div>
                <Label>Subtítulo</Label>
                <Input
                  value={config.subtitle}
                  onChange={(e) => updateConfig({ subtitle: e.target.value })}
                  placeholder="Bienvenido a Ford Yude Canahuati"
                />
              </div>

              <div>
                <Label>Mensaje de Bienvenida</Label>
                <Textarea
                  value={config.message}
                  onChange={(e) => updateConfig({ message: e.target.value })}
                  placeholder="Tu conexión está lista..."
                  rows={3}
                />
              </div>

              <div>
                <Label>URL del Logo</Label>
                <Input
                  value={config.logoUrl}
                  onChange={(e) => updateConfig({ logoUrl: e.target.value })}
                  placeholder="https://imgs.search.brave.com/64eIZLmmhJ5MQR0uvofK8JSPYd93flcYqDlCiuzbVeA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMtcGxhdGZvcm0u/OTlzdGF0aWMuY29t/Ly9Ua2Roam0wek5B/SzlpWVRqZVV3N29w/ODMwbEU9LzB4MDox/NjAweDE2MDAvZml0/LWluLzUwMHg1MDAv/OTlkZXNpZ25zLWNv/bnRlc3RzLWF0dGFj/aG1lbnRzLzczLzcz/MzYzL2F0dGFjaG1l/bnRfNzMzNjMyOTQ"
                />
              </div>
            </div>
          </FordCard>

          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Contenido Personalizado</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.customContent.showPromotions}
                  onCheckedChange={(checked) => updateConfig({
                    customContent: { ...config.customContent, showPromotions: checked }
                  })}
                />
                <Label>Mostrar Promociones</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.customContent.showSocialMedia}
                  onCheckedChange={(checked) => updateConfig({
                    customContent: { ...config.customContent, showSocialMedia: checked }
                  })}
                />
                <Label>Redes Sociales</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.customContent.showContact}
                  onCheckedChange={(checked) => updateConfig({
                    customContent: { ...config.customContent, showContact: checked }
                  })}
                />
                <Label>Información de Contacto</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.customContent.showNews}
                  onCheckedChange={(checked) => updateConfig({
                    customContent: { ...config.customContent, showNews: checked }
                  })}
                />
                <Label>Noticias</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={config.customContent.showWeather}
                  onCheckedChange={(checked) => updateConfig({
                    customContent: { ...config.customContent, showWeather: checked }
                  })}
                />
                <Label>Clima</Label>
              </div>
            </div>
          </FordCard>
        </TabsContent>

        {/* Diseño y colores */}
        <TabsContent value="design" className="space-y-6">
          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Colores del Tema</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Color de Fondo</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="color"
                    value={config.backgroundColor}
                    onChange={(e) => updateConfig({ backgroundColor: e.target.value })}
                    className="w-16 h-10"
                  />
                  <Input
                    value={config.backgroundColor}
                    onChange={(e) => updateConfig({ backgroundColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>

              <div>
                <Label>Color de Texto</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="color"
                    value={config.textColor}
                    onChange={(e) => updateConfig({ textColor: e.target.value })}
                    className="w-16 h-10"
                  />
                  <Input
                    value={config.textColor}
                    onChange={(e) => updateConfig({ textColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>

              <div>
                <Label>Color de Acento</Label>
                <div className="flex items-center space-x-2">
                  <Input
                    type="color"
                    value={config.accentColor}
                    onChange={(e) => updateConfig({ accentColor: e.target.value })}
                    className="w-16 h-10"
                  />
                  <Input
                    value={config.accentColor}
                    onChange={(e) => updateConfig({ accentColor: e.target.value })}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
          </FordCard>

          <FordCard className="p-6">
            <h3 className="text-lg font-semibold mb-4">Vista Previa de Colores</h3>
            <div 
              className="p-8 rounded-lg border-2"
              style={{ 
                backgroundColor: config.backgroundColor,
                color: config.textColor,
                borderColor: config.accentColor
              }}
            >
              <h4 className="text-2xl font-bold mb-2">{config.title}</h4>
              <p className="mb-4">{config.subtitle}</p>
              <div 
                className="inline-block px-4 py-2 rounded text-white"
                style={{ backgroundColor: config.accentColor }}
              >
                Botón de Ejemplo
              </div>
            </div>
          </FordCard>
        </TabsContent>

        {/* Gestión de imágenes */}
        <TabsContent value="images" className="space-y-6">
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Imágenes del Banner</h3>
              <FordButton
                onClick={() => {
                  setTempImage({ url: '', title: '', description: '' });
                  setEditingIndex(null);
                  setShowImageModal(true);
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Añadir Imagen
              </FordButton>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {config.bannerImages.map((image, index) => (
                <div key={index} className="group relative">
                  <FordCard className="p-4">
                    <div className="relative h-32 mb-3 rounded overflow-hidden bg-gray-100">
                      <Image
                        src={image.url}
                        alt={image.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <h4 className="font-medium text-sm mb-1">{image.title}</h4>
                    <p className="text-xs text-gray-600 line-clamp-2">
                      {image.description}
                    </p>
                    
                    <div className="flex gap-1 mt-3">
                      <FordButton
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setTempImage(image);
                          setEditingIndex(index);
                          setShowImageModal(true);
                        }}
                      >
                        <Edit3 className="w-3 h-3" />
                      </FordButton>
                      <FordButton
                        size="sm"
                        variant="outline"
                        onClick={() => removeBannerImage(index)}
                        className="text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </FordButton>
                    </div>
                  </FordCard>
                </div>
              ))}
            </div>
          </FordCard>
        </TabsContent>

        {/* Acciones rápidas */}
        <TabsContent value="actions" className="space-y-6">
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Acciones Rápidas</h3>
              <FordButton
                onClick={() => {
                  setTempAction({ title: '', description: '', url: '', icon: 'clock', color: '#3B82F6' });
                  setEditingIndex(null);
                  setShowActionModal(true);
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Añadir Acción
              </FordButton>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {config.quickActions.map((action, index) => (
                <div key={index} className="group">
                  <FordCard className="p-4 text-center">
                    <div 
                      className="w-12 h-12 mx-auto mb-3 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: action.color }}
                    >
                      <span className="text-white text-xs">
                        {action.icon.substring(0, 2).toUpperCase()}
                      </span>
                    </div>
                    <h4 className="font-medium text-sm mb-1">{action.title}</h4>
                    <p className="text-xs text-gray-600 mb-3 line-clamp-2">
                      {action.description}
                    </p>
                    
                    <div className="flex gap-1 justify-center">
                      <FordButton
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setTempAction(action);
                          setEditingIndex(index);
                          setShowActionModal(true);
                        }}
                      >
                        <Edit3 className="w-3 h-3" />
                      </FordButton>
                      <FordButton
                        size="sm"
                        variant="outline"
                        onClick={() => removeQuickAction(index)}
                        className="text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </FordButton>
                    </div>
                  </FordCard>
                </div>
              ))}
            </div>
          </FordCard>
        </TabsContent>

        {/* Promociones */}
        <TabsContent value="promotions" className="space-y-6">
          <FordCard className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Promociones</h3>
              <FordButton
                onClick={() => {
                  setTempPromotion({ title: '', description: '', imageUrl: '', url: '', isActive: true });
                  setEditingIndex(null);
                  setShowPromotionModal(true);
                }}
              >
                <Plus className="w-4 h-4 mr-2" />
                Añadir Promoción
              </FordButton>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {config.promotions.map((promotion, index) => (
                <div key={index} className="group">
                  <FordCard className="overflow-hidden">
                    <div className="relative h-32">
                      <Image
                        src={promotion.imageUrl}
                        alt={promotion.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute top-2 right-2">
                        <Badge variant={promotion.isActive ? 'default' : 'secondary'}>
                          {promotion.isActive ? 'Activa' : 'Inactiva'}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-medium mb-2">{promotion.title}</h4>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                        {promotion.description}
                      </p>
                      
                      <div className="flex gap-2">
                        <FordButton
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setTempPromotion(promotion);
                            setEditingIndex(index);
                            setShowPromotionModal(true);
                          }}
                        >
                          <Edit3 className="w-3 h-3 mr-1" />
                          Editar
                        </FordButton>
                        <FordButton
                          size="sm"
                          variant="outline"
                          onClick={() => removePromotion(index)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Eliminar
                        </FordButton>
                      </div>
                    </div>
                  </FordCard>
                </div>
              ))}
            </div>
          </FordCard>
        </TabsContent>
      </Tabs>

      {/* Modales */}
      {/* Modal de imagen */}
      {showImageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <FordCard className="w-full max-w-lg">
            <div className="p-6">
              <h3 className="text-lg font-bold mb-4">
                {editingIndex !== null ? 'Editar Imagen' : 'Añadir Imagen'}
              </h3>
              
              <div className="space-y-4">
                <div>
                  <Label>URL de la Imagen</Label>
                  <Input
                    value={tempImage.url}
                    onChange={(e) => setTempImage(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="https://ejemplo.com/imagen.jpg"
                  />
                </div>

                <div>
                  <Label>Título</Label>
                  <Input
                    value={tempImage.title}
                    onChange={(e) => setTempImage(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Título de la imagen"
                  />
                </div>

                <div>
                  <Label>Descripción</Label>
                  <Textarea
                    value={tempImage.description}
                    onChange={(e) => setTempImage(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Descripción de la imagen"
                    rows={3}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton
                  variant="outline"
                  onClick={() => setShowImageModal(false)}
                >
                  Cancelar
                </FordButton>
                <FordButton
                  onClick={addBannerImage}
                  disabled={!tempImage.url || !tempImage.title}
                >
                  {editingIndex !== null ? 'Actualizar' : 'Añadir'}
                </FordButton>
              </div>
            </div>
          </FordCard>
        </div>
      )}

      {/* Modal de acción */}
      {showActionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <FordCard className="w-full max-w-lg">
            <div className="p-6">
              <h3 className="text-lg font-bold mb-4">
                {editingIndex !== null ? 'Editar Acción' : 'Añadir Acción'}
              </h3>
              
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Título</Label>
                    <Input
                      value={tempAction.title}
                      onChange={(e) => setTempAction(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Título de la acción"
                    />
                  </div>

                  <div>
                    <Label>URL</Label>
                    <Input
                      value={tempAction.url}
                      onChange={(e) => setTempAction(prev => ({ ...prev, url: e.target.value }))}
                      placeholder="https://ejemplo.com"
                    />
                  </div>
                </div>

                <div>
                  <Label>Descripción</Label>
                  <Textarea
                    value={tempAction.description}
                    onChange={(e) => setTempAction(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Descripción de la acción"
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Icono</Label>
                    <Select
                      value={tempAction.icon}
                      onValueChange={(value) => setTempAction(prev => ({ ...prev, icon: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {iconOptions.map(icon => (
                          <SelectItem key={icon.value} value={icon.value}>
                            {icon.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Color</Label>
                    <div className="flex gap-2">
                      {colorOptions.map(color => (
                        <button
                          key={color}
                          className={`w-8 h-8 rounded-full border-2 ${
                            tempAction.color === color ? 'border-gray-800' : 'border-gray-300'
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => setTempAction(prev => ({ ...prev, color }))}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton
                  variant="outline"
                  onClick={() => setShowActionModal(false)}
                >
                  Cancelar
                </FordButton>
                <FordButton
                  onClick={addQuickAction}
                  disabled={!tempAction.title || !tempAction.url}
                >
                  {editingIndex !== null ? 'Actualizar' : 'Añadir'}
                </FordButton>
              </div>
            </div>
          </FordCard>
        </div>
      )}

      {/* Modal de promoción */}
      {showPromotionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <FordCard className="w-full max-w-lg">
            <div className="p-6">
              <h3 className="text-lg font-bold mb-4">
                {editingIndex !== null ? 'Editar Promoción' : 'Añadir Promoción'}
              </h3>
              
              <div className="space-y-4">
                <div>
                  <Label>Título</Label>
                  <Input
                    value={tempPromotion.title}
                    onChange={(e) => setTempPromotion(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Título de la promoción"
                  />
                </div>

                <div>
                  <Label>Descripción</Label>
                  <Textarea
                    value={tempPromotion.description}
                    onChange={(e) => setTempPromotion(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Descripción de la promoción"
                    rows={3}
                  />
                </div>

                <div>
                  <Label>URL de la Imagen</Label>
                  <Input
                    value={tempPromotion.imageUrl}
                    onChange={(e) => setTempPromotion(prev => ({ ...prev, imageUrl: e.target.value }))}
                    placeholder="https://imgs.search.brave.com/ATxZMBJX98mN6bvGCjwAr0R5D4c5exFNd0BBDONINFk/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/Z29kZWx0YS5jb20v/aHViZnMvQmxvZy1J/bWFnZXMvN19Ccmls/bGlhbnRfUHJvbW90/aW9uYWxfUHJvZHVj/dF9DYW1wYWlnbnMv/Ny1CcmlsbGlhbnQt/UHJvbW8tQ2FtcGFp/Z25zLWhlcm8uanBn"
                  />
                </div>

                <div>
                  <Label>URL de Destino</Label>
                  <Input
                    value={tempPromotion.url}
                    onChange={(e) => setTempPromotion(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="https://ejemplo.com/promocion"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    checked={tempPromotion.isActive}
                    onCheckedChange={(checked) => setTempPromotion(prev => ({ ...prev, isActive: checked }))}
                  />
                  <Label>Promoción Activa</Label>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton
                  variant="outline"
                  onClick={() => setShowPromotionModal(false)}
                >
                  Cancelar
                </FordButton>
                <FordButton
                  onClick={addPromotion}
                  disabled={!tempPromotion.title || !tempPromotion.imageUrl}
                >
                  {editingIndex !== null ? 'Actualizar' : 'Añadir'}
                </FordButton>
              </div>
            </div>
          </FordCard>
        </div>
      )}
    </div>
  );
}
