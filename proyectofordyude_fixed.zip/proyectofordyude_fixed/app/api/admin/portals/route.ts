
/**
 * API Route para gestión de portales cautivos múltiples
 * 
 * Funcionalidades:
 * - GET: Listar portales con filtros
 * - POST: Crear nuevo portal
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const createPortalSchema = z.object({
  name: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  slug: z.string().min(2, 'Slug debe tener al menos 2 caracteres').regex(/^[a-z0-9-]+$/, 'Slug solo puede contener letras minúsculas, números y guiones'),
  type: z.enum(['FORD', 'QUICKLANE_TRUCK', 'QUICKLANE_TEGUS', 'QUICKLANE_SPS'], {
    errorMap: () => ({ message: 'Tipo de portal inválido' })
  }),
  brand: z.string().default('Ford'),
  locationId: z.string().optional(),
  description: z.string().optional(),
  logoUrl: z.string().optional(),
  primaryColor: z.string().default('#003478'),
  secondaryColor: z.string().default('#FFFFFF'),
  themeId: z.string().optional(),
  welcomeTitle: z.string().default('Bienvenido'),
  welcomeMessage: z.string().optional(),
  customCss: z.string().optional(),
  customJs: z.string().optional(),
  metadata: z.record(z.any()).optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/portals
 * Obtener lista de portales
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1', 10)
    const pageSize = parseInt(searchParams.get('pageSize') || '20', 10)
    const search = searchParams.get('search') || ''
    const type = searchParams.get('type') || ''
    const locationId = searchParams.get('locationId') || ''
    const isActive = searchParams.get('isActive')

    const skip = (page - 1) * pageSize

    // Construir filtros
    const where: any = {}
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { slug: { contains: search, mode: 'insensitive' } },
        { brand: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (type) {
      where.type = type
    }

    if (locationId) {
      where.locationId = locationId
    }

    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true'
    }

    const [portals, total] = await Promise.all([
      prisma.portal.findMany({
        where,
        skip,
        take: pageSize,
        include: {
          location: {
            select: {
              id: true,
              name: true,
              code: true,
              type: true
            }
          },
          _count: {
            select: {
              sessions: true
            }
          }
        },
        orderBy: [
          { isActive: 'desc' },
          { type: 'asc' },
          { name: 'asc' }
        ]
      }),
      prisma.portal.count({ where })
    ])

    return NextResponse.json({
      success: true,
      data: portals,
      meta: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize)
      }
    })

  } catch (error) {
    console.error('Error fetching portals:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/portals
 * Crear nuevo portal
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = createPortalSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { slug, ...portalData } = validation.data

    // Verificar que el slug sea único
    const existingPortal = await prisma.portal.findUnique({
      where: { slug }
    })

    if (existingPortal) {
      return NextResponse.json(
        { success: false, message: 'Ya existe un portal con ese slug' },
        { status: 400 }
      )
    }

    const portal = await prisma.portal.create({
      data: {
        ...portalData,
        slug,
        isActive: true
      },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true,
            type: true
          }
        },
        _count: {
          select: {
            sessions: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: portal,
      message: 'Portal creado exitosamente'
    }, { status: 201 })

  } catch (error) {
    console.error('Error creating portal:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
