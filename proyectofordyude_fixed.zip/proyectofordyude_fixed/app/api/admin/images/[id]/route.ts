import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    const mockImage = {
      id,
      name: 'imagen-' + id + '.jpg',
      originalName: 'imagen-' + id + '.jpg',
      url: 'https://via.placeholder.com/600x400/003478/FFFFFF?text=Imagen+' + id,
      thumbnailUrl: 'https://via.placeholder.com/200x150/003478/FFFFFF?text=Imagen+' + id,
      size: 123456,
      mimeType: 'image/jpeg',
      category: 'general',
      tags: ['ejemplo'],
      alt: 'Imagen ' + id,
      description: 'Descripción de imagen ' + id,
      isPublic: true,
      isFeatured: false,
      uploadedBy: 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: {}
    };

    return NextResponse.json(mockImage);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const updates = await request.json();

    const updatedImage = {
      id,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return NextResponse.json(updatedImage);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Imagen eliminada exitosamente' 
    });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
