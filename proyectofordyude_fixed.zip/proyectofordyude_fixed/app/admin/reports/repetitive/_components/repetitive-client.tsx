
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Repeat,
  Users,
  TrendingUp,
  Clock,
  MapPin,
  Calendar,
  Download,
  Filter,
  ArrowLeft,
  Star,
  Award
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Link from 'next/link';

interface RepetitiveUser {
  id: string;
  name: string;
  email: string;
  visitCount: number;
  lastVisit: string;
  firstVisit: string;
  avgSessionTime: number;
  favoriteLocation: string;
  totalTimeSpent: number;
  deviceTypes: string[];
  loyaltyScore: number;
  category: 'Frequent' | 'Regular' | 'Occasional';
}

/**
 * Reporte de usuarios repetitivos
 * Identifica y analiza usuarios que regresan frecuentemente
 */
export function RepetitiveClient() {
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [users, setUsers] = useState<RepetitiveUser[]>([]);
  const [filterCategory, setFilterCategory] = useState('ALL_CATEGORIES');
  const [sortBy, setSortBy] = useState('visitCount');

  useEffect(() => {
    fetchRepetitiveUsers();
  }, [filterCategory, sortBy]);

  const fetchRepetitiveUsers = async () => {
    setLoading(true);
    try {
      // Simular API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockUsers: RepetitiveUser[] = [
        {
          id: '1',
          name: 'Carlos Mendoza',
          email: 'carlos.mendoza@email.com',
          visitCount: 24,
          lastVisit: '2024-01-15',
          firstVisit: '2023-08-10',
          avgSessionTime: 35,
          favoriteLocation: 'Showroom SPS',
          totalTimeSpent: 840,
          deviceTypes: ['mobile', 'desktop'],
          loyaltyScore: 95,
          category: 'Frequent'
        },
        {
          id: '2',
          name: 'María González',
          email: 'maria.gonzalez@email.com',
          visitCount: 18,
          lastVisit: '2024-01-14',
          firstVisit: '2023-09-22',
          avgSessionTime: 28,
          favoriteLocation: 'QuickLane Tegus',
          totalTimeSpent: 504,
          deviceTypes: ['mobile'],
          loyaltyScore: 82,
          category: 'Frequent'
        },
        {
          id: '3',
          name: 'Roberto Silva',
          email: 'roberto.silva@email.com',
          visitCount: 12,
          lastVisit: '2024-01-12',
          firstVisit: '2023-10-05',
          avgSessionTime: 22,
          favoriteLocation: 'Servicio La Ceiba',
          totalTimeSpent: 264,
          deviceTypes: ['desktop', 'tablet'],
          loyaltyScore: 68,
          category: 'Regular'
        },
        {
          id: '4',
          name: 'Ana Patricia López',
          email: 'ana.lopez@email.com',
          visitCount: 8,
          lastVisit: '2024-01-10',
          firstVisit: '2023-11-15',
          avgSessionTime: 18,
          favoriteLocation: 'Showroom Tegus',
          totalTimeSpent: 144,
          deviceTypes: ['mobile'],
          loyaltyScore: 45,
          category: 'Occasional'
        },
        {
          id: '5',
          name: 'Luis Fernando Castro',
          email: 'luis.castro@email.com',
          visitCount: 15,
          lastVisit: '2024-01-13',
          firstVisit: '2023-09-01',
          avgSessionTime: 31,
          favoriteLocation: 'QuickLane SPS',
          totalTimeSpent: 465,
          deviceTypes: ['desktop'],
          loyaltyScore: 75,
          category: 'Regular'
        }
      ];

      let filteredUsers = mockUsers;
      if (filterCategory !== 'ALL_CATEGORIES') {
        filteredUsers = mockUsers.filter(user => user.category === filterCategory);
      }

      // Ordenar
      filteredUsers.sort((a, b) => {
        switch (sortBy) {
          case 'visitCount':
            return b.visitCount - a.visitCount;
          case 'loyaltyScore':
            return b.loyaltyScore - a.loyaltyScore;
          case 'totalTimeSpent':
            return b.totalTimeSpent - a.totalTimeSpent;
          case 'lastVisit':
            return new Date(b.lastVisit).getTime() - new Date(a.lastVisit).getTime();
          default:
            return 0;
        }
      });

      setUsers(filteredUsers);
    } catch (error) {
      toast.error('Error al cargar usuarios repetitivos');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryBadge = (category: string) => {
    const styles = {
      Frequent: 'bg-green-100 text-green-800',
      Regular: 'bg-blue-100 text-blue-800',
      Occasional: 'bg-yellow-100 text-yellow-800'
    };
    return styles[category as keyof typeof styles] || 'bg-gray-100 text-gray-800';
  };

  const getLoyaltyIcon = (score: number) => {
    if (score >= 80) return <Award className="w-4 h-4 text-yellow-500" />;
    if (score >= 60) return <Star className="w-4 h-4 text-blue-500" />;
    return <Star className="w-4 h-4 text-gray-400" />;
  };

  const handleExport = async (format: 'pdf' | 'excel' | 'csv') => {
    setExporting(true);
    try {
      // Simular exportación
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success(`Reporte ${format.toUpperCase()} descargado correctamente`);
    } catch (error) {
      toast.error(`Error al exportar ${format.toUpperCase()}`);
    } finally {
      setExporting(false);
    }
  };

  const stats = {
    totalRepetitive: users.length,
    frequentUsers: users.filter(u => u.category === 'Frequent').length,
    avgVisits: Math.round(users.reduce((acc, u) => acc + u.visitCount, 0) / users.length || 0),
    avgLoyalty: Math.round(users.reduce((acc, u) => acc + u.loyaltyScore, 0) / users.length || 0)
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando usuarios repetitivos..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/admin/reports">
            <FordButton variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a Reportes
            </FordButton>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
              <Repeat className="w-8 h-8 text-[#003478]" />
              Usuarios Repetitivos
            </h1>
            <p className="text-gray-600 mt-1">
              Análisis de usuarios que regresan frecuentemente al portal
            </p>
          </div>
        </div>

        <div className="flex space-x-2">
          <FordButton
            variant="outline"
            onClick={() => handleExport('pdf')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            PDF
          </FordButton>
          <FordButton
            variant="outline"
            onClick={() => handleExport('excel')}
            disabled={exporting}
          >
            <Download className="w-4 h-4 mr-2" />
            Excel
          </FordButton>
        </div>
      </div>

      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <FordCard className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Repetitivos</p>
              <p className="text-2xl font-bold text-gray-800">{stats.totalRepetitive}</p>
            </div>
            <Users className="w-8 h-8 text-[#003478]" />
          </div>
        </FordCard>

        <FordCard className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Usuarios Frecuentes</p>
              <p className="text-2xl font-bold text-green-600">{stats.frequentUsers}</p>
            </div>
            <Star className="w-8 h-8 text-green-500" />
          </div>
        </FordCard>

        <FordCard className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Visitas Promedio</p>
              <p className="text-2xl font-bold text-blue-600">{stats.avgVisits}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-500" />
          </div>
        </FordCard>

        <FordCard className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Lealtad Promedio</p>
              <p className="text-2xl font-bold text-purple-600">{stats.avgLoyalty}%</p>
            </div>
            <Award className="w-8 h-8 text-purple-500" />
          </div>
        </FordCard>
      </div>

      {/* Filtros */}
      <FordCard className="p-6">
        <div className="flex items-center space-x-4 mb-4">
          <Filter className="w-5 h-5 text-[#003478]" />
          <h3 className="text-lg font-semibold text-gray-800">Filtros y Ordenamiento</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Categoría</label>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL_CATEGORIES">Todas las categorías</SelectItem>
                <SelectItem value="Frequent">Frecuentes</SelectItem>
                <SelectItem value="Regular">Regulares</SelectItem>
                <SelectItem value="Occasional">Ocasionales</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Ordenar por</label>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="visitCount">Número de visitas</SelectItem>
                <SelectItem value="loyaltyScore">Puntaje de lealtad</SelectItem>
                <SelectItem value="totalTimeSpent">Tiempo total</SelectItem>
                <SelectItem value="lastVisit">Última visita</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </FordCard>

      {/* Lista de usuarios */}
      <FordCard className="p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Usuarios Repetitivos Identificados
        </h3>
        
        <div className="space-y-4">
          {users.map((user, index) => (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-[#003478] rounded-full flex items-center justify-center text-white font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">{user.name}</h4>
                    <p className="text-sm text-gray-600">{user.email}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {getLoyaltyIcon(user.loyaltyScore)}
                  <Badge className={getCategoryBadge(user.category)}>
                    {user.category}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">Visitas</span>
                  <p className="font-bold text-[#003478]">{user.visitCount}</p>
                </div>
                
                <div>
                  <span className="text-gray-500">Lealtad</span>
                  <p className="font-bold text-purple-600">{user.loyaltyScore}%</p>
                </div>
                
                <div>
                  <span className="text-gray-500">Sesión Prom.</span>
                  <p className="font-bold text-gray-800">{user.avgSessionTime} min</p>
                </div>
                
                <div>
                  <span className="text-gray-500">Tiempo Total</span>
                  <p className="font-bold text-gray-800">{Math.round(user.totalTimeSpent / 60)}h</p>
                </div>
                
                <div>
                  <span className="text-gray-500">Ubicación Fav.</span>
                  <p className="font-bold text-gray-800 truncate">{user.favoriteLocation}</p>
                </div>
                
                <div>
                  <span className="text-gray-500">Última Visita</span>
                  <p className="font-bold text-gray-800">{new Date(user.lastVisit).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-500">Dispositivos:</span>
                    {user.deviceTypes.map((device, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {device}
                      </Badge>
                    ))}
                  </div>
                  
                  <span className="text-xs text-gray-500">
                    Cliente desde {new Date(user.firstVisit).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {users.length === 0 && (
          <div className="text-center py-8">
            <Repeat className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">
              No se encontraron usuarios repetitivos
            </h3>
            <p className="text-gray-500">
              Ajusta los filtros para ver más resultados
            </p>
          </div>
        )}
      </FordCard>
    </div>
  );
}
