
/**
 * API Route para gestión individual de vCards
 * 
 * Funcionalidades:
 * - GET: Obtener vCard específica
 * - PUT: Actualizar vCard y regenerar QR
 * - DELETE: Eliminar vCard
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'
import QRCode from 'qrcode'
import { writeFile, mkdir, unlink } from 'fs/promises'
import { join } from 'path'

const updateVCardSchema = z.object({
  advisorName: z.string().min(2).optional(),
  position: z.string().optional(),
  email: z.string().email().optional(),
  phone: z.string().optional(),
  company: z.string().optional(),
  address: z.string().optional(),
  website: z.string().optional(),
  photo: z.string().optional(),
  isActive: z.boolean().optional()
})

export const dynamic = "force-dynamic"

/**
 * Generar string vCard
 */
function generateVCardString(data: any): string {
  const vcard = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${data.advisorName}`,
    `EMAIL:${data.email}`,
    `TEL:${data.phone || ''}`,
    `ORG:${data.company}`,
    `TITLE:${data.position || ''}`,
    `ADR:;;${data.address || ''};;;`,
    `URL:${data.website || ''}`,
    'END:VCARD'
  ].join('\n')
  
  return vcard
}

/**
 * GET /api/admin/qr-generator/[id]
 * Obtener vCard específica
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    })

    if (!vcard) {
      return NextResponse.json(
        { success: false, message: 'vCard no encontrada' },
        { status: 404 }
      )
    }

    // Generar string vCard para mostrar
    const vcardString = generateVCardString(vcard)

    return NextResponse.json({
      success: true,
      data: {
        ...vcard,
        vcardString
      }
    })

  } catch (error) {
    console.error('Error fetching vCard:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/qr-generator/[id]
 * Actualizar vCard y regenerar QR
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = updateVCardSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const updateData = validation.data

    // Verificar que la vCard existe
    const existingVCard = await prisma.vCard.findUnique({
      where: { id: params.id }
    })

    if (!existingVCard) {
      return NextResponse.json(
        { success: false, message: 'vCard no encontrada' },
        { status: 404 }
      )
    }

    // Actualizar datos
    const updatedData = { ...existingVCard, ...updateData }

    // Regenerar QR si hay cambios en los datos principales
    let qrCodeUrl = existingVCard.qrCode
    
    if (updateData.advisorName || updateData.email || updateData.phone || updateData.position) {
      // Generar nuevo string vCard
      const vcardString = generateVCardString(updatedData)

      // Crear directorio si no existe
      const qrDir = join(process.cwd(), 'public', 'qr-codes')
      try {
        await mkdir(qrDir, { recursive: true })
      } catch (error) {
        // Directorio ya existe
      }

      // Eliminar QR anterior si existe
      if (existingVCard.qrCode) {
        try {
          const oldFilePath = join(process.cwd(), 'public', existingVCard.qrCode)
          await unlink(oldFilePath)
        } catch (error) {
          // Archivo no existe o no se puede eliminar
        }
      }

      // Generar nuevo QR
      const timestamp = Date.now()
      const fileName = `vcard_${timestamp}.png`
      const filePath = join(qrDir, fileName)

      const qrCodeBuffer = await QRCode.toBuffer(vcardString, {
        type: 'png',
        width: 512,
        margin: 2,
        color: {
          dark: '#003478',
          light: '#FFFFFF'
        }
      })

      await writeFile(filePath, qrCodeBuffer)
      qrCodeUrl = `/qr-codes/${fileName}`
    }

    // Actualizar en base de datos
    const vcard = await prisma.vCard.update({
      where: { id: params.id },
      data: {
        ...updateData,
        qrCode: qrCodeUrl
      }
    })

    const vcardString = generateVCardString(vcard)

    return NextResponse.json({
      success: true,
      data: {
        ...vcard,
        vcardString
      },
      message: 'vCard actualizada exitosamente'
    })

  } catch (error) {
    console.error('Error updating vCard:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/qr-generator/[id]
 * Eliminar vCard
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    })

    if (!vcard) {
      return NextResponse.json(
        { success: false, message: 'vCard no encontrada' },
        { status: 404 }
      )
    }

    // Eliminar archivo QR si existe
    if (vcard.qrCode) {
      try {
        const filePath = join(process.cwd(), 'public', vcard.qrCode)
        await unlink(filePath)
      } catch (error) {
        // Archivo no existe o no se puede eliminar
      }
    }

    // Eliminar de base de datos
    await prisma.vCard.delete({
      where: { id: params.id }
    })

    return NextResponse.json({
      success: true,
      message: 'vCard eliminada exitosamente'
    })

  } catch (error) {
    console.error('Error deleting vCard:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
