

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * POST /api/captive/connect
 * Registra una nueva conexión de usuario al portal cautivo
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      name, 
      email, 
      phone, 
      portalToken, 
      portalType, 
      deviceId, 
      userAgent 
    } = body;

    // Obtener IP del cliente
    const ipAddress = request.headers.get('x-forwarded-for') || 
                     request.headers.get('x-real-ip') || 
                     '127.0.0.1';

    // Verificar si el token de portal existe y está activo
    const token = await prisma.portalToken.findUnique({
      where: { token: portalToken }
    });

    if (!token || !token.isActive) {
      return NextResponse.json({ error: 'Token de portal inválido' }, { status: 400 });
    }

    // Crear o actualizar usuario cautivo
    const captiveUser = await prisma.captiveUser.upsert({
      where: { deviceId: deviceId },
      update: {
        name,
        email,
        phone,
        ipAddress,
        userAgent,
        connectedAt: new Date(),
        isActive: true,
        disconnectedAt: null
      },
      create: {
        deviceId,
        ipAddress,
        userAgent,
        name,
        email,
        phone,
        theme: token.themeId || 'default',
        connectedAt: new Date(),
        isActive: true
      }
    });

    // Crear sesión del portal
    const portalSession = await prisma.portalSession.create({
      data: {
        portalId: token.id,
        userId: captiveUser.id,
        deviceId,
        ipAddress,
        userAgent,
        sessionToken: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        startTime: new Date(),
        isActive: true,
        pagesViewed: 1,
        activityData: {
          portalType,
          connectionMethod: 'web_form',
          userInfo: { name, email, phone }
        }
      }
    });

    // Registrar log de conexión
    await prisma.log.create({
      data: {
        userId: captiveUser.id,
        userType: 'CAPTIVE_USER',
        action: 'LOGIN',
        description: `Usuario conectado al portal ${portalType}`,
        ipAddress,
        userAgent,
        page: `/portal/${portalToken}`,
        data: {
          portalType,
          sessionId: portalSession.id,
          userInfo: { name, email, phone }
        },
        severity: 'INFO'
      }
    });

    return NextResponse.json({
      success: true,
      sessionId: portalSession.sessionToken,
      message: 'Conexión exitosa'
    });

  } catch (error) {
    console.error('Error al conectar usuario:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
