
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { promises as fs } from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

/**
 * Descargar archivo de backup
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    // Buscar el backup
    const backup = await prisma.backup.findUnique({
      where: { id }
    });

    if (!backup) {
      return NextResponse.json({ error: 'Backup no encontrado' }, { status: 404 });
    }

    if (backup.status !== 'COMPLETED' || !backup.filePath) {
      return NextResponse.json({ error: 'Backup no disponible para descarga' }, { status: 400 });
    }

    // Verificar que el archivo existe
    try {
      await fs.access(backup.filePath);
    } catch (error) {
      return NextResponse.json({ error: 'Archivo de backup no existe' }, { status: 404 });
    }

    // Leer el archivo
    const fileBuffer = await fs.readFile(backup.filePath);
    const filename = path.basename(backup.filePath);

    // Determinar el tipo de contenido
    const contentType = backup.compressionType === 'gzip' 
      ? 'application/gzip' 
      : 'application/sql';

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': fileBuffer.length.toString(),
      },
    });

  } catch (error) {
    console.error('Error al descargar backup:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
