
"use client";

import { useEffect, useState, useRef } from 'react';

interface PerformanceMetrics {
  renderTime: number;
  reRenderCount: number;
  memoryUsage: number;
  fcp?: number;
  lcp?: number;
}

export function usePerformance(componentName: string) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    renderTime: 0,
    reRenderCount: 0,
    memoryUsage: 0,
  });
  
  const renderStartTime = useRef<number>(0);
  const renderCount = useRef<number>(0);

  useEffect(() => {
    renderStartTime.current = performance.now();
    renderCount.current += 1;

    return () => {
      const renderTime = performance.now() - renderStartTime.current;
      
      setMetrics(prev => ({
        ...prev,
        renderTime,
        reRenderCount: renderCount.current,
        memoryUsage: (performance as any)?.memory?.usedJSHeapSize || 0,
      }));

      // Log en desarrollo
      if (process.env.NODE_ENV === 'development') {
        console.log(`[${componentName}] Render time: ${renderTime.toFixed(2)}ms, Re-renders: ${renderCount.current}`);
      }
    };
  });

  // Medir Web Vitals si está disponible
  useEffect(() => {
    if (typeof window !== 'undefined' && 'PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'paint') {
            if (entry.name === 'first-contentful-paint') {
              setMetrics(prev => ({ ...prev, fcp: entry.startTime }));
            }
          } else if (entry.entryType === 'largest-contentful-paint') {
            setMetrics(prev => ({ ...prev, lcp: entry.startTime }));
          }
        }
      });

      observer.observe({ entryTypes: ['paint', 'largest-contentful-paint'] });

      return () => observer.disconnect();
    }
  }, []);

  return metrics;
}

// Hook para medir tiempo de operaciones
export function useOperationTimer() {
  const startTimer = (operationName: string) => {
    const startTime = performance.now();
    
    return {
      end: () => {
        const endTime = performance.now();
        const duration = endTime - startTime;
        
        if (process.env.NODE_ENV === 'development') {
          console.log(`[${operationName}] Duration: ${duration.toFixed(2)}ms`);
        }
        
        return duration;
      }
    };
  };

  return { startTimer };
}

// Hook para detectar renders lentos
export function useSlowRenderDetection(threshold = 16) { // 16ms = 60fps
  const renderTimes = useRef<number[]>([]);
  
  useEffect(() => {
    const startTime = performance.now();
    
    return () => {
      const renderTime = performance.now() - startTime;
      renderTimes.current.push(renderTime);
      
      // Mantener solo los últimos 10 renders
      if (renderTimes.current.length > 10) {
        renderTimes.current.shift();
      }
      
      if (renderTime > threshold) {
        console.warn(`Slow render detected: ${renderTime.toFixed(2)}ms (threshold: ${threshold}ms)`);
      }
    };
  });
  
  const getAverageRenderTime = () => {
    if (renderTimes.current.length === 0) return 0;
    const sum = renderTimes.current.reduce((a, b) => a + b, 0);
    return sum / renderTimes.current.length;
  };
  
  return { getAverageRenderTime };
}

// Hook para detectar memory leaks
export function useMemoryLeak() {
  const initialMemory = useRef<number>(0);
  const [memoryGrowth, setMemoryGrowth] = useState<number>(0);
  
  useEffect(() => {
    if ((performance as any)?.memory) {
      initialMemory.current = (performance as any).memory.usedJSHeapSize;
    }
    
    const interval = setInterval(() => {
      if ((performance as any)?.memory) {
        const currentMemory = (performance as any).memory.usedJSHeapSize;
        const growth = currentMemory - initialMemory.current;
        setMemoryGrowth(growth);
        
        // Advertir si el crecimiento es significativo
        if (growth > 50 * 1024 * 1024) { // 50MB
          console.warn(`Potential memory leak detected: ${(growth / 1024 / 1024).toFixed(2)}MB growth`);
        }
      }
    }, 30000); // Check every 30 seconds
    
    return () => clearInterval(interval);
  }, []);
  
  return { memoryGrowth };
}
