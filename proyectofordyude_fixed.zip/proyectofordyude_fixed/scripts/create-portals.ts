
import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const prisma = new PrismaClient();

async function createPortals() {
  console.log('🚀 Creando portales cautivos específicos...');

  try {
    // 1. Portal Ford General
    const fordPortal = await prisma.portal.upsert({
      where: { slug: 'ford-general' },
      update: {},
      create: {
        name: 'Portal Ford General',
        slug: 'ford-general',
        type: 'FORD',
        brand: 'Ford',
        description: 'Portal cautivo principal de Ford Yude Canahuati',
        logoUrl: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
        primaryColor: '#003478',
        secondaryColor: '#FFFFFF',
        welcomeTitle: 'Bienvenido a Ford Yude Canahuati',
        welcomeMessage: 'Conéctate a internet y descubre nuestros vehículos y servicios excepcionales.',
        isActive: true,
        metadata: {
          canApplyThemes: true,
          allowCustomization: true,
          showPromotions: true,
          showNews: true
        }
      }
    });

    // 2. Portal QuickLane General  
    const quicklanePortal = await prisma.portal.upsert({
      where: { slug: 'quicklane-general' },
      update: {},
      create: {
        name: 'Portal QuickLane',
        slug: 'quicklane-general', 
        type: 'QUICKLANE',
        brand: 'QuickLane',
        description: 'Portal cautivo para servicios QuickLane',
        logoUrl: 'https://imgs.search.brave.com/WMc4RKx9R94smsBLzGsl-bePgLA1Yw8iLXHk7rJDqmQ/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c2NoZW1lY29sb3Iu/Y29tL2ltYWdlcy9z/Y2hlbWUvcXVpY2st/bGFuZS1icmFuZC1j/b2xvcnMucG5n',
        primaryColor: '#FF6600',
        secondaryColor: '#FFFFFF', 
        welcomeTitle: 'Bienvenido a QuickLane',
        welcomeMessage: 'Servicio rápido sin cita previa. Conéctate y conoce nuestros servicios express.',
        isActive: true,
        metadata: {
          canApplyThemes: true,
          allowCustomization: true,
          showPromotions: true,
          focusService: true
        }
      }
    });

    // 3. Portal QuickLane Truck
    const quicklaneTruckPortal = await prisma.portal.upsert({
      where: { slug: 'quicklane-truck' },
      update: {},
      create: {
        name: 'Portal QuickLane Truck',
        slug: 'quicklane-truck',
        type: 'QUICKLANE_TRUCK',
        brand: 'QuickLane',
        description: 'Portal cautivo especializado en servicios para camiones',
        logoUrl: 'https://imgs.search.brave.com/7sKMTb1RYRITr3J9lRkO89ZK6TZeFaCEhlvRfOPlbWY/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9kaWdp/dGFsYXNzZXQuaW50/dWl0LmNvbS9jb250/ZW50L2RhbS9pbnR1/aXQvcWItZGVzaWdu/L2JyYW5kL2JyYW5k/LWZvdW5kYXRpb25z/L2xvZ28vZG8tbm90/LWFkZC1wcm9kdWN0/LW5hbWUtdG8tbG9n/by1waG90by5zdmc',
        primaryColor: '#FF6600',
        secondaryColor: '#000000',
        welcomeTitle: 'QuickLane Truck Services',
        welcomeMessage: 'Servicios especializados para tu camión Ford. Mantenimiento profesional sin cita previa.',
        isActive: true,
        metadata: {
          canApplyThemes: true,
          allowCustomization: true,
          showPromotions: true,
          vehicleType: 'truck',
          specialServices: ['oil_change', 'brake_service', 'tire_service', 'battery_service']
        }
      }
    });

    // 4. Portal QuickLane Tegucigalpa
    const quicklaneTegusPortal = await prisma.portal.upsert({
      where: { slug: 'quicklane-tegucigalpa' },
      update: {},
      create: {
        name: 'Portal QuickLane Tegucigalpa',
        slug: 'quicklane-tegucigalpa',
        type: 'QUICKLANE_TEGUS',
        brand: 'QuickLane',
        description: 'Portal cautivo QuickLane ubicación Tegucigalpa',
        logoUrl: 'https://imgs.search.brave.com/Gm7DjKsogFMvm5hDj-5d8n2dmNgBcnwIefVpO6oDZIE/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c2NoZW1lY29sb3Iu/Y29tL2ltYWdlcy9z/Y2hlbWUvb3Jhbmdl/LXdoaXRlLWJsYWNr/LnBuZw',
        primaryColor: '#FF6600',
        secondaryColor: '#FFFFFF',
        welcomeTitle: 'QuickLane Tegucigalpa',
        welcomeMessage: 'Tu QuickLane en la capital. Servicio rápido y confiable en el corazón de Honduras.',
        isActive: true,
        metadata: {
          canApplyThemes: true,
          allowCustomization: true,
          showPromotions: true,
          location: 'tegucigalpa',
          address: 'Tegucigalpa, Francisco Morazán, Honduras',
          phone: '+504 2234-5678'
        }
      }
    });

    // 5. Portal QuickLane San Pedro Sula
    const quicklaneSpsPortal = await prisma.portal.upsert({
      where: { slug: 'quicklane-sps' },
      update: {},
      create: {
        name: 'Portal QuickLane San Pedro Sula',
        slug: 'quicklane-sps',
        type: 'QUICKLANE_SPS',
        brand: 'QuickLane',
        description: 'Portal cautivo QuickLane ubicación San Pedro Sula',
        logoUrl: 'https://imgs.search.brave.com/O58PwaMKFNdL0NFhLh0tdFkh6WBfYEhzfFXPqurCrF8/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly93d3cu/c2NoZW1lY29sb3Iu/Y29tL2ltYWdlcy9z/Y2hlbWUvb3Jhbmdl/LXdoaXRlLnBuZw',
        primaryColor: '#FF6600',
        secondaryColor: '#FFFFFF',
        welcomeTitle: 'QuickLane San Pedro Sula',
        welcomeMessage: 'Tu QuickLane en la zona norte. Mantenimiento express para tu Ford en San Pedro Sula.',
        isActive: true,
        metadata: {
          canApplyThemes: true,
          allowCustomization: true,
          showPromotions: true,
          location: 'san_pedro_sula',
          address: 'San Pedro Sula, Cortés, Honduras',
          phone: '+504 2550-1234'
        }
      }
    });

    // Crear tokens de acceso para cada portal
    const portals = [fordPortal, quicklanePortal, quicklaneTruckPortal, quicklaneTegusPortal, quicklaneSpsPortal];
    
    for (const portal of portals) {
      const token = crypto.randomBytes(32).toString('hex');
      await prisma.portalToken.upsert({
        where: { token },
        update: {},
        create: {
          token,
          name: `Token ${portal.name}`,
          description: `Token de acceso público para ${portal.name}`,
          portalType: portal.type.toLowerCase().replace(/_/g, '-'),
          isActive: true,
          createdBy: 'system'
        }
      });
      console.log(`✅ Creado portal: ${portal.name} con token: ${token}`);
    }

    // Crear tema especial de aniversario de Yude
    const anniversaryTheme = await prisma.theme.upsert({
      where: { name: 'yude-anniversary' },
      update: {},
      create: {
        name: 'yude-anniversary',
        displayName: 'Aniversario Yude',
        description: 'Tema especial para celebrar el aniversario de Ford Yude Canahuati',
        isActive: true,
        primaryColor: '#DAA520', // Dorado
        secondaryColor: '#FFFFFF',
        accentColor: '#003478', // Ford Blue
        backgroundImage: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
        logoImage: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
        customCss: `
          .anniversary-theme {
            background: linear-gradient(135deg, #DAA520 0%, #B8860B 50%, #FFD700 100%);
          }
          .anniversary-sparkle {
            animation: sparkle 2s ease-in-out infinite alternate;
          }
          @keyframes sparkle {
            0% { opacity: 0.8; transform: scale(1); }
            100% { opacity: 1; transform: scale(1.05); }
          }
          .anniversary-banner {
            background: linear-gradient(90deg, #DAA520, #FFD700, #DAA520);
            color: #003478;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
          }
        `,
        metadata: {
          isSpecial: true,
          category: 'celebration',
          elements: {
            showFireworks: true,
            showAnniversaryBanner: true,
            specialGreeting: 'Celebrando años de excelencia automotriz',
            festiveColors: ['#DAA520', '#FFD700', '#B8860B']
          }
        }
      }
    });

    // Crear configuración para el tema de aniversario
    await prisma.themeConfig.upsert({
      where: { themeId: anniversaryTheme.id },
      update: {},
      create: {
        themeId: anniversaryTheme.id,
        logoPosition: 'center',
        headerHeight: 100,
        footerEnabled: true,
        animationsEnabled: true,
        parallaxEnabled: true,
        customFonts: {
          primary: 'Playfair Display',
          secondary: 'Roboto'
        },
        buttonStyles: {
          primary: {
            background: 'linear-gradient(135deg, #DAA520, #FFD700)',
            color: '#003478',
            border: '2px solid #B8860B'
          }
        },
        cardStyles: {
          background: 'rgba(255, 215, 0, 0.1)',
          border: '1px solid #DAA520'
        }
      }
    });

    console.log('✅ Tema de aniversario creado exitosamente');

    console.log('\n🎉 ¡Todos los portales cautivos han sido creados exitosamente!');
    console.log('\nPortales disponibles:');
    console.log('- Portal Ford General (puede aplicar temas)');
    console.log('- Portal QuickLane General (puede aplicar temas)');
    console.log('- Portal QuickLane Truck (logos específicos)');
    console.log('- Portal QuickLane Tegucigalpa (logos específicos)');
    console.log('- Portal QuickLane San Pedro Sula (logos específicos)');
    console.log('\nTemas especiales:');
    console.log('- Tema Aniversario Yude (dorado y festivo)');

  } catch (error) {
    console.error('❌ Error creando portales:', error);
  } finally {
    await prisma.$disconnect();
  }
}

createPortals();
