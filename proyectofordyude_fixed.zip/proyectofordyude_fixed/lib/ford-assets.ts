
export const fordAssets = {
  "brand_colors": {
    "primary": {
      "ford_blue": {
        "hex": "#003478",
        "rgb": [0, 52, 120],
        "cmyk": [100, 89, 26, 12],
        "pantone": "PMS 288 C",
        "description": "Color azul principal de Ford, usado en el óvalo azul y como color dominante de marca"
      }
    },
    "secondary": {
      "white": {
        "hex": "#FFFFFF",
        "rgb": [255, 255, 255],
        "cmyk": [0, 0, 0, 0],
        "description": "Color complementario obligatorio para logotipos y texto sobre Ford Blue"
      },
      "silver_sand": {
        "hex": "#C6C6C6",
        "rgb": [198, 198, 198],
        "cmyk": [0, 0, 0, 22],
        "pantone": "PMS 420 C",
        "description": "Gris frío para elementos secundarios"
      }
    },
    "accent_colors": {
      "maastricht_blue": {
        "hex": "#081534",
        "rgb": [8, 21, 52],
        "cmyk": [85, 60, 0, 80],
        "pantone": "PMS 296 C"
      },
      "dark_cerulean": {
        "hex": "#133A7C",
        "rgb": [19, 58, 124],
        "cmyk": [85, 53, 0, 51],
        "pantone": "PMS 3591 C"
      },
      "lapis_lazuli": {
        "hex": "#2A6BAC",
        "rgb": [42, 107, 172],
        "cmyk": [76, 38, 0, 33],
        "pantone": "PMS 7455 C"
      },
      "picton_blue": {
        "hex": "#47A8E5",
        "rgb": [71, 168, 229],
        "cmyk": [69, 27, 0, 10],
        "pantone": "PMS 298 C"
      }
    }
  },
  "logos": {
    "official_transparent": [
      {
        "type": "PNG transparente oficial",
        "resolution": "2000x1440",
        "url": "https://www.freepnglogos.com/uploads/large-ford-logo-0.png",
        "description": "Logo Ford oficial en PNG con fondo transparente, alta resolución"
      },
      {
        "type": "PNG HD aislado",
        "resolution": "2048x2048",
        "url": "https://www.pngmart.com/files/22/Ford-Logo-PNG-HD-Isolated.png",
        "description": "Logo Ford HD aislado, formato cuadrado"
      },
      {
        "type": "PNG transparente horizontal",
        "resolution": "2500x949",
        "url": "https://freepnglogo.com/images/all_img/1719934890ford-logo-png.png",
        "description": "Logo Ford horizontal con fondo transparente"
      }
    ],
    "blue_oval_versions": [
      {
        "type": "Óvalo azul alta resolución",
        "resolution": "1800x1200",
        "url": "https://wallpapers.com/images/hd/ford-logo-1800-x-1200-wallpaper-9aaksmtk072ewndr.jpg",
        "description": "Logo Ford óvalo azul sobre fondo negro"
      }
    ],
    "white_versions": [
      {
        "type": "Logo blanco transparente",
        "resolution": "1920x960",
        "url": "https://static.vecteezy.com/system/resources/previews/019/909/675/large_2x/ford-transparent-ford-free-free-png.png",
        "description": "Logo Ford en blanco con fondo transparente"
      }
    ]
  },
  "vehicles": {
    "mustang": [
      {
        "type": "Ford Mustang oficial 4K",
        "resolution": "3840x2160",
        "url": "https://i.pinimg.com/originals/0c/1d/68/0c1d68b46c3f7b23b87a37185c570c7f.jpg",
        "description": "Ford Mustang 1967 Charge Cars en 4K, imagen oficial de alta calidad"
      },
      {
        "type": "Ford Mustang 4K Ultra HD",
        "resolution": "4096x2160",
        "url": "https://wallpapercave.com/wp/wp5562176.jpg",
        "description": "Ford Mustang moderno en 4K Ultra HD"
      }
    ],
    "f150": [
      {
        "type": "Ford F-150 2025 oficial",
        "resolution": "1280x720",
        "url": "https://i.ytimg.com/vi/xrrrpZhBlDc/maxresdefault.jpg",
        "description": "Nueva Ford F-150 2025 pickup truck, imagen promocional oficial"
      }
    ],
    "explorer": [
      {
        "type": "Ford Explorer 2025 SUV",
        "resolution": "2000x754",
        "url": "https://images.dealer.com/ddc/vehicles/2025/Ford/Explorer/SUV/trim_Active_2a83d6/perspective/side-left/2025_76.png",
        "description": "Ford Explorer 2025 SUV vista lateral, imagen de concesionario oficial"
      },
      {
        "type": "Ford Explorer marketing",
        "resolution": "1920x550",
        "url": "https://trafficcontrolmarketing.com/dealer_photos/Ford/2025/Explorer/images/Header01.jpg",
        "description": "Ford Explorer imagen de marketing oficial"
      }
    ],
    "bronco": [
      {
        "type": "Ford Bronco promocional oficial",
        "resolution": "1400x918",
        "url": "https://s1.cdn.autoevolution.com/images/news/gallery/2021-ford-bronco-official-reveal-set-for-july-2020-teasers-incoming_14.jpg",
        "description": "Ford Bronco 2021 imagen promocional oficial de autoevolution"
      }
    ]
  },
  "themed_images": {
    "dia_de_la_madre": [
      {
        "type": "Ford Día de la Madre promocional",
        "resolution": "1080x1080",
        "url": "https://lookaside.fbsbx.com/lookaside/crawler/media/?media_id=2573326649363062",
        "description": "Publicación oficial Ford Talleres Martinez Día de la Madre"
      },
      {
        "type": "Campaña Día de las Madres genérica",
        "resolution": "1916x1917",
        "url": "https://i.pinimg.com/originals/61/9c/45/619c45e1bc98be4819d819dad15d1445.jpg",
        "description": "Diseño promocional para Día de las Madres aplicable a Ford"
      }
    ],
    "dia_de_la_mujer": [
      {
        "type": "Ford women empowerment campaign",
        "resolution": "1280x720",
        "url": "https://i.ytimg.com/vi/no1XAbBt9Hw/maxresdefault.jpg",
        "description": "Campaña Ford de empoderamiento femenino - equipo femenino construyendo Bronco"
      },
      {
        "type": "Ford Ecuador women campaign",
        "resolution": "1238x2200",
        "url": "https://i.pinimg.com/originals/f3/03/d4/f303d4e1b5cfcee05e1a73acbd52db54.jpg",
        "description": "Campaña Ford Ecuador rompiendo estereotipos de género"
      }
    ],
    "dia_del_hombre": [
      {
        "type": "Father's Day Ford promotional",
        "resolution": "1500x902",
        "url": "https://smartcdn.gprod.postmedia.digital/nexus/wp-content/uploads/2024/05/Car-Show.png",
        "description": "Ford Father's Day Car Show con clásicos Ford"
      },
      {
        "type": "Ford Ranger campaña masculina",
        "resolution": "850x1276",
        "url": "https://i.pinimg.com/originals/53/98/c3/5398c3f85d4e21a6c9e49bd65138fb46.png",
        "description": "Campaña Ford Ranger dirigida al público masculino"
      }
    ],
    "independencia_honduras": [
      {
        "type": "Desfile Ford Honduras 2024",
        "resolution": "940x700",
        "url": "https://iconosmag.com/wp-content/uploads/2024/06/portada-desfile-agas-yude-ford-honduras-2024-1.jpg",
        "description": "Desfile Agas Yude Ford Honduras 2024 San Pedro Sula"
      },
      {
        "type": "Ford Honduras Independence Day",
        "resolution": "900x696",
        "url": "https://iconosmag.com/wp-content/uploads/2024/06/desfile-agas-yude-ford-san-pedro-sula-2024.jpg",
        "description": "Celebración Día de la Independencia Ford Honduras"
      }
    ],
    "navidad": [
      {
        "type": "Ford Christmas campaign",
        "resolution": "736x514",
        "url": "https://i.pinimg.com/736x/92/bf/f1/92bff1422ecc8bc9b6ffd55a6014a4da--chat-board-card-designs.jpg",
        "description": "Campaña navideña Ford clásica con temática navideña"
      },
      {
        "type": "Ford Built For Holidays",
        "resolution": "1500x752",
        "url": "https://fordauthority.com/wp-content/uploads/2020/12/Ford-Built-For-The-Holidays-Running-Of-The-Santas-Commercial-004.jpg",
        "description": "Comercial Ford 'Built For The Holidays' con Santas corriendo"
      },
      {
        "type": "Ford Navidad SUV",
        "resolution": "750x810",
        "url": "https://autoland.com.pe/wp-content/uploads/2020/12/BANLP_Navidad_750x810.png",
        "description": "Banner navideño Ford SUV Perú"
      }
    ],
    "verano": [
      {
        "type": "Ford Summer Experience 2025",
        "resolution": "1200x800",
        "url": "https://automundo.com.ar/wp-content/uploads/2024/12/Verano-2025-Ford-3.jpeg",
        "description": "Ford Summer Experience 2025 Argentina"
      },
      {
        "type": "Ford Summer Energy Cariló",
        "resolution": "1024x686",
        "url": "https://cuyomotor.com.ar/wp-content/uploads/2024/01/Ford-verano-2024-carilo-1024x686.jpg",
        "description": "Ford Summer Energy 2024 en Cariló"
      },
      {
        "type": "Ford Summer Attraction",
        "resolution": "1300x860",
        "url": "http://www.conduciendo.com/wp-content/uploads/2017/12/FordSummerAttraction-21122017-02.jpg",
        "description": "Ford Summer Attraction con novedades de la marca"
      }
    ]
  },
  "design_elements": {
    "corporate_patterns": [
      {
        "type": "Ford brand logo fondo azul",
        "resolution": "1920x1561",
        "url": "https://static.vecteezy.com/system/resources/previews/020/500/239/original/ford-brand-logo-car-symbol-white-design-usa-automobile-illustration-with-blue-background-free-vector.jpg",
        "description": "Logo Ford con fondo azul corporativo, diseño vectorial"
      }
    ],
    "showroom_elements": [
      {
        "type": "Ford showroom design moderno",
        "resolution": "6240x4160",
        "url": "https://thedesigncompound.com/data/portfolio/ford-automobile-showroom/03-ford-cars-display.jpg?20200505",
        "description": "Diseño interior moderno de showroom Ford con exhibición de vehículos"
      },
      {
        "type": "Ford showroom recepción",
        "resolution": "5472x3648",
        "url": "https://thedesigncompound.com/data/portfolio/ford-automobile-showroom/18-reception-design.jpg?20210929201239",
        "description": "Área de recepción elegante en showroom Ford"
      }
    ]
  }
};

export const getThemeAssets = (themeName: string) => {
  const themeMap: Record<string, any> = {
    'mother': fordAssets.themed_images.dia_de_la_madre,
    'woman': fordAssets.themed_images.dia_de_la_mujer,
    'man': fordAssets.themed_images.dia_del_hombre,
    'independence': fordAssets.themed_images.independencia_honduras,
    'xmas': fordAssets.themed_images.navidad,
    'summer': fordAssets.themed_images.verano
  };
  
  return themeMap[themeName] || [];
};
