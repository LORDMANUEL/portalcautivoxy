
'use client';

import { useEffect } from 'react';
import { signOut } from 'next-auth/react';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function AdminLogoutPage() {
  useEffect(() => {
    signOut({ callbackUrl: '/admin/login' });
  }, []);

  return (
    <div className="min-h-screen bg-[#003478] flex items-center justify-center">
      <div className="text-center space-y-4">
        <LoadingSpinner size="lg" message="Cerrando sesión..." />
        <p className="text-white text-lg">
          Hasta pronto, administrador
        </p>
      </div>
    </div>
  );
}
