

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import bcrypt from 'bcryptjs';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/user-management
 * Obtiene todos los administradores con sus roles y ubicaciones
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const admins = await prisma.admin.findMany({
      include: {
        location: {
          select: {
            name: true,
            code: true
          }
        },
        roles: {
          include: {
            role: {
              select: {
                id: true,
                name: true,
                displayName: true,
                priority: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(admins);
  } catch (error) {
    console.error('Error al obtener administradores:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * POST /api/admin/user-management
 * Crea un nuevo administrador
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { username, email, name, password, locationId, isActive, roleIds } = body;

    if (!username || !name || !password) {
      return NextResponse.json({ error: 'Usuario, nombre y contraseña son obligatorios' }, { status: 400 });
    }

    if (!roleIds || roleIds.length === 0) {
      return NextResponse.json({ error: 'Debe asignar al menos un rol' }, { status: 400 });
    }

    // Verificar que el username sea único
    const existingAdmin = await prisma.admin.findUnique({
      where: { username }
    });

    if (existingAdmin) {
      return NextResponse.json({ error: 'Ya existe un administrador con este usuario' }, { status: 400 });
    }

    // Hash de la contraseña
    const hashedPassword = await bcrypt.hash(password, 12);

    // Crear el administrador
    const admin = await prisma.admin.create({
      data: {
        username,
        email: email || null,
        name,
        password: hashedPassword,
        locationId: locationId || null,
        isActive: isActive !== false,
        role: 'ADMIN' // Legacy field
      }
    });

    // Asignar roles
    const roleAssignments = roleIds.map((roleId: string) => ({
      adminId: admin.id,
      roleId,
      assignedBy: session.user?.id || 'admin'
    }));

    await prisma.adminRole.createMany({
      data: roleAssignments
    });

    // Obtener el admin creado con sus roles
    const createdAdmin = await prisma.admin.findUnique({
      where: { id: admin.id },
      include: {
        location: {
          select: {
            name: true,
            code: true
          }
        },
        roles: {
          include: {
            role: {
              select: {
                id: true,
                name: true,
                displayName: true,
                priority: true
              }
            }
          }
        }
      }
    });

    return NextResponse.json(createdAdmin);
  } catch (error) {
    console.error('Error al crear administrador:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
