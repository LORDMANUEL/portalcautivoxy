
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/contact/[id]/vcard
 * Descarga archivo vCard (.vcf) desde página de contacto
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    });

    if (!vcard || !vcard.isActive) {
      return NextResponse.json({ error: 'Contacto no encontrado' }, { status: 404 });
    }

    // Incrementar contador de descargas
    await prisma.vCard.update({
      where: { id: params.id },
      data: { downloadCount: { increment: 1 } }
    });

    // Crear contenido vCard estándar
    const vCardContent = `BEGIN:VCARD
VERSION:3.0
FN:${vcard.advisorName}
ORG:${vcard.company}
TITLE:${vcard.position || 'Asesor de Servicio'}
EMAIL:${vcard.email}
TEL:${vcard.phone || ''}
ADR:;;${vcard.address || ''};;;;
URL:${vcard.website || ''}
NOTE:Contacto desde Ford Yude Canahuati Portal Cautivo
PHOTO:${vcard.photo || ''}
END:VCARD`;

    return new NextResponse(vCardContent, {
      headers: {
        'Content-Type': 'text/vcard',
        'Content-Disposition': `attachment; filename="${vcard.advisorName.replace(/\s+/g, '-').toLowerCase()}.vcf"`
      }
    });
  } catch (error) {
    console.error('Error al generar vCard:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
