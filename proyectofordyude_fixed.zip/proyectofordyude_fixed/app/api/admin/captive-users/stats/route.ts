
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

/**
 * GET - Obtiene estadísticas de usuarios del portal cautivo
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Estadísticas simuladas
    const stats = {
      totalUsers: 2847,
      activeUsers: 156,
      newUsersToday: 23,
      averageSession: 18,
      topPortal: 'Ford General',
      totalSessions: 4521,
      deviceBreakdown: {
        mobile: 1654,
        desktop: 892,
        tablet: 301
      },
      popularTimes: [
        { hour: 8, count: 45 },
        { hour: 9, count: 78 },
        { hour: 10, count: 92 },
        { hour: 11, count: 87 },
        { hour: 12, count: 65 },
        { hour: 13, count: 123 },
        { hour: 14, count: 145 },
        { hour: 15, count: 167 },
        { hour: 16, count: 189 },
        { hour: 17, count: 156 },
        { hour: 18, count: 134 },
        { hour: 19, count: 98 }
      ]
    };

    return NextResponse.json(stats);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
