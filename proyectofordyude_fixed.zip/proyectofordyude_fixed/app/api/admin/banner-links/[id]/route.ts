import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;

    const mockBanner = {
      id,
      name: 'Banner ' + id,
      description: 'Descripción del banner ' + id,
      bannerUrl: 'https://via.placeholder.com/400x300/003478/FFFFFF?text=Banner+' + id,
      targetUrl: 'https://fordyude.com',
      embedCode: '<div><a href="https://fordyude.com"><img src="https://via.placeholder.com/400x300" alt="Banner ' + id + '" /></a></div>',
      qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://fordyude.com',
      width: 400,
      height: 300,
      format: 'jpg',
      isActive: true,
      clickCount: Math.floor(Math.random() * 500),
      viewCount: Math.floor(Math.random() * 2000),
      portal: 'ford-general',
      theme: 'default',
      customization: {
        backgroundColor: '#FFFFFF',
        textColor: '#003478',
        borderColor: '#CCCCCC',
        borderRadius: 8,
        shadow: true,
        animation: false
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    return NextResponse.json(mockBanner);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const { id } = params;
    const updates = await request.json();

    const updatedBanner = {
      id,
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return NextResponse.json(updatedBanner);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Banner eliminado exitosamente' 
    });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
