
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Database,
  Download,
  Upload,
  Calendar,
  Clock,
  HardDrive,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Play,
  Pause,
  Settings,
  RefreshCw,
  FileDown,
  Trash2,
  Eye
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';

interface Backup {
  id: string;
  name: string;
  type: string;
  status: string;
  locationId: string | null;
  filePath: string | null;
  fileSize: string | null;
  compressionType: string;
  isAutomatic: boolean;
  isEncrypted: boolean;
  startedAt: string;
  completedAt: string | null;
  errorMessage: string | null;
  retentionDays: number;
  location?: {
    name: string;
    code: string;
  };
}

interface BackupFormData {
  name: string;
  type: string;
  locationId: string;
  compressionType: string;
  isEncrypted: boolean;
  retentionDays: string;
}

export function BackupClient() {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isConnectionModalOpen, setIsConnectionModalOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [progress, setProgress] = useState(0);

  const [stats, setStats] = useState({
    totalBackups: 0,
    successfulBackups: 0,
    failedBackups: 0,
    totalSize: 0,
    lastBackup: null as string | null
  });

  const [formData, setFormData] = useState<BackupFormData>({
    name: '',
    type: 'FULL',
    locationId: '',
    compressionType: 'gzip',
    isEncrypted: false,
    retentionDays: '30'
  });

  useEffect(() => {
    fetchBackups();
    fetchLocations();
    fetchStats();
  }, []);

  const fetchBackups = async () => {
    try {
      const response = await fetch('/api/admin/backups');
      if (response.ok) {
        const data = await response.json();
        setBackups(data);
      } else {
        toast.error('Error al cargar los backups');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/admin/locations');
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error('Error al cargar ubicaciones');
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/backups/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error al cargar estadísticas');
    }
  };

  const handleInputChange = (field: keyof BackupFormData, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleCreateBackup = async () => {
    if (!formData.name) {
      toast.error('El nombre del backup es obligatorio');
      return;
    }

    setCreating(true);
    setProgress(0);

    try {
      const payload = {
        ...formData,
        retentionDays: parseInt(formData.retentionDays) || 30
      };

      const response = await fetch('/api/admin/backups', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success('Backup iniciado correctamente');
        setIsModalOpen(false);
        resetForm();
        
        const progressInterval = setInterval(() => {
          setProgress(prev => {
            if (prev >= 100) {
              clearInterval(progressInterval);
              fetchBackups();
              fetchStats();
              return 100;
            }
            return prev + Math.random() * 15;
          });
        }, 500);

      } else {
        toast.error('Error al crear el backup');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setTimeout(() => {
        setCreating(false);
        setProgress(0);
      }, 2000);
    }
  };

  const handleDownloadBackup = async (backup: Backup) => {
    try {
      const response = await fetch(`/api/admin/backups/${backup.id}/download`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `backup-${backup.name}-${new Date(backup.startedAt).toISOString().split('T')[0]}.sql.gz`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } else {
        toast.error('Error al descargar el backup');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  const handleDeleteBackup = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este backup?')) return;

    try {
      const response = await fetch(`/api/admin/backups/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Backup eliminado correctamente');
        fetchBackups();
        fetchStats();
      } else {
        toast.error('Error al eliminar el backup');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'FULL',
      locationId: '',
      compressionType: 'gzip',
      isEncrypted: false,
      retentionDays: '30'
    });
  };

  const formatFileSize = (bytes: string) => {
    if (!bytes) return 'N/A';
    const size = parseInt(bytes);
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    if (size === 0) return '0 Bytes';
    const i = Math.floor(Math.log(size) / Math.log(1024));
    return Math.round(size / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'COMPLETED': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'FAILED': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'RUNNING': return <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />;
      default: return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  // Exportar código fuente del proyecto
  const handleExportSourceCode = async () => {
    try {
      const response = await fetch('/api/admin/backups/export-source', {
        method: 'POST'
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ford-yude-source-${new Date().toISOString().split('T')[0]}.zip`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('Código fuente exportado exitosamente');
      } else {
        toast.error('Error al exportar código fuente');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  // Importar datos desde archivo
  const handleImportData = async (file: File) => {
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/admin/backups/import', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        toast.success('Datos importados exitosamente');
        fetchBackups();
        setIsImportModalOpen(false);
      } else {
        toast.error('Error al importar datos');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  // Conectar a base de datos externa
  const handleExternalConnection = async (connectionData: any) => {
    try {
      const response = await fetch('/api/admin/backups/external-db', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(connectionData),
      });

      if (response.ok) {
        toast.success('Conexión externa establecida');
        setIsConnectionModalOpen(false);
      } else {
        toast.error('Error en conexión externa');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando sistema de backup..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <FordCard>
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Backups</p>
                <p className="text-2xl font-bold text-gray-800">{stats.totalBackups}</p>
              </div>
              <Database className="w-8 h-8 text-[#003478]" />
            </div>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Exitosos</p>
                <p className="text-2xl font-bold text-green-600">{stats.successfulBackups}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Fallidos</p>
                <p className="text-2xl font-bold text-red-600">{stats.failedBackups}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tamaño Total</p>
                <p className="text-2xl font-bold text-gray-800">
                  {formatFileSize(stats.totalSize.toString())}
                </p>
              </div>
              <HardDrive className="w-8 h-8 text-[#003478]" />
            </div>
          </div>
        </FordCard>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <Database className="w-8 h-8 text-[#003478]" />
            Backup Base de Datos
          </h1>
          <p className="text-gray-600 mt-1">
            Sistema automático de respaldo y recuperación
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <FordButton variant="outline" onClick={fetchBackups}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Actualizar
          </FordButton>

          <FordButton variant="outline" onClick={handleExportSourceCode}>
            <FileDown className="w-4 h-4 mr-2" />
            Exportar Código
          </FordButton>

          <FordButton variant="outline" onClick={() => setIsImportModalOpen(true)}>
            <Upload className="w-4 h-4 mr-2" />
            Importar Datos
          </FordButton>

          <FordButton variant="outline" onClick={() => setIsConnectionModalOpen(true)}>
            <Settings className="w-4 h-4 mr-2" />
            BD Externa
          </FordButton>

          <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
            <DialogTrigger asChild>
              <FordButton onClick={() => resetForm()}>
                <Database className="w-4 h-4 mr-2" />
                Nuevo Backup
              </FordButton>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Crear Nuevo Backup</DialogTitle>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="name">Nombre del Backup *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    placeholder={`Backup semanal - ${new Date().toLocaleDateString()}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Tipo de Backup</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => handleInputChange('type', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FULL">Completo</SelectItem>
                      <SelectItem value="PARTIAL">Parcial</SelectItem>
                      <SelectItem value="INCREMENTAL">Incremental</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="compressionType">Compresión</Label>
                  <Select
                    value={formData.compressionType}
                    onValueChange={(value) => handleInputChange('compressionType', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gzip">GZIP</SelectItem>
                      <SelectItem value="zip">ZIP</SelectItem>
                      <SelectItem value="none">Sin compresión</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2 md:col-span-2">
                  <Switch
                    id="isEncrypted"
                    checked={formData.isEncrypted}
                    onCheckedChange={(checked) => handleInputChange('isEncrypted', checked)}
                  />
                  <Label htmlFor="isEncrypted">Encriptar Backup</Label>
                  <Shield className="w-4 h-4 text-gray-500" />
                </div>
              </div>

              {creating && (
                <div className="py-4">
                  <Label className="text-sm font-medium mb-2 block">
                    Progreso del Backup: {Math.round(progress)}%
                  </Label>
                  <Progress value={progress} className="w-full" />
                </div>
              )}

              <div className="flex justify-end space-x-2">
                <FordButton
                  variant="outline"
                  onClick={() => {
                    setIsModalOpen(false);
                    resetForm();
                  }}
                  disabled={creating}
                >
                  Cancelar
                </FordButton>
                <FordButton onClick={handleCreateBackup} disabled={creating}>
                  {creating ? (
                    <LoadingSpinner size="sm" message="Creando..." />
                  ) : (
                    <>
                      <Database className="w-4 h-4 mr-2" />
                      Crear Backup
                    </>
                  )}
                </FordButton>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {backups.length === 0 ? (
        <FordCard className="text-center py-12">
          <Database className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            No hay backups disponibles
          </h3>
          <p className="text-gray-500 mb-4">
            Crea tu primer backup para comenzar
          </p>
        </FordCard>
      ) : (
        <div className="space-y-4">
          {backups.map((backup) => (
            <motion.div
              key={backup.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <FordCard className="hover:shadow-lg transition-all duration-200">
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      {getStatusIcon(backup.status)}
                      <div>
                        <h3 className="font-semibold text-gray-800">
                          {backup.name}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(backup.startedAt).toLocaleString('es-HN')}
                          </span>
                          {backup.location && (
                            <span className="flex items-center">
                              <HardDrive className="w-4 h-4 mr-1" />
                              {backup.location.name}
                            </span>
                          )}
                          <span className="flex items-center">
                            <HardDrive className="w-4 h-4 mr-1" />
                            {formatFileSize(backup.fileSize || '0')}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        backup.type === 'FULL' ? 'bg-blue-100 text-blue-800' :
                        backup.type === 'PARTIAL' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {backup.type}
                      </span>

                      {backup.isEncrypted && (
                        <div title="Encriptado">
                          <Shield className="w-4 h-4 text-green-600" />
                        </div>
                      )}

                      {backup.status === 'COMPLETED' && (
                        <>
                          <FordButton
                            size="sm"
                            variant="outline"
                            onClick={() => handleDownloadBackup(backup)}
                          >
                            <Download className="w-4 h-4" />
                          </FordButton>
                        </>
                      )}

                      <FordButton
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteBackup(backup.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </FordButton>
                    </div>
                  </div>

                  {backup.errorMessage && (
                    <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-center text-red-800">
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        <span className="text-sm">{backup.errorMessage}</span>
                      </div>
                    </div>
                  )}
                </div>
              </FordCard>
            </motion.div>
          ))}
        </div>
      )}

      {/* Modal para importar datos */}
      <Dialog open={isImportModalOpen} onOpenChange={setIsImportModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Importar Datos</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="import-file">Seleccionar archivo de respaldo</Label>
              <Input
                id="import-file"
                type="file"
                accept=".sql,.gz,.zip"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleImportData(file);
                }}
              />
            </div>
            <p className="text-sm text-gray-500">
              Formatos soportados: .sql, .gz, .zip
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal para conexión BD externa */}
      <Dialog open={isConnectionModalOpen} onOpenChange={setIsConnectionModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Conectar Base de Datos Externa</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ext-host">Host</Label>
                <Input id="ext-host" placeholder="localhost" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ext-port">Puerto</Label>
                <Input id="ext-port" placeholder="5432" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ext-database">Base de Datos</Label>
              <Input id="ext-database" placeholder="nombre_bd" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ext-username">Usuario</Label>
                <Input id="ext-username" placeholder="usuario" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ext-password">Contraseña</Label>
                <Input id="ext-password" type="password" placeholder="••••••••" />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <FordButton variant="outline" onClick={() => setIsConnectionModalOpen(false)}>
                Cancelar
              </FordButton>
              <FordButton onClick={() => handleExternalConnection({})}>
                <Database className="w-4 h-4 mr-2" />
                Conectar
              </FordButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
