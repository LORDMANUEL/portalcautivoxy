
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, ipAddress, macAddress, location, description, imageUrl } = body;

    if (!name?.trim() || !ipAddress?.trim()) {
      return NextResponse.json({ error: 'Nombre e IP son requeridos' }, { status: 400 });
    }

    const accessPoint = await prisma.accessPoint.update({
      where: { id: params.id },
      data: {
        name: name.trim(),
        ipAddress: ipAddress.trim(),
        macAddress: macAddress?.trim() || null,
        location: location?.trim() || null,
        description: description?.trim() || null,
        imageUrl: imageUrl?.trim() || null,
      },
    });

    return NextResponse.json(accessPoint);
  } catch (error) {
    console.error('Error updating access point:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { isActive } = body;

    const accessPoint = await prisma.accessPoint.update({
      where: { id: params.id },
      data: { isActive },
    });

    return NextResponse.json(accessPoint);
  } catch (error) {
    console.error('Error updating access point status:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    await prisma.accessPoint.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting access point:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
