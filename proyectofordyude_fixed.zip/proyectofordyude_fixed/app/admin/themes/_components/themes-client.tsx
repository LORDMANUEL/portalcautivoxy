
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import {
  Palette,
  Eye,
  Edit,
  Trash2,
  Plus,
  Heart,
  Users,
  Flag,
  Gift,
  Sun,
  Calendar,
  ToggleLeft,
  Save,
  X,
  CheckCircle
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { toast } from 'react-hot-toast';

interface Theme {
  id: string;
  name: string;
  displayName: string;
  description?: string;
  isActive: boolean;
  primaryColor: string;
  secondaryColor: string;
  accentColor?: string;
  backgroundImage?: string;
  logoImage?: string;
  startDate?: Date;
  endDate?: Date;
  usageCount: number;
  metadata?: {
    welcomeMessage?: string;
    rssCategory?: string;
    promotionType?: string;
  };
}

const THEME_ICONS = {
  mother: Heart,
  woman: Users,
  man: Users,
  independence: Flag,
  xmas: Gift,
  summer: Sun,
  default: Palette
};

export function ThemesClient() {
  const [themes, setThemes] = useState<Theme[]>([]);
  const [editingTheme, setEditingTheme] = useState<Theme | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadThemes();
  }, []);

  const loadThemes = async () => {
    setLoading(true);
    
    try {
      const response = await fetch('/api/admin/themes');
      if (response.ok) {
        const data = await response.json();
        // Mapear datos de la API al formato del componente
        const mappedThemes = data.map((theme: any) => ({
          id: theme.id,
          name: theme.name,
          displayName: theme.displayName,
          description: theme.description || '',
          isActive: theme.isActive,
          primaryColor: theme.primaryColor,
          secondaryColor: theme.secondaryColor,
          accentColor: theme.accentColor,
          backgroundImage: theme.backgroundImage,
          logoImage: theme.logoImage,
          startDate: theme.startDate ? new Date(theme.startDate) : undefined,
          endDate: theme.endDate ? new Date(theme.endDate) : undefined,
          usageCount: theme.usageCount || 0
        }));
        setThemes(mappedThemes);
      } else {
        toast.error('Error al cargar los temas');
      }
    } catch (error) {
      console.error('Error al cargar temas:', error);
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleTheme = async (themeId: string) => {
    try {
      // Obtener el tema actual para saber su estado
      const currentTheme = themes.find(theme => theme.id === themeId);
      if (!currentTheme) return;

      const response = await fetch(`/api/admin/themes/${themeId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...currentTheme,
          isActive: !currentTheme.isActive
        }),
      });

      if (response.ok) {
        // Actualizar estado local
        setThemes(prev => prev.map(theme =>
          theme.id === themeId
            ? { ...theme, isActive: !theme.isActive }
            : theme
        ));
        
        toast.success('Estado del tema actualizado');
      } else {
        toast.error('Error al actualizar tema');
      }
    } catch (error) {
      console.error('Error al actualizar tema:', error);
      toast.error('Error de conexión');
    }
  };

  const handleEditTheme = (theme: Theme) => {
    setEditingTheme({ ...theme });
  };

  const handleSaveTheme = async () => {
    if (!editingTheme) return;
    
    try {
      const response = await fetch(`/api/admin/themes/${editingTheme.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          primaryColor: editingTheme.primaryColor,
          secondaryColor: editingTheme.secondaryColor,
          accentColor: editingTheme.accentColor,
          backgroundImage: editingTheme.backgroundImage,
          logoImage: editingTheme.logoImage,
          isActive: editingTheme.isActive
        }),
      });

      if (response.ok) {
        // Actualizar estado local
        setThemes(prev => prev.map(theme =>
          theme.id === editingTheme.id ? editingTheme : theme
        ));
        
        setEditingTheme(null);
        toast.success('Tema actualizado exitosamente');
      } else {
        toast.error('Error al guardar tema');
      }
    } catch (error) {
      console.error('Error al guardar tema:', error);
      toast.error('Error de conexión');
    }
  };

  const handleDeleteTheme = async (themeId: string) => {
    if (!confirm('¿Estás seguro de eliminar este tema?')) return;
    
    try {
      const response = await fetch(`/api/admin/themes/${themeId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Actualizar estado local
        setThemes(prev => prev.filter(theme => theme.id !== themeId));
        toast.success('Tema eliminado');
      } else {
        toast.error('Error al eliminar tema');
      }
    } catch (error) {
      console.error('Error al eliminar tema:', error);
      toast.error('Error de conexión');
    }
  };

  const handleAutoActivateThemes = async () => {
    try {
      const response = await fetch('/api/admin/themes/auto-activate', {
        method: 'POST'
      });

      if (response.ok) {
        const result = await response.json();
        toast.success(
          result.message || 'Activación automática completada',
          { 
            duration: 4000,
            position: 'top-right'
          }
        );
        
        // Recargar temas para mostrar cambios
        loadThemes();
        
        // Mostrar detalles en consola para debugging
        console.log('🎯 Resultado activación automática:', result);
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || 'Error en activación automática');
      }
    } catch (error) {
      console.error('Error en activación automática:', error);
      toast.error('Error de conexión al activar temas');
    }
  };

  const handlePreviewTheme = (theme: Theme) => {
    // Crear parámetros de color para el preview (nombres coincidentes con PreviewClient)
    const themeParams = {
      primary: theme.primaryColor,
      secondary: theme.secondaryColor,
      accent: theme.accentColor || theme.primaryColor,
      backgroundImage: theme.backgroundImage || ''
    };

    // Codificar los parámetros como query string
    const colorsParam = encodeURIComponent(JSON.stringify(themeParams));
    const previewUrl = `/portal/preview?theme=${theme.name}&colors=${colorsParam}`;
    
    // Abrir en nueva pestaña para preview
    window.open(previewUrl, '_blank');
    
    toast.success(`Previsualizando tema: ${theme.displayName}`);
  };

  const handlePreviewAccessGranted = (theme: Theme) => {
    // Aplicar temporalmente el tema y abrir página de acceso garantizado
    const themeParams = {
      primary: theme.primaryColor,
      secondary: theme.secondaryColor,
      accent: theme.accentColor || theme.primaryColor,
      backgroundImage: theme.backgroundImage || '',
      name: theme.name,
      displayName: theme.displayName,
      welcomeMessage: theme.metadata?.welcomeMessage || 'Bienvenido a Ford WiFi'
    };

    // Codificar los parámetros como query string
    const colorsParam = encodeURIComponent(JSON.stringify(themeParams));
    const previewUrl = `/portal/access-granted?preview=true&theme=${theme.name}&colors=${colorsParam}`;
    
    // Abrir en nueva pestaña para preview
    window.open(previewUrl, '_blank');
    
    toast.success(`Vista previa Acceso Garantizado: ${theme.displayName}`);
  };

  const getThemeIcon = (themeName: string) => {
    return THEME_ICONS[themeName as keyof typeof THEME_ICONS] || Palette;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
          <div className="h-10 bg-gray-300 rounded w-32 animate-pulse" />
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-64 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Temas</h1>
          <p className="text-gray-600">
            {themes.length} temas • {themes.filter(t => t.isActive).length} activos
          </p>
        </div>
        <div className="flex space-x-3">
          <FordButton
            variant="outline"
            onClick={handleAutoActivateThemes}
          >
            <Calendar className="w-4 h-4 mr-2" />
            Activación Automática
          </FordButton>
          <FordButton>
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Tema
          </FordButton>
        </div>
      </div>

      {/* Themes Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {themes.map((theme, index) => {
          const IconComponent = getThemeIcon(theme.name);
          
          return (
            <motion.div
              key={theme.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <FordCard className="overflow-hidden" hover>
                {/* Theme Preview */}
                <div 
                  className="h-32 relative"
                  style={{ backgroundColor: theme.primaryColor }}
                >
                  {theme.backgroundImage && (
                    <Image
                      src={theme.backgroundImage}
                      alt={theme.displayName}
                      fill
                      className="object-cover opacity-30"
                    />
                  )}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <IconComponent 
                      className="w-12 h-12 text-white"
                      style={{ color: theme.secondaryColor }}
                    />
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute top-3 right-3">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      theme.isActive
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {theme.isActive ? 'Activo' : 'Inactivo'}
                    </span>
                  </div>
                </div>

                {/* Theme Info */}
                <div className="p-4 space-y-3">
                  <div>
                    <h3 className="font-bold text-gray-800">{theme.displayName}</h3>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {theme.description}
                    </p>
                  </div>

                  {/* Colors */}
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-500">Colores:</span>
                    <div 
                      className="w-4 h-4 rounded-full border border-gray-300"
                      style={{ backgroundColor: theme.primaryColor }}
                    />
                    <div 
                      className="w-4 h-4 rounded-full border border-gray-300"
                      style={{ backgroundColor: theme.secondaryColor }}
                    />
                    {theme.accentColor && (
                      <div 
                        className="w-4 h-4 rounded-full border border-gray-300"
                        style={{ backgroundColor: theme.accentColor }}
                      />
                    )}
                  </div>

                  {/* Usage Stats */}
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>{theme.usageCount} usos</span>
                    {theme.startDate && theme.endDate && (
                      <span className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        Estacional
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="flex space-x-1">
                      <FordButton 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handlePreviewTheme(theme)}
                      >
                        <Eye className="w-4 h-4" />
                      </FordButton>
                      <FordButton 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handlePreviewAccessGranted(theme)}
                      >
                        <CheckCircle className="w-4 h-4" />
                      </FordButton>
                      <FordButton 
                        variant="ghost" 
                        size="sm"
                        onClick={() => handleEditTheme(theme)}
                      >
                        <Edit className="w-4 h-4" />
                      </FordButton>
                      {theme.name !== 'default' && (
                        <FordButton 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDeleteTheme(theme.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </FordButton>
                      )}
                    </div>
                    
                    <FordButton
                      variant={theme.isActive ? "outline" : "primary"}
                      size="sm"
                      onClick={() => handleToggleTheme(theme.id)}
                    >
                      <ToggleLeft className="w-4 h-4 mr-1" />
                      {theme.isActive ? 'Desactivar' : 'Activar'}
                    </FordButton>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          );
        })}
      </div>

      {/* Edit Theme Modal */}
      {editingTheme && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">
                  Editar Tema: {editingTheme.displayName}
                </h2>
                <button
                  onClick={() => setEditingTheme(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre de visualización
                  </label>
                  <input
                    type="text"
                    value={editingTheme.displayName}
                    onChange={(e) => setEditingTheme(prev => 
                      prev ? {...prev, displayName: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descripción
                  </label>
                  <textarea
                    value={editingTheme.description || ''}
                    onChange={(e) => setEditingTheme(prev => 
                      prev ? {...prev, description: e.target.value} : null
                    )}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Color Primario
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="color"
                        value={editingTheme.primaryColor}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, primaryColor: e.target.value} : null
                        )}
                        className="w-12 h-10 border border-gray-300 rounded"
                      />
                      <input
                        type="text"
                        value={editingTheme.primaryColor}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, primaryColor: e.target.value} : null
                        )}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Color Secundario
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="color"
                        value={editingTheme.secondaryColor}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, secondaryColor: e.target.value} : null
                        )}
                        className="w-12 h-10 border border-gray-300 rounded"
                      />
                      <input
                        type="text"
                        value={editingTheme.secondaryColor}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, secondaryColor: e.target.value} : null
                        )}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Color de Acento
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="color"
                        value={editingTheme.accentColor || '#003478'}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, accentColor: e.target.value} : null
                        )}
                        className="w-12 h-10 border border-gray-300 rounded"
                      />
                      <input
                        type="text"
                        value={editingTheme.accentColor || ''}
                        onChange={(e) => setEditingTheme(prev => 
                          prev ? {...prev, accentColor: e.target.value} : null
                        )}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent text-sm"
                        placeholder="#003478"
                      />
                    </div>
                  </div>
                </div>

                {/* Imagen de Fondo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Imagen de Fondo
                  </label>
                  
                  {/* Preview de la imagen actual */}
                  {editingTheme.backgroundImage && (
                    <div className="mb-3">
                      <div className="relative w-full h-32 rounded-lg overflow-hidden border border-gray-300">
                        <Image
                          src={editingTheme.backgroundImage}
                          alt="Preview imagen de fondo"
                          fill
                          className="object-cover"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                          <span className="text-white text-sm font-medium">Preview Imagen de Fondo</span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Input para URL */}
                  <input
                    type="url"
                    value={editingTheme.backgroundImage || ''}
                    onChange={(e) => setEditingTheme(prev => 
                      prev ? {...prev, backgroundImage: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="https://static.vecteezy.com/system/resources/previews/015/021/782/non_2x/abstract-background-of-modern-gradient-fluid-with-orange-background-color-suitable-for-any-theme-free-vector.jpg"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Ingresa la URL de la imagen de fondo para este tema
                  </p>
                </div>

                {/* Preview en tiempo real del tema */}
                <div className="border border-gray-300 rounded-lg p-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Preview del Tema
                  </label>
                  <div 
                    className="relative w-full h-24 rounded-lg overflow-hidden"
                    style={{
                      backgroundColor: editingTheme.secondaryColor,
                      backgroundImage: editingTheme.backgroundImage ? `url(${editingTheme.backgroundImage})` : undefined,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center'
                    }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div 
                        className="px-4 py-2 rounded-lg text-white font-medium shadow-lg"
                        style={{ backgroundColor: editingTheme.primaryColor }}
                      >
                        Portal Ford WiFi
                      </div>
                    </div>
                    {/* Accent color indicator */}
                    <div 
                      className="absolute top-2 right-2 w-4 h-4 rounded-full border-2 border-white"
                      style={{ backgroundColor: editingTheme.accentColor || editingTheme.primaryColor }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Este es un preview de cómo se verá el tema en el portal
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={editingTheme.isActive}
                    onChange={(e) => setEditingTheme(prev => 
                      prev ? {...prev, isActive: e.target.checked} : null
                    )}
                    className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                  />
                  <label htmlFor="isActive" className="text-sm text-gray-700">
                    Tema activo
                  </label>
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6 pt-6 border-t">
                <FordButton
                  variant="outline"
                  onClick={() => setEditingTheme(null)}
                >
                  Cancelar
                </FordButton>
                <FordButton onClick={handleSaveTheme}>
                  <Save className="w-4 h-4 mr-2" />
                  Guardar Cambios
                </FordButton>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
