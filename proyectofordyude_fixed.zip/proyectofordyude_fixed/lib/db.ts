
/**
 * Configuración y instancia de Prisma Client para Ford Yude Canahuati Portal
 * 
 * Este archivo maneja la conexión a la base de datos PostgreSQL usando Prisma ORM.
 * Implementa el patrón singleton para evitar múltiples instancias durante el desarrollo
 * con hot reload de Next.js.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import { PrismaClient } from '@prisma/client'

/**
 * Extensión del objeto global para almacenar la instancia de Prisma
 * Previene la creación de múltiples conexiones durante hot reload en desarrollo
 */
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * Instancia singleton de Prisma Client
 * 
 * En desarrollo, reutiliza la instancia existente en el objeto global.
 * En producción, crea una nueva instancia cada vez.
 * 
 * @constant {PrismaClient} prisma - Instancia única de Prisma Client
 */
export const prisma = globalForPrisma.prisma ?? new PrismaClient()

/**
 * En desarrollo, almacena la instancia en el objeto global
 * para evitar reconexiones innecesarias durante hot reload
 */
if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
