

import { Metadata } from 'next';
import { UserManagementClient } from './_components/user-management-client';

export const metadata: Metadata = {
  title: 'Gestión de Usuarios - Administración Ford',
  description: 'Gestión de usuarios administradores con permisos granulares Ford Yude Canahuati',
};

export default function UserManagementPage() {
  return <UserManagementClient />;
}
