
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Wifi,
  Globe,
  CheckCircle,
  Star,
  Heart,
  Car,
  Wrench,
  Clock,
  MapPin,
  Phone,
  Mail,
  Facebook,
  Instagram,
  Youtube,
  ExternalLink,
  Smartphone,
  Monitor,
  Shield,
  Zap
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';

interface InternetReadyConfig {
  title: string;
  subtitle: string;
  message: string;
  backgroundColor: string;
  textColor: string;
  accentColor: string;
  logoUrl: string;
  bannerImages: Array<{
    url: string;
    title: string;
    description: string;
  }>;
  socialLinks: Array<{
    platform: string;
    url: string;
    icon: string;
  }>;
  quickActions: Array<{
    title: string;
    description: string;
    url: string;
    icon: string;
    color: string;
  }>;
  promotions: Array<{
    title: string;
    description: string;
    imageUrl: string;
    url: string;
    isActive: boolean;
  }>;
  customContent: {
    showWeather: boolean;
    showNews: boolean;
    showPromotions: boolean;
    showSocialMedia: boolean;
    showContact: boolean;
  };
}

/**
 * Cliente personalizable para la página "Ya tienes Internet"
 * Permite configurar contenido, colores, imágenes y funcionalidades
 */
export function InternetReadyClient() {
  const [config, setConfig] = useState<InternetReadyConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    fetchConfiguration();
    
    // Rotación automática de imágenes
    const interval = setInterval(() => {
      if (config?.bannerImages.length) {
        setCurrentImageIndex(prev => 
          (prev + 1) % config.bannerImages.length
        );
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [config?.bannerImages.length]);

  /**
   * Obtiene configuración personalizada
   */
  const fetchConfiguration = async () => {
    try {
      const response = await fetch('/api/admin/internet-ready-config');
      if (response.ok) {
        const data = await response.json();
        setConfig(data);
      } else {
        // Configuración por defecto si no hay personalizada
        setConfig(getDefaultConfig());
      }
    } catch (error) {
      console.error('Error:', error);
      setConfig(getDefaultConfig());
    } finally {
      setLoading(false);
    }
  };

  /**
   * Configuración por defecto
   */
  const getDefaultConfig = (): InternetReadyConfig => ({
    title: '¡Ya tienes Internet!',
    subtitle: 'Bienvenido a Ford Yude Canahuati',
    message: 'Tu conexión está lista. Explora nuestros servicios y mantente conectado con nosotros.',
    backgroundColor: '#F8FAFC',
    textColor: '#1E293B',
    accentColor: '#003478',
    logoUrl: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
    bannerImages: [
      {
        url: 'https://designcollaborative.com/wp-content/uploads/2021/11/Schmidt_Ford-Dealership_1.jpg',
        title: 'Showroom Ford Moderno',
        description: 'Visita nuestras instalaciones de clase mundial'
      },
      {
        url: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
        title: 'Ford F-150 2025',
        description: 'Descubre la nueva generación de pickups'
      },
      {
        url: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
        title: 'Servicio QuickLane',
        description: 'Mantenimiento express sin cita previa'
      }
    ],
    socialLinks: [
      {
        platform: 'Facebook',
        url: 'https://facebook.com/fordyudecanahuati',
        icon: 'facebook'
      },
      {
        platform: 'Instagram',
        url: 'https://instagram.com/fordyudecanahuati',
        icon: 'instagram'
      },
      {
        platform: 'YouTube',
        url: 'https://youtube.com/fordyudecanahuati',
        icon: 'youtube'
      }
    ],
    quickActions: [
      {
        title: 'Agendar Cita',
        description: 'Programa tu servicio',
        url: 'https://fordyude.com/citas',
        icon: 'clock',
        color: '#22C55E'
      },
      {
        title: 'Ver Vehículos',
        description: 'Catálogo completo',
        url: 'https://fordyude.com/vehiculos',
        icon: 'car',
        color: '#3B82F6'
      },
      {
        title: 'Servicios',
        description: 'Mantenimiento y reparación',
        url: 'https://fordyude.com/servicios',
        icon: 'wrench',
        color: '#F59E0B'
      },
      {
        title: 'Contacto',
        description: 'Habla con nosotros',
        url: 'https://fordyude.com/contacto',
        icon: 'phone',
        color: '#EF4444'
      }
    ],
    promotions: [
      {
        title: 'Ofertas Especiales',
        description: 'Descuentos exclusivos en vehículos nuevos',
        imageUrl: 'https://vehicle-images.dealerinspire.com/stock-images/ford/39cad4a9d232ab0d0238f6978baae254.png',
        url: 'https://fordyude.com/ofertas',
        isActive: true
      },
      {
        title: 'Programa de Lealtad',
        description: 'Beneficios exclusivos para clientes Ford',
        imageUrl: 'https://i.pinimg.com/originals/bd/73/7b/bd737ba02050aa1b08a6901addd69883.jpg',
        url: 'https://fordyude.com/lealtad',
        isActive: true
      }
    ],
    customContent: {
      showWeather: true,
      showNews: true,
      showPromotions: true,
      showSocialMedia: true,
      showContact: true
    }
  });

  /**
   * Obtiene icono para acción rápida
   */
  const getActionIcon = (iconName: string) => {
    const icons: { [key: string]: any } = {
      clock: Clock,
      car: Car,
      wrench: Wrench,
      phone: Phone,
      mail: Mail,
      mapPin: MapPin,
      shield: Shield,
      zap: Zap
    };
    return icons[iconName] || ExternalLink;
  };

  /**
   * Obtiene icono para red social
   */
  const getSocialIcon = (platform: string) => {
    const icons: { [key: string]: any } = {
      facebook: Facebook,
      instagram: Instagram,
      youtube: Youtube
    };
    return icons[platform.toLowerCase()] || ExternalLink;
  };

  if (loading || !config) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <Wifi className="w-16 h-16 text-ford-blue mx-auto mb-4 animate-pulse" />
          <h2 className="text-2xl font-semibold text-gray-800">Conectando...</h2>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: config.backgroundColor,
        color: config.textColor 
      }}
    >
      {/* Header con logo y estado */}
      <div className="relative overflow-hidden">
        {/* Banner rotativo de fondo */}
        <div className="absolute inset-0">
          {config.bannerImages.map((image, index) => (
            <motion.div
              key={index}
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ 
                opacity: index === currentImageIndex ? 0.3 : 0,
                scale: index === currentImageIndex ? 1.05 : 1 
              }}
              transition={{ duration: 1 }}
            >
              <Image
                src={image.url}
                alt={image.title}
                fill
                className="object-cover"
              />
            </motion.div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/30" />
        </div>

        {/* Contenido del header */}
        <div className="relative z-10 px-4 py-16 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="w-24 h-24 mx-auto mb-6 p-4 bg-white rounded-full shadow-lg">
              <Image
                src={config.logoUrl}
                alt="Ford Logo"
                width={64}
                height={64}
                className="w-full h-full object-contain"
              />
            </div>
            
            <div className="flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-500 mr-3" />
              <Wifi className="w-8 h-8 text-green-500" />
            </div>
          </motion.div>

          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-white"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              {config.title}
            </h1>
            <h2 className="text-xl md:text-2xl mb-6 opacity-90">
              {config.subtitle}
            </h2>
            <p className="text-lg max-w-2xl mx-auto opacity-80">
              {config.message}
            </p>
          </motion.div>

          {/* Indicador de conexión */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.6, duration: 0.3 }}
            className="mt-8 inline-flex items-center px-6 py-3 bg-green-500 text-white rounded-full shadow-lg"
          >
            <div className="w-3 h-3 bg-white rounded-full mr-3 animate-pulse" />
            <span className="font-semibold">Conexión Activa</span>
          </motion.div>
        </div>
      </div>

      {/* Acciones rápidas */}
      <div className="px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-center mb-8">
            Acceso Rápido
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {config.quickActions.map((action, index) => {
              const Icon = getActionIcon(action.icon);
              return (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <FordCard className="p-6 h-full cursor-pointer hover:shadow-lg transition-shadow">
                    <a
                      href={action.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-center"
                    >
                      <div 
                        className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: action.color }}
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <h4 className="font-semibold text-lg mb-2">
                        {action.title}
                      </h4>
                      <p className="text-gray-600 text-sm">
                        {action.description}
                      </p>
                    </a>
                  </FordCard>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Promociones */}
      {config.customContent.showPromotions && (
        <div className="px-4 py-12 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <h3 className="text-2xl font-bold text-center mb-8">
              Ofertas Especiales
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {config.promotions.filter(p => p.isActive).map((promotion, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.02 }}
                  className="group cursor-pointer"
                >
                  <FordCard className="overflow-hidden">
                    <a
                      href={promotion.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block"
                    >
                      <div className="relative h-48 overflow-hidden">
                        <Image
                          src={promotion.imageUrl}
                          alt={promotion.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute top-4 right-4">
                          <Badge variant="default" className="bg-red-500">
                            Oferta
                          </Badge>
                        </div>
                      </div>
                      <div className="p-6">
                        <h4 className="font-semibold text-xl mb-2">
                          {promotion.title}
                        </h4>
                        <p className="text-gray-600">
                          {promotion.description}
                        </p>
                        <div className="mt-4 flex items-center text-ford-blue">
                          <span className="mr-2">Ver más</span>
                          <ExternalLink className="w-4 h-4" />
                        </div>
                      </div>
                    </a>
                  </FordCard>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Redes sociales */}
      {config.customContent.showSocialMedia && (
        <div className="px-4 py-12">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-8">
              Síguenos en Redes Sociales
            </h3>
            
            <div className="flex justify-center space-x-6">
              {config.socialLinks.map((social, index) => {
                const Icon = getSocialIcon(social.platform);
                return (
                  <motion.a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-16 h-16 bg-ford-blue text-white rounded-full flex items-center justify-center hover:bg-ford-blue-dark transition-colors"
                  >
                    <Icon className="w-8 h-8" />
                  </motion.a>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Footer informativo */}
      <div 
        className="px-4 py-8 border-t"
        style={{ borderColor: config.accentColor + '20' }}
      >
        <div className="max-w-6xl mx-auto text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-semibold mb-4 flex items-center justify-center">
                <MapPin className="w-5 h-5 mr-2" style={{ color: config.accentColor }} />
                Ubicaciones
              </h4>
              <p className="text-sm text-gray-600">
                Tegucigalpa • San Pedro Sula • La Ceiba
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 flex items-center justify-center">
                <Phone className="w-5 h-5 mr-2" style={{ color: config.accentColor }} />
                Contacto
              </h4>
              <p className="text-sm text-gray-600">
                +504 2234-5678
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 flex items-center justify-center">
                <Globe className="w-5 h-5 mr-2" style={{ color: config.accentColor }} />
                Web
              </h4>
              <p className="text-sm text-gray-600">
                www.fordyude.com
              </p>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-500">
              © 2025 Ford Yude Canahuati. Todos los derechos reservados.
            </p>
            <p className="text-xs text-gray-400 mt-2">
              Conexión proporcionada por el Portal Cautivo Ford
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
