
import { Metadata } from 'next';
import { BannerLinksClient } from './_components/banner-links-client';

export const metadata: Metadata = {
  title: 'Links de Banners - Admin Ford',
  description: 'Gestión de links de banners externos para portales cautivos',
};

export default function BannerLinksPage() {
  return <BannerLinksClient />;
}
