

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { randomBytes } from 'crypto';

export const dynamic = 'force-dynamic';

/**
 * Genera un token único para portales
 */
function generatePortalToken(): string {
  return randomBytes(16).toString('hex');
}

/**
 * GET /api/admin/portal-tokens
 * Obtiene todos los tokens de portales
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const tokens = await prisma.portalToken.findMany({
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(tokens);
  } catch (error) {
    console.error('Error al obtener tokens:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * POST /api/admin/portal-tokens
 * Crea un nuevo token de portal
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, themeId, portalType, isActive, maxUses, expiresAt } = body;

    if (!name) {
      return NextResponse.json({ error: 'El nombre es obligatorio' }, { status: 400 });
    }

    // Generar token único
    let token: string;
    let isUnique = false;
    
    do {
      token = generatePortalToken();
      const existingToken = await prisma.portalToken.findUnique({
        where: { token }
      });
      isUnique = !existingToken;
    } while (!isUnique);

    const portalToken = await prisma.portalToken.create({
      data: {
        token,
        name,
        description: description || null,
        themeId: themeId || null,
        portalType,
        isActive,
        maxUses: maxUses || null,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        createdBy: session.user?.id || 'admin'
      }
    });

    return NextResponse.json(portalToken);
  } catch (error) {
    console.error('Error al crear token:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
