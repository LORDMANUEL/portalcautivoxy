
import { Metadata } from 'next';
import { CustomReportsClient } from './_components/custom-reports-client';

export const metadata: Metadata = {
  title: 'Reportes Personalizados - Admin Ford',
  description: 'Crear y configurar reportes personalizados con filtros avanzados',
};

export default function CustomReportsPage() {
  return <CustomReportsClient />;
}
