
/**
 * Definiciones de tipos TypeScript para el Portal Ford Yude Canahuati
 * 
 * Este archivo contiene todas las definiciones de tipos y interfaces
 * utilizadas en la aplicación para asegurar type safety.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0 - Actualización completa con nuevas funcionalidades
 */

// ============================================================================
// TIPOS GENERALES DEL SISTEMA
// ============================================================================

/**
 * Tipo para representar un rango de fechas
 * 
 * Utilizado en componentes de filtrado y selección de fechas
 * para reportes y análisis de datos del portal.
 */
export type DateRange = {
  from: Date | undefined
  to: Date | undefined
}

/**
 * Estados generales del sistema
 */
export type SystemStatus = 'ACTIVE' | 'INACTIVE' | 'PENDING' | 'SUSPENDED'

/**
 * Tipos de logs del sistema
 */
export type LogSeverity = 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL'
export type LogAction = 'LOGIN' | 'LOGOUT' | 'CREATE' | 'UPDATE' | 'DELETE' | 'VIEW' | 'EXPORT' | 'BACKUP' | 'RESTORE'

// ============================================================================
// TIPOS DE PORTALES Y UBICACIONES
// ============================================================================

/**
 * Tipos de portales cautivos disponibles
 */
export type PortalType = 'FORD' | 'QUICKLANE_TRUCK' | 'QUICKLANE_TEGUS' | 'QUICKLANE_SPS'

/**
 * Tipos de ubicaciones/salas
 */
export type LocationType = 'SHOWROOM' | 'SERVICE' | 'QUICKLANE' | 'OFFICE'

/**
 * Datos para crear/editar ubicaciones
 */
export interface LocationFormData {
  name: string
  code: string
  type: LocationType
  address?: string
  city?: string
  description?: string
  iconName: string
  iconColor: string
  latitude?: number
  longitude?: number
}

/**
 * Datos para crear/editar portales
 */
export interface PortalFormData {
  name: string
  slug: string
  type: PortalType
  brand: string
  locationId?: string
  description?: string
  logoUrl?: string
  primaryColor: string
  secondaryColor: string
  welcomeTitle: string
  welcomeMessage?: string
}

// ============================================================================
// TIPOS DE USUARIOS Y PERMISOS
// ============================================================================

/**
 * Roles de usuario del sistema
 */
export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'OPERATOR' | 'VIEWER'

/**
 * Módulos del sistema para permisos
 */
export type PermissionModule = 
  | 'dashboard' 
  | 'users' 
  | 'locations' 
  | 'portals' 
  | 'themes' 
  | 'qr-generator' 
  | 'reports' 
  | 'backup' 
  | 'settings' 
  | 'logs'

/**
 * Acciones permitidas en el sistema
 */
export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'export' | 'manage'

/**
 * Estructura completa de permisos
 */
export interface Permission {
  id: string
  name: string
  module: PermissionModule
  action: PermissionAction
  description?: string
  isActive: boolean
}

/**
 * Datos para crear/editar roles
 */
export interface RoleFormData {
  name: string
  displayName: string
  description?: string
  priority: number
  canManageUsers: boolean
  canManageSystem: boolean
  permissions: string[] // IDs de permisos
}

/**
 * Datos para crear/editar usuarios administradores
 */
export interface AdminFormData {
  username: string
  email?: string
  name: string
  password?: string
  locationId?: string
  roles: string[] // IDs de roles
}

// ============================================================================
// TIPOS DE TEMAS Y CONFIGURACIÓN VISUAL
// ============================================================================

/**
 * Tipos de temas estacionales/temáticos
 */
export type ThemeType = 'default' | 'mother' | 'woman' | 'man' | 'independence' | 'xmas' | 'summer'

/**
 * Posiciones para elementos de temas
 */
export type LogoPosition = 'left' | 'center' | 'right'

/**
 * Configuración de estilos personalizados
 */
export interface CustomStyles {
  buttonStyles?: {
    borderRadius?: number
    padding?: string
    fontSize?: number
    fontWeight?: string
  }
  cardStyles?: {
    borderRadius?: number
    shadow?: string
    padding?: string
    borderWidth?: number
  }
  layoutConfig?: {
    maxWidth?: number
    spacing?: string
    gridColumns?: number
  }
}

/**
 * Datos para crear/editar temas
 */
export interface ThemeFormData {
  name: string
  displayName: string
  description?: string
  primaryColor: string
  secondaryColor: string
  accentColor?: string
  backgroundImage?: string
  logoImage?: string
  startDate?: Date
  endDate?: Date
  config?: {
    logoPosition: LogoPosition
    headerHeight: number
    footerEnabled: boolean
    animationsEnabled: boolean
    parallaxEnabled: boolean
    customStyles: CustomStyles
  }
}

// ============================================================================
// TIPOS DE GENERADOR QR Y VCARDS
// ============================================================================

/**
 * Datos para crear vCards de asesores
 */
export interface VCardFormData {
  advisorName: string
  position?: string
  email: string
  phone?: string
  company: string
  address?: string
  website?: string
  photo?: string
}

/**
 * Tipos de códigos QR generables
 */
export type QRCodeType = 'vcard' | 'url' | 'text' | 'wifi' | 'email'

/**
 * Datos para generar códigos QR
 */
export interface QRGenerationData {
  type: QRCodeType
  data: string | VCardFormData
  size?: number
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H'
  includeMargin?: boolean
  colorDark?: string
  colorLight?: string
}

// ============================================================================
// TIPOS DE REPORTES Y EXPORTACIÓN
// ============================================================================

/**
 * Tipos de reportes disponibles
 */
export type ReportType = 'connections' | 'users' | 'locations' | 'portals' | 'themes' | 'system'

/**
 * Formatos de exportación
 */
export type ExportFormat = 'PDF' | 'CSV' | 'EXCEL' | 'JSON'

/**
 * Filtros para reportes
 */
export interface ReportFilters {
  dateRange?: DateRange
  locationIds?: string[]
  portalTypes?: PortalType[]
  userTypes?: string[]
  includeInactive?: boolean
}

/**
 * Configuración de reporte
 */
export interface ReportConfig {
  type: ReportType
  format: ExportFormat
  filters: ReportFilters
  includeCharts?: boolean
  includeRawData?: boolean
  customFields?: string[]
}

// ============================================================================
// TIPOS DE BACKUP Y RESTAURACIÓN
// ============================================================================

/**
 * Tipos de backup
 */
export type BackupType = 'FULL' | 'PARTIAL' | 'INCREMENTAL'

/**
 * Estados de backup
 */
export type BackupStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED'

/**
 * Tipos de compresión
 */
export type CompressionType = 'gzip' | 'zip' | 'none'

/**
 * Configuración de backup
 */
export interface BackupConfig {
  name: string
  type: BackupType
  locationId?: string
  compressionType: CompressionType
  isEncrypted: boolean
  retentionDays: number
  includeTables?: string[]
  excludeTables?: string[]
}

/**
 * Programación de tareas automáticas
 */
export interface ScheduledTaskConfig {
  name: string
  type: 'BACKUP' | 'RSS_UPDATE' | 'CLEANUP' | 'REPORT_GENERATION'
  schedule: string // Cron expression
  config: Record<string, any>
}

// ============================================================================
// TIPOS DE DASHBOARD Y ESTADÍSTICAS
// ============================================================================

/**
 * Estadísticas del dashboard
 */
export interface DashboardStats {
  totalUsers: number
  activeConnections: number
  totalLocations: number
  activePortals: number
  todayConnections: number
  connectionTrend: number // Porcentaje de cambio
  topLocation: string
  topPortal: string
}

/**
 * Datos de gráficos para dashboard
 */
export interface ChartData {
  labels: string[]
  datasets: {
    label: string
    data: number[]
    backgroundColor?: string | string[]
    borderColor?: string | string[]
    borderWidth?: number
  }[]
}

/**
 * Métricas de tiempo real
 */
export interface RealTimeMetrics {
  currentConnections: number
  bandwidth: {
    upload: number
    download: number
  }
  systemLoad: {
    cpu: number
    memory: number
    disk: number
  }
  alerts: {
    level: 'info' | 'warning' | 'error'
    message: string
    timestamp: Date
  }[]
}

// ============================================================================
// TIPOS DE FORMULARIOS Y VALIDACIÓN
// ============================================================================

/**
 * Estado de formularios
 */
export interface FormState<T> {
  data: T
  errors: Partial<Record<keyof T, string>>
  isSubmitting: boolean
  isValid: boolean
}

/**
 * Resultado de operaciones API
 */
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  message?: string
  errors?: string[]
  meta?: {
    total?: number
    page?: number
    pageSize?: number
  }
}

/**
 * Configuración de paginación
 */
export interface PaginationConfig {
  page: number
  pageSize: number
  sortBy?: string
  sortOrder?: 'asc' | 'desc'
  filters?: Record<string, any>
}

// ============================================================================
// TIPOS DE EVENTOS Y NOTIFICACIONES
// ============================================================================

/**
 * Tipos de notificaciones
 */
export type NotificationType = 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR'

/**
 * Estructura de notificaciones
 */
export interface SystemNotification {
  id: string
  title: string
  message: string
  type: NotificationType
  isRead: boolean
  targetUser?: string
  data?: Record<string, any>
  createdAt: Date
  readAt?: Date
}

/**
 * Configuración de Assets de Ford
 */
export interface FordAssets {
  logos: {
    primary: string
    secondary: string
    white: string
    dark: string
  }
  colors: {
    primary: string
    secondary: string
    accent: string[]
  }
  vehicles: {
    category: string
    images: string[]
  }[]
  themes: {
    [key: string]: {
      images: string[]
      colors: string[]
    }
  }
}

// ============================================================================
// CONSTANTES Y ENUMS
// ============================================================================

/**
 * Iconos disponibles para ubicaciones (Lucide React)
 */
export const LOCATION_ICONS = [
  'building', 'car', 'wrench', 'settings', 'map-pin', 'home', 
  'briefcase', 'tool', 'garage', 'shop', 'office-building'
] as const

/**
 * Colores predefinidos para el sistema
 */
export const SYSTEM_COLORS = {
  FORD_BLUE: '#003478',
  FORD_WHITE: '#FFFFFF',
  FORD_SILVER: '#C6C6C6',
  SUCCESS: '#10B981',
  WARNING: '#F59E0B',
  ERROR: '#EF4444',
  INFO: '#3B82F6'
} as const

/**
 * Configuraciones de exportación por defecto
 */
export const DEFAULT_EXPORT_CONFIG = {
  PDF: { orientation: 'portrait', format: 'A4' },
  CSV: { delimiter: ',', encoding: 'utf8' },
  EXCEL: { sheetName: 'Ford Portal Data' }
} as const
