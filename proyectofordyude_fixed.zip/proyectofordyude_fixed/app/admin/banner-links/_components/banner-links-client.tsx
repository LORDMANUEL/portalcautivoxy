
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Link as LinkIcon,
  QrCode,
  Copy,
  Download,
  ExternalLink,
  Share2,
  Image as ImageIcon,
  Palette,
  Settings,
  Globe,
  Code,
  Eye,
  Plus,
  Edit3,
  Trash2
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Image from 'next/image';

interface BannerLink {
  id: string;
  name: string;
  description: string;
  bannerUrl: string;
  targetUrl: string;
  embedCode: string;
  qrCodeUrl: string;
  width: number;
  height: number;
  format: 'jpg' | 'png' | 'gif' | 'svg';
  isActive: boolean;
  clickCount: number;
  viewCount: number;
  portal: string;
  theme: string;
  customization: {
    backgroundColor: string;
    textColor: string;
    borderColor: string;
    borderRadius: number;
    shadow: boolean;
    animation: boolean;
  };
  createdAt: string;
  updatedAt: string;
}

/**
 * Cliente para gestión de links de banners externos
 * Permite crear banners reutilizables para uso en otros sitios
 */
export function BannerLinksClient() {
  const [banners, setBanners] = useState<BannerLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedBanner, setSelectedBanner] = useState<BannerLink | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  // Formulario para crear/editar banner
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    bannerUrl: '',
    targetUrl: '',
    width: 300,
    height: 250,
    format: 'jpg' as 'jpg' | 'png' | 'gif' | 'svg',
    portal: 'ford-general',
    theme: 'default',
    customization: {
      backgroundColor: '#FFFFFF',
      textColor: '#003478',
      borderColor: '#CCCCCC',
      borderRadius: 8,
      shadow: true,
      animation: false
    }
  });

  useEffect(() => {
    fetchBanners();
  }, []);

  /**
   * Obtiene todos los banners
   */
  const fetchBanners = async () => {
    try {
      const response = await fetch('/api/admin/banner-links');
      if (response.ok) {
        const data = await response.json();
        setBanners(data);
      } else {
        toast.error('Error al cargar banners');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al cargar banners');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Crea nuevo banner
   */
  const createBanner = async () => {
    try {
      const response = await fetch('/api/admin/banner-links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const newBanner = await response.json();
        setBanners(prev => [newBanner, ...prev]);
        setShowCreateModal(false);
        resetForm();
        toast.success('Banner creado exitosamente');
      } else {
        toast.error('Error al crear banner');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al crear banner');
    }
  };

  /**
   * Actualiza banner existente
   */
  const updateBanner = async () => {
    if (!selectedBanner) return;

    try {
      const response = await fetch(`/api/admin/banner-links/${selectedBanner.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const updatedBanner = await response.json();
        setBanners(prev => prev.map(b => b.id === selectedBanner.id ? updatedBanner : b));
        setShowEditModal(false);
        setSelectedBanner(null);
        resetForm();
        toast.success('Banner actualizado exitosamente');
      } else {
        toast.error('Error al actualizar banner');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al actualizar banner');
    }
  };

  /**
   * Elimina banner
   */
  const deleteBanner = async (bannerId: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar este banner?')) return;

    try {
      const response = await fetch(`/api/admin/banner-links/${bannerId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setBanners(prev => prev.filter(b => b.id !== bannerId));
        toast.success('Banner eliminado exitosamente');
      } else {
        toast.error('Error al eliminar banner');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al eliminar banner');
    }
  };

  /**
   * Copia código embed al portapapeles
   */
  const copyEmbedCode = async (embedCode: string) => {
    try {
      await navigator.clipboard.writeText(embedCode);
      toast.success('Código embed copiado al portapapeles');
    } catch (error) {
      toast.error('Error al copiar código');
    }
  };

  /**
   * Copia URL del banner
   */
  const copyBannerUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('URL copiada al portapapeles');
    } catch (error) {
      toast.error('Error al copiar URL');
    }
  };

  /**
   * Descarga QR code
   */
  const downloadQRCode = async (banner: BannerLink) => {
    try {
      const response = await fetch(banner.qrCodeUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `qr-${banner.name.replace(/\s+/g, '-').toLowerCase()}.png`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('QR code descargado');
    } catch (error) {
      toast.error('Error al descargar QR code');
    }
  };

  /**
   * Resetea formulario
   */
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      bannerUrl: '',
      targetUrl: '',
      width: 300,
      height: 250,
      format: 'jpg',
      portal: 'ford-general',
      theme: 'default',
      customization: {
        backgroundColor: '#FFFFFF',
        textColor: '#003478',
        borderColor: '#CCCCCC',
        borderRadius: 8,
        shadow: true,
        animation: false
      }
    });
  };

  /**
   * Abre modal de edición
   */
  const openEditModal = (banner: BannerLink) => {
    setSelectedBanner(banner);
    setFormData({
      name: banner.name,
      description: banner.description,
      bannerUrl: banner.bannerUrl,
      targetUrl: banner.targetUrl,
      width: banner.width,
      height: banner.height,
      format: banner.format,
      portal: banner.portal,
      theme: banner.theme,
      customization: banner.customization
    });
    setShowEditModal(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-ford-blue">Links de Banners</h1>
          <p className="text-gray-600 mt-2">
            Crea banners reutilizables para usar en otros sitios web
          </p>
        </div>
        <FordButton onClick={() => setShowCreateModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Crear Banner
        </FordButton>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <ImageIcon className="w-6 h-6 text-ford-blue" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Banners</p>
              <p className="text-2xl font-bold text-ford-blue">{banners.length}</p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Eye className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Vistas</p>
              <p className="text-2xl font-bold text-green-600">
                {banners.reduce((sum, b) => sum + b.viewCount, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <ExternalLink className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Clics</p>
              <p className="text-2xl font-bold text-orange-600">
                {banners.reduce((sum, b) => sum + b.clickCount, 0).toLocaleString()}
              </p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Globe className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Activos</p>
              <p className="text-2xl font-bold text-purple-600">
                {banners.filter(b => b.isActive).length}
              </p>
            </div>
          </div>
        </FordCard>
      </div>

      {/* Lista de banners */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banners.map(banner => (
          <motion.div
            key={banner.id}
            whileHover={{ scale: 1.02 }}
            className="group"
          >
            <FordCard className="p-6 h-full flex flex-col">
              {/* Vista previa del banner */}
              <div className="relative mb-4 rounded-lg overflow-hidden bg-gray-100 aspect-video">
                <Image
                  src={banner.bannerUrl}
                  alt={banner.name}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <FordButton
                      size="sm"
                      onClick={() => {
                        setSelectedBanner(banner);
                        setShowPreviewModal(true);
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Vista Previa
                    </FordButton>
                  </div>
                </div>
              </div>

              {/* Información del banner */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-lg">{banner.name}</h3>
                  <Badge variant={banner.isActive ? 'default' : 'secondary'}>
                    {banner.isActive ? 'Activo' : 'Inactivo'}
                  </Badge>
                </div>
                
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {banner.description}
                </p>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Dimensiones:</span>
                    <span>{banner.width}x{banner.height}px</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Formato:</span>
                    <span className="uppercase">{banner.format}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Vistas:</span>
                    <span>{banner.viewCount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Clics:</span>
                    <span>{banner.clickCount.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Acciones */}
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <FordButton
                    variant="outline"
                    size="sm"
                    onClick={() => copyBannerUrl(banner.bannerUrl)}
                  >
                    <LinkIcon className="w-4 h-4 mr-1" />
                    URL
                  </FordButton>
                  <FordButton
                    variant="outline"
                    size="sm"
                    onClick={() => copyEmbedCode(banner.embedCode)}
                  >
                    <Code className="w-4 h-4 mr-1" />
                    Embed
                  </FordButton>
                </div>
                
                <div className="grid grid-cols-3 gap-2">
                  <FordButton
                    variant="outline"
                    size="sm"
                    onClick={() => downloadQRCode(banner)}
                  >
                    <QrCode className="w-4 h-4" />
                  </FordButton>
                  <FordButton
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(banner)}
                  >
                    <Edit3 className="w-4 h-4" />
                  </FordButton>
                  <FordButton
                    variant="outline"
                    size="sm"
                    onClick={() => deleteBanner(banner.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </FordButton>
                </div>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {banners.length === 0 && (
        <FordCard className="p-12 text-center">
          <ImageIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No hay banners creados</h3>
          <p className="text-gray-500 mb-6">
            Crea tu primer banner para comenzar a generar links reutilizables
          </p>
          <FordButton onClick={() => setShowCreateModal(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Crear Primer Banner
          </FordButton>
        </FordCard>
      )}

      {/* Modal de creación/edición */}
      {(showCreateModal || showEditModal) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-6">
                {showCreateModal ? 'Crear Nuevo Banner' : 'Editar Banner'}
              </h3>

              <Tabs defaultValue="basic" className="space-y-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="basic">Información Básica</TabsTrigger>
                  <TabsTrigger value="design">Diseño</TabsTrigger>
                  <TabsTrigger value="advanced">Avanzado</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nombre del Banner</Label>
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Ej: Banner Ford F-150"
                      />
                    </div>

                    <div>
                      <Label>Portal Asociado</Label>
                      <Select
                        value={formData.portal}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, portal: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ford-general">Ford General</SelectItem>
                          <SelectItem value="quicklane-truck">QuickLane Truck</SelectItem>
                          <SelectItem value="quicklane-tegus">QuickLane Tegucigalpa</SelectItem>
                          <SelectItem value="quicklane-sps">QuickLane SPS</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="md:col-span-2">
                      <Label>Descripción</Label>
                      <Textarea
                        value={formData.description}
                        onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Descripción del banner..."
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label>URL de la Imagen</Label>
                      <Input
                        value={formData.bannerUrl}
                        onChange={(e) => setFormData(prev => ({ ...prev, bannerUrl: e.target.value }))}
                        placeholder="https://imgs.search.brave.com/sgfLxTAJPEv9hzNwFWgkdfq81aayR-Lc0GHv-JDIqBM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/YmFubmVyYnV6ei5j/b20vbWVkaWEvY2F0/YWxvZy9wcm9kdWN0/L3Jlc2l6ZS80MjQv/bi8wL24wX2JidmJj/YjAwXzFfdXMuanBn"
                      />
                    </div>

                    <div>
                      <Label>URL de Destino</Label>
                      <Input
                        value={formData.targetUrl}
                        onChange={(e) => setFormData(prev => ({ ...prev, targetUrl: e.target.value }))}
                        placeholder="https://fordyude.com"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="design" className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <Label>Ancho (px)</Label>
                      <Input
                        type="number"
                        value={formData.width}
                        onChange={(e) => setFormData(prev => ({ ...prev, width: parseInt(e.target.value) || 300 }))}
                      />
                    </div>

                    <div>
                      <Label>Alto (px)</Label>
                      <Input
                        type="number"
                        value={formData.height}
                        onChange={(e) => setFormData(prev => ({ ...prev, height: parseInt(e.target.value) || 250 }))}
                      />
                    </div>

                    <div>
                      <Label>Formato</Label>
                      <Select
                        value={formData.format}
                        onValueChange={(value: 'jpg' | 'png' | 'gif' | 'svg') => 
                          setFormData(prev => ({ ...prev, format: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="jpg">JPG</SelectItem>
                          <SelectItem value="png">PNG</SelectItem>
                          <SelectItem value="gif">GIF</SelectItem>
                          <SelectItem value="svg">SVG</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Radio del Borde</Label>
                      <Input
                        type="number"
                        value={formData.customization.borderRadius}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            borderRadius: parseInt(e.target.value) || 0
                          }
                        }))}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label>Color de Fondo</Label>
                      <Input
                        type="color"
                        value={formData.customization.backgroundColor}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            backgroundColor: e.target.value
                          }
                        }))}
                      />
                    </div>

                    <div>
                      <Label>Color de Texto</Label>
                      <Input
                        type="color"
                        value={formData.customization.textColor}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            textColor: e.target.value
                          }
                        }))}
                      />
                    </div>

                    <div>
                      <Label>Color del Borde</Label>
                      <Input
                        type="color"
                        value={formData.customization.borderColor}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            borderColor: e.target.value
                          }
                        }))}
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-6">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.customization.shadow}
                        onCheckedChange={(checked) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            shadow: checked
                          }
                        }))}
                      />
                      <Label>Sombra</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.customization.animation}
                        onCheckedChange={(checked) => setFormData(prev => ({
                          ...prev,
                          customization: {
                            ...prev.customization,
                            animation: checked
                          }
                        }))}
                      />
                      <Label>Animación</Label>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="advanced" className="space-y-4">
                  <div>
                    <Label>Tema Asociado</Label>
                    <Select
                      value={formData.theme}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, theme: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="default">Por Defecto</SelectItem>
                        <SelectItem value="summer">Verano</SelectItem>
                        <SelectItem value="yude-anniversary">Aniversario Yude</SelectItem>
                        <SelectItem value="quicklane">QuickLane</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Vista Previa del Código Embed</Label>
                    <Textarea
                      value={`<div style="width:${formData.width}px;height:${formData.height}px;background:${formData.customization.backgroundColor};border:1px solid ${formData.customization.borderColor};border-radius:${formData.customization.borderRadius}px;${formData.customization.shadow ? 'box-shadow:0 4px 8px rgba(0,0,0,0.1);' : ''}">
  <a href="${formData.targetUrl}" target="_blank">
    <img src="${formData.bannerUrl}" alt="${formData.name}" style="width:100%;height:100%;object-fit:cover;border-radius:${formData.customization.borderRadius}px;" />
  </a>
</div>`}
                      rows={8}
                      readOnly
                      className="font-mono text-xs"
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton
                  variant="outline"
                  onClick={() => {
                    setShowCreateModal(false);
                    setShowEditModal(false);
                    resetForm();
                  }}
                >
                  Cancelar
                </FordButton>
                <FordButton
                  onClick={showCreateModal ? createBanner : updateBanner}
                  disabled={!formData.name || !formData.bannerUrl || !formData.targetUrl}
                >
                  {showCreateModal ? 'Crear Banner' : 'Actualizar Banner'}
                </FordButton>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de vista previa */}
      {showPreviewModal && selectedBanner && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-2xl">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-4">Vista Previa: {selectedBanner.name}</h3>
              
              <div className="text-center mb-6">
                <div
                  className="inline-block"
                  style={{
                    width: selectedBanner.width,
                    height: selectedBanner.height,
                    background: selectedBanner.customization.backgroundColor,
                    border: `1px solid ${selectedBanner.customization.borderColor}`,
                    borderRadius: selectedBanner.customization.borderRadius,
                    boxShadow: selectedBanner.customization.shadow ? '0 4px 8px rgba(0,0,0,0.1)' : 'none'
                  }}
                >
                  <Image
                    src={selectedBanner.bannerUrl}
                    alt={selectedBanner.name}
                    width={selectedBanner.width}
                    height={selectedBanner.height}
                    className="object-cover rounded"
                    style={{ borderRadius: selectedBanner.customization.borderRadius }}
                  />
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">URL de destino:</span>
                  <span className="font-mono text-blue-600">{selectedBanner.targetUrl}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Dimensiones:</span>
                  <span>{selectedBanner.width}x{selectedBanner.height}px</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Formato:</span>
                  <span className="uppercase">{selectedBanner.format}</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton
                  variant="outline"
                  onClick={() => setShowPreviewModal(false)}
                >
                  Cerrar
                </FordButton>
                <FordButton
                  onClick={() => copyEmbedCode(selectedBanner.embedCode)}
                >
                  <Code className="w-4 h-4 mr-2" />
                  Copiar Código
                </FordButton>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
