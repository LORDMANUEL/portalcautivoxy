
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  Filter,
  Download,
  RefreshCw,
  AlertTriangle,
  Info,
  CheckCircle,
  XCircle,
  Activity,
  User,
  Shield,
  Clock,
  Calendar
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { toast } from 'react-hot-toast';

interface LogEntry {
  id: string;
  userId?: string;
  userType: 'CAPTIVE_USER' | 'ADMIN';
  action: string;
  description?: string;
  ipAddress: string;
  userAgent?: string;
  page?: string;
  data?: any;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  createdAt: Date;
}

export function LogsClient() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [userTypeFilter, setUserTypeFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState('7d');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, [dateRange]);

  useEffect(() => {
    let filtered = logs;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(log =>
        log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.ipAddress.includes(searchTerm) ||
        log.page?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Severity filter
    if (severityFilter !== 'all') {
      filtered = filtered.filter(log => log.severity === severityFilter);
    }

    // User type filter
    if (userTypeFilter !== 'all') {
      filtered = filtered.filter(log => log.userType === userTypeFilter);
    }

    setFilteredLogs(filtered);
  }, [logs, searchTerm, severityFilter, userTypeFilter]);

  const loadLogs = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockLogs: LogEntry[] = [
      {
        id: '1',
        userId: 'user123',
        userType: 'CAPTIVE_USER',
        action: 'CONNECTION',
        description: 'Usuario conectado exitosamente al portal cautivo',
        ipAddress: '192.168.1.101',
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)',
        page: '/portal',
        severity: 'INFO',
        createdAt: new Date(Date.now() - 300000)
      },
      {
        id: '2',
        userType: 'ADMIN',
        action: 'THEME_UPDATE',
        description: 'Tema "summer" activado por administrador',
        ipAddress: '192.168.1.10',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        page: '/admin/themes',
        data: { theme: 'summer', previousTheme: 'default' },
        severity: 'INFO',
        createdAt: new Date(Date.now() - 600000)
      },
      {
        id: '3',
        userId: 'user456',
        userType: 'CAPTIVE_USER',
        action: 'CONNECTION_FAILED',
        description: 'Intento de conexión fallido - términos no aceptados',
        ipAddress: '192.168.1.102',
        userAgent: 'Mozilla/5.0 (Android 13; SM-G991B)',
        page: '/portal',
        severity: 'WARNING',
        createdAt: new Date(Date.now() - 900000)
      },
      {
        id: '4',
        userType: 'ADMIN',
        action: 'LOGIN_ATTEMPT',
        description: 'Intento de login con credenciales inválidas',
        ipAddress: '203.45.67.89',
        userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
        page: '/admin/login',
        severity: 'ERROR',
        createdAt: new Date(Date.now() - 1200000)
      },
      {
        id: '5',
        userId: 'user789',
        userType: 'CAPTIVE_USER',
        action: 'SESSION_TIMEOUT',
        description: 'Sesión de usuario expirada después de 2 horas',
        ipAddress: '192.168.1.103',
        severity: 'INFO',
        createdAt: new Date(Date.now() - 1800000)
      },
      {
        id: '6',
        userType: 'ADMIN',
        action: 'BANNER_CREATE',
        description: 'Nuevo banner promocional creado: "Ford F-150 2025"',
        ipAddress: '192.168.1.10',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        page: '/admin/banners',
        data: { bannerId: 'banner_123', title: 'Ford F-150 2025' },
        severity: 'INFO',
        createdAt: new Date(Date.now() - 2400000)
      },
      {
        id: '7',
        userType: 'ADMIN',
        action: 'SYSTEM_ERROR',
        description: 'Error al conectar con el feed RSS de noticias Ford',
        ipAddress: '192.168.1.10',
        page: '/admin/rss',
        data: { feedUrl: 'https://media.ford.com/rss/releases.xml', error: 'Connection timeout' },
        severity: 'CRITICAL',
        createdAt: new Date(Date.now() - 3600000)
      }
    ];
    
    setLogs(mockLogs);
    setLoading(false);
  };

  const handleExportLogs = () => {
    // Simulate CSV export
    const csvContent = filteredLogs.map(log => 
      `${log.createdAt.toISOString()},${log.severity},${log.userType},${log.action},${log.ipAddress},"${log.description}"`
    ).join('\n');
    
    const header = 'Fecha,Severidad,Tipo Usuario,Acción,IP,Descripción\n';
    const blob = new Blob([header + csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ford-logs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast.success('Logs exportados exitosamente');
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'INFO': return <Info className="w-4 h-4 text-blue-500" />;
      case 'WARNING': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'ERROR': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'CRITICAL': return <XCircle className="w-4 h-4 text-red-700" />;
      default: return <CheckCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'INFO': return 'bg-blue-100 text-blue-800';
      case 'WARNING': return 'bg-yellow-100 text-yellow-800';
      case 'ERROR': return 'bg-red-100 text-red-800';
      case 'CRITICAL': return 'bg-red-200 text-red-900';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getUserTypeIcon = (userType: string) => {
    return userType === 'ADMIN' ? (
      <Shield className="w-4 h-4 text-purple-500" />
    ) : (
      <User className="w-4 h-4 text-green-500" />
    );
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
          <div className="flex space-x-2">
            <div className="h-10 bg-gray-300 rounded w-24 animate-pulse" />
            <div className="h-10 bg-gray-300 rounded w-24 animate-pulse" />
          </div>
        </div>
        <div className="space-y-4">
          {[...Array(10)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Logs del Sistema</h1>
          <p className="text-gray-600">
            {filteredLogs.length} entradas mostradas de {logs.length} total
          </p>
        </div>
        <div className="flex space-x-2">
          <FordButton variant="outline" size="sm" onClick={loadLogs}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Actualizar
          </FordButton>
          <FordButton variant="outline" size="sm" onClick={handleExportLogs}>
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </FordButton>
        </div>
      </div>

      {/* Filters */}
      <FordCard className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar en logs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
              />
            </div>
          </div>
          
          <div>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#003478] focus:border-transparent"
            >
              <option value="all">Todas las severidades</option>
              <option value="INFO">Info</option>
              <option value="WARNING">Warning</option>
              <option value="ERROR">Error</option>
              <option value="CRITICAL">Critical</option>
            </select>
          </div>

          <div>
            <select
              value={userTypeFilter}
              onChange={(e) => setUserTypeFilter(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#003478] focus:border-transparent"
            >
              <option value="all">Todos los usuarios</option>
              <option value="CAPTIVE_USER">Usuarios</option>
              <option value="ADMIN">Administradores</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t">
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Calendar className="w-4 h-4" />
              <span>Período:</span>
            </div>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="border border-gray-300 rounded px-2 py-1 text-sm focus:ring-2 focus:ring-[#003478] focus:border-transparent"
            >
              <option value="24h">Últimas 24 horas</option>
              <option value="7d">Últimos 7 días</option>
              <option value="30d">Últimos 30 días</option>
              <option value="90d">Últimos 90 días</option>
            </select>
          </div>

          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-gray-600">Info</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span className="text-gray-600">Warning</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span className="text-gray-600">Error</span>
            </div>
          </div>
        </div>
      </FordCard>

      {/* Logs List */}
      <div className="space-y-2">
        {filteredLogs.map((log, index) => (
          <motion.div
            key={log.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.02 }}
          >
            <FordCard className="p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4 flex-1">
                  <div className="flex items-center space-x-2 mt-1">
                    {getSeverityIcon(log.severity)}
                    {getUserTypeIcon(log.userType)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-semibold text-gray-800">
                        {log.action.replace('_', ' ')}
                      </h3>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(log.severity)}`}>
                        {log.severity}
                      </span>
                      <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                        {log.userType === 'ADMIN' ? 'Admin' : 'Usuario'}
                      </span>
                    </div>
                    
                    <p className="text-gray-700 mb-2">
                      {log.description || 'Sin descripción disponible'}
                    </p>
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span className="flex items-center">
                        <Activity className="w-3 h-3 mr-1" />
                        IP: {log.ipAddress}
                      </span>
                      {log.page && (
                        <span>Página: {log.page}</span>
                      )}
                      {log.userId && (
                        <span>User ID: {log.userId}</span>
                      )}
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {log.createdAt.toLocaleString('es-HN')}
                      </span>
                    </div>
                    
                    {log.data && (
                      <details className="mt-2">
                        <summary className="text-xs text-[#003478] cursor-pointer hover:underline">
                          Ver datos adicionales
                        </summary>
                        <pre className="text-xs bg-gray-100 p-2 rounded mt-1 overflow-x-auto">
                          {JSON.stringify(log.data, null, 2)}
                        </pre>
                      </details>
                    )}
                  </div>
                </div>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {filteredLogs.length === 0 && (
        <FordCard className="p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            No se encontraron logs
          </h3>
          <p className="text-gray-600">
            Intenta ajustar los filtros de búsqueda o el rango de fechas.
          </p>
        </FordCard>
      )}
    </div>
  );
}
