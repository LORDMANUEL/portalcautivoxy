

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  Eye, 
  Star,
  Calendar,
  MapPin,
  Tag,
  Image as ImageIcon,
  DollarSign
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Image from 'next/image';

interface Promotion {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  type: string;
  category?: string;
  discount?: number;
  price?: number;
  originalPrice?: number;
  validFrom: string;
  validUntil?: string;
  isActive: boolean;
  isFeatured: boolean;
  location?: string;
  targetTheme?: string;
  conditions?: string;
  contactInfo?: string;
  clickCount: number;
  viewCount: number;
  priority: number;
  createdAt: string;
  updatedAt: string;
}

const PROMOTION_TYPES = [
  { value: 'GENERAL', label: 'General' },
  { value: 'VEHICLE', label: 'Vehículos' },
  { value: 'SERVICE', label: 'Servicio' },
  { value: 'QUICKLANE', label: 'QuickLane' }
];

const PROMOTION_CATEGORIES = [
  { value: 'new-vehicles', label: 'Vehículos Nuevos' },
  { value: 'used-vehicles', label: 'Vehículos Usados' },
  { value: 'service', label: 'Servicio Técnico' },
  { value: 'parts', label: 'Repuestos' },
  { value: 'maintenance', label: 'Mantenimiento' },
  { value: 'financing', label: 'Financiamiento' }
];

const LOCATIONS = [
  { value: 'all', label: 'Todas las ubicaciones' },
  { value: 'sps', label: 'San Pedro Sula' },
  { value: 'tegus', label: 'Tegucigalpa' },
  { value: 'ceiba', label: 'La Ceiba' }
];

export function PromotionsClient() {
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPromotion, setEditingPromotion] = useState<Promotion | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    imageUrl: '',
    type: 'GENERAL',
    category: '',
    discount: '',
    price: '',
    originalPrice: '',
    validFrom: new Date().toISOString().split('T')[0],
    validUntil: '',
    isActive: true,
    isFeatured: false,
    location: '',
    targetTheme: '',
    conditions: '',
    contactInfo: '',
    priority: '0'
  });

  useEffect(() => {
    loadPromotions();
  }, []);

  const loadPromotions = async () => {
    try {
      const response = await fetch('/api/admin/promotions');
      if (response.ok) {
        const data = await response.json();
        setPromotions(data);
      } else {
        throw new Error('Error al cargar promociones');
      }
    } catch (error) {
      toast.error('Error al cargar promociones');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast.error('El título es obligatorio');
      return;
    }

    try {
      const url = editingPromotion 
        ? `/api/admin/promotions/${editingPromotion.id}`
        : '/api/admin/promotions';
      
      const method = editingPromotion ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          discount: formData.discount ? parseFloat(formData.discount) : null,
          price: formData.price ? parseFloat(formData.price) : null,
          originalPrice: formData.originalPrice ? parseFloat(formData.originalPrice) : null,
          priority: parseInt(formData.priority),
          validUntil: formData.validUntil || null
        }),
      });

      if (response.ok) {
        toast.success(editingPromotion ? 'Promoción actualizada' : 'Promoción creada');
        setIsDialogOpen(false);
        resetForm();
        loadPromotions();
      } else {
        throw new Error('Error al guardar promoción');
      }
    } catch (error) {
      toast.error('Error al guardar promoción');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar esta promoción?')) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/promotions/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Promoción eliminada');
        loadPromotions();
      } else {
        throw new Error('Error al eliminar promoción');
      }
    } catch (error) {
      toast.error('Error al eliminar promoción');
    }
  };

  const handleEdit = (promotion: Promotion) => {
    setEditingPromotion(promotion);
    setFormData({
      title: promotion.title,
      description: promotion.description || '',
      imageUrl: promotion.imageUrl || '',
      type: promotion.type,
      category: promotion.category || '',
      discount: promotion.discount?.toString() || '',
      price: promotion.price?.toString() || '',
      originalPrice: promotion.originalPrice?.toString() || '',
      validFrom: promotion.validFrom.split('T')[0],
      validUntil: promotion.validUntil ? promotion.validUntil.split('T')[0] : '',
      isActive: promotion.isActive,
      isFeatured: promotion.isFeatured,
      location: promotion.location || '',
      targetTheme: promotion.targetTheme || '',
      conditions: promotion.conditions || '',
      contactInfo: promotion.contactInfo || '',
      priority: promotion.priority.toString()
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingPromotion(null);
    setFormData({
      title: '',
      description: '',
      imageUrl: '',
      type: 'GENERAL',
      category: '',
      discount: '',
      price: '',
      originalPrice: '',
      validFrom: new Date().toISOString().split('T')[0],
      validUntil: '',
      isActive: true,
      isFeatured: false,
      location: '',
      targetTheme: '',
      conditions: '',
      contactInfo: '',
      priority: '0'
    });
  };

  const toggleStatus = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/promotions/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        toast.success(isActive ? 'Promoción desactivada' : 'Promoción activada');
        loadPromotions();
      }
    } catch (error) {
      toast.error('Error al cambiar estado');
    }
  };

  const filteredPromotions = promotions.filter(promotion => {
    const matchesSearch = promotion.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         promotion.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = !filterType || filterType === 'all-types' || promotion.type === filterType;
    const matchesStatus = !filterStatus || filterStatus === 'all-status' || 
                         (filterStatus === 'active' && promotion.isActive) ||
                         (filterStatus === 'inactive' && !promotion.isActive);
    
    return matchesSearch && matchesType && matchesStatus;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#003478]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Promociones</h1>
          <p className="text-gray-600">Gestiona promociones y ofertas especiales</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <FordButton onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Nueva Promoción
            </FordButton>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingPromotion ? 'Editar Promoción' : 'Nueva Promoción'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Título *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Título emocionante de la promoción"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="type">Tipo</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PROMOTION_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe los detalles de la promoción..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="imageUrl">URL de Imagen</Label>
                <Input
                  id="imageUrl"
                  value={formData.imageUrl}
                  onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
                  placeholder="https://ejemplo.com/imagen.jpg"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Precio Especial</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                    placeholder="0.00"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="originalPrice">Precio Original</Label>
                  <Input
                    id="originalPrice"
                    type="number"
                    step="0.01"
                    value={formData.originalPrice}
                    onChange={(e) => setFormData(prev => ({ ...prev, originalPrice: e.target.value }))}
                    placeholder="0.00"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="discount">Descuento (%)</Label>
                  <Input
                    id="discount"
                    type="number"
                    step="0.01"
                    value={formData.discount}
                    onChange={(e) => setFormData(prev => ({ ...prev, discount: e.target.value }))}
                    placeholder="0"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="validFrom">Válido Desde</Label>
                  <Input
                    id="validFrom"
                    type="date"
                    value={formData.validFrom}
                    onChange={(e) => setFormData(prev => ({ ...prev, validFrom: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="validUntil">Válido Hasta</Label>
                  <Input
                    id="validUntil"
                    type="date"
                    value={formData.validUntil}
                    onChange={(e) => setFormData(prev => ({ ...prev, validUntil: e.target.value }))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="conditions">Términos y Condiciones</Label>
                <Textarea
                  id="conditions"
                  value={formData.conditions}
                  onChange={(e) => setFormData(prev => ({ ...prev, conditions: e.target.value }))}
                  placeholder="Términos y condiciones de la promoción..."
                  rows={2}
                />
              </div>

              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isActive"
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked as boolean }))}
                  />
                  <Label htmlFor="isActive">Activa</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isFeatured"
                    checked={formData.isFeatured}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isFeatured: checked as boolean }))}
                  />
                  <Label htmlFor="isFeatured">Destacada</Label>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <FordButton
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </FordButton>
                <FordButton type="submit">
                  {editingPromotion ? 'Actualizar' : 'Crear'}
                </FordButton>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtros */}
      <FordCard className="p-4">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-64">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar promociones..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filtrar por tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-types">Todos los tipos</SelectItem>
              {PROMOTION_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-status">Todos</SelectItem>
              <SelectItem value="active">Activas</SelectItem>
              <SelectItem value="inactive">Inactivas</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </FordCard>

      {/* Lista de promociones */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPromotions.map((promotion) => (
          <motion.div
            key={promotion.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group"
          >
            <FordCard className="p-0 overflow-hidden hover:shadow-lg transition-shadow">
              {/* Imagen */}
              {promotion.imageUrl && (
                <div className="relative h-48 bg-gray-100">
                  <Image
                    src={promotion.imageUrl}
                    alt={promotion.title}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                  {promotion.isFeatured && (
                    <div className="absolute top-2 right-2">
                      <Badge className="bg-yellow-500 text-black">
                        <Star className="w-3 h-3 mr-1" />
                        Destacada
                      </Badge>
                    </div>
                  )}
                  <div className="absolute top-2 left-2">
                    <Badge className={promotion.isActive ? 'bg-green-500' : 'bg-red-500'}>
                      {promotion.isActive ? 'Activa' : 'Inactiva'}
                    </Badge>
                  </div>
                </div>
              )}
              
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-800 line-clamp-2">
                    {promotion.title}
                  </h3>
                  <Badge variant="outline">
                    {PROMOTION_TYPES.find(t => t.value === promotion.type)?.label}
                  </Badge>
                </div>
                
                {promotion.description && (
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                    {promotion.description}
                  </p>
                )}
                
                {/* Precios */}
                {(promotion.price || promotion.discount) && (
                  <div className="flex items-center space-x-2 mb-3">
                    {promotion.price && (
                      <span className="text-lg font-bold text-[#003478]">
                        L. {promotion.price.toLocaleString()}
                      </span>
                    )}
                    {promotion.originalPrice && (
                      <span className="text-sm text-gray-500 line-through">
                        L. {promotion.originalPrice.toLocaleString()}
                      </span>
                    )}
                    {promotion.discount && (
                      <Badge className="bg-red-500">
                        -{promotion.discount}%
                      </Badge>
                    )}
                  </div>
                )}
                
                {/* Fechas */}
                <div className="flex items-center text-xs text-gray-500 mb-3">
                  <Calendar className="w-3 h-3 mr-1" />
                  {new Date(promotion.validFrom).toLocaleDateString()}
                  {promotion.validUntil && (
                    <>
                      {' - '}
                      {new Date(promotion.validUntil).toLocaleDateString()}
                    </>
                  )}
                </div>
                
                {/* Stats */}
                <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center">
                      <Eye className="w-3 h-3 mr-1" />
                      {promotion.viewCount}
                    </span>
                    <span className="flex items-center">
                      <DollarSign className="w-3 h-3 mr-1" />
                      {promotion.clickCount}
                    </span>
                  </div>
                  <span>#{promotion.priority}</span>
                </div>
                
                {/* Acciones */}
                <div className="flex space-x-2">
                  <FordButton
                    size="sm"
                    variant="outline"
                    onClick={() => handleEdit(promotion)}
                    className="flex-1"
                  >
                    <Edit3 className="w-3 h-3 mr-1" />
                    Editar
                  </FordButton>
                  
                  <FordButton
                    size="sm"
                    variant="outline"
                    onClick={() => toggleStatus(promotion.id, promotion.isActive)}
                    className={promotion.isActive ? 'text-red-600' : 'text-green-600'}
                  >
                    {promotion.isActive ? 'Desactivar' : 'Activar'}
                  </FordButton>
                  
                  <FordButton
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(promotion.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </FordButton>
                </div>
              </div>
            </FordCard>
          </motion.div>
        ))}
      </div>

      {filteredPromotions.length === 0 && (
        <div className="text-center py-12">
          <Tag className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">
            No se encontraron promociones
          </h3>
          <p className="text-gray-500">
            {searchTerm || filterType || filterStatus 
              ? 'Intenta ajustar los filtros de búsqueda'
              : 'Crea tu primera promoción para comenzar'
            }
          </p>
        </div>
      )}
    </div>
  );
}
