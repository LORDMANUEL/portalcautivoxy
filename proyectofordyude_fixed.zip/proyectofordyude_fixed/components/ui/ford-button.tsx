
'use client';

import { motion } from 'framer-motion';
import { forwardRef, MouseEvent } from 'react';
import { cn } from '@/lib/utils';

interface FordButtonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  disabled?: boolean;
  className?: string;
  onClick?: (event: MouseEvent<HTMLButtonElement>) => void;
  type?: 'button' | 'submit' | 'reset';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export const FordButton = forwardRef<HTMLButtonElement, FordButtonProps>(
  ({ className, variant = 'primary', size = 'md', isLoading, children, onClick, disabled, type = 'button', style }, ref) => {
    const baseClasses = 'inline-flex items-center justify-center rounded-md font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';
    
    const variants = {
      primary: 'bg-[#003478] text-white hover:bg-[#133A7C] focus:ring-[#003478] shadow-lg hover:shadow-xl',
      secondary: 'bg-[#C6C6C6] text-[#003478] hover:bg-[#B0B0B0] focus:ring-[#C6C6C6]',
      outline: 'border-2 border-[#003478] text-[#003478] hover:bg-[#003478] hover:text-white focus:ring-[#003478]',
      ghost: 'text-[#003478] hover:bg-[#003478] hover:text-white focus:ring-[#003478]'
    };

    const sizes = {
      sm: 'px-3 py-1.5 text-xs',
      md: 'px-4 py-2 text-sm',
      lg: 'px-6 py-3 text-base'
    };

    return (
      <motion.button
        ref={ref}
        type={type}
        className={cn(baseClasses, variants[variant], sizes[size], className)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        disabled={isLoading || disabled}
        onClick={onClick}
        style={style}
      >
        {isLoading ? (
          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
        ) : null}
        {children}
      </motion.button>
    );
  }
);

FordButton.displayName = 'FordButton';
