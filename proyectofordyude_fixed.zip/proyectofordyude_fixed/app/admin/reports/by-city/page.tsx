
import { Metadata } from 'next';
import { ByCityClient } from './_components/by-city-client';

export const metadata: Metadata = {
  title: 'Reporte por Ciudad - Admin Ford',
  description: 'Reporte detallado de usuarios por ciudad y ubicación',
};

export default function ByCityReportPage() {
  return <ByCityClient />;
}
