
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { AlertTriangle, RefreshCw, Home, Phone, MessageCircle } from 'lucide-react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';

export function ErrorClient() {
  const handleRetry = () => {
    window.location.reload();
  };

  const handleGoHome = () => {
    window.location.href = '/portal';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-red-50">
      <Header variant="public" />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="w-20 h-20 bg-yellow-500 rounded-full flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-yellow-600">
                ¡Oops!
              </h1>
              <p className="text-xl text-gray-600">
                Algo salió mal
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Error Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <FordCard className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Error de Conexión
              </h2>
              <p className="text-gray-600 mb-6">
                Ha ocurrido un problema temporal con el portal cautivo. 
                Nuestro equipo técnico está trabajando para solucionarlo.
              </p>
              
              <div className="space-y-3 text-sm text-gray-600 mb-6">
                <p>• Verifica tu conexión a internet</p>
                <p>• Intenta recargar la página</p>
                <p>• Si el problema persiste, contacta soporte</p>
              </div>

              <div className="space-y-3">
                <FordButton
                  size="lg"
                  className="w-full"
                  onClick={handleRetry}
                >
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Intentar Nuevamente
                </FordButton>
                
                <FordButton
                  variant="outline"
                  size="lg"
                  className="w-full"
                  onClick={handleGoHome}
                >
                  <Home className="w-5 h-5 mr-2" />
                  Ir al Portal Principal
                </FordButton>
              </div>
            </FordCard>
          </motion.div>

          {/* Support Options */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <FordCard className="p-8">
              <h2 className="text-2xl font-bold text-[#003478] mb-6">
                ¿Necesitas Ayuda?
              </h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-800 mb-2">Soporte Técnico</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    Nuestro equipo está disponible para ayudarte con cualquier problema de conectividad.
                  </p>
                  <FordButton variant="outline" size="sm" className="w-full">
                    <Phone className="w-4 h-4 mr-2" />
                    Llamar Soporte: +504 2550-0000
                  </FordButton>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-800 mb-2">Chat en Línea</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    Chatea con nuestros representantes para resolver tu consulta rápidamente.
                  </p>
                  <FordButton variant="outline" size="sm" className="w-full">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Iniciar Chat
                  </FordButton>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-[#003478] mb-1">Código de Error</h4>
                  <p className="text-xs font-mono text-gray-600">ERR_CAPTIVE_PORTAL_001</p>
                  <p className="text-xs text-gray-500 mt-2">
                    Proporciona este código al solicitar soporte técnico
                  </p>
                </div>
              </div>
            </FordCard>
          </motion.div>
        </div>

        {/* Alternative Access */}
        <motion.section
          className="mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <FordCard className="overflow-hidden">
            <div className="relative h-48 md:h-64">
              <Image
                src="https://thedesigncompound.com/data/portfolio/ford-automobile-showroom/18-reception-design.jpg?20210929201239"
                alt="Ford Reception"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#003478]/80 to-transparent flex items-center">
                <div className="px-8 text-white">
                  <h2 className="text-2xl md:text-3xl font-bold mb-3">
                    Mientras solucionamos el problema...
                  </h2>
                  <p className="text-lg text-blue-100 mb-4">
                    Puedes visitarnos en nuestras instalaciones para recibir atención personalizada
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <FordButton variant="secondary" size="sm">
                      Ver Ubicación
                    </FordButton>
                    <FordButton variant="outline" size="sm" className="border-white text-white hover:bg-white hover:text-[#003478]">
                      Horarios de Atención
                    </FordButton>
                  </div>
                </div>
              </div>
            </div>
          </FordCard>
        </motion.section>

        {/* Status Information */}
        <motion.section
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <FordCard className="p-6 max-w-2xl mx-auto">
            <h3 className="text-lg font-bold text-[#003478] mb-3">
              Estado del Sistema
            </h3>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <div className="w-3 h-3 bg-green-500 rounded-full mx-auto mb-1"></div>
                <p className="text-gray-600">Red Principal</p>
                <p className="text-green-600 font-semibold">Operativo</p>
              </div>
              <div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full mx-auto mb-1"></div>
                <p className="text-gray-600">Portal Cautivo</p>
                <p className="text-yellow-600 font-semibold">Mantenimiento</p>
              </div>
              <div>
                <div className="w-3 h-3 bg-green-500 rounded-full mx-auto mb-1"></div>
                <p className="text-gray-600">Servicios Ford</p>
                <p className="text-green-600 font-semibold">Disponible</p>
              </div>
            </div>
          </FordCard>
        </motion.section>
      </main>

      <Footer />
    </div>
  );
}
