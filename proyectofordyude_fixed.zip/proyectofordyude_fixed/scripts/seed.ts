

import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

/**
 * Script de seed para poblar la base de datos con datos iniciales
 * Incluye usuarios, roles, permisos, temas y datos de demostración
 */
async function main() {
  console.log('🌱 Iniciando seed de la base de datos...');

  // 1. Crear roles del sistema
  console.log('📝 Creando roles del sistema...');
  const roles = await Promise.all([
    prisma.role.upsert({
      where: { name: 'SUPER_ADMIN' },
      update: {},
      create: {
        name: 'SUPER_ADMIN',
        displayName: 'Super Administrador',
        description: 'Acceso completo al sistema',
        priority: 100,
        canManageUsers: true,
        canManageSystem: true,
        isActive: true
      }
    }),
    prisma.role.upsert({
      where: { name: 'ADMIN' },
      update: {},
      create: {
        name: 'ADMIN',
        displayName: 'Administrador',
        description: 'Gestión general del portal',
        priority: 80,
        canManageUsers: false,
        canManageSystem: false,
        isActive: true
      }
    }),
    prisma.role.upsert({
      where: { name: 'OPERATOR' },
      update: {},
      create: {
        name: 'OPERATOR',
        displayName: 'Operador',
        description: 'Operaciones básicas del portal',
        priority: 60,
        canManageUsers: false,
        canManageSystem: false,
        isActive: true
      }
    }),
    prisma.role.upsert({
      where: { name: 'VIEWER' },
      update: {},
      create: {
        name: 'VIEWER',
        displayName: 'Visualizador',
        description: 'Solo lectura de reportes',
        priority: 40,
        canManageUsers: false,
        canManageSystem: false,
        isActive: true
      }
    })
  ]);

  // 2. Crear permisos del sistema
  console.log('🔐 Creando permisos del sistema...');
  const permissions = await Promise.all([
    // Dashboard
    prisma.permission.upsert({
      where: { name: 'dashboard.view' },
      update: {},
      create: { name: 'dashboard.view', module: 'dashboard', action: 'view', description: 'Ver dashboard' }
    }),
    // Usuarios
    prisma.permission.upsert({
      where: { name: 'users.view' },
      update: {},
      create: { name: 'users.view', module: 'users', action: 'view', description: 'Ver usuarios conectados' }
    }),
    prisma.permission.upsert({
      where: { name: 'users.manage' },
      update: {},
      create: { name: 'users.manage', module: 'users', action: 'manage', description: 'Gestionar usuarios administradores' }
    }),
    // Temas
    prisma.permission.upsert({
      where: { name: 'themes.view' },
      update: {},
      create: { name: 'themes.view', module: 'themes', action: 'view', description: 'Ver temas' }
    }),
    prisma.permission.upsert({
      where: { name: 'themes.edit' },
      update: {},
      create: { name: 'themes.edit', module: 'themes', action: 'edit', description: 'Editar temas' }
    }),
    // Reportes
    prisma.permission.upsert({
      where: { name: 'reports.view' },
      update: {},
      create: { name: 'reports.view', module: 'reports', action: 'view', description: 'Ver reportes' }
    }),
    prisma.permission.upsert({
      where: { name: 'reports.export' },
      update: {},
      create: { name: 'reports.export', module: 'reports', action: 'export', description: 'Exportar reportes' }
    }),
    // Backup
    prisma.permission.upsert({
      where: { name: 'backup.create' },
      update: {},
      create: { name: 'backup.create', module: 'backup', action: 'create', description: 'Crear backups' }
    }),
    prisma.permission.upsert({
      where: { name: 'backup.restore' },
      update: {},
      create: { name: 'backup.restore', module: 'backup', action: 'restore', description: 'Restaurar backups' }
    })
  ]);

  // 3. Asignar permisos a roles
  console.log('🎭 Asignando permisos a roles...');
  
  // Super Admin - todos los permisos
  for (const permission of permissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: roles[0].id, // SUPER_ADMIN
          permissionId: permission.id
        }
      },
      update: {},
      create: {
        roleId: roles[0].id,
        permissionId: permission.id
      }
    });
  }

  // Admin - permisos básicos
  const adminPermissions = permissions.filter(p => 
    ['dashboard.view', 'users.view', 'themes.view', 'themes.edit', 'reports.view', 'reports.export'].includes(p.name)
  );
  
  for (const permission of adminPermissions) {
    await prisma.rolePermission.upsert({
      where: {
        roleId_permissionId: {
          roleId: roles[1].id, // ADMIN
          permissionId: permission.id
        }
      },
      update: {},
      create: {
        roleId: roles[1].id,
        permissionId: permission.id
      }
    });
  }

  // 4. Crear ubicaciones
  console.log('📍 Creando ubicaciones...');
  const locations = await Promise.all([
    prisma.location.upsert({
      where: { code: 'SPS' },
      update: {},
      create: {
        name: 'Showroom San Pedro Sula',
        code: 'SPS',
        type: 'SHOWROOM',
        address: 'Col. Los Andes, 3era Avenida',
        city: 'San Pedro Sula',
        country: 'Honduras',
        latitude: 15.5040,
        longitude: -88.0253,
        description: 'Showroom principal en San Pedro Sula',
        iconName: 'building',
        iconColor: '#003478',
        isActive: true,
        routerConfig: {
          ssid: 'Ford_WiFi_SPS',
          password: 'FordSPS2025',
          ipRange: '192.168.1.0/24',
          dnsServers: ['8.8.8.8', '8.8.4.4'],
          captivePortalUrl: 'https://portal.yudecanahuati.com'
        }
      }
    }),
    prisma.location.upsert({
      where: { code: 'TEG' },
      update: {},
      create: {
        name: 'Showroom Tegucigalpa',
        code: 'TEG',
        type: 'SHOWROOM',
        address: 'Boulevard Morazán',
        city: 'Tegucigalpa',
        country: 'Honduras',
        latitude: 14.0723,
        longitude: -87.1921,
        description: 'Showroom en la capital',
        iconName: 'building',
        iconColor: '#003478',
        isActive: true
      }
    }),
    prisma.location.upsert({
      where: { code: 'CEI' },
      update: {},
      create: {
        name: 'Sucursal La Ceiba',
        code: 'CEI',
        type: 'SERVICE',
        address: 'Barrio El Centro',
        city: 'La Ceiba',
        country: 'Honduras',
        latitude: 15.7598,
        longitude: -86.7822,
        description: 'Sucursal de servicios en La Ceiba',
        iconName: 'wrench',
        iconColor: '#FF6B35',
        isActive: true
      }
    })
  ]);

  // 5. Crear administrador principal
  console.log('👤 Creando administrador principal...');
  const hashedPassword = await bcrypt.hash('admin123', 12);
  
  const mainAdmin = await prisma.admin.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      email: 'admin@yudecanahuati.com',
      name: 'Administrador Principal',
      password: hashedPassword,
      role: 'SUPER_ADMIN',
      isActive: true,
      locationId: locations[0].id
    }
  });

  // Asignar rol de Super Admin
  await prisma.adminRole.upsert({
    where: {
      adminId_roleId: {
        adminId: mainAdmin.id,
        roleId: roles[0].id
      }
    },
    update: {},
    create: {
      adminId: mainAdmin.id,
      roleId: roles[0].id,
      assignedBy: mainAdmin.id
    }
  });

  // Crear usuario de prueba requerido
  const testAdmin = await prisma.admin.upsert({
    where: { username: 'john@doe.com' },
    update: {},
    create: {
      username: 'john@doe.com',
      email: 'john@doe.com',
      name: 'John Doe',
      password: await bcrypt.hash('johndoe123', 12),
      role: 'ADMIN',
      isActive: true
    }
  });

  await prisma.adminRole.upsert({
    where: {
      adminId_roleId: {
        adminId: testAdmin.id,
        roleId: roles[0].id
      }
    },
    update: {},
    create: {
      adminId: testAdmin.id,
      roleId: roles[0].id,
      assignedBy: mainAdmin.id
    }
  });

  // 6. Crear temas
  console.log('🎨 Creando temas...');
  const themes = await Promise.all([
    prisma.theme.upsert({
      where: { name: 'default' },
      update: {},
      create: {
        name: 'default',
        displayName: 'Tema Por Defecto',
        description: 'Tema corporativo Ford estándar',
        primaryColor: '#003478',
        secondaryColor: '#FFFFFF',
        accentColor: '#47A8E5',
        isActive: true
      }
    }),
    prisma.theme.upsert({
      where: { name: 'mother' },
      update: {},
      create: {
        name: 'mother',
        displayName: 'Día de la Madre',
        description: 'Tema especial para el Día de la Madre',
        primaryColor: '#E91E63',
        secondaryColor: '#FFFFFF',
        accentColor: '#F8BBD9',
        backgroundImage: 'https://i.pinimg.com/originals/61/9c/45/619c45e1bc98be4819d819dad15d1445.jpg',
        isActive: true,
        startDate: new Date('2025-05-01'),
        endDate: new Date('2025-05-31')
      }
    }),
    prisma.theme.upsert({
      where: { name: 'xmas' },
      update: {},
      create: {
        name: 'xmas',
        displayName: 'Navidad',
        description: 'Tema navideño especial',
        primaryColor: '#C62828',
        secondaryColor: '#FFFFFF',
        accentColor: '#4CAF50',
        backgroundImage: 'https://i.pinimg.com/736x/92/bf/f1/92bff1422ecc8bc9b6ffd55a6014a4da--chat-board-card-designs.jpg',
        isActive: true,
        startDate: new Date('2025-12-01'),
        endDate: new Date('2025-12-31')
      }
    })
  ]);

  // 7. Crear configuraciones del sistema
  console.log('⚙️ Creando configuraciones del sistema...');
  const configs = [
    { key: 'site_name', value: 'Ford Yude Canahuati Portal', description: 'Nombre del sitio' },
    { key: 'contact_email', value: 'info@yudecanahuati.com', description: 'Email de contacto' },
    { key: 'contact_phone', value: '+504 2550-5050', description: 'Teléfono de contacto' },
    { key: 'wifi_timeout', value: '120', description: 'Tiempo de sesión WiFi en minutos' },
    { key: 'backup_retention', value: '30', description: 'Días de retención de backups' }
  ];

  for (const config of configs) {
    await prisma.systemConfig.upsert({
      where: { key: config.key },
      update: {},
      create: config
    });
  }

  // 8. Crear algunos datos de demostración
  console.log('📊 Creando datos de demostración...');
  
  // Feeds RSS de ejemplo
  await prisma.rssFeed.upsert({
    where: { url: 'https://www.ford.com/rss/news.xml' },
    update: {},
    create: {
      title: 'Ford News',
      description: 'Noticias oficiales de Ford',
      url: 'https://www.ford.com/rss/news.xml',
      category: 'ford',
      isActive: true
    }
  });

  // Banner de ejemplo
  await prisma.banner.upsert({
    where: { id: 'demo-banner' },
    update: {},
    create: {
      id: 'demo-banner',
      title: 'Bienvenido a Ford Yude Canahuati',
      description: 'Descubre nuestros nuevos modelos 2025',
      imageUrl: 'https://wallpapercave.com/wp/wp5562176.jpg',
      position: 'TOP',
      isActive: true,
      displayOrder: 1
    }
  });

  // Portal tokens de ejemplo
  await prisma.portalToken.upsert({
    where: { token: 'demo-ford-portal' },
    update: {},
    create: {
      token: 'demo-ford-portal',
      name: 'Portal Ford Demo',
      description: 'Portal de demostración Ford',
      portalType: 'ford',
      themeId: 'default',
      isActive: true,
      createdBy: mainAdmin.id
    }
  });

  console.log('✅ Seed completado exitosamente!');
  console.log('\n🔑 Credenciales de acceso:');
  console.log('   👤 Usuario: admin');
  console.log('   🔒 Contraseña: admin123');
  console.log('   🌐 URL Admin: http://localhost:3000/admin/login');
  console.log('\n📝 Usuario de prueba:');
  console.log('   👤 Usuario: john@doe.com');
  console.log('   🔒 Contraseña: johndoe123');
  console.log('\n🔗 Portal de demo:');
  console.log('   🌐 URL: http://localhost:3000/portal/demo-ford-portal');
}

main()
  .catch((e) => {
    console.error('❌ Error durante el seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
