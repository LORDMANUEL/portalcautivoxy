
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const { deviceId, userId } = await request.json();

    if (!deviceId && !userId) {
      return NextResponse.json(
        { error: 'Device ID or User ID is required' },
        { status: 400 }
      );
    }

    // Find and update captive user
    const whereClause = deviceId ? { deviceId } : { id: userId };
    
    const captiveUser = await prisma.captiveUser.findFirst({
      where: {
        ...whereClause,
        isActive: true
      }
    });

    if (!captiveUser) {
      return NextResponse.json(
        { error: 'Active user session not found' },
        { status: 404 }
      );
    }

    // Calculate session duration
    const sessionDuration = Math.floor(
      (new Date().getTime() - captiveUser.connectedAt.getTime()) / 1000 / 60
    );

    // Update user as disconnected
    const updatedUser = await prisma.captiveUser.update({
      where: { id: captiveUser.id },
      data: {
        isActive: false,
        disconnectedAt: new Date(),
        sessionDuration
      }
    });

    // Create log entry
    await prisma.log.create({
      data: {
        userId: captiveUser.id,
        userType: 'CAPTIVE_USER',
        action: 'DISCONNECTION',
        description: `User disconnected: ${captiveUser.name} (session: ${sessionDuration} minutes)`,
        ipAddress: request.headers.get('x-forwarded-for') || '127.0.0.1',
        userAgent: request.headers.get('user-agent') || 'Unknown',
        data: { sessionDuration },
        severity: 'INFO'
      }
    });

    return NextResponse.json({ 
      message: 'Disconnected successfully',
      sessionDuration
    });

  } catch (error) {
    console.error('Disconnection error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
