
import { Metadata } from 'next';
import { SettingsClient } from './_components/settings-client';

export const metadata: Metadata = {
  title: 'Configuración - Admin Ford',
  description: 'Configuración avanzada del portal cautivo',
};

export default function AdminSettingsPage() {
  return <SettingsClient />;
}
