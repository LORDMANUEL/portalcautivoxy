

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/themes/active
 * Obtiene el tema activo actual (público - no requiere autenticación)
 */
export async function GET() {
  try {
    // Primero intentar obtener tema activo por fecha
    const currentDate = new Date();
    const activeThemeByDate = await prisma.theme.findFirst({
      where: {
        isActive: true,
        startDate: {
          lte: currentDate
        },
        endDate: {
          gte: currentDate
        }
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    if (activeThemeByDate) {
      return NextResponse.json(activeThemeByDate);
    }

    // Si no hay tema por fecha, obtener cualquier tema activo
    const activeTheme = await prisma.theme.findFirst({
      where: {
        isActive: true
      },
      orderBy: {
        updatedAt: 'desc'
      }
    });

    if (activeTheme) {
      return NextResponse.json(activeTheme);
    }

    // Si no hay temas activos, retornar tema por defecto
    const defaultTheme = await prisma.theme.findFirst({
      where: {
        name: 'default'
      }
    });

    if (defaultTheme) {
      return NextResponse.json(defaultTheme);
    }

    // Fallback: crear tema por defecto si no existe
    const fallbackTheme = await prisma.theme.create({
      data: {
        name: 'default',
        displayName: 'Tema Por Defecto',
        description: 'Tema por defecto de Ford',
        primaryColor: '#003478',
        secondaryColor: '#FFFFFF',
        accentColor: '#0056b3',
        isActive: true,
        metadata: {
          welcomeMessage: 'Bienvenido a Ford WiFi',
          rssCategory: 'general',
          promotionType: 'general'
        }
      }
    });

    return NextResponse.json(fallbackTheme);
  } catch (error) {
    console.error('Error al obtener tema activo:', error);
    
    // Fallback en caso de error
    const fallbackResponse = {
      id: 'fallback',
      name: 'default',
      displayName: 'Tema Por Defecto',
      description: 'Tema por defecto de Ford',
      primaryColor: '#003478',
      secondaryColor: '#FFFFFF',
      accentColor: '#0056b3',
      backgroundImage: null,
      logoImage: null,
      isActive: true,
      metadata: {
        welcomeMessage: 'Bienvenido a Ford WiFi',
        rssCategory: 'general',
        promotionType: 'general'
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    return NextResponse.json(fallbackResponse);
  }
}
