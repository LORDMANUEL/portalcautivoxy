
/**
 * API Route para gestión individual de roles
 * 
 * Funcionalidades:
 * - GET: Obtener rol específico
 * - PUT: Actualizar rol
 * - DELETE: Eliminar rol
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Prisma } from '@prisma/client'
import { z } from 'zod'

const updateRoleSchema = z.object({
  name: z.string().min(2).optional(),
  displayName: z.string().min(2).optional(),
  description: z.string().optional(),
  priority: z.number().min(0).max(100).optional(),
  canManageUsers: z.boolean().optional(),
  canManageSystem: z.boolean().optional(),
  isActive: z.boolean().optional(),
  permissions: z.array(z.string()).optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/roles/[id]
 * Obtener rol específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const role = await prisma.role.findUnique({
      where: { id: params.id },
      include: {
        rolePermissions: {
          include: {
            permission: true
          }
        },
        _count: {
          select: {
            admins: true
          }
        }
      }
    })

    if (!role) {
      return NextResponse.json(
        { success: false, message: 'Rol no encontrado' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: role
    })

  } catch (error) {
    console.error('Error fetching role:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/roles/[id]
 * Actualizar rol
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = updateRoleSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { name, displayName, description, priority, canManageUsers, canManageSystem, isActive, permissions } = validation.data

    // Verificar que el rol existe
    const existingRole = await prisma.role.findUnique({
      where: { id: params.id }
    })

    if (!existingRole) {
      return NextResponse.json(
        { success: false, message: 'Rol no encontrado' },
        { status: 404 }
      )
    }

    // Verificar nombre único (si se está cambiando)
    if (name && name !== existingRole.name) {
      const nameTaken = await prisma.role.findUnique({
        where: { name }
      })

      if (nameTaken) {
        return NextResponse.json(
          { success: false, message: 'Ya existe un rol con ese nombre' },
          { status: 400 }
        )
      }
    }

    // Preparar datos de actualización
    const updateData: any = {}
    
    if (name !== undefined) updateData.name = name
    if (displayName !== undefined) updateData.displayName = displayName
    if (description !== undefined) updateData.description = description
    if (priority !== undefined) updateData.priority = priority
    if (canManageUsers !== undefined) updateData.canManageUsers = canManageUsers
    if (canManageSystem !== undefined) updateData.canManageSystem = canManageSystem
    if (isActive !== undefined) updateData.isActive = isActive

    // Actualizar en transacción
    const updatedRole = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // Actualizar rol
      const role = await tx.role.update({
        where: { id: params.id },
        data: updateData
      })

      // Actualizar permisos si se proporcionaron
      if (permissions !== undefined) {
        // Eliminar permisos existentes
        await tx.rolePermission.deleteMany({
          where: { roleId: params.id }
        })

        // Agregar nuevos permisos
        if (permissions.length > 0) {
          await tx.rolePermission.createMany({
            data: permissions.map(permissionId => ({
              roleId: params.id,
              permissionId
            }))
          })
        }
      }

      return role
    })

    // Obtener rol completo
    const roleWithPermissions = await prisma.role.findUnique({
      where: { id: params.id },
      include: {
        rolePermissions: {
          include: {
            permission: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: roleWithPermissions,
      message: 'Rol actualizado exitosamente'
    })

  } catch (error) {
    console.error('Error updating role:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/roles/[id]
 * Eliminar rol (soft delete)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const role = await prisma.role.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            admins: true
          }
        }
      }
    })

    if (!role) {
      return NextResponse.json(
        { success: false, message: 'Rol no encontrado' },
        { status: 404 }
      )
    }

    // No permitir eliminar roles que tienen usuarios asignados
    if (role._count.admins > 0) {
      return NextResponse.json(
        { success: false, message: 'No se puede eliminar un rol que tiene usuarios asignados' },
        { status: 400 }
      )
    }

    // Soft delete - marcar como inactivo
    await prisma.role.update({
      where: { id: params.id },
      data: { 
        isActive: false,
        updatedAt: new Date()
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Rol eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error deleting role:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
