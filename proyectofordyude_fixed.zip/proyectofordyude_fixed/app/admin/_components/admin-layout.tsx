

'use client';

import { useState, useEffect } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import {
  LayoutDashboard,
  Users,
  Palette,
  QrCode,
  Link2,
  PaintBucket,
  BarChart3,
  Image as ImageIcon,
  Rss,
  Database,
  UserCog,
  MapPin,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  Search,
  Gamepad2,
  Tag,
  CheckCircle,
  Globe,
  Eye,
  ExternalLink,
  Edit3,
  Wifi
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { UserDropdown } from '@/components/ui/user-dropdown';
import { NotificationDropdown } from '@/components/ui/notification-dropdown';

interface AdminLayoutProps {
  children: React.ReactNode;
}

/**
 * Lista de elementos del sidebar con iconos de Lucide React
 * Estructura final completa con todas las funcionalidades implementadas
 */
const sidebarItems = [
  { name: 'Dashboard', href: '/admin/dashboard', icon: LayoutDashboard },
  { name: 'Usuarios Conectados', href: '/admin/users', icon: Users },
  { name: 'Usuarios Portal Cautivo', href: '/admin/captive-users', icon: Wifi },
  { name: 'Temas', href: '/admin/themes', icon: Palette },
  { name: 'Editor de Temas', href: '/admin/theme-editor', icon: PaintBucket },
  { name: 'Gestor de Imágenes', href: '/admin/image-manager', icon: ImageIcon },
  { name: 'Promociones', href: '/admin/promotions', icon: Tag },
  { name: 'Generador QR/vCards', href: '/admin/qr-generator', icon: QrCode },
  { name: 'Links Portales Cautivos', href: '/admin/portal-links', icon: Link2 },
  { name: 'Links de Banners', href: '/admin/banner-links', icon: ExternalLink },
  { name: 'Editor Internet-Ready', href: '/admin/internet-ready-editor', icon: Edit3 },
  { name: 'Acceso Garantizado', href: '/portal/access-granted', icon: CheckCircle },
  { name: 'Portal Internet Listo', href: '/portal/internet-ready', icon: Globe },
  { name: 'Vista Previa Portal', href: '/portal/preview', icon: Eye },
  { name: 'Reportes', href: '/admin/reports', icon: BarChart3 },
  { name: 'Banners', href: '/admin/banners', icon: ImageIcon },
  { name: 'RSS Feeds', href: '/admin/rss', icon: Rss },
  { name: 'Backup BD', href: '/admin/backup', icon: Database },
  { name: 'Gestión Usuarios', href: '/admin/user-management', icon: UserCog },
  { name: 'Ubicaciones/Routers', href: '/admin/locations', icon: MapPin },
  { name: 'Logs', href: '/admin/logs', icon: FileText },
  { name: 'Configuraciones', href: '/admin/settings', icon: Settings },
  { name: 'Easter Egg', href: '/admin/easteregg', icon: Gamepad2 },
];

/**
 * Layout principal del panel de administración Ford
 * Incluye sidebar con navegación completa y header responsive
 */
export function AdminLayout({ children }: AdminLayoutProps) {
  const { data: session, status } = useSession();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    // Cerrar sidebar automáticamente al cambiar de ruta en móvil
    setSidebarOpen(false);
  }, [pathname]);

  // Estado de carga del session
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <LoadingSpinner size="lg" message="Cargando panel de administración..." />
      </div>
    );
  }

  // Verificación de autenticación
  if (!session) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Acceso Denegado</h1>
          <p className="text-gray-600 mb-6">Debes iniciar sesión para acceder al panel.</p>
          <Link href="/admin/login">
            <FordButton>Iniciar Sesión</FordButton>
          </Link>
        </div>
      </div>
    );
  }

  /**
   * Maneja el logout del administrador
   */
  const handleLogout = async () => {
    await signOut({ callbackUrl: '/admin/login' });
  };

  return (
    <div className="h-screen bg-gray-100 flex overflow-hidden">
      {/* Sidebar con navegación completa */}
      <AnimatePresence>
        {(sidebarOpen || (typeof window !== 'undefined' && window.innerWidth >= 1024)) && (
          <motion.div
            className="fixed inset-y-0 left-0 z-50 w-64 bg-[#003478] lg:relative lg:translate-x-0"
            initial={{ x: -256 }}
            animate={{ x: 0 }}
            exit={{ x: -256 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex flex-col h-full">
              {/* Logo Ford con branding */}
              <div className="flex items-center justify-between p-4 border-b border-blue-600">
                <div className="flex items-center space-x-3">
                  <Image
                    src="https://static.vecteezy.com/system/resources/previews/019/909/675/large_2x/ford-transparent-ford-free-free-png.png"
                    alt="Ford Logo"
                    width={32}
                    height={32}
                    className="object-contain"
                  />
                  <div className="text-white">
                    <h1 className="text-lg font-bold">Ford Admin</h1>
                    <p className="text-xs text-blue-200">Portal Cautivo</p>
                  </div>
                </div>
                <button
                  className="lg:hidden text-white hover:text-blue-200 transition-colors"
                  onClick={() => setSidebarOpen(false)}
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Navegación principal con todos los menús */}
              <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
                {sidebarItems.map((item) => {
                  const IconComponent = item.icon;
                  const isActive = pathname === item.href;
                  
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                        isActive
                          ? 'bg-blue-600 text-white shadow-lg'
                          : 'text-blue-200 hover:bg-blue-600 hover:text-white hover:shadow-md'
                      }`}
                    >
                      <IconComponent className="w-5 h-5 flex-shrink-0" />
                      <span className="text-sm font-medium truncate">{item.name}</span>
                    </Link>
                  );
                })}
              </nav>

              {/* Información del usuario autenticado */}
              <div className="p-4 border-t border-blue-600">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">
                      {session.user?.name?.charAt(0) || 'A'}
                    </span>
                  </div>
                  <div className="text-white">
                    <p className="text-sm font-medium truncate">{session.user?.name}</p>
                    <p className="text-xs text-blue-200">{session.user?.role || 'Admin'}</p>
                  </div>
                </div>
                <FordButton
                  variant="outline"
                  size="sm"
                  className="w-full border-blue-400 text-blue-200 hover:bg-blue-600 hover:border-blue-300"
                  onClick={handleLogout}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Cerrar Sesión
                </FordButton>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay para móvil */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Contenido principal */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header superior con controles */}
        <header className="bg-white border-b border-gray-200 px-4 py-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                className="lg:hidden text-gray-600 hover:text-[#003478] transition-colors"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-800">
                  {sidebarItems.find(item => item.href === pathname)?.name || 'Panel de Administración'}
                </h1>
                <p className="text-sm text-gray-600">
                  Bienvenido, {session.user?.name} - Ford Yude Canahuati
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* Buscador global */}
              <div className="hidden sm:block relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Buscar..."
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent text-sm"
                />
              </div>

              {/* Notificaciones funcionales */}
              <NotificationDropdown />

              {/* Menú de usuario funcional */}
              <UserDropdown />
            </div>
          </div>
        </header>

        {/* Área de contenido principal con animaciones */}
        <main className="flex-1 overflow-auto bg-gray-50 p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
