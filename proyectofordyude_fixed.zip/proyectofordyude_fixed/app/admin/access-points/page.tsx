
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { 
  Wifi, 
  Plus, 
  Edit, 
  Trash2, 
  MapPin,
  Router,
  Clock,
  CheckCircle,
  XCircle,
  Image as ImageIcon
} from 'lucide-react';
import Image from 'next/image';

interface AccessPoint {
  id: string;
  name: string;
  ipAddress: string;
  macAddress?: string;
  location?: string;
  description?: string;
  imageUrl?: string;
  isActive: boolean;
  lastSeen?: string;
  configData?: any;
  createdAt: string;
  updatedAt: string;
}

export default function AccessPointsPage() {
  const [accessPoints, setAccessPoints] = useState<AccessPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    ipAddress: '',
    macAddress: '',
    location: '',
    description: '',
    imageUrl: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchAccessPoints();
  }, []);

  const fetchAccessPoints = async () => {
    try {
      const response = await fetch('/api/admin/access-points');
      if (response.ok) {
        const data = await response.json();
        setAccessPoints(data);
      }
    } catch (error) {
      console.error('Error fetching access points:', error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      ipAddress: '',
      macAddress: '',
      location: '',
      description: '',
      imageUrl: ''
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = async () => {
    try {
      const url = editingId 
        ? `/api/admin/access-points/${editingId}`
        : '/api/admin/access-points';
      
      const response = await fetch(url, {
        method: editingId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        toast({
          title: editingId ? "Access Point actualizado" : "Access Point creado",
          description: `El Access Point ha sido ${editingId ? 'actualizado' : 'creado'} exitosamente`
        });
        resetForm();
        fetchAccessPoints();
      } else {
        throw new Error(`Error al ${editingId ? 'actualizar' : 'crear'} Access Point`);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: `No se pudo ${editingId ? 'actualizar' : 'crear'} el Access Point`,
        variant: "destructive"
      });
    }
  };

  const handleEdit = (accessPoint: AccessPoint) => {
    setFormData({
      name: accessPoint.name,
      ipAddress: accessPoint.ipAddress,
      macAddress: accessPoint.macAddress || '',
      location: accessPoint.location || '',
      description: accessPoint.description || '',
      imageUrl: accessPoint.imageUrl || ''
    });
    setEditingId(accessPoint.id);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Estás seguro de que deseas eliminar este Access Point?')) return;

    try {
      const response = await fetch(`/api/admin/access-points/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast({
          title: "Access Point eliminado",
          description: "El Access Point ha sido eliminado exitosamente"
        });
        fetchAccessPoints();
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el Access Point",
        variant: "destructive"
      });
    }
  };

  const toggleStatus = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/access-points/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive })
      });

      if (response.ok) {
        toast({
          title: isActive ? "Access Point desactivado" : "Access Point activado",
          description: `El Access Point ha sido ${isActive ? 'desactivado' : 'activado'} exitosamente`
        });
        fetchAccessPoints();
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cambiar el estado del Access Point",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestión de Access Points</h1>
          <p className="text-gray-600">Administra los puntos de acceso WiFi del portal cautivo</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Access Point
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Wifi className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total APs</p>
                <p className="text-2xl font-bold text-gray-900">
                  {accessPoints.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Activos</p>
                <p className="text-2xl font-bold text-gray-900">
                  {accessPoints.filter(ap => ap.isActive).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <XCircle className="h-8 w-8 text-red-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Inactivos</p>
                <p className="text-2xl font-bold text-gray-900">
                  {accessPoints.filter(ap => !ap.isActive).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Clock className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Con Ubicación</p>
                <p className="text-2xl font-bold text-gray-900">
                  {accessPoints.filter(ap => ap.location).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Formulario */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>
              {editingId ? 'Editar Access Point' : 'Nuevo Access Point'}
            </CardTitle>
            <CardDescription>
              {editingId ? 'Actualiza los datos del Access Point' : 'Registra un nuevo punto de acceso WiFi'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre del Access Point *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ej: AP-Recepcion"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="ipAddress">Dirección IP *</Label>
                <Input
                  id="ipAddress"
                  value={formData.ipAddress}
                  onChange={(e) => setFormData({...formData, ipAddress: e.target.value})}
                  placeholder="192.168.1.100"
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="macAddress">Dirección MAC</Label>
                <Input
                  id="macAddress"
                  value={formData.macAddress}
                  onChange={(e) => setFormData({...formData, macAddress: e.target.value})}
                  placeholder="00:11:22:33:44:55"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="location">Ubicación</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                  placeholder="Recepción Principal"
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Descripción del Access Point..."
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="imageUrl">URL de Imagen (Opcional)</Label>
              <Input
                id="imageUrl"
                value={formData.imageUrl}
                onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                placeholder="https://lh6.googleusercontent.com/Em-YMrKtGLWwmCNCBuV2sqJLb2Xyyku5cfslP3pbeUEiC5ZrO2Z4Dh6awtqwQCo2TO5NqIGn-DCs4iHOtT0DsIcCuR4QY3-KlNd4h3vE_AzBjQUBlkJD-inpone8H5OWlS896sABWdliWQaRAOtX3gykKbdD4JZKXM7x-9Z7WsHPC_fRdhS9VvLNTw"
                className="mt-1"
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={resetForm}>
                Cancelar
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={!formData.name.trim() || !formData.ipAddress.trim()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {editingId ? 'Actualizar' : 'Crear'} Access Point
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de Access Points */}
      <Card>
        <CardHeader>
          <CardTitle>Access Points Configurados</CardTitle>
          <CardDescription>
            Lista de todos los puntos de acceso WiFi registrados
          </CardDescription>
        </CardHeader>
        <CardContent>
          {accessPoints.length === 0 ? (
            <div className="text-center py-8">
              <Wifi className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No hay Access Points configurados</p>
              <p className="text-sm text-gray-400">Registra el primer punto de acceso</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {accessPoints.map((ap) => (
                <div key={ap.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant={ap.isActive ? "default" : "secondary"}>
                      {ap.isActive ? "Activo" : "Inactivo"}
                    </Badge>
                    {ap.lastSeen && (
                      <span className="text-xs text-gray-500">
                        Visto: {new Date(ap.lastSeen).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                  
                  {/* Image */}
                  {ap.imageUrl && (
                    <div className="relative w-full h-32 mb-3 rounded-md overflow-hidden bg-gray-100">
                      <Image
                        src={ap.imageUrl}
                        alt={ap.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                  
                  <div className="space-y-2 mb-4">
                    <h3 className="font-semibold text-lg text-gray-900">{ap.name}</h3>
                    
                    <div className="space-y-1">
                      <div className="flex items-center text-sm text-gray-600">
                        <Router className="w-3 h-3 mr-2" />
                        {ap.ipAddress}
                      </div>
                      {ap.macAddress && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Wifi className="w-3 h-3 mr-2" />
                          {ap.macAddress}
                        </div>
                      )}
                      {ap.location && (
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="w-3 h-3 mr-2" />
                          {ap.location}
                        </div>
                      )}
                    </div>
                    
                    {ap.description && (
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {ap.description}
                      </p>
                    )}
                  </div>

                  <div className="flex justify-between space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(ap)}
                      className="flex-1"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleStatus(ap.id, ap.isActive)}
                      className="flex-1"
                    >
                      {ap.isActive ? <XCircle className="w-4 h-4 mr-1" /> : <CheckCircle className="w-4 h-4 mr-1" />}
                      {ap.isActive ? 'Desactivar' : 'Activar'}
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(ap.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
