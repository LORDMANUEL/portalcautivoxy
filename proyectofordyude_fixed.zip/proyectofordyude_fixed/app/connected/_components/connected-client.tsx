
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { 
  Wifi, 
  Clock, 
  Smartphone, 
  MapPin, 
  Signal, 
  Shield,
  ExternalLink,
  Share2,
  Bell,
  Star
} from 'lucide-react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';

interface ConnectionInfo {
  ipAddress: string;
  deviceType: string;
  connectedAt: Date;
  sessionDuration: number;
  dataUsed: string;
  signalStrength: number;
}

interface NewsItem {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  url: string;
  publishedAt: Date;
}

export function ConnectedClient() {
  const [connectionInfo, setConnectionInfo] = useState<ConnectionInfo>({
    ipAddress: '192.168.1.100',
    deviceType: 'Desktop',
    connectedAt: new Date(),
    sessionDuration: 0,
    dataUsed: '0 MB',
    signalStrength: 85
  });

  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [selectedTheme, setSelectedTheme] = useState<string>('default');

  useEffect(() => {
    // Get device info
    const userAgent = navigator.userAgent;
    let deviceType = 'Desktop';
    if (/Mobi|Android/i.test(userAgent)) deviceType = 'Mobile';
    else if (/iPad|Tablet/i.test(userAgent)) deviceType = 'Tablet';

    // Get theme from localStorage
    const theme = localStorage.getItem('selectedTheme') || 'default';
    setSelectedTheme(theme);

    setConnectionInfo(prev => ({
      ...prev,
      deviceType,
      ipAddress: `192.168.1.${Math.floor(Math.random() * 200) + 100}`
    }));

    // Simulate news loading
    setNewsItems([
      {
        id: '1',
        title: 'Nueva Ford F-150 2025 ya disponible',
        description: 'Descubre las innovaciones de la pickup más vendida de América.',
        imageUrl: 'https://i.ytimg.com/vi/xrrrpZhBlDc/maxresdefault.jpg',
        url: '#',
        publishedAt: new Date()
      },
      {
        id: '2',
        title: 'Ford celebra 50 años en Honduras',
        description: 'Medio siglo de excelencia automotriz en territorio catracho.',
        imageUrl: 'https://iconosmag.com/wp-content/uploads/2024/06/portada-desfile-agas-yude-ford-honduras-2024-1.jpg',
        url: '#',
        publishedAt: new Date()
      },
      {
        id: '3',
        title: 'Servicio de mantenimiento Ford',
        description: 'Agenda tu cita de servicio con nuestros técnicos especializados.',
        imageUrl: 'https://thedesigncompound.com/data/portfolio/ford-automobile-showroom/18-reception-design.jpg?20210929201239',
        url: '#',
        publishedAt: new Date()
      }
    ]);

    // Session timer
    const timer = setInterval(() => {
      setConnectionInfo(prev => ({
        ...prev,
        sessionDuration: prev.sessionDuration + 1,
        dataUsed: `${Math.floor((prev.sessionDuration + 1) / 10)} MB`
      }));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Ford Yude Canahuati WiFi',
          text: 'Conectado al WiFi gratuito de Ford Yude Canahuati',
          url: window.location.origin
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(window.location.origin);
      alert('Enlace copiado al portapapeles');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      <Header variant="public" theme={selectedTheme} />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Message */}
        <motion.section
          className="text-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
              <Wifi className="w-8 h-8 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-3xl md:text-4xl font-bold text-[#003478]">
                ¡Conectado exitosamente!
              </h1>
              <p className="text-lg text-gray-600">
                Bienvenido al WiFi de Ford Yude Canahuati
              </p>
            </div>
          </div>
        </motion.section>

        <div className="grid lg:grid-cols-3 gap-8 mb-8">
          {/* Connection Status */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <FordCard className="p-6">
              <h2 className="text-xl font-bold text-[#003478] mb-4 flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Estado de Conexión
              </h2>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">IP Address:</span>
                  <span className="font-mono text-sm">{connectionInfo.ipAddress}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Dispositivo:</span>
                  <span className="flex items-center">
                    <Smartphone className="w-4 h-4 mr-1" />
                    {connectionInfo.deviceType}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Señal:</span>
                  <span className="flex items-center text-green-600">
                    <Signal className="w-4 h-4 mr-1" />
                    {connectionInfo.signalStrength}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Datos:</span>
                  <span className="text-blue-600">{connectionInfo.dataUsed}</span>
                </div>
              </div>
            </FordCard>
          </motion.div>

          {/* Session Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <FordCard className="p-6">
              <h2 className="text-xl font-bold text-[#003478] mb-4 flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                Sesión Actual
              </h2>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#003478]">
                    {formatDuration(connectionInfo.sessionDuration)}
                  </div>
                  <p className="text-gray-600">Tiempo conectado</p>
                </div>
                <div className="text-center">
                  <div className="text-sm text-gray-600">
                    Conectado desde: {connectionInfo.connectedAt.toLocaleTimeString('es-HN')}
                  </div>
                </div>
              </div>
            </FordCard>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <FordCard className="p-6">
              <h2 className="text-xl font-bold text-[#003478] mb-4">
                Acciones Rápidas
              </h2>
              <div className="space-y-3">
                <FordButton 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={handleShare}
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Compartir WiFi
                </FordButton>
                <FordButton 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Notificaciones
                </FordButton>
                <FordButton 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                >
                  <MapPin className="w-4 h-4 mr-2" />
                  Ubicación
                </FordButton>
              </div>
            </FordCard>
          </motion.div>
        </div>

        {/* News and Content */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h2 className="text-2xl font-bold text-[#003478] mb-6 flex items-center">
            <Star className="w-6 h-6 mr-2" />
            Noticias y Promociones Ford
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {newsItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
              >
                <FordCard className="overflow-hidden" hover>
                  <div className="relative h-48">
                    <Image
                      src={item.imageUrl}
                      alt={item.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="p-4 space-y-3">
                    <h3 className="font-bold text-[#003478] line-clamp-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 text-sm line-clamp-3">
                      {item.description}
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">
                        {item.publishedAt.toLocaleDateString('es-HN')}
                      </span>
                      <FordButton variant="ghost" size="sm">
                        <ExternalLink className="w-4 h-4 mr-1" />
                        Leer más
                      </FordButton>
                    </div>
                  </div>
                </FordCard>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Disconnect Button */}
        <motion.section
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <FordButton 
            variant="outline" 
            size="lg"
            onClick={() => window.location.href = '/disconnected'}
          >
            Desconectarse del WiFi
          </FordButton>
        </motion.section>
      </main>

      <Footer />
    </div>
  );
}
