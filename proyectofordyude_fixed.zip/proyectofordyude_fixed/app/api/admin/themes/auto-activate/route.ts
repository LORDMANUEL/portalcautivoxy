

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * POST /api/admin/themes/auto-activate
 * Activa automáticamente temas basado en fechas especiales
 */
export async function POST() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1; // getMonth() devuelve 0-11
    const currentDay = currentDate.getDate();

    console.log(`🗓️ Verificando temas para fecha: ${currentDay}/${currentMonth}/${currentYear}`);

    // Definir calendario de eventos especiales
    const specialEvents = [
      {
        name: 'mother',
        displayName: 'Día de la Madre',
        startMonth: 5,
        startDay: 1,
        endMonth: 5,
        endDay: 15,
        priority: 1
      },
      {
        name: 'woman',
        displayName: 'Día de la Mujer',
        startMonth: 3,
        startDay: 1,
        endMonth: 3,
        endDay: 15,
        priority: 1
      },
      {
        name: 'man',
        displayName: 'Día del Hombre',
        startMonth: 6,
        startDay: 15,
        endMonth: 6,
        endDay: 25,
        priority: 1
      },
      {
        name: 'independence',
        displayName: 'Independencia Honduras',
        startMonth: 9,
        startDay: 10,
        endMonth: 9,
        endDay: 20,
        priority: 2 // Alta prioridad para eventos patrios
      },
      {
        name: 'xmas',
        displayName: 'Navidad',
        startMonth: 12,
        startDay: 1,
        endMonth: 12,
        endDay: 31,
        priority: 1
      },
      {
        name: 'summer',
        displayName: 'Verano',
        startMonth: 6,
        startDay: 1,
        endMonth: 8,
        endDay: 31,
        priority: 0 // Baja prioridad, se activa solo si no hay otros temas
      }
    ];

    // Buscar eventos activos para la fecha actual
    const activeEvents = specialEvents.filter(event => {
      const isInRange = (currentMonth >= event.startMonth && currentMonth <= event.endMonth) &&
                       (currentMonth === event.startMonth ? currentDay >= event.startDay : true) &&
                       (currentMonth === event.endMonth ? currentDay <= event.endDay : true);
      return isInRange;
    });

    console.log(`📅 Eventos activos encontrados: ${activeEvents.length}`);

    let themeToActivate = null;
    let activatedCount = 0;
    let deactivatedCount = 0;

    if (activeEvents.length > 0) {
      // Seleccionar evento con mayor prioridad
      activeEvents.sort((a, b) => b.priority - a.priority);
      const selectedEvent = activeEvents[0];
      
      console.log(`🎯 Seleccionado evento: ${selectedEvent.displayName} (prioridad: ${selectedEvent.priority})`);

      // Buscar el tema correspondiente en la base de datos
      const themeToActivateFromDB = await prisma.theme.findFirst({
        where: { name: selectedEvent.name }
      });

      if (themeToActivateFromDB) {
        themeToActivate = themeToActivateFromDB;
        
        // Actualizar fechas del tema seleccionado
        await prisma.theme.update({
          where: { id: themeToActivate.id },
          data: {
            startDate: new Date(currentYear, selectedEvent.startMonth - 1, selectedEvent.startDay),
            endDate: new Date(currentYear, selectedEvent.endMonth - 1, selectedEvent.endDay),
            isActive: true,
            updatedAt: new Date()
          }
        });
        
        activatedCount++;
        console.log(`✅ Tema activado: ${selectedEvent.displayName}`);
      }
    }

    // Desactivar todos los otros temas que no sean el seleccionado
    const otherThemes = await prisma.theme.findMany({
      where: {
        AND: [
          { id: { not: themeToActivate?.id } },
          { isActive: true },
          { name: { not: 'default' } } // No desactivar el tema por defecto
        ]
      }
    });

    for (const theme of otherThemes) {
      // Verificar si el tema tiene fechas válidas y si está fuera del rango
      if (theme.startDate && theme.endDate) {
        const themeStart = new Date(theme.startDate);
        const themeEnd = new Date(theme.endDate);
        const now = new Date();
        
        if (now < themeStart || now > themeEnd) {
          await prisma.theme.update({
            where: { id: theme.id },
            data: { isActive: false, updatedAt: new Date() }
          });
          deactivatedCount++;
          console.log(`❌ Tema desactivado: ${theme.displayName}`);
        }
      }
    }

    // Si no hay temas especiales activos, activar tema por defecto
    if (!themeToActivate) {
      const defaultTheme = await prisma.theme.findFirst({
        where: { name: 'default' }
      });
      
      if (defaultTheme && !defaultTheme.isActive) {
        await prisma.theme.update({
          where: { id: defaultTheme.id },
          data: { isActive: true, updatedAt: new Date() }
        });
        themeToActivate = defaultTheme;
        activatedCount++;
        console.log(`✅ Tema por defecto activado`);
      }
    }

    const result = {
      success: true,
      currentDate: currentDate.toISOString(),
      activeTheme: themeToActivate ? {
        id: themeToActivate.id,
        name: themeToActivate.name,
        displayName: themeToActivate.displayName
      } : null,
      themesActivated: activatedCount,
      themesDeactivated: deactivatedCount,
      specialEvents: activeEvents,
      message: themeToActivate 
        ? `Tema "${themeToActivate.displayName}" activado automáticamente`
        : 'No se encontraron temas especiales para la fecha actual'
    };

    console.log('🎉 Activación automática completada:', result);
    return NextResponse.json(result);

  } catch (error) {
    console.error('❌ Error en activación automática de temas:', error);
    return NextResponse.json({ 
      error: 'Error interno del servidor',
      details: error instanceof Error ? error.message : 'Error desconocido'
    }, { status: 500 });
  }
}

/**
 * GET /api/admin/themes/auto-activate
 * Obtiene información sobre la activación automática sin ejecutarla
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentDay = currentDate.getDate();

    // Mismos eventos especiales que en POST
    const specialEvents = [
      { name: 'mother', displayName: 'Día de la Madre', startMonth: 5, startDay: 1, endMonth: 5, endDay: 15, priority: 1 },
      { name: 'woman', displayName: 'Día de la Mujer', startMonth: 3, startDay: 1, endMonth: 3, endDay: 15, priority: 1 },
      { name: 'man', displayName: 'Día del Hombre', startMonth: 6, startDay: 15, endMonth: 6, endDay: 25, priority: 1 },
      { name: 'independence', displayName: 'Independencia Honduras', startMonth: 9, startDay: 10, endMonth: 9, endDay: 20, priority: 2 },
      { name: 'xmas', displayName: 'Navidad', startMonth: 12, startDay: 1, endMonth: 12, endDay: 31, priority: 1 },
      { name: 'summer', displayName: 'Verano', startMonth: 6, startDay: 1, endMonth: 8, endDay: 31, priority: 0 }
    ];

    const activeEvents = specialEvents.filter(event => {
      const isInRange = (currentMonth >= event.startMonth && currentMonth <= event.endMonth) &&
                       (currentMonth === event.startMonth ? currentDay >= event.startDay : true) &&
                       (currentMonth === event.endMonth ? currentDay <= event.endDay : true);
      return isInRange;
    });

    // Obtener tema actualmente activo
    const currentActiveTheme = await prisma.theme.findFirst({
      where: { isActive: true },
      orderBy: { updatedAt: 'desc' }
    });

    return NextResponse.json({
      currentDate: currentDate.toISOString(),
      currentActiveTheme: currentActiveTheme ? {
        id: currentActiveTheme.id,
        name: currentActiveTheme.name,
        displayName: currentActiveTheme.displayName
      } : null,
      activeEvents,
      allEvents: specialEvents,
      recommendedAction: activeEvents.length > 0 
        ? `Activar tema: ${activeEvents.sort((a, b) => b.priority - a.priority)[0].displayName}`
        : 'Mantener tema por defecto'
    });

  } catch (error) {
    console.error('Error al obtener información de activación automática:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
