
'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload,
  Image as ImageIcon,
  Trash2,
  Edit3,
  Eye,
  Copy,
  Download,
  Search,
  Filter,
  Grid,
  List,
  Plus,
  FolderOpen,
  Star,
  FileImage,
  Palette
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import Image from 'next/image';

interface ImageAsset {
  id: string;
  name: string;
  originalName: string;
  url: string;
  thumbnailUrl?: string;
  size: number;
  mimeType: string;
  category: string;
  tags: string[];
  alt: string;
  description?: string;
  isPublic: boolean;
  isFeatured: boolean;
  uploadedBy: string;
  createdAt: string;
  updatedAt: string;
  metadata: {
    width?: number;
    height?: number;
    usage: string[];
    portal?: string;
    theme?: string;
  };
}

interface UploadProgress {
  id: string;
  name: string;
  progress: number;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  error?: string;
}

/**
 * Gestor completo de imágenes para portales cautivos
 * Permite subir, organizar y gestionar imágenes para temas y portales
 */
export function ImageManagerClient() {
  const [images, setImages] = useState<ImageAsset[]>([]);
  const [filteredImages, setFilteredImages] = useState<ImageAsset[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress[]>([]);
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedImage, setSelectedImage] = useState<ImageAsset | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Filtros y búsqueda
  const categories = [
    'all', 'backgrounds', 'logos', 'banners', 'icons', 'vehicles', 
    'showroom', 'services', 'promotions', 'seasonal', 'quicklane'
  ];

  useEffect(() => {
    fetchImages();
  }, []);

  useEffect(() => {
    filterImages();
  }, [images, searchTerm, categoryFilter]);

  /**
   * Obtiene todas las imágenes
   */
  const fetchImages = async () => {
    try {
      const response = await fetch('/api/admin/images');
      if (response.ok) {
        const data = await response.json();
        setImages(data);
      } else {
        toast.error('Error al cargar imágenes');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al cargar imágenes');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Filtra imágenes según búsqueda y categoría
   */
  const filterImages = useCallback(() => {
    let filtered = images;

    // Filtrar por categoría
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(img => img.category === categoryFilter);
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(img => 
        img.name.toLowerCase().includes(search) ||
        img.alt.toLowerCase().includes(search) ||
        img.tags.some(tag => tag.toLowerCase().includes(search)) ||
        (img.description && img.description.toLowerCase().includes(search))
      );
    }

    setFilteredImages(filtered);
  }, [images, searchTerm, categoryFilter]);

  /**
   * Maneja la subida de archivos
   */
  const handleFileUpload = async (files: FileList) => {
    if (!files.length) return;

    setUploading(true);
    const uploads: UploadProgress[] = [];

    // Inicializar progreso para cada archivo
    Array.from(files).forEach((file, index) => {
      uploads.push({
        id: `upload-${Date.now()}-${index}`,
        name: file.name,
        progress: 0,
        status: 'uploading'
      });
    });

    setUploadProgress(uploads);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const formData = new FormData();
        formData.append('file', file);
        formData.append('category', categoryFilter === 'all' ? 'general' : categoryFilter);

        // Simular progreso de subida
        const updateProgress = (progress: number) => {
          setUploadProgress(prev => prev.map(upload => 
            upload.id === uploads[i].id 
              ? { ...upload, progress, status: progress === 100 ? 'processing' : 'uploading' }
              : upload
          ));
        };

        // Simular subida progresiva
        for (let progress = 0; progress <= 100; progress += 10) {
          await new Promise(resolve => setTimeout(resolve, 100));
          updateProgress(progress);
        }

        try {
          const response = await fetch('/api/admin/images/upload', {
            method: 'POST',
            body: formData
          });

          if (response.ok) {
            setUploadProgress(prev => prev.map(upload => 
              upload.id === uploads[i].id 
                ? { ...upload, status: 'completed', progress: 100 }
                : upload
            ));
          } else {
            throw new Error('Error uploading file');
          }
        } catch (error) {
          setUploadProgress(prev => prev.map(upload => 
            upload.id === uploads[i].id 
              ? { ...upload, status: 'error', error: 'Error al subir archivo' }
              : upload
          ));
        }
      }

      // Refrescar lista de imágenes
      await fetchImages();
      toast.success(`${files.length} imagen(es) subidas exitosamente`);

      // Limpiar progreso después de 3 segundos
      setTimeout(() => {
        setUploadProgress([]);
        setShowUploadModal(false);
      }, 3000);

    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al subir imágenes');
    } finally {
      setUploading(false);
    }
  };

  /**
   * Elimina imagen seleccionada
   */
  const deleteImage = async (imageId: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar esta imagen?')) return;

    try {
      const response = await fetch(`/api/admin/images/${imageId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setImages(prev => prev.filter(img => img.id !== imageId));
        toast.success('Imagen eliminada exitosamente');
      } else {
        toast.error('Error al eliminar imagen');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al eliminar imagen');
    }
  };

  /**
   * Copia URL de la imagen al portapapeles
   */
  const copyImageUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('URL copiada al portapapeles');
    } catch (error) {
      toast.error('Error al copiar URL');
    }
  };

  /**
   * Actualiza información de la imagen
   */
  const updateImage = async (imageId: string, updates: Partial<ImageAsset>) => {
    try {
      const response = await fetch(`/api/admin/images/${imageId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });

      if (response.ok) {
        const updatedImage = await response.json();
        setImages(prev => prev.map(img => 
          img.id === imageId ? updatedImage : img
        ));
        toast.success('Imagen actualizada exitosamente');
        setShowEditModal(false);
      } else {
        toast.error('Error al actualizar imagen');
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Error al actualizar imagen');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-ford-blue">Gestor de Imágenes</h1>
          <p className="text-gray-600 mt-2">
            Administra imágenes para portales cautivos y temas
          </p>
        </div>
        <FordButton onClick={() => setShowUploadModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Subir Imágenes
        </FordButton>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <ImageIcon className="w-6 h-6 text-ford-blue" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Imágenes</p>
              <p className="text-2xl font-bold text-ford-blue">{images.length}</p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              <Star className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Destacadas</p>
              <p className="text-2xl font-bold text-green-600">
                {images.filter(img => img.isFeatured).length}
              </p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <FolderOpen className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Categorías</p>
              <p className="text-2xl font-bold text-purple-600">
                {new Set(images.map(img => img.category)).size}
              </p>
            </div>
          </div>
        </FordCard>

        <FordCard className="p-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <FileImage className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Tamaño Total</p>
              <p className="text-2xl font-bold text-orange-600">
                {(images.reduce((sum, img) => sum + img.size, 0) / (1024 * 1024)).toFixed(1)}MB
              </p>
            </div>
          </div>
        </FordCard>
      </div>

      {/* Controles de filtro y búsqueda */}
      <FordCard className="p-6">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex flex-col md:flex-row gap-4 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar imágenes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrar por categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category === 'all' ? 'Todas las categorías' : 
                     category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <FordButton
              variant={viewMode === 'grid' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </FordButton>
            <FordButton
              variant={viewMode === 'list' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </FordButton>
          </div>
        </div>
      </FordCard>

      {/* Progreso de subida */}
      <AnimatePresence>
        {uploadProgress.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <FordCard className="p-4">
              <h3 className="font-semibold mb-4">Subiendo archivos</h3>
              <div className="space-y-3">
                {uploadProgress.map(upload => (
                  <div key={upload.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="truncate">{upload.name}</span>
                      <Badge variant={
                        upload.status === 'completed' ? 'default' :
                        upload.status === 'error' ? 'destructive' : 'secondary'
                      }>
                        {upload.status === 'uploading' ? 'Subiendo' :
                         upload.status === 'processing' ? 'Procesando' :
                         upload.status === 'completed' ? 'Completado' : 'Error'}
                      </Badge>
                    </div>
                    <Progress value={upload.progress} className="h-2" />
                    {upload.error && (
                      <p className="text-red-500 text-xs">{upload.error}</p>
                    )}
                  </div>
                ))}
              </div>
            </FordCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Galería de imágenes */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredImages.map(image => (
            <motion.div
              key={image.id}
              whileHover={{ scale: 1.05 }}
              className="group relative"
            >
              <FordCard className="p-2 h-48 flex flex-col">
                <div className="relative flex-1 rounded-lg overflow-hidden bg-gray-100">
                  <Image
                    src={image.thumbnailUrl || image.url}
                    alt={image.alt}
                    fill
                    className="object-cover"
                  />
                  
                  {/* Overlay con acciones */}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 flex gap-2 transition-opacity">
                      <button
                        onClick={() => {
                          setSelectedImage(image);
                          setShowEditModal(true);
                        }}
                        className="p-2 bg-white rounded-full hover:bg-gray-100"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => copyImageUrl(image.url)}
                        className="p-2 bg-white rounded-full hover:bg-gray-100"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => deleteImage(image.id)}
                        className="p-2 bg-red-500 text-white rounded-full hover:bg-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="absolute top-2 left-2 flex gap-1">
                    {image.isFeatured && (
                      <Badge variant="default" className="text-xs">
                        <Star className="w-3 h-3 mr-1" />
                        Destacada
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="pt-2">
                  <p className="text-xs text-gray-600 truncate">{image.name}</p>
                  <p className="text-xs text-gray-400">
                    {(image.size / 1024).toFixed(1)}KB
                  </p>
                </div>
              </FordCard>
            </motion.div>
          ))}
        </div>
      ) : (
        <FordCard>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4">Vista previa</th>
                  <th className="text-left p-4">Nombre</th>
                  <th className="text-left p-4">Categoría</th>
                  <th className="text-left p-4">Tamaño</th>
                  <th className="text-left p-4">Fecha</th>
                  <th className="text-left p-4">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredImages.map(image => (
                  <tr key={image.id} className="border-b hover:bg-gray-50">
                    <td className="p-4">
                      <div className="w-12 h-12 relative rounded-lg overflow-hidden bg-gray-100">
                        <Image
                          src={image.thumbnailUrl || image.url}
                          alt={image.alt}
                          fill
                          className="object-cover"
                        />
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{image.name}</p>
                        <p className="text-sm text-gray-500">{image.alt}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline">{image.category}</Badge>
                    </td>
                    <td className="p-4">
                      {(image.size / 1024).toFixed(1)}KB
                    </td>
                    <td className="p-4">
                      {new Date(image.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            setSelectedImage(image);
                            setShowEditModal(true);
                          }}
                          className="p-1 hover:bg-gray-100 rounded"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => copyImageUrl(image.url)}
                          className="p-1 hover:bg-gray-100 rounded"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteImage(image.id)}
                          className="p-1 hover:bg-gray-100 rounded text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </FordCard>
      )}

      {/* Modal de subida */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <FordCard className="w-full max-w-lg m-4">
            <div className="p-6">
              <h3 className="text-xl font-bold mb-4">Subir Imágenes</h3>
              
              <div className="space-y-4">
                <div>
                  <Label>Categoría</Label>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.filter(c => c !== 'all').map(category => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
                    className="hidden"
                    id="file-upload"
                  />
                  <label htmlFor="file-upload" className="cursor-pointer">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-lg font-medium">Seleccionar archivos</p>
                    <p className="text-gray-500">o arrastra y suelta aquí</p>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-6">
                <FordButton 
                  variant="outline" 
                  onClick={() => setShowUploadModal(false)}
                  disabled={uploading}
                >
                  Cancelar
                </FordButton>
              </div>
            </div>
          </FordCard>
        </div>
      )}
    </div>
  );
}
