

import { Metadata } from 'next';
import { ThemeEditorClient } from './_components/theme-editor-client';

export const metadata: Metadata = {
  title: 'Editor de Temas - Administración Ford',
  description: 'Editor visual de temas para portales cautivos Ford Yude Canahuati',
};

export default function ThemeEditorPage() {
  return <ThemeEditorClient />;
}
