
import { Metadata } from 'next';
import { ReportsClient } from './_components/reports-client';

export const metadata: Metadata = {
  title: 'Reportes y Estadísticas - Admin Ford',
  description: 'Reportes detallados y estadísticas del portal cautivo',
};

export default function AdminReportsPage() {
  return <ReportsClient />;
}
