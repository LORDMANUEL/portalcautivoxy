

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// GET - Obtener todas las promociones
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const promotions = await prisma.promotion.findMany({
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' }
      ]
    });

    return NextResponse.json(promotions);
  } catch (error) {
    console.error('Error al obtener promociones:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// POST - Crear nueva promoción
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const data = await request.json();
    
    // Validaciones básicas
    if (!data.title?.trim()) {
      return NextResponse.json(
        { error: 'El título es obligatorio' },
        { status: 400 }
      );
    }

    // Crear promoción
    const promotion = await prisma.promotion.create({
      data: {
        title: data.title.trim(),
        description: data.description?.trim() || null,
        imageUrl: data.imageUrl?.trim() || null,
        type: data.type || 'GENERAL',
        category: data.category?.trim() || null,
        discount: data.discount ? parseFloat(data.discount) : null,
        price: data.price ? parseFloat(data.price) : null,
        originalPrice: data.originalPrice ? parseFloat(data.originalPrice) : null,
        validFrom: data.validFrom ? new Date(data.validFrom) : new Date(),
        validUntil: data.validUntil ? new Date(data.validUntil) : null,
        isActive: data.isActive ?? true,
        isFeatured: data.isFeatured ?? false,
        location: data.location?.trim() || null,
        targetTheme: data.targetTheme?.trim() || null,
        conditions: data.conditions?.trim() || null,
        contactInfo: data.contactInfo?.trim() || null,
        priority: data.priority ? parseInt(data.priority) : 0,
        createdBy: session.user?.id || null
      }
    });

    return NextResponse.json(promotion, { status: 201 });
  } catch (error) {
    console.error('Error al crear promoción:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
