
'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  Globe,
  Download,
  Share2,
  QrCode,
  Calendar,
  Clock
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';
import Image from 'next/image';

interface VCard {
  id: string;
  advisorName: string;
  position: string | null;
  email: string;
  phone: string | null;
  company: string;
  address: string | null;
  website: string | null;
  photo: string | null;
  downloadCount: number;
  createdAt: string;
  updatedAt: string;
}

interface ContactClientProps {
  vcard: VCard;
}

/**
 * Cliente de página de contacto - Información del vendedor accesible vía QR
 */
export default function ContactClient({ vcard }: ContactClientProps) {
  const [downloading, setDownloading] = useState(false);

  /**
   * Descarga la vCard del asesor
   */
  const handleDownloadVCard = async () => {
    setDownloading(true);
    try {
      const response = await fetch(`/api/contact/${vcard.id}/vcard`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${vcard.advisorName.replace(/\s+/g, '-').toLowerCase()}.vcf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        toast.success('vCard descargada exitosamente');
      } else {
        toast.error('Error al descargar vCard');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setDownloading(false);
    }
  };

  /**
   * Comparte el contacto usando Web Share API
   */
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${vcard.advisorName} - Ford Yude Canahuati`,
          text: `Contacta con ${vcard.advisorName}, ${vcard.position || 'Asesor de Servicio'} en Ford Yude Canahuati`,
          url: window.location.href
        });
      } catch (error) {
        // Usuario canceló el compartir
      }
    } else {
      // Fallback - copiar URL
      try {
        await navigator.clipboard.writeText(window.location.href);
        toast.success('URL copiada al portapapeles');
      } catch (error) {
        toast.error('Error al copiar URL');
      }
    }
  };

  /**
   * Inicia llamada telefónica
   */
  const handleCall = () => {
    if (vcard.phone) {
      window.location.href = `tel:${vcard.phone}`;
    }
  };

  /**
   * Inicia email
   */
  const handleEmail = () => {
    window.location.href = `mailto:${vcard.email}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header Ford */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-[#003478] rounded-full flex items-center justify-center">
              <Building className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#003478]">Ford Yude Canahuati</h1>
              <p className="text-gray-600">Portal Cautivo</p>
            </div>
          </div>
        </motion.div>

        {/* Tarjeta principal del contacto */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <FordCard className="overflow-hidden">
            <div className="relative">
              {/* Fondo decorativo */}
              <div className="absolute inset-0 bg-gradient-to-r from-[#003478] to-[#2A6BAC] opacity-10" />
              
              <div className="relative p-8">
                {/* Avatar y información principal */}
                <div className="flex flex-col items-center text-center mb-8">
                  <div className="relative mb-4">
                    {vcard.photo ? (
                      <Image
                        src={vcard.photo}
                        alt={vcard.advisorName}
                        width={120}
                        height={120}
                        className="rounded-full object-cover border-4 border-white shadow-lg"
                      />
                    ) : (
                      <Avatar className="w-30 h-30 border-4 border-white shadow-lg">
                        <AvatarFallback className="bg-[#003478] text-white text-3xl">
                          {vcard.advisorName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                    )}
                    <div className="absolute -bottom-2 -right-2 bg-green-500 w-8 h-8 rounded-full border-4 border-white flex items-center justify-center">
                      <div className="w-3 h-3 bg-white rounded-full" />
                    </div>
                  </div>

                  <h2 className="text-3xl font-bold text-gray-800 mb-2">
                    {vcard.advisorName}
                  </h2>
                  <p className="text-xl text-[#003478] font-semibold mb-1">
                    {vcard.position || 'Asesor de Servicio'}
                  </p>
                  <p className="text-lg text-gray-600 mb-6">
                    {vcard.company}
                  </p>

                  {/* Botones de acción principales */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-md">
                    {vcard.phone && (
                      <FordButton
                        onClick={handleCall}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Phone className="w-4 h-4 mr-2" />
                        Llamar
                      </FordButton>
                    )}
                    
                    <FordButton
                      onClick={handleEmail}
                      variant="outline"
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      Email
                    </FordButton>
                  </div>
                </div>

                {/* Información de contacto detallada */}
                <div className="space-y-4 mb-8">
                  <div className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg">
                    <Mail className="w-5 h-5 text-[#003478]" />
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold text-gray-800">{vcard.email}</p>
                    </div>
                  </div>

                  {vcard.phone && (
                    <div className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg">
                      <Phone className="w-5 h-5 text-[#003478]" />
                      <div>
                        <p className="text-sm text-gray-600">Teléfono</p>
                        <p className="font-semibold text-gray-800">{vcard.phone}</p>
                      </div>
                    </div>
                  )}

                  {vcard.address && (
                    <div className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg">
                      <MapPin className="w-5 h-5 text-[#003478]" />
                      <div>
                        <p className="text-sm text-gray-600">Dirección</p>
                        <p className="font-semibold text-gray-800">{vcard.address}</p>
                      </div>
                    </div>
                  )}

                  {vcard.website && (
                    <div className="flex items-center space-x-3 p-3 bg-white/50 rounded-lg">
                      <Globe className="w-5 h-5 text-[#003478]" />
                      <div>
                        <p className="text-sm text-gray-600">Sitio Web</p>
                        <a
                          href={vcard.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-semibold text-[#003478] hover:underline"
                        >
                          {vcard.website}
                        </a>
                      </div>
                    </div>
                  )}
                </div>

                {/* Acciones adicionales */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <FordButton
                    onClick={handleDownloadVCard}
                    disabled={downloading}
                    className="flex-1"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    {downloading ? 'Descargando...' : 'Descargar Contacto'}
                  </FordButton>
                  
                  <FordButton
                    onClick={handleShare}
                    variant="outline"
                    className="flex-1"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartir
                  </FordButton>
                </div>

                {/* Estadísticas */}
                <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                  <div className="flex items-center justify-center space-x-6 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Download className="w-4 h-4" />
                      <span>{vcard.downloadCount} descargas</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>Actualizado {new Date(vcard.updatedAt).toLocaleDateString('es-HN')}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </FordCard>
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-center mt-8 text-gray-500 text-sm"
        >
          <p>© 2025 Ford Yude Canahuati - Todos los derechos reservados</p>
          <p className="mt-1">San Pedro Sula, Honduras</p>
        </motion.div>
      </div>
    </div>
  );
}
