

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const THEME_IMAGES = {
  mother: 'https://cdn.abacus.ai/images/da9ded75-eefc-4c87-9115-98e4ed6bab45.png',
  woman: 'https://cdn.abacus.ai/images/15c4cd22-d7d5-4fc4-a82e-65223cf077a8.png',
  man: 'https://cdn.abacus.ai/images/19d7d3e3-85ec-4108-8350-cf23c5c08f6b.png',
  independence: 'https://cdn.abacus.ai/images/5b4c5f66-6be1-4ec3-845a-8e44df264f41.png',
  xmas: 'https://cdn.abacus.ai/images/3b580114-962f-445a-aa31-3f439293b740.png',
  summer: 'https://cdn.abacus.ai/images/8d98d8fa-ed3d-4223-af0c-6e390633dc9f.png'
};

const THEME_MESSAGES = {
  mother: '¡Feliz Día de las Madres! Disfruta tu conexión gratuita',
  woman: 'Celebramos a la mujer empoderada. ¡Conéctate gratis!',
  man: '¡Feliz Día del Hombre! Tu conexión está lista',
  independence: '¡Viva Honduras! Conéctate y celebra con nosotros',
  xmas: '¡Feliz Navidad! El mejor regalo es estar conectado',
  summer: '¡Disfruta el verano conectado! WiFi gratuito para ti'
};

const THEME_COLORS = {
  mother: {
    primary: '#E91E63',
    secondary: '#FCE4EC',
    accent: '#AD1457'
  },
  woman: {
    primary: '#9C27B0',
    secondary: '#F3E5F5',
    accent: '#7B1FA2'
  },
  man: {
    primary: '#1565C0',
    secondary: '#E3F2FD',
    accent: '#0D47A1'
  },
  independence: {
    primary: '#1976D2',
    secondary: '#FFFFFF',
    accent: '#1565C0'
  },
  xmas: {
    primary: '#C62828',
    secondary: '#FFEBEE',
    accent: '#2E7D32'
  },
  summer: {
    primary: '#FF9800',
    secondary: '#FFF3E0',
    accent: '#F57C00'
  }
};

async function updateThemes() {
  console.log('🎨 Actualizando temas con imágenes y configuraciones...');
  
  try {
    // Obtener temas existentes
    const themes = await prisma.theme.findMany();
    console.log(`📋 Encontrados ${themes.length} temas existentes`);
    
    for (const theme of themes) {
      const themeKey = theme.name as keyof typeof THEME_IMAGES;
      
      if (THEME_IMAGES[themeKey]) {
        console.log(`🔄 Actualizando tema: ${theme.displayName}`);
        
        const colors = THEME_COLORS[themeKey] || {
          primary: '#003478',
          secondary: '#FFFFFF',
          accent: '#0056b3'
        };
        
        const metadata = {
          welcomeMessage: THEME_MESSAGES[themeKey] || 'Bienvenido a Ford WiFi',
          seasonalDates: getSeasonalDates(themeKey),
          rssCategory: getRssCategory(themeKey),
          promotionType: getPromotionType(themeKey)
        };
        
        await prisma.theme.update({
          where: { id: theme.id },
          data: {
            backgroundImage: THEME_IMAGES[themeKey],
            primaryColor: colors.primary,
            secondaryColor: colors.secondary,
            accentColor: colors.accent,
            metadata: metadata,
            ...getDateRanges(themeKey)
          }
        });
        
        console.log(`✅ Tema ${theme.displayName} actualizado correctamente`);
      }
    }
    
    console.log('🎉 Todos los temas actualizados exitosamente!');
    
  } catch (error) {
    console.error('❌ Error actualizando temas:', error);
  } finally {
    await prisma.$disconnect();
  }
}

function getSeasonalDates(themeKey: string) {
  const currentYear = new Date().getFullYear();
  
  switch (themeKey) {
    case 'mother':
      return {
        startMonth: 5, // Mayo
        startDay: 1,
        endMonth: 5,
        endDay: 15
      };
    case 'woman':
      return {
        startMonth: 3, // Marzo
        startDay: 1,
        endMonth: 3,
        endDay: 15
      };
    case 'man':
      return {
        startMonth: 6, // Junio
        startDay: 15,
        endMonth: 6,
        endDay: 25
      };
    case 'independence':
      return {
        startMonth: 9, // Septiembre
        startDay: 10,
        endMonth: 9,
        endDay: 20
      };
    case 'xmas':
      return {
        startMonth: 12, // Diciembre
        startDay: 1,
        endMonth: 12,
        endDay: 31
      };
    case 'summer':
      return {
        startMonth: 6, // Junio
        startDay: 1,
        endMonth: 8,
        endDay: 31
      };
    default:
      return null;
  }
}

function getDateRanges(themeKey: string) {
  const dates = getSeasonalDates(themeKey);
  if (!dates) return {};
  
  const currentYear = new Date().getFullYear();
  
  return {
    startDate: new Date(currentYear, dates.startMonth - 1, dates.startDay),
    endDate: new Date(currentYear, dates.endMonth - 1, dates.endDay)
  };
}

function getRssCategory(themeKey: string) {
  switch (themeKey) {
    case 'mother':
    case 'woman':
      return 'family';
    case 'man':
      return 'sports';
    case 'independence':
      return 'honduras';
    case 'xmas':
      return 'holidays';
    case 'summer':
      return 'travel';
    default:
      return 'general';
  }
}

function getPromotionType(themeKey: string) {
  switch (themeKey) {
    case 'mother':
      return 'mothers_day';
    case 'woman':
      return 'womens_day';
    case 'man':
      return 'mens_day';
    case 'independence':
      return 'patriotic';
    case 'xmas':
      return 'christmas';
    case 'summer':
      return 'summer_deals';
    default:
      return 'general';
  }
}

// Ejecutar el script
updateThemes();
