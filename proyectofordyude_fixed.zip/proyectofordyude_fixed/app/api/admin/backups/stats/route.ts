
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * Obtener estadísticas de backups
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const [totalBackups, successfulBackups, failedBackups, totalSizeResult, lastBackup] = await Promise.all([
      prisma.backup.count(),
      prisma.backup.count({ where: { status: 'COMPLETED' } }),
      prisma.backup.count({ where: { status: 'FAILED' } }),
      prisma.backup.aggregate({
        _sum: { fileSize: true },
        where: { status: 'COMPLETED' }
      }),
      prisma.backup.findFirst({
        where: { status: 'COMPLETED' },
        orderBy: { completedAt: 'desc' },
        select: { completedAt: true }
      })
    ]);

    const totalSize = totalSizeResult._sum.fileSize || BigInt(0);

    return NextResponse.json({
      totalBackups,
      successfulBackups,
      failedBackups,
      totalSize: totalSize.toString(),
      lastBackup: lastBackup?.completedAt?.toISOString() || null
    });
  } catch (error) {
    console.error('Error al obtener estadísticas de backups:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
