

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { 
  Wifi, 
  Car, 
  Wrench, 
  Clock, 
  MapPin, 
  Phone, 
  Mail,
  Globe,
  Zap,
  Truck,
  Building
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Header } from '@/components/layout/header';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { fordAssets } from '@/lib/ford-assets';
import { toast } from 'sonner';

interface PortalService {
  name: string;
  icon: any;
}

interface PortalContact {
  phone: string;
  email: string;
  aaddress: string;
}

interface PortalConfig {
  name: string;
  subtitle: string;
  primaryColor: string;
  secondaryColor: string;
  logo: string;
  icon: any;
  welcomeMessage?: string;
  services?: PortalService[];
  contact?: PortalContact;
}

interface PortalClientProps {
  portalToken: any;
  theme?: any;
  searchParams: {
    theme?: string;
    colors?: string;
  };
}

/**
 * Cliente del portal cautivo con soporte para múltiples tipos de portales
 * Maneja diferentes marcas: Ford, QuickLane Truck, QuickLane Tegus, QuickLane SPS
 */
export function PortalClient({ portalToken, theme, searchParams }: PortalClientProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [userInfo, setUserInfo] = useState({
    name: '',
    email: '',
    phone: '',
    acceptTerms: false
  });

  // Array de imágenes para el carrusel
  const carouselImages = [
    {
      url: 'https://designcollaborative.com/wp-content/uploads/2021/11/Schmidt_Ford-Dealership_1.jpg',
      title: 'Showroom Ford Moderno',
      description: 'Experiencia de concesionario de clase mundial'
    },
    {
      url: 'https://www.ehaf.com/storage/app/projects_gallery/full_size/ford-showroom-qatar3.jpg',
      title: 'Instalaciones Elegantes',
      description: 'Diseño contemporáneo y atención personalizada'
    },
    {
      url: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
      title: 'Ford F-150 2025',
      description: 'La pickup más vendida de América'
    },
    {
      url: 'https://vehicle-images.dealerinspire.com/stock-images/ford/39cad4a9d232ab0d0238f6978baae254.png',
      title: 'Ford Explorer 2025',
      description: 'SUV familiar con tecnología avanzada'
    },
    {
      url: 'https://i.pinimg.com/originals/bd/73/7b/bd737ba02050aa1b08a6901addd69883.jpg',
      title: 'Ford Mustang',
      description: 'Potencia e innovación americanas'
    },
    {
      url: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
      title: 'Servicio QuickLane',
      description: 'Mantenimiento express sin cita previa'
    },
    {
      url: 'https://www.baltana.com/files/cars-1/Ford-Logo-Wallpaper-1920x1080-68942.jpg',
      title: 'Ford Yude Canahuati',
      description: 'Tu concesionario Ford de confianza'
    }
  ];

  // Configuración específica por tipo de portal
  const portalConfigs: Record<string, PortalConfig> = {
    ford: {
      name: 'Ford Yude Canahuati',
      subtitle: 'Portal Cautivo Oficial',
      primaryColor: '#003478',
      secondaryColor: '#47A8E5',
      logo: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      icon: Car,
      welcomeMessage: 'Bienvenido al portal de Ford Yude Canahuati. Conéctate a nuestra red WiFi gratuita.',
      services: [
        { name: 'Venta de Vehículos', icon: Car },
        { name: 'Servicio Técnico', icon: Wrench },
        { name: 'Repuestos Originales', icon: Building }
      ],
      contact: {
        phone: '+504 2234-5678',
        email: 'info@fordyude.com',
        aaddress: 'Honduras'
      }
    },
    'ford-general': {
      name: 'Ford Yude Canahuati',
      subtitle: 'Portal Cautivo Oficial',
      primaryColor: '#003478',
      secondaryColor: '#47A8E5',
      logo: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      icon: Car,
      welcomeMessage: 'Bienvenido al portal de Ford Yude Canahuati. Conéctate a nuestra red WiFi gratuita.',
      services: [
        { name: 'Venta de Vehículos', icon: Car },
        { name: 'Servicio Técnico', icon: Wrench },
        { name: 'Repuestos Originales', icon: Building }
      ],
      contact: {
        phone: '+504 2234-5678',
        email: 'info@fordyude.com',
        aaddress: 'Honduras'
      }
    },
    quicklane: {
      name: 'QuickLane',
      subtitle: 'Servicio Express',
      primaryColor: '#FF6600',
      secondaryColor: '#FFFFFF',
      logo: 'https://imgs.search.brave.com/4Mi7tqhF-bLL5KiUTAcaDLTUCJFtLF9zLy2Q8GZlOEc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMtcGxhdGZvcm0u/OTlzdGF0aWMuY29t/Ly95X1JQZ0JUeGNN/LWpnTUNaVHVnM3V3/eXhoVlU9LzEyN3gx/NDY6MTkwMngxOTIx/L2ZpdC1pbi81MDB4/NTAwL3Byb2plY3Rz/LWZpbGVzLzExOC8x/MTg0OS8xMTg0OTk5/LzVlZWVkM2YxLTEz/MzAtNGE0ZC04ZmY3/LTk3NDEyMTY5ZDBm/ZS5qcGc',
      icon: Wrench,
      welcomeMessage: 'Bienvenido a QuickLane. Servicio rápido sin cita previa.',
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Servicio Rápido', icon: Clock }
      ],
      contact: {
        phone: '+504 2550-5050',
        email: 'info@quicklane.hn',
        aaddress: 'Honduras'
      }
    },
    'quicklane-general': {
      name: 'QuickLane',
      subtitle: 'Servicio Express',
      primaryColor: '#FF6600',
      secondaryColor: '#FFFFFF',
      logo: 'https://imgs.search.brave.com/4Mi7tqhF-bLL5KiUTAcaDLTUCJFtLF9zLy2Q8GZlOEc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMtcGxhdGZvcm0u/OTlzdGF0aWMuY29t/Ly95X1JQZ0JUeGNN/LWpnTUNaVHVnM3V3/eXhoVlU9LzEyN3gx/NDY6MTkwMngxOTIx/L2ZpdC1pbi81MDB4/NTAwL3Byb2plY3Rz/LWZpbGVzLzExOC8x/MTg0OS8xMTg0OTk5/LzVlZWVkM2YxLTEz/MzAtNGE0ZC04ZmY3/LTk3NDEyMTY5ZDBm/ZS5qcGc',
      icon: Wrench,
      welcomeMessage: 'Bienvenido a QuickLane. Servicio express sin cita previa.',
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Servicio Rápido', icon: Clock }
      ],
      contact: {
        phone: '+504 2550-5050',
        email: 'info@quicklane.hn',
        aaddress: 'Honduras'
      }
    },
    'quicklane-truck': {
      name: 'QuickLane Truck Services',
      subtitle: 'Especialistas en Camiones',
      primaryColor: '#FF6600',
      secondaryColor: '#000000',
      logo: 'https://imgs.search.brave.com/7QaKj31zUBT8S5ThS54rU-cf-eDu_yONOxb7uHW-itA/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pLnBp/bmltZy5jb20vb3Jp/Z2luYWxzL2Q2Lzc4/LzRjL2Q2Nzg0Y2M0/MGQ3NmFhM2Q1Y2Jl/MGUwOGE2ZmUxNzUw/LmpwZw',
      icon: Truck,
      welcomeMessage: 'Bienvenido a QuickLane Truck. Servicio especializado para vehículos comerciales.',
      services: [
        { name: 'Mantenimiento de Camiones', icon: Truck },
        { name: 'Servicio Express', icon: Zap },
        { name: 'Diagnóstico Especializado', icon: Wrench }
      ],
      contact: {
        phone: '+504 2550-5055',
        email: 'truck@quicklane.hn',
        aaddress: 'QuickLane Truck - Honduras'
      }
    },
    'quicklane-tegus': {
      name: 'QuickLane Tegucigalpa',
      subtitle: 'Servicio Express en la Capital',
      primaryColor: '#FF6600',
      secondaryColor: '#FFFFFF',
      logo: 'https://imgs.search.brave.com/OiTSrylhrJnBouZlc3g35qin3X_no-imHFdqHIo6l8Q/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9kMXlq/am5weDBwNTNzOC5j/bG91ZGZyb250Lm5l/dC9zdHlsZXMvbG9n/by10aHVtYm5haWwv/czMvMDAxNi82NjI5/L2JyYW5kLmdpZj9p/dG9rPWp0RE5JblBJ.jpeg',
      icon: Building,
      welcomeMessage: 'Bienvenido a QuickLane Tegucigalpa. Servicio express en la capital.',
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Servicio Técnico', icon: Building }
      ],
      contact: {
        phone: '+504 2550-5050',
        email: 'tegus@quicklane.hn',
        aaddress: 'Tegucigalpa, Honduras'
      }
    },
    'quicklane-sps': {
      name: 'QuickLane San Pedro Sula',
      subtitle: 'Servicio Express en la Zona Norte',
      primaryColor: '#FF6600',
      secondaryColor: '#FFFFFF',
      logo: 'https://imgs.search.brave.com/4yqyuh914gIEj3HqhDumD-OJpoudC-E6GJKdyefyZEc/rs:fit:0:180:1:0/g:ce/aHR0cHM6Ly9iYW5u/ZXIyLmNsZWFucG5n/LmNvbS8yMDE4MDQx/OS9vb3EvYXZmNnM1/djQ4LndlYnA',
      icon: Building,
      welcomeMessage: 'Bienvenido a QuickLane San Pedro Sula. Servicio express en la zona norte.',
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Servicio Técnico', icon: Building }
      ],
      contact: {
        phone: '+504 2550-5050',
        email: 'sps@quicklane.hn',
        aaddress: 'San Pedro Sula, Honduras'
      }
    },
    'quicklane-tegucigalpa': {
      name: 'QuickLane Tegucigalpa',
      subtitle: 'Servicio Express en la Capital',
      primaryColor: '#FF6600',
      secondaryColor: '#FFFFFF',
      logo: 'https://imgs.search.brave.com/AIL3Alxsh64UqJT4frAUpF-DVxWjwrtWMJdS5RX2p-4/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9kMXlq/am5weDBwNTNzOC5j/bG91ZGZyb250Lm5l/dC9zdHlsZXMvbG9n/by10aHVtYm5haWwv/czMvMDAxMS80NjYy/L2JyYW5kLmdpZj9p/dG9rPU9jb2JGbkxE.jpeg',
      icon: Building,
      services: [
        { name: 'Venta de Vehículos', icon: Car },
        { name: 'Servicio Técnico', icon: Wrench },
        { name: 'Repuestos Originales', icon: Building }
      ],
      welcomeMessage: 'Bienvenido al portal de Ford Yude Canahuati. Conéctate a nuestra red WiFi gratuita y descubre nuestros servicios.',
      contact: {
        phone: '+504 2550-5050',
        email: 'info@yudecanahuati.com',
        aaddress: 'San Pedro Sula, Honduras'
      }
    },
    quicklane_truck: {
      name: 'QuickLane Truck',
      subtitle: 'Servicio Express para Camiones',
      primaryColor: '#FF6B35',
      secondaryColor: '#FFA726',
      logo: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      icon: Truck,
      services: [
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Servicio de Camiones', icon: Truck },
        { name: 'Diagnóstico Rápido', icon: Wrench }
      ],
      welcomeMessage: 'Bienvenido a QuickLane Truck. Servicio especializado y rápido para tu vehículo comercial.',
      contact: {
        phone: '+504 2550-5055',
        email: 'truck@quicklane.hn',
        aaddress: 'QuickLane Truck - San Pedro Sula'
      }
    },
    quicklane_tegus: {
      name: 'QuickLane Tegucigalpa',
      subtitle: 'Servicio Express',
      primaryColor: '#4ECDC4',
      secondaryColor: '#80E0D8',
      logo: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      icon: Zap,
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Revisión Técnica', icon: Building }
      ],
      welcomeMessage: 'Bienvenido a QuickLane Tegucigalpa. Servicio rápido y confiable sin cita previa.',
      contact: {
        phone: '+504 2550-5060',
        email: 'tegus@quicklane.hn',
        aaddress: 'QuickLane Tegucigalpa'
      }
    },
    quicklane_sps: {
      name: 'QuickLane San Pedro Sula',
      subtitle: 'Servicio Express',
      primaryColor: '#45B7D1',
      secondaryColor: '#7BC4E8',
      logo: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      icon: Zap,
      services: [
        { name: 'Cambio de Aceite', icon: Wrench },
        { name: 'Mantenimiento Express', icon: Zap },
        { name: 'Llantas y Balanceo', icon: Car }
      ],
      welcomeMessage: 'Bienvenido a QuickLane San Pedro Sula. Tu Ford merece el mejor cuidado express.',
      contact: {
        phone: '+504 2550-5065',
        email: 'sps@quicklane.hn',
        aaddress: 'QuickLane San Pedro Sula'
      }
    }
  };

  const config = portalConfigs[portalToken.portalType as keyof typeof portalConfigs] || portalConfigs.ford;

  // Aplicar tema personalizado si existe
  const [currentTheme, setCurrentTheme] = useState({
    primaryColor: config.primaryColor,
    secondaryColor: config.secondaryColor,
    backgroundImage: '',
    ...theme
  });

  // Tema especial de aniversario de Yude
  const isAnniversaryTheme = theme?.name === 'yude-anniversary';
  const anniversaryStyles = isAnniversaryTheme ? {
    backgroundGradient: 'linear-gradient(135deg, #DAA520 0%, #B8860B 50%, #FFD700 100%)',
    sparkleAnimation: true,
    festiveColors: ['#DAA520', '#FFD700', '#B8860B'],
    specialGreeting: 'Celebrando años de excelencia automotriz'
  } : null;

  useEffect(() => {
    // Aplicar colores personalizados desde searchParams si existen
    if (searchParams.colors) {
      try {
        const colors = JSON.parse(decodeURIComponent(searchParams.colors));
        setCurrentTheme((prev: any) => ({
          ...prev,
          ...colors
        }));
      } catch (error) {
        console.error('Error parsing colors:', error);
      }
    }
  }, [searchParams]);

  // useEffect para rotación automática del carrusel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === carouselImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000); // Cambiar imagen cada 5 segundos

    return () => clearInterval(interval);
  }, [carouselImages.length]);

  /**
   * Maneja la conexión a WiFi
   */
  const handleConnect = async () => {
    if (!userInfo.name || !userInfo.email || !userInfo.acceptTerms) {
      toast.error('Por favor completa todos los campos obligatorios');
      return;
    }

    setIsConnecting(true);
    
    try {
      // Simular proceso de conexión
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Registrar usuario conectado
      const response = await fetch('/api/captive/connect', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...userInfo,
          portalToken: portalToken.token,
          portalType: portalToken.portalType,
          deviceId: navigator.userAgent,
          userAgent: navigator.userAgent
        }),
      });

      if (response.ok) {
        toast.success('¡Solicitud procesada exitosamente!', {
          duration: 3000
        });
        
        // Guardar información del usuario en localStorage
        localStorage.setItem('connectedUser', JSON.stringify({
          name: userInfo.name,
          email: userInfo.email,
          phone: userInfo.phone
        }));
        
        // Guardar portal usado
        localStorage.setItem('lastPortal', portalToken.portalType);
        
        // Redirigir a página de "Acceso Garantizado" con parámetros
        setTimeout(() => {
          window.location.href = `/portal/access-granted?portal=${portalToken.portalType}&user=${encodeURIComponent(userInfo.name)}`;
        }, 1500);
      } else {
        throw new Error('Error en la conexión');
      }
    } catch (error) {
      toast.error('Error al conectar. Por favor intenta nuevamente.');
    } finally {
      setIsConnecting(false);
    }
  };

  /**
   * Maneja cambios en el formulario
   */
  const handleInputChange = (field: string, value: string | boolean) => {
    setUserInfo(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const IconComponent = config.icon;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Carrusel de fondo */}
      <div className="absolute inset-0">
        {carouselImages.map((image, index) => (
          <motion.div
            key={index}
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: index === currentImageIndex ? 1 : 0,
              scale: index === currentImageIndex ? 1.05 : 1
            }}
            transition={{ duration: 1, ease: "easeInOut" }}
            style={{
              background: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.3)), url(${image.url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat'
            }}
          />
        ))}
        
        {/* Overlay de color del tema */}
        <div 
          className="absolute inset-0"
          style={{
            background: `linear-gradient(135deg, ${currentTheme.primaryColor}10, ${currentTheme.secondaryColor}10)`
          }}
        />
      </div>

      {/* Contenido del portal */}
      <div className="relative z-10 min-h-screen">
      {/* Header personalizado */}
      <Header variant="public" theme={portalToken.portalType} />

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Logo y bienvenida principal */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center mb-6">
            <Image
              src={config.logo}
              alt={`${config.name} Logo`}
              width={120}
              height={120}
              className="object-contain filter drop-shadow-lg"
            />
          </div>
          
          <h1 className="text-4xl font-bold mb-2" style={{ color: currentTheme.primaryColor }}>
            {config.name}
          </h1>
          <p className="text-xl text-gray-600 mb-4">
            {config.subtitle}
          </p>
          <div className="flex items-center justify-center space-x-2 text-gray-600">
            <Wifi className="w-5 h-5" />
            <span>WiFi Gratuito Disponible</span>
          </div>
        </motion.div>

        {/* Grid principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulario de conexión */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <FordCard className="p-8">
                <div className="flex items-center mb-6">
                  <IconComponent 
                    className="w-8 h-8 mr-3" 
                    style={{ color: currentTheme.primaryColor }} 
                  />
                  <h2 className="text-2xl font-bold text-gray-800">
                    Conectarse a WiFi
                  </h2>
                </div>

                <p className="text-gray-600 mb-6">
                  {config.welcomeMessage || "Bienvenido al portal"}
                </p>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre Completo *</Label>
                      <Input
                        id="name"
                        value={userInfo.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Tu nombre completo"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={userInfo.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="tu@email.com"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono (opcional)</Label>
                    <Input
                      id="phone"
                      value={userInfo.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="+504 0000-0000"
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="acceptTerms"
                      checked={userInfo.acceptTerms}
                      onCheckedChange={(checked) => handleInputChange('acceptTerms', checked as boolean)}
                    />
                    <Label htmlFor="acceptTerms" className="text-sm">
                      Acepto los términos de uso y política de privacidad *
                    </Label>
                  </div>

                  <FordButton
                    onClick={handleConnect}
                    disabled={isConnecting || !userInfo.name || !userInfo.email || !userInfo.acceptTerms}
                    className="w-full py-3 text-lg"
                    style={{ backgroundColor: currentTheme.primaryColor }}
                  >
                    {isConnecting ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                        Conectando...
                      </>
                    ) : (
                      <>
                        <Wifi className="w-5 h-5 mr-2" />
                        Conectar a WiFi Gratuito
                      </>
                    )}
                  </FordButton>
                </div>
              </FordCard>
            </motion.div>
          </div>

          {/* Panel lateral con información */}
          <div className="space-y-6">
            {/* Servicios */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <FordCard className="p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  Nuestros Servicios
                </h3>
                <div className="space-y-3">
                  {config.services?.map((service, index) => {
                    const ServiceIcon = service.icon;
                    return (
                      <div key={index} className="flex items-center space-x-3">
                        <ServiceIcon 
                          className="w-5 h-5" 
                          style={{ color: currentTheme.primaryColor }} 
                        />
                        <span className="text-gray-700">{service.name}</span>
                      </div>
                    );
                  })}
                </div>
              </FordCard>
            </motion.div>

            {/* Información de contacto */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <FordCard className="p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  Contacto
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">{config.contact?.phone}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">{config.contact?.email}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-red-600" />
                    <span className="text-gray-700">{config.contact?.aaddress}</span>
                  </div>
                </div>
              </FordCard>
            </motion.div>

            {/* Horarios */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
            >
              <FordCard className="p-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4">
                  <Clock className="w-5 h-5 inline mr-2" />
                  Horarios de Atención
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Lun - Vie:</span>
                    <span className="text-gray-800 font-medium">8:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Sábado:</span>
                    <span className="text-gray-800 font-medium">8:00 AM - 4:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Domingo:</span>
                    <span className="text-gray-800 font-medium">Cerrado</span>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          </div>
        </div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-center mt-12 pt-8 border-t border-gray-200"
        >
          <p className="text-gray-600 text-sm">
            © 2025 Ford Yude Canahuati. Todos los derechos reservados.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Portal desarrollado por Luis Manuel Fajardo Rivera
          </p>
        </motion.div>
      </div>
      </div>
    </div>
  );
}
