

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * PUT /api/admin/themes/[id]
 * Actualiza un tema existente
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { 
      displayName,
      description,
      primaryColor, 
      secondaryColor, 
      accentColor,
      backgroundImage,
      logoImage,
      customCss,
      customJs,
      isActive,
      startDate,
      endDate,
      metadata
    } = body;

    // Verificar que el tema existe
    const existingTheme = await prisma.theme.findUnique({
      where: { id: params.id }
    });

    if (!existingTheme) {
      return NextResponse.json({ error: 'Tema no encontrado' }, { status: 404 });
    }

    // Actualizar el tema
    const updatedTheme = await prisma.theme.update({
      where: { id: params.id },
      data: {
        displayName: displayName || existingTheme.displayName,
        description: description !== undefined ? description : existingTheme.description,
        primaryColor: primaryColor || existingTheme.primaryColor,
        secondaryColor: secondaryColor || existingTheme.secondaryColor,
        accentColor: accentColor !== undefined ? accentColor : existingTheme.accentColor,
        backgroundImage: backgroundImage !== undefined ? backgroundImage : existingTheme.backgroundImage,
        logoImage: logoImage !== undefined ? logoImage : existingTheme.logoImage,
        customCss: customCss !== undefined ? customCss : existingTheme.customCss,
        customJs: customJs !== undefined ? customJs : existingTheme.customJs,
        isActive: isActive !== undefined ? isActive : existingTheme.isActive,
        startDate: startDate !== undefined ? (startDate ? new Date(startDate) : null) : existingTheme.startDate,
        endDate: endDate !== undefined ? (endDate ? new Date(endDate) : null) : existingTheme.endDate,
        metadata: metadata !== undefined ? metadata : existingTheme.metadata,
        updatedAt: new Date()
      },
      include: {
        config: true
      }
    });

    return NextResponse.json(updatedTheme);
  } catch (error) {
    console.error('Error al actualizar tema:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/themes/[id]
 * Elimina un tema (solo si no es el tema por defecto)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Verificar que el tema existe y no es el tema por defecto
    const existingTheme = await prisma.theme.findUnique({
      where: { id: params.id }
    });

    if (!existingTheme) {
      return NextResponse.json({ error: 'Tema no encontrado' }, { status: 404 });
    }

    if (existingTheme.name === 'default') {
      return NextResponse.json({ error: 'No se puede eliminar el tema por defecto' }, { status: 400 });
    }

    // Eliminar el tema
    await prisma.theme.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar tema:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * GET /api/admin/themes/[id]
 * Obtiene un tema específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const theme = await prisma.theme.findUnique({
      where: { id: params.id },
      include: {
        config: true
      }
    });

    if (!theme) {
      return NextResponse.json({ error: 'Tema no encontrado' }, { status: 404 });
    }

    return NextResponse.json(theme);
  } catch (error) {
    console.error('Error al obtener tema:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
