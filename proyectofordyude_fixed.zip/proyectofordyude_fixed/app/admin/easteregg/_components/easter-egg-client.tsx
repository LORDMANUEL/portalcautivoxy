

'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Gamepad2,
  Trophy,
  Star,
  Heart,
  Zap,
  Crown,
  Gift,
  Sparkles,
  Rocket,
  Music,
  Coffee,
  Pizza
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { toast } from 'sonner';
import Image from 'next/image';

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: any;
  unlocked: boolean;
  unlockedAt?: Date;
}

/**
 * Easter Egg especial para administradores
 * Incluye mini-juegos, logros y funcionalidades divertidas
 */
export function EasterEggClient() {
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [gameActive, setGameActive] = useState(false);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [showConfetti, setShowConfetti] = useState(false);
  const [clickCount, setClickCount] = useState(0);
  const [secretUnlocked, setSecretUnlocked] = useState(false);
  const [konami, setKonami] = useState('');
  const gameRef = useRef<HTMLDivElement>(null);

  // Secuencia Konami Code
  const konamiCode = 'ArrowUpArrowUpArrowDownArrowDownArrowLeftArrowRightArrowLeftArrowRightKeyBKeyA';

  useEffect(() => {
    initializeAchievements();
    
    // Event listener para Konami Code
    const handleKeyPress = (e: KeyboardEvent) => {
      const newKonami = konami + e.code;
      setKonami(newKonami);
      
      if (konamiCode.startsWith(newKonami)) {
        if (newKonami === konamiCode) {
          unlockSecret();
          setKonami('');
        }
      } else {
        setKonami('');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [konami]);

  /**
   * Inicializa los logros disponibles
   */
  const initializeAchievements = () => {
    const defaultAchievements: Achievement[] = [
      {
        id: 'first_click',
        name: 'Primer Clic',
        description: 'Has hecho tu primer clic en el Easter Egg',
        icon: Star,
        unlocked: false
      },
      {
        id: 'click_master',
        name: 'Maestro del Clic',
        description: 'Has hecho 100 clics',
        icon: Trophy,
        unlocked: false
      },
      {
        id: 'speed_demon',
        name: 'Demonio de la Velocidad',
        description: 'Haz 10 clics en 3 segundos',
        icon: Zap,
        unlocked: false
      },
      {
        id: 'konami_master',
        name: 'Maestro Konami',
        description: 'Has ingresado el código secreto Konami',
        icon: Crown,
        unlocked: false
      },
      {
        id: 'ford_legend',
        name: 'Leyenda Ford',
        description: 'Has demostrado tu lealtad a Ford',
        icon: Heart,
        unlocked: false
      }
    ];

    setAchievements(defaultAchievements);
  };

  /**
   * Maneja el clic en el Easter Egg
   */
  const handleEasterEggClick = () => {
    setClickCount(prev => prev + 1);
    setScore(prev => prev + 10);

    // Primer clic
    if (clickCount === 0) {
      unlockAchievement('first_click');
    }

    // 100 clics
    if (clickCount === 99) {
      unlockAchievement('click_master');
    }

    // Efecto de confetti cada 50 clics
    if ((clickCount + 1) % 50 === 0) {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);
    }

    // Subir de nivel cada 200 puntos
    if (score > 0 && (score + 10) % 200 === 0) {
      setLevel(prev => prev + 1);
      toast.success(`¡Nivel ${level + 1} alcanzado!`, {
        icon: '🎉'
      });
    }
  };

  /**
   * Desbloquea un logro
   */
  const unlockAchievement = (achievementId: string) => {
    setAchievements(prev => prev.map(achievement => 
      achievement.id === achievementId && !achievement.unlocked
        ? { ...achievement, unlocked: true, unlockedAt: new Date() }
        : achievement
    ));

    const achievement = achievements.find(a => a.id === achievementId);
    if (achievement && !achievement.unlocked) {
      toast.success(`¡Logro desbloqueado: ${achievement.name}!`, {
        icon: '🏆'
      });
    }
  };

  /**
   * Desbloquea el secreto especial
   */
  const unlockSecret = () => {
    setSecretUnlocked(true);
    unlockAchievement('konami_master');
    unlockAchievement('ford_legend');
    setShowConfetti(true);
    
    toast.success('¡Código Konami activado! 🎮', {
      description: 'Has desbloqueado el secreto especial de Ford',
      duration: 5000
    });

    setTimeout(() => setShowConfetti(false), 5000);
  };

  /**
   * Inicia el mini-juego
   */
  const startGame = () => {
    setGameActive(true);
    toast.info('¡Mini-juego iniciado! Haz clic lo más rápido posible', {
      icon: '🎮'
    });

    // Juego de 10 segundos
    setTimeout(() => {
      setGameActive(false);
      const finalScore = score;
      toast.success(`¡Juego terminado! Puntuación final: ${finalScore}`, {
        icon: '🏁'
      });
    }, 10000);
  };

  /**
   * Resetea las estadísticas
   */
  const resetStats = () => {
    if (confirm('¿Estás seguro de resetear todas las estadísticas?')) {
      setScore(0);
      setLevel(1);
      setClickCount(0);
      setSecretUnlocked(false);
      initializeAchievements();
      toast.info('Estadísticas reseteadas', {
        icon: '🔄'
      });
    }
  };

  return (
    <div className="space-y-6 relative">
      {/* Confetti Effect */}
      <AnimatePresence>
        {showConfetti && (
          <div className="fixed inset-0 pointer-events-none z-50">
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-3 h-3 bg-gradient-to-r from-yellow-400 to-red-500 rounded-full"
                initial={{
                  x: Math.random() * window.innerWidth,
                  y: -10,
                  rotate: 0,
                  scale: 0
                }}
                animate={{
                  y: window.innerHeight + 10,
                  rotate: 360,
                  scale: [0, 1, 0]
                }}
                transition={{
                  duration: 3,
                  delay: Math.random() * 2
                }}
              />
            ))}
          </div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-800 flex items-center justify-center gap-3 mb-2">
          <Gamepad2 className="w-10 h-10 text-[#003478]" />
          Ford Easter Egg
          <Sparkles className="w-8 h-8 text-yellow-500" />
        </h1>
        <p className="text-gray-600">
          ¡Funcionalidad especial solo para administradores Ford!
        </p>
        <p className="text-sm text-gray-500 mt-2">
          💡 Pista: Prueba el código Konami (↑↑↓↓←→←→BA)
        </p>
      </div>

      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <FordCard>
          <div className="p-4 text-center">
            <Zap className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Puntuación</p>
            <p className="text-2xl font-bold text-[#003478]">{score}</p>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4 text-center">
            <Crown className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Nivel</p>
            <p className="text-2xl font-bold text-[#003478]">{level}</p>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4 text-center">
            <Star className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Clics</p>
            <p className="text-2xl font-bold text-[#003478]">{clickCount}</p>
          </div>
        </FordCard>

        <FordCard>
          <div className="p-4 text-center">
            <Trophy className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <p className="text-sm text-gray-600">Logros</p>
            <p className="text-2xl font-bold text-[#003478]">
              {achievements.filter(a => a.unlocked).length}/{achievements.length}
            </p>
          </div>
        </FordCard>
      </div>

      {/* Easter Egg principal */}
      <div className="flex flex-col items-center space-y-6">
        <motion.div
          ref={gameRef}
          className="relative cursor-pointer"
          onClick={handleEasterEggClick}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          animate={gameActive ? { 
            scale: [1, 1.1, 1],
            boxShadow: ['0px 0px 0px rgba(0,52,120,0)', '0px 0px 30px rgba(0,52,120,0.5)', '0px 0px 0px rgba(0,52,120,0)']
          } : {}}
          transition={gameActive ? { repeat: Infinity, duration: 1 } : {}}
        >
          <FordCard className="p-8 bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-[#003478]">
            <div className="text-center">
              <div className="relative">
                <Image
                  src="https://www.freepnglogos.com/uploads/large-ford-logo-0.png"
                  alt="Ford Logo Easter Egg"
                  width={120}
                  height={120}
                  className="mx-auto mb-4 filter drop-shadow-lg"
                />
                {gameActive && (
                  <motion.div
                    className="absolute inset-0 border-4 border-yellow-400 rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                  />
                )}
              </div>
              <h3 className="text-xl font-bold text-[#003478] mb-2">
                ¡Haz clic en el logo Ford!
              </h3>
              <p className="text-gray-600">
                {gameActive ? '¡Juego activo! ¡Haz clic rápido!' : 'Cada clic suma 10 puntos'}
              </p>
            </div>
          </FordCard>
        </motion.div>

        {/* Controles del juego */}
        <div className="flex space-x-4">
          <FordButton
            onClick={startGame}
            disabled={gameActive}
            className="bg-green-600 hover:bg-green-700"
          >
            <Rocket className="w-4 h-4 mr-2" />
            {gameActive ? 'Juego Activo...' : 'Iniciar Mini-Juego'}
          </FordButton>

          <FordButton
            variant="outline"
            onClick={resetStats}
          >
            Resetear Stats
          </FordButton>
        </div>
      </div>

      {/* Secreto especial desbloqueado */}
      <AnimatePresence>
        {secretUnlocked && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="text-center"
          >
            <FordCard className="p-6 bg-gradient-to-r from-purple-100 to-pink-100 border-2 border-purple-400">
              <div className="space-y-4">
                <div className="flex items-center justify-center space-x-2">
                  <Crown className="w-8 h-8 text-purple-600" />
                  <h3 className="text-2xl font-bold text-purple-800">
                    ¡SECRETO DESBLOQUEADO!
                  </h3>
                  <Crown className="w-8 h-8 text-purple-600" />
                </div>
                
                <p className="text-purple-700 font-medium">
                  🎉 ¡Felicidades! Has encontrado el Easter Egg secreto de Ford Yude Canahuati
                </p>
                
                <div className="bg-white p-4 rounded-lg border border-purple-200">
                  <p className="text-gray-800 font-semibold mb-2">
                    Mensaje especial del desarrollador:
                  </p>
                  <p className="text-gray-700 italic">
                    "Este portal fue desarrollado con amor y dedicación para Ford Yude Canahuati. 
                    Gracias por ser parte de la familia Ford y por descubrir este pequeño secreto. 
                    ¡Que tengas un excelente día!"
                  </p>
                  <div className="flex items-center justify-center mt-4 space-x-2">
                    <Coffee className="w-5 h-5 text-brown-500" />
                    <span className="text-sm text-gray-600">
                      Desarrollado por Luis Manuel Fajardo Rivera
                    </span>
                    <Pizza className="w-5 h-5 text-orange-500" />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 mt-4">
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <Music className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                    <p className="text-xs text-purple-700">Música inspiradora</p>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <Heart className="w-6 h-6 text-red-500 mx-auto mb-1" />
                    <p className="text-xs text-purple-700">Desarrollado con amor</p>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <Gift className="w-6 h-6 text-green-600 mx-auto mb-1" />
                    <p className="text-xs text-purple-700">Un regalo para ti</p>
                  </div>
                </div>
              </div>
            </FordCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Panel de logros */}
      <FordCard>
        <div className="p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
            <Trophy className="w-6 h-6 text-yellow-500 mr-2" />
            Logros Desbloqueados
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement) => {
              const IconComponent = achievement.icon;
              
              return (
                <motion.div
                  key={achievement.id}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    achievement.unlocked
                      ? 'bg-green-50 border-green-200'
                      : 'bg-gray-50 border-gray-200 opacity-60'
                  }`}
                  whileHover={achievement.unlocked ? { scale: 1.02 } : {}}
                >
                  <div className="flex items-start space-x-3">
                    <IconComponent 
                      className={`w-6 h-6 ${
                        achievement.unlocked ? 'text-green-600' : 'text-gray-400'
                      }`} 
                    />
                    <div>
                      <h4 className={`font-semibold ${
                        achievement.unlocked ? 'text-green-800' : 'text-gray-600'
                      }`}>
                        {achievement.name}
                      </h4>
                      <p className={`text-sm ${
                        achievement.unlocked ? 'text-green-700' : 'text-gray-500'
                      }`}>
                        {achievement.description}
                      </p>
                      {achievement.unlocked && achievement.unlockedAt && (
                        <p className="text-xs text-green-600 mt-1">
                          Desbloqueado: {achievement.unlockedAt.toLocaleString()}
                        </p>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </FordCard>
    </div>
  );
}
