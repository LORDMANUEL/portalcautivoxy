
/**
 * Diálogo para Ver Detalles de vCard
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

'use client'

import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { 
  QrCode,
  User,
  Mail,
  Phone,
  Building,
  MapPin,
  Globe,
  Calendar,
  Download,
  FileText,
  Image,
  CheckCircle,
  XCircle,
  Eye,
  TrendingUp
} from 'lucide-react'

interface VCard {
  id: string
  advisorName: string
  position?: string
  email: string
  phone?: string
  company: string
  address?: string
  website?: string
  photo?: string
  qrCode?: string
  isActive: boolean
  downloadCount: number
  createdAt: string
  updatedAt: string
}

interface ViewVCardDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  vcard: VCard
  onClose: () => void
}

export default function ViewVCardDialog({
  open,
  onOpenChange,
  vcard,
  onClose
}: ViewVCardDialogProps) {
  const [downloading, setDownloading] = useState<'vcard' | 'qr' | null>(null)

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handleClose = () => {
    onClose()
    onOpenChange(false)
  }

  const handleDownload = async (type: 'vcard' | 'qr') => {
    try {
      setDownloading(type)
      
      const response = await fetch(`/api/admin/qr-generator/download/${vcard.id}?type=${type}`)
      
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        
        // Obtener nombre del archivo desde headers
        const contentDisposition = response.headers.get('content-disposition')
        const fileName = contentDisposition
          ? contentDisposition.split('filename=')[1]?.replace(/"/g, '')
          : `${type}_${vcard.advisorName.replace(/\s+/g, '_')}.${type === 'vcard' ? 'vcf' : 'png'}`
        
        a.download = fileName
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
        
        toast.success(`${type === 'vcard' ? 'vCard' : 'Código QR'} descargado exitosamente`)
      } else {
        toast.error('Error al descargar archivo')
      }
    } catch (error) {
      console.error('Error downloading file:', error)
      toast.error('Error al descargar archivo')
    } finally {
      setDownloading(null)
    }
  }

  const generateVCardString = (vcard: VCard) => {
    return [
      'BEGIN:VCARD',
      'VERSION:3.0',
      `FN:${vcard.advisorName}`,
      `EMAIL:${vcard.email}`,
      `TEL:${vcard.phone || ''}`,
      `ORG:${vcard.company}`,
      `TITLE:${vcard.position || ''}`,
      `ADR:;;${vcard.address || ''};;;`,
      `URL:${vcard.website || ''}`,
      'END:VCARD'
    ].join('\n')
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Detalles de vCard
          </DialogTitle>
          <DialogDescription>
            Información completa de la vCard y código QR
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Información de la vCard */}
          <div className="space-y-6">
            {/* Información Personal */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Información Personal
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="text-lg">
                      {getInitials(vcard.advisorName)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold">{vcard.advisorName}</h3>
                    {vcard.position && (
                      <p className="text-gray-600 mb-2">{vcard.position}</p>
                    )}
                    
                    <Badge
                      variant={vcard.isActive ? 'default' : 'secondary'}
                      className={
                        vcard.isActive
                          ? 'bg-green-100 text-green-800 border-green-200'
                          : 'bg-red-100 text-red-800 border-red-200'
                      }
                    >
                      {vcard.isActive ? (
                        <>
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Activa
                        </>
                      ) : (
                        <>
                          <XCircle className="h-3 w-3 mr-1" />
                          Inactiva
                        </>
                      )}
                    </Badge>
                  </div>
                </div>

                <Separator className="my-4" />

                <div className="space-y-3">
                  {/* Email */}
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm text-gray-600">{vcard.email}</p>
                    </div>
                  </div>

                  {/* Teléfono */}
                  {vcard.phone && (
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Teléfono</p>
                        <p className="text-sm text-gray-600">{vcard.phone}</p>
                      </div>
                    </div>
                  )}

                  {/* Empresa */}
                  <div className="flex items-center gap-3">
                    <Building className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="font-medium">Empresa</p>
                      <p className="text-sm text-gray-600">{vcard.company}</p>
                    </div>
                  </div>

                  {/* Dirección */}
                  {vcard.address && (
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-gray-400 mt-0.5" />
                      <div>
                        <p className="font-medium">Dirección</p>
                        <p className="text-sm text-gray-600">{vcard.address}</p>
                      </div>
                    </div>
                  )}

                  {/* Website */}
                  {vcard.website && (
                    <div className="flex items-center gap-3">
                      <Globe className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="font-medium">Sitio Web</p>
                        <a 
                          href={vcard.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-blue-600 hover:underline"
                        >
                          {vcard.website}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Estadísticas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Estadísticas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{vcard.downloadCount}</div>
                    <div className="text-sm text-gray-600">Descargas totales</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {vcard.qrCode ? '✓' : '✗'}
                    </div>
                    <div className="text-sm text-gray-600">Código QR</div>
                  </div>
                </div>

                <Separator className="my-4" />

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">Creada:</span>
                    <span className="font-medium">{formatDate(vcard.createdAt)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-gray-400" />
                    <span className="text-gray-600">Última actualización:</span>
                    <span className="font-medium">{formatDate(vcard.updatedAt)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Código QR y Preview */}
          <div className="space-y-6">
            {/* Código QR */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Código QR
                </CardTitle>
              </CardHeader>
              <CardContent>
                {vcard.qrCode ? (
                  <div className="text-center space-y-4">
                    <div className="bg-white p-4 rounded-lg border-2 border-gray-200 inline-block">
                      <img
                        src={vcard.qrCode}
                        alt={`Código QR para ${vcard.advisorName}`}
                        className="w-48 h-48 mx-auto"
                      />
                    </div>
                    <p className="text-sm text-gray-600">
                      Escanea este código QR para agregar el contacto automáticamente
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <QrCode className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">Código QR no generado</p>
                    <p className="text-sm text-gray-400">
                      El código QR se genera automáticamente al crear la vCard
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Preview de vCard */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Preview vCard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <pre className="text-xs text-gray-700 whitespace-pre-wrap font-mono">
                    {generateVCardString(vcard)}
                  </pre>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Este es el contenido que se descarga en el archivo .vcf
                </p>
              </CardContent>
            </Card>

            {/* Acciones de Descarga */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  Descargas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-3">
                  <Button
                    onClick={() => handleDownload('vcard')}
                    disabled={downloading === 'vcard'}
                    className="w-full"
                    variant="outline"
                  >
                    {downloading === 'vcard' ? (
                      <>
                        <Download className="h-4 w-4 mr-2 animate-bounce" />
                        Descargando vCard...
                      </>
                    ) : (
                      <>
                        <FileText className="h-4 w-4 mr-2" />
                        Descargar vCard (.vcf)
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => handleDownload('qr')}
                    disabled={downloading === 'qr' || !vcard.qrCode}
                    className="w-full"
                    variant="outline"
                  >
                    {downloading === 'qr' ? (
                      <>
                        <Download className="h-4 w-4 mr-2 animate-bounce" />
                        Descargando QR...
                      </>
                    ) : (
                      <>
                        <Image className="h-4 w-4 mr-2" />
                        Descargar Código QR (.png)
                      </>
                    )}
                  </Button>
                </div>
                
                {!vcard.qrCode && (
                  <p className="text-xs text-gray-500 mt-2 text-center">
                    El código QR no está disponible para descarga
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={downloading !== null}
          >
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
