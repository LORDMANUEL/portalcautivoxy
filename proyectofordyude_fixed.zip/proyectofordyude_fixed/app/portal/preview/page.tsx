
import { Metadata } from 'next/types';
import { PreviewClient } from './_components/preview-client';

export const metadata: Metadata = {
  title: 'Vista Previa de Tema - Ford Yude Canahuati',
  description: 'Vista previa del tema personalizado para portal cautivo Ford.',
};

interface PreviewPageProps {
  searchParams: {
    theme?: string;
    colors?: string;
  };
}

export default function PreviewPage({ searchParams }: PreviewPageProps) {
  return <PreviewClient searchParams={searchParams} />;
}
