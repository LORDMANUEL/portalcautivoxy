
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  Filter,
  Download,
  RefreshCw,
  Eye,
  Ban,
  Trash2,
  Smartphone,
  Monitor,
  Tablet,
  Wifi,
  WifiOff,
  Clock,
  MapPin
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { toast } from 'react-hot-toast';

interface CaptiveUser {
  id: string;
  deviceId: string;
  ipAddress: string;
  deviceName?: string;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  email?: string;
  name?: string;
  phone?: string;
  connectedAt: Date;
  disconnectedAt?: Date;
  sessionDuration: number;
  isActive: boolean;
  theme: string;
  dataUsed: string;
  location?: string;
}

export function UsersClient() {
  const [users, setUsers] = useState<CaptiveUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<CaptiveUser[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    let filtered = users;

    if (searchTerm) {
      filtered = filtered.filter(user =>
        user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.ipAddress.includes(searchTerm) ||
        user.deviceId.includes(searchTerm)
      );
    }

    if (filterStatus !== 'all') {
      filtered = filtered.filter(user =>
        filterStatus === 'active' ? user.isActive : !user.isActive
      );
    }

    setFilteredUsers(filtered);
  }, [users, searchTerm, filterStatus]);

  const loadUsers = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUsers: CaptiveUser[] = [
      {
        id: '1',
        deviceId: 'aa:bb:cc:dd:ee:01',
        ipAddress: '192.168.1.101',
        deviceName: 'iPhone de María',
        deviceType: 'mobile',
        email: 'maria@email.com',
        name: 'María González',
        phone: '+504 9999-0001',
        connectedAt: new Date(Date.now() - 1800000),
        sessionDuration: 1800,
        isActive: true,
        theme: 'summer',
        dataUsed: '45 MB',
        location: 'San Pedro Sula'
      },
      {
        id: '2',
        deviceId: 'aa:bb:cc:dd:ee:02',
        ipAddress: '192.168.1.102',
        deviceName: 'MacBook Pro',
        deviceType: 'desktop',
        email: 'carlos@email.com',
        name: 'Carlos Rodríguez',
        connectedAt: new Date(Date.now() - 3600000),
        sessionDuration: 3600,
        isActive: true,
        theme: 'default',
        dataUsed: '128 MB'
      },
      {
        id: '3',
        deviceId: 'aa:bb:cc:dd:ee:03',
        ipAddress: '192.168.1.103',
        deviceType: 'tablet',
        email: 'ana@email.com',
        name: 'Ana Martínez',
        connectedAt: new Date(Date.now() - 7200000),
        disconnectedAt: new Date(Date.now() - 300000),
        sessionDuration: 6900,
        isActive: false,
        theme: 'mother',
        dataUsed: '89 MB'
      }
    ];
    
    setUsers(mockUsers);
    setLoading(false);
  };

  const handleDisconnectUser = async (userId: string) => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setUsers(prev => prev.map(user =>
        user.id === userId
          ? { ...user, isActive: false, disconnectedAt: new Date() }
          : user
      ));
      
      toast.success('Usuario desconectado exitosamente');
    } catch (error) {
      toast.error('Error al desconectar usuario');
    }
  };

  const handleBanUser = async (userId: string) => {
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      toast.success('Usuario bloqueado');
    } catch (error) {
      toast.error('Error al bloquear usuario');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('¿Estás seguro de eliminar este usuario?')) return;
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setUsers(prev => prev.filter(user => user.id !== userId));
      toast.success('Usuario eliminado');
    } catch (error) {
      toast.error('Error al eliminar usuario');
    }
  };

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case 'mobile': return Smartphone;
      case 'tablet': return Tablet;
      default: return Monitor;
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
          <div className="h-10 bg-gray-300 rounded w-32 animate-pulse" />
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-20 bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Gestión de Usuarios</h1>
          <p className="text-gray-600">
            {filteredUsers.length} usuarios • {filteredUsers.filter(u => u.isActive).length} conectados
          </p>
        </div>
        <div className="flex space-x-2">
          <FordButton variant="outline" size="sm" onClick={loadUsers}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Actualizar
          </FordButton>
          <FordButton variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </FordButton>
        </div>
      </div>

      {/* Filters */}
      <FordCard className="p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Buscar por nombre, email, IP o dispositivo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-[#003478] focus:border-transparent"
            >
              <option value="all">Todos</option>
              <option value="active">Conectados</option>
              <option value="inactive">Desconectados</option>
            </select>
          </div>
        </div>
      </FordCard>

      {/* Users List */}
      <div className="space-y-4">
        {filteredUsers.map((user, index) => {
          const DeviceIcon = getDeviceIcon(user.deviceType);
          
          return (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <FordCard className="p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                      user.isActive ? 'bg-green-100' : 'bg-gray-100'
                    }`}>
                      <DeviceIcon className={`w-6 h-6 ${
                        user.isActive ? 'text-green-600' : 'text-gray-500'
                      }`} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold text-gray-800">
                          {user.name || 'Usuario Anónimo'}
                        </h3>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          user.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {user.isActive ? (
                            <>
                              <Wifi className="w-3 h-3 mr-1" />
                              Conectado
                            </>
                          ) : (
                            <>
                              <WifiOff className="w-3 h-3 mr-1" />
                              Desconectado
                            </>
                          )}
                        </span>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                        <span>{user.email || 'Sin email'}</span>
                        <span>•</span>
                        <span>{user.ipAddress}</span>
                        <span>•</span>
                        <span className="flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {formatDuration(user.sessionDuration)}
                        </span>
                        {user.location && (
                          <>
                            <span>•</span>
                            <span className="flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {user.location}
                            </span>
                          </>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-4 text-xs text-gray-500 mt-1">
                        <span>Dispositivo: {user.deviceName || user.deviceId}</span>
                        <span>•</span>
                        <span>Tema: {user.theme}</span>
                        <span>•</span>
                        <span>Datos: {user.dataUsed}</span>
                        <span>•</span>
                        <span>
                          Conectado: {user.connectedAt.toLocaleString('es-HN')}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <FordButton variant="ghost" size="sm">
                      <Eye className="w-4 h-4" />
                    </FordButton>
                    
                    {user.isActive && (
                      <FordButton
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDisconnectUser(user.id)}
                      >
                        <WifiOff className="w-4 h-4 text-orange-600" />
                      </FordButton>
                    )}
                    
                    <FordButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleBanUser(user.id)}
                    >
                      <Ban className="w-4 h-4 text-red-600" />
                    </FordButton>
                    
                    <FordButton
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteUser(user.id)}
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </FordButton>
                  </div>
                </div>
              </FordCard>
            </motion.div>
          );
        })}
      </div>

      {filteredUsers.length === 0 && (
        <FordCard className="p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-800 mb-2">
            No se encontraron usuarios
          </h3>
          <p className="text-gray-600">
            Intenta ajustar los filtros de búsqueda o espera nuevas conexiones.
          </p>
        </FordCard>
      )}
    </div>
  );
}
