
"use client";

import { cn } from "@/lib/utils";

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "circle" | "text" | "card";
  lines?: number;
}

export function LoadingSkeleton({ 
  className, 
  variant = "default", 
  lines = 1,
  ...props 
}: SkeletonProps) {
  if (variant === "text") {
    return (
      <div className="space-y-2">
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-4 bg-muted rounded loading-shimmer",
              i === lines - 1 && lines > 1 ? "w-3/4" : "w-full",
              className
            )}
            {...props}
          />
        ))}
      </div>
    );
  }

  if (variant === "circle") {
    return (
      <div
        className={cn(
          "rounded-full bg-muted loading-shimmer",
          className
        )}
        {...props}
      />
    );
  }

  if (variant === "card") {
    return (
      <div className={cn("rounded-lg border bg-card p-6 space-y-4", className)}>
        <div className="flex items-center space-x-4">
          <LoadingSkeleton variant="circle" className="h-12 w-12" />
          <div className="space-y-2 flex-1">
            <LoadingSkeleton className="h-4 w-1/2" />
            <LoadingSkeleton className="h-3 w-1/3" />
          </div>
        </div>
        <LoadingSkeleton variant="text" lines={3} />
      </div>
    );
  }

  return (
    <div
      className={cn(
        "animate-pulse rounded-md bg-muted loading-shimmer",
        className
      )}
      {...props}
    />
  );
}
