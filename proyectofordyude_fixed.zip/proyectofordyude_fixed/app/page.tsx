
import { redirect } from 'next/navigation';

// Redirect root to admin login (new architecture)
export default function HomePage() {
  redirect('/admin/login');
}
