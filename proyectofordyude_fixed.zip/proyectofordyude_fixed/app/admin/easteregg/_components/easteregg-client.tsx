
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Code,
  Coffee,
  Heart,
  Palette,
  Zap,
  Star,
  Rocket,
  Crown,
  Award
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';

export function EasterEggClient() {
  const [currentColor, setCurrentColor] = useState('#003478');
  const [isAnimating, setIsAnimating] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const colors = [
    '#003478', // Ford Blue
    '#ff69b4', // Hot Pink
    '#00ff00', // Lime Green
    '#ff4500', // Orange Red
    '#9370db', // Medium Purple
    '#ffd700', // Gold
    '#ff1493', // Deep Pink
    '#00ced1', // Dark Turquoise
    '#ff6347', // Tomato
    '#32cd32'  // Lime Green
  ];

  const handleColorChange = () => {
    setIsAnimating(true);
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setCurrentColor(randomColor);
    setShowConfetti(true);
    
    setTimeout(() => {
      setIsAnimating(false);
      setShowConfetti(false);
    }, 2000);
  };

  const signatures = [
    "Hecho con ❤️ por Luis Manuel",
    "Desarrollado con pasión por LMFR",
    "Crafted with code by Luis Manuel Fajardo Rivera",
    "Built with Next.js & TypeScript by LMFR",
    "Powered by Coffee ☕ & Code 💻"
  ];

  const [currentSignature, setCurrentSignature] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSignature(prev => (prev + 1) % signatures.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div 
      className="min-h-screen transition-all duration-1000"
      style={{ backgroundColor: `${currentColor}20` }}
    >
      <div className="p-6">
        {/* Confetti Effect */}
        {showConfetti && (
          <div className="fixed inset-0 pointer-events-none z-50">
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full"
                style={{ 
                  backgroundColor: colors[Math.floor(Math.random() * colors.length)],
                  left: `${Math.random() * 100}%`,
                  top: '-10px'
                }}
                animate={{
                  y: window.innerHeight + 100,
                  rotate: 360,
                  opacity: [1, 0]
                }}
                transition={{
                  duration: Math.random() * 2 + 1,
                  ease: "easeOut"
                }}
              />
            ))}
          </div>
        )}

        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="text-8xl mb-4"
            animate={{ 
              rotate: isAnimating ? 360 : 0,
              scale: isAnimating ? 1.2 : 1 
            }}
            transition={{ duration: 0.5 }}
          >
            🥚
          </motion.div>
          <h1 
            className="text-6xl font-bold mb-4 transition-colors duration-500"
            style={{ color: currentColor }}
          >
            Easter Egg!
          </h1>
          <p className="text-xl text-gray-600">
            Has encontrado la página oculta del desarrollador
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Color Changer */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <FordCard className="p-8 text-center">
              <motion.div
                className="w-32 h-32 rounded-full mx-auto mb-6 shadow-lg"
                style={{ backgroundColor: currentColor }}
                animate={{ 
                  scale: isAnimating ? 1.1 : 1,
                  boxShadow: isAnimating ? `0 0 40px ${currentColor}` : `0 0 20px ${currentColor}40`
                }}
                transition={{ duration: 0.3 }}
              />
              
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Cambiador de Colores Mágico
              </h2>
              <p className="text-gray-600 mb-6">
                Cada click cambia el tema del portal. ¡Experimenta con diferentes colores!
              </p>
              
              <FordButton
                onClick={handleColorChange}
                size="lg"
                style={{ backgroundColor: currentColor }}
                className="transform hover:scale-105 transition-transform"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                ¡Cambiar Color!
              </FordButton>
            </FordCard>
          </motion.div>

          {/* Developer Stats */}
          <motion.div
            className="grid md:grid-cols-3 gap-6"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <FordCard className="p-6 text-center">
              <Code className="w-12 h-12 mx-auto mb-4" style={{ color: currentColor }} />
              <h3 className="text-xl font-bold text-gray-800 mb-2">2,500+</h3>
              <p className="text-gray-600">Líneas de Código</p>
            </FordCard>

            <FordCard className="p-6 text-center">
              <Coffee className="w-12 h-12 mx-auto mb-4" style={{ color: currentColor }} />
              <h3 className="text-xl font-bold text-gray-800 mb-2">47</h3>
              <p className="text-gray-600">Tazas de Café</p>
            </FordCard>

            <FordCard className="p-6 text-center">
              <Heart className="w-12 h-12 mx-auto mb-4" style={{ color: currentColor }} />
              <h3 className="text-xl font-bold text-gray-800 mb-2">∞</h3>
              <p className="text-gray-600">Horas de Pasión</p>
            </FordCard>
          </motion.div>

          {/* Tech Stack */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <FordCard className="p-8">
              <div className="flex items-center mb-6">
                <Zap className="w-8 h-8 mr-3" style={{ color: currentColor }} />
                <h2 className="text-2xl font-bold text-gray-800">Stack Tecnológico</h2>
              </div>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { name: 'Next.js 14', icon: '⚡' },
                  { name: 'React 18', icon: '⚛️' },
                  { name: 'TypeScript', icon: '🔷' },
                  { name: 'Tailwind CSS', icon: '🎨' },
                  { name: 'Framer Motion', icon: '🎭' },
                  { name: 'Prisma ORM', icon: '🗃️' },
                  { name: 'NextAuth.js', icon: '🔐' },
                  { name: 'PostgreSQL', icon: '🐘' }
                ].map((tech, index) => (
                  <motion.div
                    key={tech.name}
                    className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg"
                    whileHover={{ scale: 1.05 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.7 + index * 0.1 }}
                  >
                    <span className="text-2xl">{tech.icon}</span>
                    <span className="font-medium text-gray-800">{tech.name}</span>
                  </motion.div>
                ))}
              </div>
            </FordCard>
          </motion.div>

          {/* Animated Icons */}
          <motion.div
            className="grid grid-cols-5 gap-4 max-w-md mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            {[Star, Rocket, Crown, Award, Sparkles].map((Icon, index) => (
              <motion.div
                key={index}
                animate={{
                  y: [0, -10, 0],
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.1, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: index * 0.2
                }}
                className="flex justify-center"
              >
                <Icon 
                  className="w-8 h-8" 
                  style={{ color: currentColor }}
                />
              </motion.div>
            ))}
          </motion.div>

          {/* Developer Signature */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <FordCard className="p-8 text-center">
              <motion.div
                key={currentSignature}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="text-lg font-medium"
                style={{ color: currentColor }}
              >
                {signatures[currentSignature]}
              </motion.div>
              
              <div className="mt-6 pt-6 border-t border-gray-200">
                <p className="text-gray-600 text-sm">
                  Portal Cautivo Ford Yude Canahuati v1.0
                </p>
                <p className="text-gray-500 text-xs mt-2">
                  Desarrollado con Next.js, TypeScript y mucho ☕
                </p>
                <motion.p 
                  className="text-lg font-bold mt-4"
                  style={{ color: currentColor }}
                  animate={{ scale: [1, 1.05, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  Luis Manuel Fajardo Rivera
                </motion.p>
              </div>
            </FordCard>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
