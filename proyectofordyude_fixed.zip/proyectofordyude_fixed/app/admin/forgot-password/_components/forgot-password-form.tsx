
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, ArrowLeft, User } from 'lucide-react';
import Link from 'next/link';

export function ForgotPasswordForm() {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: username, 2: security questions
  const [answers, setAnswers] = useState({ q1: '', q2: '' });
  const router = useRouter();

  const securityQuestions = [
    { id: 'q1', question: '¿Cuál es el nombre de la empresa?', answer: 'Ford Yude Canahuati' },
    { id: 'q2', question: '¿En qué ciudad se encuentra la empresa?', answer: 'San Pedro Sula' }
  ];

  const handleUsernameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simular verificación (solo acepta "admin")
    setTimeout(() => {
      if (username.toLowerCase() === 'admin') {
        setStep(2);
      } else {
        alert('Usuario no encontrado. Intenta con "admin"');
      }
      setLoading(false);
    }, 1000);
  };

  const handleSecuritySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Verificar respuestas de seguridad
    setTimeout(() => {
      const isCorrect = 
        answers.q1.toLowerCase().includes('ford') && answers.q1.toLowerCase().includes('yude') &&
        answers.q2.toLowerCase().includes('san pedro sula');

      if (isCorrect) {
        // Redirigir a reset password con token demo
        router.push('/admin/reset-password?token=demo-reset-token&username=admin');
      } else {
        alert('Respuestas incorrectas. Intenta nuevamente.');
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <Card className="w-full">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <User className="h-5 w-5 text-blue-600" />
          Recuperación de Contraseña
        </CardTitle>
      </CardHeader>
      <CardContent>
        {step === 1 ? (
          <form onSubmit={handleUsernameSubmit} className="space-y-4">
            <div>
              <Label htmlFor="username">Nombre de Usuario</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Ingresa tu usuario"
                required
                className="pl-10"
              />
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            </div>

            <div className="bg-blue-50 p-3 rounded-lg flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-blue-700">
                <p><strong>Demostración:</strong> Este es un sistema de recuperación de contraseña demo.</p>
                <p>Usuario válido: <code className="bg-blue-100 px-1 rounded">admin</code></p>
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading || !username.trim()}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {loading ? 'Verificando...' : 'Continuar'}
            </Button>
          </form>
        ) : (
          <form onSubmit={handleSecuritySubmit} className="space-y-4">
            <div className="text-sm text-gray-600 mb-4">
              Usuario: <strong>{username}</strong>
            </div>

            {securityQuestions.map((q) => (
              <div key={q.id}>
                <Label htmlFor={q.id}>{q.question}</Label>
                <Input
                  id={q.id}
                  type="text"
                  value={answers[q.id as keyof typeof answers]}
                  onChange={(e) => setAnswers(prev => ({ ...prev, [q.id]: e.target.value }))}
                  placeholder="Tu respuesta"
                  required
                />
              </div>
            ))}

            <div className="bg-amber-50 p-3 rounded-lg flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-amber-700">
                <p><strong>Pistas:</strong></p>
                <p>• Pregunta 1: Incluye "Ford" y el apellido del concesionario</p>
                <p>• Pregunta 2: Ciudad principal de Honduras donde opera</p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setStep(1)}
                className="flex-1"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
              <Button
                type="submit"
                disabled={loading || !answers.q1.trim() || !answers.q2.trim()}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Verificando...' : 'Verificar'}
              </Button>
            </div>
          </form>
        )}

        <div className="mt-6 text-center">
          <Link 
            href="/admin/login"
            className="text-sm text-blue-600 hover:text-blue-800 flex items-center justify-center gap-1"
          >
            <ArrowLeft className="h-3 w-3" />
            Volver al inicio de sesión
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
