
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { prisma } from '@/lib/db';

import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


// Simulación de datos de imágenes para desarrollo
const mockImages = [
  {
    id: '1',
    name: 'ford-logo-oficial.png',
    originalName: 'ford-logo-oficial.png',
    url: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
    thumbnailUrl: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
    size: 45623,
    mimeType: 'image/png',
    category: 'logos',
    tags: ['ford', 'logo', 'brand'],
    alt: 'Logo oficial de Ford',
    description: 'Logo oficial de Ford Motor Company',
    isPublic: true,
    isFeatured: true,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 512,
      height: 512,
      usage: ['portal', 'theme', 'banner'],
      portal: 'ford-general',
      theme: 'default'
    }
  },
  {
    id: '2',
    name: 'quicklane-logo.png',
    originalName: 'quicklane-logo.png',
    url: 'https://imgs.search.brave.com/4yqyuh914gIEj3HqhDumD-OJpoudC-E6GJKdyefyZEc/rs:fit:0:180:1:0/g:ce/aHR0cHM6Ly9iYW5u/ZXIyLmNsZWFucG5n/LmNvbS8yMDE4MDQx/OS9vb3EvYXZmNnM1/djQ4LndlYnA',
    thumbnailUrl: 'https://imgs.search.brave.com/kD1X2RLp6YZcPOtCBPvLKE_jFKagExfxb2xH8LmF_BM/rs:fit:0:180:1:0/g:ce/aHR0cHM6Ly9xdWlj/a2xhbmVzYS5jb20v/d3AtY29udGVudC91/cGxvYWRzL3F1aWNr/LWxhbmUtbG9nby13/aGl0ZS5wbmc',
    size: 34567,
    mimeType: 'image/png',
    category: 'logos',
    tags: ['quicklane', 'logo', 'service'],
    alt: 'Logo de QuickLane',
    description: 'Logo oficial de servicios QuickLane',
    isPublic: true,
    isFeatured: true,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 400,
      height: 200,
      usage: ['portal', 'banner'],
      portal: 'quicklane',
      theme: 'quicklane'
    }
  },
  {
    id: '3',
    name: 'showroom-background.jpg',
    originalName: 'showroom-background.jpg',
    url: 'https://designcollaborative.com/wp-content/uploads/2021/11/Schmidt_Ford-Dealership_1.jpg',
    thumbnailUrl: 'https://designcollaborative.com/wp-content/uploads/2021/11/Schmidt_Ford-Dealership_1.jpg',
    size: 256789,
    mimeType: 'image/jpeg',
    category: 'backgrounds',
    tags: ['showroom', 'ford', 'dealership', 'background'],
    alt: 'Showroom Ford moderno',
    description: 'Imagen de showroom Ford para fondos de portal',
    isPublic: true,
    isFeatured: false,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 1920,
      height: 1080,
      usage: ['background', 'banner'],
      portal: 'ford-general',
      theme: 'default'
    }
  },
  {
    id: '4',
    name: 'f150-2025.jpg',
    originalName: 'ford-f150-2025.jpg',
    url: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
    thumbnailUrl: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
    size: 189456,
    mimeType: 'image/jpeg',
    category: 'vehicles',
    tags: ['f150', 'pickup', 'ford', '2025', 'truck'],
    alt: 'Ford F-150 2025',
    description: 'Nueva Ford F-150 modelo 2025 King Ranch',
    isPublic: true,
    isFeatured: true,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 1600,
      height: 900,
      usage: ['carousel', 'promotion', 'banner'],
      portal: 'ford-general',
      theme: 'default'
    }
  },
  {
    id: '5',
    name: 'anniversary-banner.jpg',
    originalName: 'yude-anniversary-banner.jpg',
    url: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
    thumbnailUrl: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
    size: 345678,
    mimeType: 'image/jpeg',
    category: 'seasonal',
    tags: ['anniversary', 'yude', 'celebration', 'golden'],
    alt: 'Banner de aniversario Yude',
    description: 'Banner especial para celebración de aniversario',
    isPublic: true,
    isFeatured: true,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 2070,
      height: 1380,
      usage: ['background', 'banner'],
      portal: 'all',  
      theme: 'yude-anniversary'
    }
  },
  {
    id: '6',
    name: 'service-banner.jpg',
    originalName: 'quicklane-service-banner.jpg',
    url: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
    thumbnailUrl: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
    size: 178934,
    mimeType: 'image/png',
    category: 'services',
    tags: ['quicklane', 'service', 'automotive', 'maintenance'],
    alt: 'Centro de servicio QuickLane',
    description: 'Imagen promocional de servicios QuickLane',
    isPublic: true,
    isFeatured: false,
    uploadedBy: 'admin',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      width: 1280,
      height: 720,
      usage: ['carousel', 'promotion'],
      portal: 'quicklane',
      theme: 'quicklane'
    }
  }
];

/**
 * GET - Obtiene todas las imágenes del gestor
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Por ahora devolver datos mock, después se puede integrar con base de datos
    return NextResponse.json(mockImages);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

/**
 * POST - Crea nueva imagen (metadata, la subida se maneja en /upload)
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, url, category, tags, alt, description, metadata } = body;

    // Validaciones básicas
    if (!name || !url || !category) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Simular creación de imagen
    const newImage = {
      id: Date.now().toString(),
      name,
      originalName: name,
      url,
      thumbnailUrl: url,
      size: Math.floor(Math.random() * 500000) + 50000,
      mimeType: 'image/jpeg',
      category,
      tags: tags || [],
      alt: alt || name,
      description: description || '',
      isPublic: true,
      isFeatured: false,
      uploadedBy: session.user?.email || 'admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      metadata: metadata || {}
    };

    return NextResponse.json(newImage, { status: 201 });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
