
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
import { getServerSession } from 'next-auth';

import { authOptions } from '@/lib/auth';


// Datos simulados de banners
const mockBanners = [
  {
    id: '1',
    name: 'Banner Ford F-150',
    description: 'Promoción especial de la nueva Ford F-150 2025',
    bannerUrl: 'https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg',
    targetUrl: 'https://fordyude.com/vehiculos/f150',
    embedCode: '<div style="width:400px;height:300px;"><a href="https://fordyude.com/vehiculos/f150" target="_blank"><img src="https://www.motortrend.com/files/672a8172d1f0a50008ae4352/023-2025-ford-f-150-hybrid-king-ranch-front-view.jpg" style="width:100%;height:100%;object-fit:cover;" alt="Ford F-150" /></a></div>',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://fordyude.com/vehiculos/f150',
    width: 400,
    height: 300,
    format: 'jpg' as const,
    isActive: true,
    clickCount: 156,
    viewCount: 2341,
    portal: 'ford-general',
    theme: 'default',
    customization: {
      backgroundColor: '#FFFFFF',
      textColor: '#003478',
      borderColor: '#CCCCCC',
      borderRadius: 8,
      shadow: true,
      animation: false
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Banner QuickLane Service',
    description: 'Servicios express QuickLane sin cita previa',
    bannerUrl: 'https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png',
    targetUrl: 'https://fordyude.com/servicios/quicklane',
    embedCode: '<div style="width:350px;height:250px;"><a href="https://fordyude.com/servicios/quicklane" target="_blank"><img src="https://tandgarch.com/wp-content/uploads/2022/09/Enscape_2022-09-01-14-52-24_009-1280x720.png" style="width:100%;height:100%;object-fit:cover;" alt="QuickLane Service" /></a></div>',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://fordyude.com/servicios/quicklane',
    width: 350,
    height: 250,
    format: 'png' as const,
    isActive: true,
    clickCount: 89,
    viewCount: 1567,
    portal: 'quicklane-general',
    theme: 'quicklane',
    customization: {
      backgroundColor: '#FF6600',
      textColor: '#FFFFFF',
      borderColor: '#E55A00',
      borderRadius: 12,
      shadow: true,
      animation: true
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: '3',
    name: 'Banner Aniversario Yude',
    description: 'Celebración especial del aniversario de Ford Yude Canahuati',
    bannerUrl: 'https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070',
    targetUrl: 'https://fordyude.com/aniversario',
    embedCode: '<div style="width:500px;height:300px;"><a href="https://fordyude.com/aniversario" target="_blank"><img src="https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=2070" style="width:100%;height:100%;object-fit:cover;" alt="Aniversario Yude" /></a></div>',
    qrCodeUrl: 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://fordyude.com/aniversario',
    width: 500,
    height: 300,
    format: 'jpg' as const,
    isActive: true,
    clickCount: 234,
    viewCount: 3456,
    portal: 'ford-general',
    theme: 'yude-anniversary',
    customization: {
      backgroundColor: '#DAA520',
      textColor: '#003478',
      borderColor: '#B8860B',
      borderRadius: 15,
      shadow: true,
      animation: true
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

/**
 * GET - Obtiene todos los banners
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    return NextResponse.json(mockBanners);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

/**
 * POST - Crea nuevo banner
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, bannerUrl, targetUrl, width, height, format, portal, theme, customization } = body;

    // Validaciones
    if (!name || !bannerUrl || !targetUrl) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // Generar código embed
    const embedCode = `<div style="width:${width}px;height:${height}px;background:${customization.backgroundColor};border:1px solid ${customization.borderColor};border-radius:${customization.borderRadius}px;${customization.shadow ? 'box-shadow:0 4px 8px rgba(0,0,0,0.1);' : ''}">
  <a href="${targetUrl}" target="_blank">
    <img src="${bannerUrl}" alt="${name}" style="width:100%;height:100%;object-fit:cover;border-radius:${customization.borderRadius}px;" />
  </a>
</div>`;

    // Generar QR code
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(targetUrl)}`;

    const newBanner = {
      id: Date.now().toString(),
      name,
      description: description || '',
      bannerUrl,
      targetUrl,
      embedCode,
      qrCodeUrl,
      width: width || 300,
      height: height || 250,
      format: format || 'jpg',
      isActive: true,
      clickCount: 0,
      viewCount: 0,
      portal: portal || 'ford-general',
      theme: theme || 'default',
      customization: customization || {
        backgroundColor: '#FFFFFF',
        textColor: '#003478',
        borderColor: '#CCCCCC',
        borderRadius: 8,
        shadow: true,
        animation: false
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    return NextResponse.json(newBanner, { status: 201 });

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
