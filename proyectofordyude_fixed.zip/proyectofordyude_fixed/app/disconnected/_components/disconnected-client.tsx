
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { WifiOff, RotateCcw, Clock, MapPin, Phone } from 'lucide-react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';

export function DisconnectedClient() {
  const handleReconnect = () => {
    window.location.href = '/portal';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-gray-100">
      <Header variant="public" />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center">
              <WifiOff className="w-10 h-10 text-white" />
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-red-600">
                Desconectado
              </h1>
              <p className="text-xl text-gray-600">
                Tu sesión WiFi ha finalizado
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Disconnection Info */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <FordCard className="p-8 text-center">
              <WifiOff className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-800 mb-4">
                Sesión Finalizada
              </h2>
              <p className="text-gray-600 mb-6">
                Gracias por usar el WiFi gratuito de Ford Yude Canahuati. 
                Tu sesión ha terminado de manera segura.
              </p>
              
              <div className="space-y-3 text-sm text-gray-600 mb-6">
                <div className="flex items-center justify-center space-x-2">
                  <Clock className="w-4 h-4" />
                  <span>Desconectado a las {new Date().toLocaleTimeString('es-HN')}</span>
                </div>
              </div>

              <FordButton
                size="lg"
                className="w-full"
                onClick={handleReconnect}
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Conectarse Nuevamente
              </FordButton>
            </FordCard>
          </motion.div>

          {/* Ford Services */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <FordCard className="p-8">
              <h2 className="text-2xl font-bold text-[#003478] mb-6">
                Servicios Ford Yude Canahuati
              </h2>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-[#003478] mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-800">Ubicación</h3>
                    <p className="text-gray-600 text-sm">
                      San Pedro Sula, Honduras<br />
                      Visítanos en nuestro showroom
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-[#003478] mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-800">Contacto</h3>
                    <p className="text-gray-600 text-sm">
                      +504 2550-0000<br />
                      info@fordyude.hn
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="w-6 h-6 text-[#003478] mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-800">Horarios</h3>
                    <p className="text-gray-600 text-sm">
                      Lun - Vie: 8:00 AM - 6:00 PM<br />
                      Sáb: 8:00 AM - 5:00 PM
                    </p>
                  </div>
                </div>
              </div>
            </FordCard>
          </motion.div>
        </div>

        {/* Ford Showcase */}
        <motion.section
          className="mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <FordCard className="overflow-hidden">
            <div className="relative h-64 md:h-80">
              <Image
                src="https://thedesigncompound.com/data/portfolio/ford-automobile-showroom/03-ford-cars-display.jpg?20200505"
                alt="Ford Showroom"
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-[#003478]/80 to-transparent flex items-center">
                <div className="px-8 text-white">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">
                    Descubre Ford 2025
                  </h2>
                  <p className="text-lg md:text-xl text-blue-100 mb-6">
                    Innovación, tecnología y calidad en cada vehículo
                  </p>
                  <FordButton variant="secondary" size="lg">
                    Ver Catálogo
                  </FordButton>
                </div>
              </div>
            </div>
          </FordCard>
        </motion.section>

        {/* Quick Actions */}
        <motion.section
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <FordButton
              variant="outline"
              className="w-full"
              onClick={handleReconnect}
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reconectar
            </FordButton>
            
            <FordButton
              variant="outline"
              className="w-full"
              onClick={() => window.location.href = '/portal'}
            >
              <WifiOff className="w-4 h-4 mr-2" />
              Portal Principal
            </FordButton>
            
            <FordButton
              variant="outline"
              className="w-full"
              onClick={() => window.open('tel:+50425500000', '_self')}
            >
              <Phone className="w-4 h-4 mr-2" />
              Llamar
            </FordButton>
          </div>
        </motion.section>
      </main>

      <Footer />
    </div>
  );
}
