
/**
 * API Route para gestión individual de permisos
 * 
 * Funcionalidades:
 * - GET: Obtener permiso específico
 * - PUT: Actualizar permiso
 * - DELETE: Eliminar permiso
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const updatePermissionSchema = z.object({
  name: z.string().min(3).optional(),
  module: z.string().min(2).optional(),
  action: z.string().min(2).optional(),
  description: z.string().optional(),
  isActive: z.boolean().optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/permissions/[id]
 * Obtener permiso específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const permission = await prisma.permission.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            rolePermissions: true
          }
        }
      }
    })

    if (!permission) {
      return NextResponse.json(
        { success: false, message: 'Permiso no encontrado' },
        { status: 404 }
      )
    }

    return NextResponse.json({
      success: true,
      data: permission
    })

  } catch (error) {
    console.error('Error fetching permission:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/permissions/[id]
 * Actualizar permiso
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = updatePermissionSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { name, module, action, description, isActive } = validation.data

    // Verificar que el permiso existe
    const existingPermission = await prisma.permission.findUnique({
      where: { id: params.id }
    })

    if (!existingPermission) {
      return NextResponse.json(
        { success: false, message: 'Permiso no encontrado' },
        { status: 404 }
      )
    }

    // Verificar nombre único (si se está cambiando)
    if (name && name !== existingPermission.name) {
      const nameTaken = await prisma.permission.findUnique({
        where: { name }
      })

      if (nameTaken) {
        return NextResponse.json(
          { success: false, message: 'Ya existe un permiso con ese nombre' },
          { status: 400 }
        )
      }
    }

    // Preparar datos de actualización
    const updateData: any = {}
    
    if (name !== undefined) updateData.name = name
    if (module !== undefined) updateData.module = module
    if (action !== undefined) updateData.action = action
    if (description !== undefined) updateData.description = description
    if (isActive !== undefined) updateData.isActive = isActive

    const permission = await prisma.permission.update({
      where: { id: params.id },
      data: updateData
    })

    return NextResponse.json({
      success: true,
      data: permission,
      message: 'Permiso actualizado exitosamente'
    })

  } catch (error) {
    console.error('Error updating permission:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/permissions/[id]
 * Eliminar permiso (soft delete)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const permission = await prisma.permission.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            rolePermissions: true
          }
        }
      }
    })

    if (!permission) {
      return NextResponse.json(
        { success: false, message: 'Permiso no encontrado' },
        { status: 404 }
      )
    }

    // No permitir eliminar permisos que tienen roles asignados
    if (permission._count.rolePermissions > 0) {
      return NextResponse.json(
        { success: false, message: 'No se puede eliminar un permiso que está asignado a roles' },
        { status: 400 }
      )
    }

    // Soft delete - marcar como inactivo
    await prisma.permission.update({
      where: { id: params.id },
      data: { 
        isActive: false
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Permiso eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error deleting permission:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
