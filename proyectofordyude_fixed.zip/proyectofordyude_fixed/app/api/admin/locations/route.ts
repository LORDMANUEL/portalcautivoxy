

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/locations
 * Obtiene todas las ubicaciones con contadores relacionados
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const locations = await prisma.location.findMany({
      include: {
        _count: {
          select: {
            portals: true,
            backups: true,
            admins: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(locations);
  } catch (error) {
    console.error('Error al obtener ubicaciones:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * POST /api/admin/locations
 * Crea una nueva ubicación
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { 
      name, 
      code, 
      type, 
      address, 
      city, 
      country, 
      latitude, 
      longitude, 
      description,
      iconName,
      iconColor,
      isActive,
      routerConfig
    } = body;

    if (!name || !code) {
      return NextResponse.json({ error: 'Nombre y código son obligatorios' }, { status: 400 });
    }

    // Verificar que el código sea único
    const existingLocation = await prisma.location.findUnique({
      where: { code }
    });

    if (existingLocation) {
      return NextResponse.json({ error: 'Ya existe una ubicación con este código' }, { status: 400 });
    }

    const location = await prisma.location.create({
      data: {
        name,
        code,
        type: type || 'SHOWROOM',
        address: address || null,
        city: city || null,
        country: country || 'Honduras',
        latitude: latitude || null,
        longitude: longitude || null,
        description: description || null,
        iconName: iconName || 'building',
        iconColor: iconColor || '#003478',
        isActive: isActive !== false,
        routerConfig: routerConfig || null
      },
      include: {
        _count: {
          select: {
            portals: true,
            backups: true,
            admins: true
          }
        }
      }
    });

    return NextResponse.json(location);
  } catch (error) {
    console.error('Error al crear ubicación:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
