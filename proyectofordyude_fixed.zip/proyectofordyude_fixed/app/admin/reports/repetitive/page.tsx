
import { Metadata } from 'next';
import { RepetitiveClient } from './_components/repetitive-client';

export const metadata: Metadata = {
  title: 'Usuarios Repetitivos - Admin Ford',
  description: 'Análisis de usuarios que regresan frecuentemente al portal',
};

export default function RepetitiveReportPage() {
  return <RepetitiveClient />;
}
