
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Rss,
  Plus,
  Edit,
  Trash2,
  RefreshCw,
  ExternalLink,
  Eye,
  EyeOff,
  Clock,
  AlertCircle,
  Save,
  X
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RssEmbedGenerator } from './rss-embed-generator';
import { toast } from 'react-hot-toast';

interface RssFeed {
  id: string;
  title: string;
  description?: string;
  url: string;
  isActive: boolean;
  category: string;
  updateFreq: number;
  lastFetch?: Date;
  itemCount: number;
  createdAt: Date;
  status: 'active' | 'error' | 'pending';
}

interface RssItem {
  id: string;
  feedId: string;
  title: string;
  description?: string;
  link: string;
  pubDate?: Date;
  imageUrl?: string;
  isVisible: boolean;
}

export function RssClient() {
  const [feeds, setFeeds] = useState<RssFeed[]>([]);
  const [items, setItems] = useState<RssItem[]>([]);
  const [editingFeed, setEditingFeed] = useState<RssFeed | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedFeed, setSelectedFeed] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeeds();
  }, []);

  useEffect(() => {
    if (selectedFeed) {
      loadFeedItems(selectedFeed);
    }
  }, [selectedFeed]);

  const loadFeeds = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockFeeds: RssFeed[] = [
      {
        id: '1',
        title: 'Noticias Ford Global',
        description: 'Últimas noticias y novedades de Ford a nivel mundial',
        url: 'https://media.ford.com/rss/releases.xml',
        isActive: true,
        category: 'ford',
        updateFreq: 60,
        lastFetch: new Date(Date.now() - 1800000),
        itemCount: 25,
        createdAt: new Date(),
        status: 'active'
      },
      {
        id: '2',
        title: 'Noticias Automotrices Honduras',
        description: 'Noticias del sector automotriz en Honduras',
        url: 'https://automotriz.hn/rss',
        isActive: true,
        category: 'automotive',
        updateFreq: 120,
        lastFetch: new Date(Date.now() - 3600000),
        itemCount: 18,
        createdAt: new Date(),
        status: 'active'
      },
      {
        id: '3',
        title: 'La Prensa Honduras',
        description: 'Noticias generales de Honduras',
        url: 'https://laprensa.hn/rss',
        isActive: false,
        category: 'news',
        updateFreq: 30,
        lastFetch: new Date(Date.now() - 7200000),
        itemCount: 42,
        createdAt: new Date(),
        status: 'error'
      }
    ];
    
    setFeeds(mockFeeds);
    setSelectedFeed(mockFeeds[0]?.id);
    setLoading(false);
  };

  const loadFeedItems = async (feedId: string) => {
    // Simulate API call
    const mockItems: RssItem[] = [
      {
        id: '1',
        feedId: feedId,
        title: 'Ford Presenta Nueva Tecnología Híbrida para 2025',
        description: 'La compañía anuncia avances significativos en su línea de vehículos híbridos...',
        link: 'https://media.ford.com/content/fordmedia/fna/us/en/news/2024/ford-hybrid-technology.html',
        pubDate: new Date(Date.now() - 3600000),
        imageUrl: 'https://i.ytimg.com/vi/iIVn17FLyGE/maxresdefault.jpg',
        isVisible: true
      },
      {
        id: '2',
        feedId: feedId,
        title: 'Ventas de Ford Crecen 15% en Latinoamérica',
        description: 'Excelentes resultados para Ford en la región, con Honduras liderando el crecimiento...',
        link: 'https://media.ford.com/content/fordmedia/fna/us/en/news/2024/ford-latam-sales.html',
        pubDate: new Date(Date.now() - 7200000),
        isVisible: true
      },
      {
        id: '3',
        feedId: feedId,
        title: 'Ford Mustang Eléctrico Llega a Centroamérica',
        description: 'El icónico Mustang ahora en versión completamente eléctrica disponible en la región...',
        link: 'https://media.ford.com/content/fordmedia/fna/us/en/news/2024/mustang-electric-central-america.html',
        pubDate: new Date(Date.now() - 10800000),
        isVisible: true
      }
    ];
    
    setItems(mockItems);
  };

  const handleCreateFeed = () => {
    const newFeed: RssFeed = {
      id: 'new',
      title: '',
      description: '',
      url: '',
      isActive: true,
      category: 'news',
      updateFreq: 60,
      itemCount: 0,
      createdAt: new Date(),
      status: 'pending'
    };
    
    setEditingFeed(newFeed);
    setIsCreating(true);
  };

  const handleEditFeed = (feed: RssFeed) => {
    setEditingFeed({ ...feed });
    setIsCreating(false);
  };

  const handleSaveFeed = async () => {
    if (!editingFeed) return;
    
    if (!editingFeed.title || !editingFeed.url) {
      toast.error('Título y URL son requeridos');
      return;
    }
    
    try {
      if (isCreating) {
        const newFeed = {
          ...editingFeed,
          id: Date.now().toString(),
          createdAt: new Date()
        };
        setFeeds(prev => [...prev, newFeed]);
        toast.success('Feed RSS creado exitosamente');
      } else {
        setFeeds(prev => prev.map(feed =>
          feed.id === editingFeed.id ? editingFeed : feed
        ));
        toast.success('Feed RSS actualizado exitosamente');
      }
      
      setEditingFeed(null);
      setIsCreating(false);
    } catch (error) {
      toast.error('Error al guardar feed RSS');
    }
  };

  const handleToggleFeed = async (feedId: string) => {
    try {
      setFeeds(prev => prev.map(feed =>
        feed.id === feedId
          ? { ...feed, isActive: !feed.isActive }
          : feed
      ));
      
      toast.success('Estado del feed actualizado');
    } catch (error) {
      toast.error('Error al actualizar feed');
    }
  };

  const handleRefreshFeed = async (feedId: string) => {
    try {
      setFeeds(prev => prev.map(feed =>
        feed.id === feedId
          ? { ...feed, lastFetch: new Date(), status: 'active' }
          : feed
      ));
      
      toast.success('Feed actualizado exitosamente');
    } catch (error) {
      toast.error('Error al actualizar feed');
    }
  };

  const handleDeleteFeed = async (feedId: string) => {
    if (!confirm('¿Estás seguro de eliminar este feed RSS?')) return;
    
    try {
      setFeeds(prev => prev.filter(feed => feed.id !== feedId));
      if (selectedFeed === feedId) {
        setSelectedFeed(feeds[0]?.id || null);
      }
      toast.success('Feed RSS eliminado');
    } catch (error) {
      toast.error('Error al eliminar feed');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'ford': return 'bg-blue-100 text-blue-800';
      case 'automotive': return 'bg-purple-100 text-purple-800';
      case 'news': return 'bg-orange-100 text-orange-800';
      case 'local': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
          <div className="h-10 bg-gray-300 rounded w-32 animate-pulse" />
        </div>
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="h-96 bg-gray-200 rounded-lg animate-pulse" />
          <div className="lg:col-span-2 h-96 bg-gray-200 rounded-lg animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Gestión de RSS Feeds</h1>
          <p className="text-gray-600">
            {feeds.length} feeds • {feeds.filter(f => f.isActive).length} activos
          </p>
        </div>
        <FordButton onClick={handleCreateFeed}>
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Feed
        </FordButton>
      </div>

      {/* Tabs para feeds y generador embebido */}
      <Tabs defaultValue="feeds" className="w-full">
        <TabsList>
          <TabsTrigger value="feeds">Gestión de Feeds</TabsTrigger>
          <TabsTrigger value="embed">Código Embebido</TabsTrigger>
        </TabsList>
        
        <TabsContent value="feeds" className="space-y-6 mt-6">
          {/* Contenido original de feeds */}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Feeds List */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-800">Feeds RSS</h2>
          
          {feeds.map((feed, index) => (
            <motion.div
              key={feed.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <FordCard 
                className={`p-4 cursor-pointer transition-all ${
                  selectedFeed === feed.id ? 'ring-2 ring-[#003478] bg-blue-50' : ''
                }`}
                onClick={() => setSelectedFeed(feed.id)}
                hover
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-800 line-clamp-1">
                      {feed.title}
                    </h3>
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {feed.description || 'Sin descripción'}
                    </p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(feed.status)}`}>
                      {feed.status}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <span className={`px-2 py-1 rounded ${getCategoryColor(feed.category)}`}>
                    {feed.category}
                  </span>
                  <span>{feed.itemCount} items</span>
                </div>

                {feed.lastFetch && (
                  <div className="flex items-center text-xs text-gray-500 mb-3">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>Actualizado: {feed.lastFetch.toLocaleString('es-HN')}</span>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex space-x-1">
                    <FordButton 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEditFeed(feed);
                      }}
                    >
                      <Edit className="w-3 h-3" />
                    </FordButton>
                    
                    <FordButton 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRefreshFeed(feed.id);
                      }}
                    >
                      <RefreshCw className="w-3 h-3" />
                    </FordButton>
                    
                    <FordButton 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFeed(feed.id);
                      }}
                    >
                      <Trash2 className="w-3 h-3 text-red-600" />
                    </FordButton>
                  </div>
                  
                  <FordButton
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleFeed(feed.id);
                    }}
                  >
                    {feed.isActive ? (
                      <Eye className="w-3 h-3 text-green-600" />
                    ) : (
                      <EyeOff className="w-3 h-3 text-gray-400" />
                    )}
                  </FordButton>
                </div>
              </FordCard>
            </motion.div>
          ))}

          {feeds.length === 0 && (
            <FordCard className="p-8 text-center">
              <Rss className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold text-gray-800 mb-2">No hay feeds RSS</h3>
              <p className="text-gray-600 text-sm mb-4">
                Crea tu primer feed RSS para mostrar noticias en el portal.
              </p>
              <FordButton size="sm" onClick={handleCreateFeed}>
                <Plus className="w-4 h-4 mr-2" />
                Crear Feed
              </FordButton>
            </FordCard>
          )}
        </div>

        {/* Feed Items */}
        <div className="lg:col-span-2">
          {selectedFeed ? (
            <FordCard className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-800">
                  Elementos del Feed
                </h2>
                <div className="flex items-center space-x-2">
                  <FordButton variant="outline" size="sm">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Actualizar
                  </FordButton>
                  <FordButton variant="outline" size="sm">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver Feed
                  </FordButton>
                </div>
              </div>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {items.map((item, index) => (
                  <motion.div
                    key={item.id}
                    className="border-b border-gray-200 pb-4 last:border-b-0"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800 mb-1 line-clamp-2">
                          {item.title}
                        </h3>
                        <p className="text-sm text-gray-600 line-clamp-3 mb-2">
                          {item.description}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>
                            {item.pubDate?.toLocaleDateString('es-HN')} • {item.pubDate?.toLocaleTimeString('es-HN')}
                          </span>
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[#003478] hover:underline flex items-center"
                          >
                            Ver original <ExternalLink className="w-3 h-3 ml-1" />
                          </a>
                        </div>
                      </div>
                      
                      <div className="ml-4 flex items-center space-x-2">
                        <FordButton variant="ghost" size="sm">
                          {item.isVisible ? (
                            <Eye className="w-4 h-4 text-green-600" />
                          ) : (
                            <EyeOff className="w-4 h-4 text-gray-400" />
                          )}
                        </FordButton>
                      </div>
                    </div>
                  </motion.div>
                ))}

                {items.length === 0 && (
                  <div className="text-center py-8">
                    <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="font-semibold text-gray-800 mb-2">
                      No hay elementos disponibles
                    </h3>
                    <p className="text-gray-600 text-sm">
                      El feed no ha sido actualizado o no contiene elementos válidos.
                    </p>
                  </div>
                )}
              </div>
            </FordCard>
          ) : (
            <FordCard className="p-12 text-center">
              <Rss className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                Selecciona un Feed RSS
              </h3>
              <p className="text-gray-600">
                Elige un feed de la lista para ver sus elementos y configuración.
              </p>
            </FordCard>
          )}
        </div>
      </div>

      {/* Edit/Create Feed Modal */}
      {editingFeed && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-800">
                  {isCreating ? 'Crear Nuevo Feed RSS' : `Editar Feed: ${editingFeed.title}`}
                </h2>
                <button
                  onClick={() => {
                    setEditingFeed(null);
                    setIsCreating(false);
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Título *
                  </label>
                  <input
                    type="text"
                    value={editingFeed.title}
                    onChange={(e) => setEditingFeed(prev => 
                      prev ? {...prev, title: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="Nombre del feed RSS"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Descripción
                  </label>
                  <textarea
                    value={editingFeed.description || ''}
                    onChange={(e) => setEditingFeed(prev => 
                      prev ? {...prev, description: e.target.value} : null
                    )}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="Descripción del feed (opcional)"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    URL del Feed RSS *
                  </label>
                  <input
                    type="url"
                    value={editingFeed.url}
                    onChange={(e) => setEditingFeed(prev => 
                      prev ? {...prev, url: e.target.value} : null
                    )}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    placeholder="https://ejemplo.com/rss.xml"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Categoría
                    </label>
                    <select
                      value={editingFeed.category}
                      onChange={(e) => setEditingFeed(prev => 
                        prev ? {...prev, category: e.target.value} : null
                      )}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    >
                      <option value="news">Noticias</option>
                      <option value="ford">Ford</option>
                      <option value="automotive">Automotriz</option>
                      <option value="local">Local</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Frecuencia de Actualización (minutos)
                    </label>
                    <input
                      type="number"
                      min="15"
                      max="1440"
                      value={editingFeed.updateFreq}
                      onChange={(e) => setEditingFeed(prev => 
                        prev ? {...prev, updateFreq: parseInt(e.target.value)} : null
                      )}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={editingFeed.isActive}
                    onChange={(e) => setEditingFeed(prev => 
                      prev ? {...prev, isActive: e.target.checked} : null
                    )}
                    className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                  />
                  <label htmlFor="isActive" className="text-sm text-gray-700">
                    Feed activo
                  </label>
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6 pt-6 border-t">
                <FordButton
                  variant="outline"
                  onClick={() => {
                    setEditingFeed(null);
                    setIsCreating(false);
                  }}
                >
                  Cancelar
                </FordButton>
                <FordButton onClick={handleSaveFeed}>
                  <Save className="w-4 h-4 mr-2" />
                  {isCreating ? 'Crear Feed' : 'Guardar Cambios'}
                </FordButton>
              </div>
            </div>
          </motion.div>
        </div>
      )}
        </TabsContent>
        
        <TabsContent value="embed" className="space-y-6 mt-6">
          <RssEmbedGenerator feeds={feeds} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
