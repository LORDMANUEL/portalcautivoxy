
/**
 * API Route para generador de códigos QR y vCards
 * 
 * Funcionalidades:
 * - GET: Listar vCards creadas
 * - POST: Crear nueva vCard y generar QR
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'
import QRCode from 'qrcode'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'

const createVCardSchema = z.object({
  advisorName: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  position: z.string().optional(),
  email: z.string().email('Email inválido'),
  phone: z.string().optional(),
  company: z.string().default('Ford Yude Canahuati'),
  address: z.string().optional(),
  website: z.string().optional(),
  photo: z.string().optional()
})

export const dynamic = "force-dynamic"

/**
 * Generar string vCard
 */
function generateVCardString(data: any): string {
  const vcard = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${data.advisorName}`,
    `EMAIL:${data.email}`,
    `TEL:${data.phone || ''}`,
    `ORG:${data.company}`,
    `TITLE:${data.position || ''}`,
    `ADR:;;${data.address || ''};;;`,
    `URL:${data.website || ''}`,
    'END:VCARD'
  ].join('\n')
  
  return vcard
}

/**
 * GET /api/admin/qr-generator
 * Obtener lista de vCards
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1', 10)
    const pageSize = parseInt(searchParams.get('pageSize') || '20', 10)
    const search = searchParams.get('search') || ''

    const skip = (page - 1) * pageSize

    // Construir filtros
    const where: any = {}
    
    if (search) {
      where.OR = [
        { advisorName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { position: { contains: search, mode: 'insensitive' } },
        { company: { contains: search, mode: 'insensitive' } }
      ]
    }

    const [vcards, total] = await Promise.all([
      prisma.vCard.findMany({
        where,
        skip,
        take: pageSize,
        orderBy: [
          { isActive: 'desc' },
          { createdAt: 'desc' }
        ]
      }),
      prisma.vCard.count({ where })
    ])

    return NextResponse.json({
      success: true,
      data: vcards,
      meta: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize)
      }
    })

  } catch (error) {
    console.error('Error fetching vCards:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/admin/qr-generator
 * Crear nueva vCard y generar QR
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = createVCardSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const vcardData = validation.data

    // Generar string vCard
    const vcardString = generateVCardString(vcardData)

    // Crear directorio si no existe
    const qrDir = join(process.cwd(), 'public', 'qr-codes')
    try {
      await mkdir(qrDir, { recursive: true })
    } catch (error) {
      // Directorio ya existe
    }

    // Generar nombre de archivo único
    const timestamp = Date.now()
    const fileName = `vcard_${timestamp}.png`
    const filePath = join(qrDir, fileName)

    // Generar código QR
    const qrCodeBuffer = await QRCode.toBuffer(vcardString, {
      type: 'png',
      width: 512,
      margin: 2,
      color: {
        dark: '#003478', // Ford Blue
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    })

    // Guardar archivo QR
    await writeFile(filePath, qrCodeBuffer)

    const qrCodeUrl = `/qr-codes/${fileName}`

    // Guardar vCard en base de datos
    const vcard = await prisma.vCard.create({
      data: {
        ...vcardData,
        qrCode: qrCodeUrl,
        isActive: true,
        downloadCount: 0
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        ...vcard,
        vcardString,
        qrCodeBase64: `data:image/png;base64,${qrCodeBuffer.toString('base64')}`
      },
      message: 'vCard y código QR creados exitosamente'
    }, { status: 201 })

  } catch (error) {
    console.error('Error creating vCard:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
