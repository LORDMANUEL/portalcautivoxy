
import { Metadata } from 'next';
import { BannersClient } from './_components/banners-client';

export const metadata: Metadata = {
  title: 'Gestión de Banners - Admin Ford',
  description: 'Administrar banners promocionales del portal cautivo',
};

export default function AdminBannersPage() {
  return <BannersClient />;
}
