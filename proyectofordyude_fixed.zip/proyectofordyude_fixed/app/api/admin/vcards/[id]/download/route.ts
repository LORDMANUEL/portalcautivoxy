

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import QRCode from 'qrcode';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/vcards/[id]/download
 * Descarga el código QR como archivo PNG
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Obtener la vCard
    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    });

    if (!vcard) {
      return NextResponse.json({ error: 'vCard no encontrada' }, { status: 404 });
    }

    // Crear URL de contacto para QR (consistente con la creación)
    const contactUrl = `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/contact/${vcard.id}`;

    // Generar código QR como buffer PNG
    const qrBuffer = await QRCode.toBuffer(contactUrl, {
      type: 'png',
      width: 400,
      margin: 2,
      color: {
        dark: '#003478',
        light: '#FFFFFF'
      }
    });

    // Incrementar contador de descargas
    await prisma.vCard.update({
      where: { id: params.id },
      data: {
        downloadCount: {
          increment: 1
        }
      }
    });

    // Retornar el archivo PNG
    return new NextResponse(qrBuffer, {
      headers: {
        'Content-Type': 'image/png',
        'Content-Disposition': `attachment; filename="qr-${vcard.advisorName.replace(/\s+/g, '-').toLowerCase()}.png"`
      }
    });
  } catch (error) {
    console.error('Error al generar QR PNG:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
