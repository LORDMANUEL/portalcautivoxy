
import { unstable_cache } from 'next/cache';
import type { Prisma } from '@prisma/client';

// Cache utility para consultas de base de datos
export class CacheManager {
  private static readonly CACHE_TAGS = {
    USERS: 'users',
    PORTALS: 'portals',
    THEMES: 'themes',
    REPORTS: 'reports',
    ANALYTICS: 'analytics',
    NOTIFICATIONS: 'notifications',
  } as const;

  // Cache para usuarios
  static cacheUsers = (fn: () => Promise<any>) =>
    unstable_cache(fn, ['users'], {
      tags: [this.CACHE_TAGS.USERS],
      revalidate: 300, // 5 minutos
    });

  // Cache para portales
  static cachePortals = (fn: () => Promise<any>) =>
    unstable_cache(fn, ['portals'], {
      tags: [this.CACHE_TAGS.PORTALS],
      revalidate: 600, // 10 minutos
    });

  // Cache para temas
  static cacheThemes = (fn: () => Promise<any>) =>
    unstable_cache(fn, ['themes'], {
      tags: [this.CACHE_TAGS.THEMES],
      revalidate: 1800, // 30 minutos
    });

  // Cache para reportes
  static cacheReports = (fn: () => Promise<any>) =>
    unstable_cache(fn, ['reports'], {
      tags: [this.CACHE_TAGS.REPORTS],
      revalidate: 900, // 15 minutos
    });

  // Cache para analytics
  static cacheAnalytics = (fn: () => Promise<any>) =>
    unstable_cache(fn, ['analytics'], {
      tags: [this.CACHE_TAGS.ANALYTICS],
      revalidate: 180, // 3 minutos
    });

  // Invalidar cache específico
  static async invalidateCache(tag: keyof typeof this.CACHE_TAGS) {
    const { revalidateTag } = await import('next/cache');
    revalidateTag(this.CACHE_TAGS[tag]);
  }

  // Invalidar todo el cache
  static async invalidateAllCache() {
    const { revalidateTag } = await import('next/cache');
    Object.values(this.CACHE_TAGS).forEach(tag => revalidateTag(tag));
  }
}

// Redis cache (simulado con Map para esta implementación)
class MemoryCache {
  private cache = new Map<string, { value: any; expiry: number }>();
  
  set(key: string, value: any, ttl: number = 300000) { // 5 min default
    const expiry = Date.now() + ttl;
    this.cache.set(key, { value, expiry });
  }
  
  get(key: string) {
    const item = this.cache.get(key);
    if (!item) return null;
    
    if (Date.now() > item.expiry) {
      this.cache.delete(key);
      return null;
    }
    
    return item.value;
  }
  
  delete(key: string) {
    this.cache.delete(key);
  }
  
  clear() {
    this.cache.clear();
  }
  
  // Limpiar cache expirado
  cleanup() {
    const now = Date.now();
    for (const [key, item] of this.cache.entries()) {
      if (now > item.expiry) {
        this.cache.delete(key);
      }
    }
  }
}

export const memoryCache = new MemoryCache();

// Cleanup automático cada 5 minutos
if (typeof window === 'undefined') {
  setInterval(() => {
    memoryCache.cleanup();
  }, 300000);
}
