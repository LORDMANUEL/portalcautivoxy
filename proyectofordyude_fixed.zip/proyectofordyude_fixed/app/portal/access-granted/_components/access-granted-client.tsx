
'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { 
  CheckCircle, 
  Wifi, 
  Clock, 
  Globe, 
  Car,
  Smartphone,
  ArrowRight,
  Shield,
  Zap,
  Heart,
  Users,
  Flag,
  Gift,
  Sun,
  Signal,
  Router,
  MapPin,
  Calendar,
  Activity
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { Progress } from '@/components/ui/progress';
import { fordAssets } from '@/lib/ford-assets';

interface ActiveTheme {
  id: string;
  name: string;
  displayName: string;
  description?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor?: string;
  backgroundImage?: string;
  logoImage?: string;
  metadata?: {
    welcomeMessage?: string;
    rssCategory?: string;
    promotionType?: string;
  };
}

interface ConnectionInfo {
  ssid: string;
  portalType: string;
  location: string;
  speed: string;
  connectedAt: string;
  ipAddress: string;
  deviceId: string;
  sessionId: string;
}

interface UserInfo {
  name?: string;
  email?: string;
  phone?: string;
}

const THEME_ICONS = {
  mother: Heart,
  woman: Users,
  man: Users,
  independence: Flag,
  xmas: Gift,
  summer: Sun,
  default: CheckCircle
};

/**
 * Página de confirmación "Acceso Garantizado"
 * Se muestra después de completar el formulario cautivo con información real de conexión
 */
export function AccessGrantedClient() {
  const searchParams = useSearchParams();
  const [progress, setProgress] = useState(0);
  const [isConnecting, setIsConnecting] = useState(true);
  const [activeTheme, setActiveTheme] = useState<ActiveTheme | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectionInfo, setConnectionInfo] = useState<ConnectionInfo | null>(null);
  const [userInfo, setUserInfo] = useState<UserInfo>({});

  useEffect(() => {
    // Cargar tema activo y datos de conexión
    loadActiveTheme();
    loadConnectionInfo();
    loadUserInfo();
  }, []);

  useEffect(() => {
    // Simular progreso de conexión
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setIsConnecting(false);
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 300);

    return () => clearInterval(interval);
  }, []);

  const loadConnectionInfo = () => {
    // Obtener información de conexión de parámetros URL o localStorage
    const portalType = searchParams.get('portal') || localStorage.getItem('lastPortal') || 'ford-traditional';
    const userAgent = navigator.userAgent;
    const connectedAt = new Date().toLocaleString();
    
    // Configuraciones por tipo de portal
    const portalConfigs = {
      'ford-traditional': {
        ssid: 'Ford_WiFi_Free',
        location: 'Ford Yude Canahuati - San Pedro Sula',
        speed: '100 Mbps'
      },
      'quicklane-truck': {
        ssid: 'QuickLane_Truck_WiFi',
        location: 'QuickLane Truck - San Pedro Sula',
        speed: '50 Mbps'
      },
      'quicklane-tegus': {
        ssid: 'QuickLane_Tegus_WiFi',
        location: 'QuickLane Tegucigalpa',
        speed: '75 Mbps'
      },
      'quicklane-sps': {
        ssid: 'QuickLane_SPS_WiFi',
        location: 'QuickLane San Pedro Sula',
        speed: '75 Mbps'
      }
    };

    const config = portalConfigs[portalType as keyof typeof portalConfigs] || portalConfigs['ford-traditional'];
    
    setConnectionInfo({
      ssid: config.ssid,
      portalType,
      location: config.location,
      speed: config.speed,
      connectedAt,
      ipAddress: '192.168.1.' + Math.floor(Math.random() * 100 + 100),
      deviceId: userAgent.includes('Mobile') ? 'Móvil' : 'PC',
      sessionId: 'FORD-' + Date.now().toString().slice(-8)
    });
  };

  const loadUserInfo = () => {
    // Obtener información del usuario de localStorage (guardada en el portal cautivo)
    const savedUserInfo = localStorage.getItem('connectedUser');
    if (savedUserInfo) {
      try {
        const parsed = JSON.parse(savedUserInfo);
        setUserInfo(parsed);
      } catch (error) {
        console.error('Error parsing user info:', error);
      }
    }
  };

  const loadActiveTheme = async () => {
    try {
      const response = await fetch('/api/themes/active');
      if (response.ok) {
        const theme = await response.json();
        setActiveTheme(theme);
      }
    } catch (error) {
      console.error('Error al cargar tema activo:', error);
      // Fallback theme
      setActiveTheme({
        id: 'fallback',
        name: 'default',
        displayName: 'Tema Por Defecto',
        primaryColor: '#003478',
        secondaryColor: '#FFFFFF',
        accentColor: '#0056b3',
        metadata: {
          welcomeMessage: 'Bienvenido a Ford WiFi'
        }
      });
    } finally {
      setLoading(false);
    }
  };

  // Obtener el icono del tema
  const getThemeIcon = () => {
    if (!activeTheme) return CheckCircle;
    const IconComponent = THEME_ICONS[activeTheme.name as keyof typeof THEME_ICONS] || CheckCircle;
    return IconComponent;
  };

  // Obtener el mensaje de bienvenida
  const getWelcomeMessage = () => {
    if (!activeTheme?.metadata?.welcomeMessage) {
      return '¡Acceso Garantizado!';
    }
    return activeTheme.metadata.welcomeMessage;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#003478] mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    );
  }

  // Obtener estilos dinámicos del tema
  const dynamicStyles = {
    backgroundColor: activeTheme?.secondaryColor || '#FFFFFF',
    backgroundImage: activeTheme?.backgroundImage ? `url(${activeTheme.backgroundImage})` : undefined,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat'
  };

  const ThemeIcon = getThemeIcon();

  return (
    <motion.div 
      className="min-h-screen relative"
      style={activeTheme?.backgroundImage ? dynamicStyles : undefined}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1.2, ease: "easeOut" }}
    >
      {/* Overlay animado para mejorar legibilidad cuando hay imagen de fondo */}
      {activeTheme?.backgroundImage && (
        <motion.div 
          className="absolute inset-0 bg-black bg-opacity-40 z-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        />
      )}
      
      {/* Efecto de partículas sutiles para temas especiales */}
      {activeTheme?.name !== 'default' && (
        <motion.div
          className="absolute inset-0 z-0 pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.1 }}
          transition={{ duration: 2, delay: 1 }}
        >
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, ${activeTheme?.primaryColor}40 0%, transparent 50%), radial-gradient(circle at 75% 75%, ${activeTheme?.accentColor || activeTheme?.primaryColor}30 0%, transparent 50%)`,
            backgroundAttachment: 'fixed'
          }} />
        </motion.div>
      )}
      
      {/* Contenido principal */}
      <div className="relative z-10">
        {/* Header con animaciones suaves */}
        <motion.div 
          className="shadow-sm border-b backdrop-blur-sm"
          style={{ 
            backgroundColor: activeTheme?.backgroundImage 
              ? 'rgba(255, 255, 255, 0.95)' 
              : activeTheme?.secondaryColor || '#FFFFFF'
          }}
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="max-w-4xl mx-auto px-4 py-4">
            <motion.div 
              className="flex items-center justify-center"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="relative w-32 h-16">
                <Image
                  src={fordAssets.logos.official_transparent[0].url}
                  alt="Ford Logo"
                  fill
                  className="object-contain transition-all duration-500 hover:scale-105"
                  priority
                />
                
                {/* Efecto de brillo sutil en el logo */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0"
                  animate={{ 
                    opacity: [0, 0.3, 0], 
                    x: [-100, 100] 
                  }}
                  transition={{ 
                    duration: 3, 
                    repeat: Infinity, 
                    repeatDelay: 5,
                    ease: "easeInOut"
                  }}
                />
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* Contenido Principal */}
        <div className="max-w-2xl mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <FordCard 
              className="text-center backdrop-blur-sm"
              style={{
                backgroundColor: activeTheme?.backgroundImage 
                  ? 'rgba(255, 255, 255, 0.95)' 
                  : undefined
              }}
            >
              <div className="p-8 space-y-6">
                {/* Icon de éxito temático */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="flex justify-center"
                >
                  <div 
                    className="w-20 h-20 rounded-full flex items-center justify-center"
                    style={{
                      backgroundColor: activeTheme?.primaryColor ? `${activeTheme.primaryColor}20` : '#22c55e20'
                    }}
                  >
                    <ThemeIcon 
                      className="w-12 h-12" 
                      style={{ color: activeTheme?.primaryColor || '#22c55e' }}
                    />
                  </div>
                </motion.div>

                {/* Título personalizado */}
                <div className="space-y-3">
                  <h1 
                    className="text-3xl font-bold"
                    style={{ color: activeTheme?.primaryColor || '#1f2937' }}
                  >
                    {getWelcomeMessage()}
                  </h1>
                  <p className="text-gray-600 text-lg">
                    Tu solicitud ha sido procesada exitosamente
                  </p>
                </div>

                {/* Barra de progreso */}
                {isConnecting ? (
                  <div className="space-y-3">
                    <div 
                      className="flex items-center justify-center space-x-2 font-medium"
                      style={{ color: activeTheme?.primaryColor || '#003478' }}
                    >
                      <Wifi className="w-5 h-5 animate-pulse" />
                      <span>Estableciendo conexión...</span>
                    </div>
                    <Progress 
                      value={progress} 
                      className="w-full"
                      style={{ 
                        '--progress-background': activeTheme?.primaryColor || '#003478'
                      } as React.CSSProperties}
                    />
                    <p className="text-sm text-gray-500">{progress}% completado</p>
                  </div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="space-y-4"
                  >
                    <div 
                      className="flex items-center justify-center space-x-2 font-medium"
                      style={{ color: activeTheme?.primaryColor || '#22c55e' }}
                    >
                      <Shield className="w-5 h-5" />
                      <span>Conexión establecida</span>
                    </div>
                    
                    {/* Información de conexión real */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                      <div 
                        className="p-4 rounded-lg border"
                        style={{ 
                          backgroundColor: activeTheme?.primaryColor ? `${activeTheme.primaryColor}05` : '#f8fafc',
                          borderColor: activeTheme?.primaryColor ? `${activeTheme.primaryColor}20` : '#e2e8f0'
                        }}
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <Wifi 
                            className="w-6 h-6" 
                            style={{ color: activeTheme?.primaryColor || '#003478' }}
                          />
                          <h3 className="font-medium text-gray-800">Información de Red</h3>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">SSID:</span>
                            <span className="font-medium">{connectionInfo?.ssid || 'Ford_WiFi_Free'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">IP:</span>
                            <span className="font-medium">{connectionInfo?.ipAddress || '192.168.1.100'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Velocidad:</span>
                            <span className="font-medium text-green-600">{connectionInfo?.speed || '100 Mbps'}</span>
                          </div>
                        </div>
                      </div>

                      <div 
                        className="p-4 rounded-lg border"
                        style={{ 
                          backgroundColor: activeTheme?.accentColor ? `${activeTheme.accentColor}05` : '#f0fdf4',
                          borderColor: activeTheme?.accentColor ? `${activeTheme.accentColor}20` : '#bbf7d0'
                        }}
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <MapPin 
                            className="w-6 h-6" 
                            style={{ color: activeTheme?.accentColor || '#22c55e' }}
                          />
                          <h3 className="font-medium text-gray-800">Ubicación</h3>
                        </div>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Portal:</span>
                            <span className="font-medium">{connectionInfo?.portalType?.replace('-', ' ').toUpperCase() || 'FORD'}</span>
                          </div>
                          <div className="text-gray-600 text-xs leading-relaxed">
                            {connectionInfo?.location || 'Ford Yude Canahuati - San Pedro Sula'}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Información de sesión y usuario */}
                    {(connectionInfo || userInfo.name) && (
                      <div 
                        className="mt-4 p-4 rounded-lg border"
                        style={{ 
                          backgroundColor: activeTheme?.primaryColor ? `${activeTheme.primaryColor}03` : '#fafafa',
                          borderColor: activeTheme?.primaryColor ? `${activeTheme.primaryColor}15` : '#e5e5e5'
                        }}
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <Activity 
                            className="w-5 h-5" 
                            style={{ color: activeTheme?.primaryColor || '#003478' }}
                          />
                          <h4 className="font-medium text-gray-800">Detalles de Sesión</h4>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Usuario:</span>
                            <div className="font-medium">{userInfo.name || 'Invitado'}</div>
                          </div>
                          <div>
                            <span className="text-gray-600">Conectado:</span>
                            <div className="font-medium">{connectionInfo?.connectedAt || new Date().toLocaleString()}</div>
                          </div>
                          <div>
                            <span className="text-gray-600">Dispositivo:</span>
                            <div className="font-medium">{connectionInfo?.deviceId || 'Desconocido'}</div>
                          </div>
                        </div>
                        {connectionInfo?.sessionId && (
                          <div className="mt-2 pt-2 border-t border-gray-200">
                            <span className="text-xs text-gray-500">
                              ID de Sesión: {connectionInfo.sessionId}
                            </span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Estado de conexión */}
                    <div className="flex items-center justify-center space-x-6 mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center space-x-2 text-green-700">
                        <Signal className="w-5 h-5" />
                        <span className="font-medium">Señal Excelente</span>
                      </div>
                      <div className="flex items-center space-x-2 text-green-700">
                        <Shield className="w-5 h-5" />
                        <span className="font-medium">Conexión Segura</span>
                      </div>
                      <div className="flex items-center space-x-2 text-green-700">
                        <Clock className="w-5 h-5" />
                        <span className="font-medium">24/7 Disponible</span>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* Botones de acción */}
                {!isConnecting && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                    className="space-y-4"
                  >
                    <FordButton 
                      className="w-full"
                      onClick={() => window.location.href = '/portal/internet-ready'}
                      style={{
                        backgroundColor: activeTheme?.primaryColor || '#003478',
                        borderColor: activeTheme?.primaryColor || '#003478'
                      }}
                    >
                      <Globe className="w-4 h-4 mr-2" />
                      Ir a Portal Principal
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </FordButton>
                    
                    <div className="flex space-x-3">
                      <FordButton 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => window.open('https://www.yudecanahuati.com', '_blank')}
                        style={{
                          borderColor: activeTheme?.primaryColor || '#003478',
                          color: activeTheme?.primaryColor || '#003478'
                        }}
                      >
                        <Car className="w-4 h-4 mr-2" />
                        Ford Yude
                      </FordButton>
                      <FordButton 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => window.location.href = '/admin/login'}
                        style={{
                          borderColor: activeTheme?.accentColor || '#0056b3',
                          color: activeTheme?.accentColor || '#0056b3'
                        }}
                      >
                        <Smartphone className="w-4 h-4 mr-2" />
                        Admin
                      </FordButton>
                    </div>
                  </motion.div>
                )}

                {/* Información adicional */}
                <div className="pt-6 border-t border-gray-200">
                  <p className="text-sm text-gray-500">
                    Gracias por elegir <strong>Ford Yude Canahuati</strong>
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    Tu conexión está protegida y monitoreada
                  </p>
                </div>
              </div>
            </FordCard>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
