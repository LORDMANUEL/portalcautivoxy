
/**
 * API Route para gestión individual de usuarios administradores
 * 
 * Funcionalidades:
 * - GET: Obtener usuario específico
 * - PUT: Actualizar usuario
 * - DELETE: Eliminar usuario
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Prisma } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { z } from 'zod'

const updateUserSchema = z.object({
  username: z.string().min(3).optional(),
  email: z.string().email().optional(),
  name: z.string().min(2).optional(),
  password: z.string().min(6).optional(),
  locationId: z.string().optional(),
  isActive: z.boolean().optional(),
  roles: z.array(z.string()).optional()
})

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/users/[id]
 * Obtener usuario específico
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const user = await prisma.admin.findUnique({
      where: { id: params.id },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true,
            type: true
          }
        },
        roles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true
                  }
                }
              }
            }
          }
        }
      }
    })

    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Usuario no encontrado' },
        { status: 404 }
      )
    }

    // Remover password
    const { password, ...safeUser } = user

    return NextResponse.json({
      success: true,
      data: safeUser
    })

  } catch (error) {
    console.error('Error fetching user:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * PUT /api/admin/users/[id]
 * Actualizar usuario
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const validation = updateUserSchema.safeParse(body)

    if (!validation.success) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Datos inválidos',
          errors: validation.error.errors.map(e => e.message)
        },
        { status: 400 }
      )
    }

    const { username, email, name, password, locationId, isActive, roles } = validation.data

    // Verificar que el usuario existe
    const existingUser = await prisma.admin.findUnique({
      where: { id: params.id }
    })

    if (!existingUser) {
      return NextResponse.json(
        { success: false, message: 'Usuario no encontrado' },
        { status: 404 }
      )
    }

    // Verificar username único (si se está cambiando)
    if (username && username !== existingUser.username) {
      const usernameTaken = await prisma.admin.findUnique({
        where: { username }
      })

      if (usernameTaken) {
        return NextResponse.json(
          { success: false, message: 'El username ya existe' },
          { status: 400 }
        )
      }
    }

    // Verificar email único (si se está cambiando)
    if (email && email !== existingUser.email) {
      const emailTaken = await prisma.admin.findFirst({
        where: { email }
      })

      if (emailTaken) {
        return NextResponse.json(
          { success: false, message: 'El email ya existe' },
          { status: 400 }
        )
      }
    }

    // Preparar datos de actualización
    const updateData: any = {}
    
    if (username !== undefined) updateData.username = username
    if (email !== undefined) updateData.email = email
    if (name !== undefined) updateData.name = name
    if (locationId !== undefined) updateData.locationId = locationId
    if (isActive !== undefined) updateData.isActive = isActive
    
    if (password) {
      updateData.password = await bcrypt.hash(password, 12)
    }

    // Actualizar en transacción
    const updatedUser = await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      // Actualizar usuario
      const user = await tx.admin.update({
        where: { id: params.id },
        data: updateData
      })

      // Actualizar roles si se proporcionaron
      if (roles !== undefined) {
        // Eliminar roles existentes
        await tx.adminRole.deleteMany({
          where: { adminId: params.id }
        })

        // Agregar nuevos roles
        if (roles.length > 0) {
          await tx.adminRole.createMany({
            data: roles.map(roleId => ({
              adminId: params.id,
              roleId,
              assignedBy: session.user.id
            }))
          })
        }
      }

      return user
    })

    // Obtener usuario completo
    const userWithRoles = await prisma.admin.findUnique({
      where: { id: params.id },
      include: {
        location: {
          select: {
            id: true,
            name: true,
            code: true
          }
        },
        roles: {
          include: {
            role: {
              select: {
                id: true,
                name: true,
                displayName: true,
                priority: true
              }
            }
          }
        }
      }
    })

    // Remover password
    const { password: _, ...safeUser } = userWithRoles || {}

    return NextResponse.json({
      success: true,
      data: safeUser,
      message: 'Usuario actualizado exitosamente'
    })

  } catch (error) {
    console.error('Error updating user:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}

/**
 * DELETE /api/admin/users/[id]
 * Eliminar usuario (soft delete)
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    // No permitir auto-eliminación
    if (params.id === session.user.id) {
      return NextResponse.json(
        { success: false, message: 'No puedes eliminar tu propia cuenta' },
        { status: 400 }
      )
    }

    const user = await prisma.admin.findUnique({
      where: { id: params.id }
    })

    if (!user) {
      return NextResponse.json(
        { success: false, message: 'Usuario no encontrado' },
        { status: 404 }
      )
    }

    // Soft delete - marcar como inactivo
    await prisma.admin.update({
      where: { id: params.id },
      data: { 
        isActive: false,
        updatedAt: new Date()
      }
    })

    return NextResponse.json({
      success: true,
      message: 'Usuario eliminado exitosamente'
    })

  } catch (error) {
    console.error('Error deleting user:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
