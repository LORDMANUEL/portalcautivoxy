
/**
 * Diálogo para Ver Detalles de Usuario
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

'use client'

import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { 
  User,
  Mail,
  MapPin,
  Calendar,
  Clock,
  Shield,
  CheckCircle,
  XCircle,
  Eye
} from 'lucide-react'

interface User {
  id: string
  username: string
  name: string
  email?: string
  isActive: boolean
  lastLogin?: string
  locationId?: string
  createdAt: string
  location?: {
    id: string
    name: string
    code: string
  }
  roles: {
    role: {
      id: string
      name: string
      displayName: string
      priority: number
    }
  }[]
}

interface ViewUserDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  user: User
  onClose: () => void
}

export default function ViewUserDialog({
  open,
  onOpenChange,
  user,
  onClose
}: ViewUserDialogProps) {

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }

  const getRoleColor = (priority: number) => {
    if (priority >= 90) return 'bg-red-100 text-red-800 border-red-200'
    if (priority >= 70) return 'bg-blue-100 text-blue-800 border-blue-200'  
    if (priority >= 50) return 'bg-green-100 text-green-800 border-green-200'
    return 'bg-gray-100 text-gray-800 border-gray-200'
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const handleClose = () => {
    onClose()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Detalles del Usuario
          </DialogTitle>
          <DialogDescription>
            Información completa del usuario administrador
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Información Principal */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Información Personal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="text-lg">
                    {getInitials(user.name)}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 space-y-3">
                  <div>
                    <h3 className="text-xl font-semibold">{user.name}</h3>
                    <p className="text-gray-600">@{user.username}</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <Badge
                      variant={user.isActive ? 'default' : 'secondary'}
                      className={
                        user.isActive
                          ? 'bg-green-100 text-green-800 border-green-200'
                          : 'bg-red-100 text-red-800 border-red-200'
                      }
                    >
                      {user.isActive ? (
                        <>
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Activo
                        </>
                      ) : (
                        <>
                          <XCircle className="h-3 w-3 mr-1" />
                          Inactivo
                        </>
                      )}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Email */}
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">
                        {user.email || <span className="text-gray-400">Sin email</span>}
                      </span>
                    </div>

                    {/* Ubicación */}
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">
                        {user.location ? (
                          <>
                            {user.location.name} ({user.location.code})
                          </>
                        ) : (
                          <span className="text-gray-400">Sin ubicación</span>
                        )}
                      </span>
                    </div>

                    {/* Fecha de Creación */}
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">
                        Creado: {formatDate(user.createdAt)}
                      </span>
                    </div>

                    {/* Último Login */}
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">
                        Último login: {user.lastLogin ? formatDate(user.lastLogin) : 'Nunca'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Roles y Permisos */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Roles y Permisos
              </CardTitle>
            </CardHeader>
            <CardContent>
              {user.roles && user.roles.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {user.roles
                      .sort((a, b) => b.role.priority - a.role.priority)
                      .map((userRole) => (
                        <Badge
                          key={userRole.role.id}
                          variant="outline"
                          className={`${getRoleColor(userRole.role.priority)} text-sm`}
                        >
                          {userRole.role.displayName}
                        </Badge>
                      ))}
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900">Descripción de Roles:</h4>
                    <div className="space-y-1">
                      {user.roles.map((userRole) => (
                        <div key={userRole.role.id} className="text-sm">
                          <span className="font-medium">{userRole.role.displayName}:</span>
                          <span className="text-gray-600 ml-1">
                            {userRole.role.name === 'SUPER_ADMIN' && 'Acceso completo al sistema'}
                            {userRole.role.name === 'ADMIN' && 'Acceso administrativo con restricciones'}
                            {userRole.role.name === 'OPERATOR' && 'Acceso operativo para tareas diarias'}
                            {userRole.role.name === 'VIEWER' && 'Solo acceso de lectura'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6">
                  <Shield className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">Sin roles asignados</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Información del Sistema */}
          <Card>
            <CardHeader>
              <CardTitle>Información del Sistema</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-600">ID del Usuario:</span>
                  <p className="font-mono text-xs bg-gray-100 p-1 rounded mt-1">
                    {user.id}
                  </p>
                </div>
                
                <div>
                  <span className="font-medium text-gray-600">Estado de Cuenta:</span>
                  <p className="mt-1">
                    <Badge
                      variant={user.isActive ? 'default' : 'secondary'}
                      className={
                        user.isActive
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }
                    >
                      {user.isActive ? 'Cuenta Activa' : 'Cuenta Suspendida'}
                    </Badge>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleClose}
          >
            Cerrar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
