

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import QRCode from 'qrcode';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/vcards
 * Obtiene todas las vCards creadas
 */
export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const vcards = await prisma.vCard.findMany({
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(vcards);
  } catch (error) {
    console.error('Error al obtener vCards:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * POST /api/admin/vcards
 * Crea una nueva vCard con código QR
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { advisorName, position, email, phone, company, address, website, photo } = body;

    if (!advisorName || !email) {
      return NextResponse.json({ error: 'Nombre y email son obligatorios' }, { status: 400 });
    }

    // Crear la vCard en la base de datos primero para obtener el ID
    const vcard = await prisma.vCard.create({
      data: {
        advisorName,
        position: position || null,
        email,
        phone: phone || null,
        company,
        address: address || null,
        website: website || null,
        photo: photo || null,
        qrCode: '', // Se actualizará después
        isActive: true
      }
    });

    // Crear URL de contacto para QR
    const contactUrl = `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/contact/${vcard.id}`;

    // Generar código QR que apunta a página web
    const qrCodeDataUrl = await QRCode.toDataURL(contactUrl, {
      width: 400,
      margin: 2,
      color: {
        dark: '#003478',
        light: '#FFFFFF'
      }
    });

    // Actualizar la vCard con el código QR generado
    const updatedVCard = await prisma.vCard.update({
      where: { id: vcard.id },
      data: {
        qrCode: qrCodeDataUrl
      }
    });

    return NextResponse.json(updatedVCard);
  } catch (error) {
    console.error('Error al crear vCard:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
