
import { Metadata } from 'next';
import { ImageManagerClient } from './_components/image-manager-client';

export const metadata: Metadata = {
  title: 'Gestor de Imágenes - Admin Ford',
  description: 'Administrador de imágenes para portales cautivos y temas',
};

export default function ImageManagerPage() {
  return <ImageManagerClient />;
}
