
import { Metadata } from 'next';
import { InternetReadyEditorClient } from './_components/internet-ready-editor-client';

export const metadata: Metadata = {
  title: 'Editor Internet-Ready - Admin Ford',
  description: 'Editor para personalizar la página "Ya tienes Internet"',
};

export default function InternetReadyEditorPage() {
  return <InternetReadyEditorClient />;
}
