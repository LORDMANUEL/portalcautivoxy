
import { Metadata } from 'next';
import { AccessGrantedClient } from './_components/access-granted-client';

export const metadata: Metadata = {
  title: 'Acceso Garantizado - Ford Yude Canahuati',
  description: 'Tu acceso a internet ha sido garantizado. Bienvenido al portal Ford Yude Canahuati.',
};

export default function AccessGrantedPage() {
  return <AccessGrantedClient />;
}
