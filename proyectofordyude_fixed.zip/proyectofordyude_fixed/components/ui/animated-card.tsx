
"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import React from "react";

interface AnimatedCardProps {
  className?: string;
  delay?: number;
  direction?: "up" | "down" | "left" | "right" | "scale";
  hover?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

const variants = {
  up: {
    initial: { opacity: 0, y: 50 },
    animate: { opacity: 1, y: 0 },
  },
  down: {
    initial: { opacity: 0, y: -50 },
    animate: { opacity: 1, y: 0 },
  },
  left: {
    initial: { opacity: 0, x: -50 },
    animate: { opacity: 1, x: 0 },
  },
  right: {
    initial: { opacity: 0, x: 50 },
    animate: { opacity: 1, x: 0 },
  },
  scale: {
    initial: { opacity: 0, scale: 0.9 },
    animate: { opacity: 1, scale: 1 },
  },
};

const hoverVariants = {
  hover: {
    scale: 1.02,
    y: -5,
    boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
    transition: {
      duration: 0.3,
      ease: "easeOut",
    },
  },
};

export function AnimatedCard({
  className,
  delay = 0,
  direction = "up",
  hover = false,
  children,
  style,
}: AnimatedCardProps) {
  return (
    <motion.div
      initial="initial"
      animate="animate"
      whileHover={hover ? "hover" : undefined}
      variants={{
        ...variants[direction],
        ...(hover ? hoverVariants : {}),
      }}
      transition={{
        duration: 0.5,
        delay,
        ease: "easeOut",
      }}
      className={cn(
        "rounded-lg border bg-card text-card-foreground shadow-sm transition-all duration-300",
        hover && "cursor-pointer",
        className
      )}
      style={style}
    >
      {children}
    </motion.div>
  );
}
