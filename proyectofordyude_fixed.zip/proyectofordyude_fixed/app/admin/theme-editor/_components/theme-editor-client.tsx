

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  PaintBucket,
  Save,
  Eye,
  Undo,
  Redo,
  Palette,
  Type,
  Layout,
  Image,
  Settings,
  Download,
  Upload,
  RefreshCw
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

interface ThemeConfig {
  id: string;
  name: string;
  displayName: string;
  description: string;
  isActive: boolean;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundImage: string;
  logoImage: string;
  customCss: string;
  customJs: string;
  config: {
    logoPosition: string;
    headerHeight: number;
    footerEnabled: boolean;
    animationsEnabled: boolean;
    parallaxEnabled: boolean;
    customFonts: any;
    buttonStyles: any;
    cardStyles: any;
    layoutConfig: any;
    responsiveConfig: any;
  };
}

/**
 * Editor visual de temas para portales cautivos
 * Permite personalizar colores, fuentes, layout y elementos visuales
 */
export function ThemeEditorClient() {
  const [themes, setThemes] = useState<ThemeConfig[]>([]);
  const [selectedTheme, setSelectedTheme] = useState<ThemeConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  // Estados para el editor
  const [primaryColor, setPrimaryColor] = useState('#003478');
  const [secondaryColor, setSecondaryColor] = useState('#FFFFFF');
  const [accentColor, setAccentColor] = useState('#47A8E5');
  const [backgroundImage, setBackgroundImage] = useState('');
  const [logoImage, setLogoImage] = useState('');
  const [customCss, setCustomCss] = useState('');
  const [customJs, setCustomJs] = useState('');
  
  // Configuraciones avanzadas
  const [logoPosition, setLogoPosition] = useState('center');
  const [headerHeight, setHeaderHeight] = useState([80]);
  const [footerEnabled, setFooterEnabled] = useState(true);
  const [animationsEnabled, setAnimationsEnabled] = useState(true);
  const [parallaxEnabled, setParallaxEnabled] = useState(false);

  useEffect(() => {
    fetchThemes();
  }, []);

  /**
   * Obtiene todos los temas disponibles
   */
  const fetchThemes = async () => {
    try {
      const response = await fetch('/api/admin/themes');
      if (response.ok) {
        const data = await response.json();
        setThemes(data);
        if (data.length > 0) {
          selectTheme(data[0]);
        }
      } else {
        toast.error('Error al cargar los temas');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Selecciona un tema para editar
   */
  const selectTheme = (theme: ThemeConfig) => {
    setSelectedTheme(theme);
    setPrimaryColor(theme.primaryColor);
    setSecondaryColor(theme.secondaryColor);
    setAccentColor(theme.accentColor || '#47A8E5');
    setBackgroundImage(theme.backgroundImage || '');
    setLogoImage(theme.logoImage || '');
    setCustomCss(theme.customCss || '');
    setCustomJs(theme.customJs || '');
    
    // Configuraciones avanzadas
    if (theme.config) {
      setLogoPosition(theme.config.logoPosition || 'center');
      setHeaderHeight([theme.config.headerHeight || 80]);
      setFooterEnabled(theme.config.footerEnabled !== false);
      setAnimationsEnabled(theme.config.animationsEnabled !== false);
      setParallaxEnabled(theme.config.parallaxEnabled === true);
    }
  };

  /**
   * Guarda los cambios del tema
   */
  const handleSaveTheme = async () => {
    if (!selectedTheme) return;

    setSaving(true);
    try {
      const themeData = {
        primaryColor,
        secondaryColor,
        accentColor,
        backgroundImage,
        logoImage,
        customCss,
        customJs,
        config: {
          logoPosition,
          headerHeight: headerHeight[0],
          footerEnabled,
          animationsEnabled,
          parallaxEnabled,
          customFonts: selectedTheme.config?.customFonts || null,
          buttonStyles: {
            borderRadius: '8px',
            fontWeight: 'semibold',
            paddingX: '16px',
            paddingY: '8px'
          },
          cardStyles: {
            borderRadius: '12px',
            shadow: 'lg',
            padding: '24px'
          },
          layoutConfig: {
            maxWidth: '1200px',
            spacing: '24px'
          },
          responsiveConfig: {
            breakpoints: {
              sm: '640px',
              md: '768px',
              lg: '1024px',
              xl: '1280px'
            }
          }
        }
      };

      const response = await fetch(`/api/admin/themes/${selectedTheme.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(themeData),
      });

      if (response.ok) {
        toast.success('Tema guardado correctamente');
        fetchThemes(); // Recargar temas
      } else {
        toast.error('Error al guardar el tema');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setSaving(false);
    }
  };

  /**
   * Vista previa del tema
   */
  const handlePreviewTheme = () => {
    if (!selectedTheme) return;
    
    const previewUrl = `/portal/preview?theme=${selectedTheme.name}&colors=${encodeURIComponent(JSON.stringify({
      primary: primaryColor,
      secondary: secondaryColor,
      accent: accentColor
    }))}`;
    
    window.open(previewUrl, '_blank');
  };

  /**
   * Exporta la configuración del tema
   */
  const handleExportTheme = () => {
    if (!selectedTheme) return;

    const themeConfig = {
      name: selectedTheme.name,
      displayName: selectedTheme.displayName,
      primaryColor,
      secondaryColor,
      accentColor,
      backgroundImage,
      logoImage,
      customCss,
      customJs,
      config: {
        logoPosition,
        headerHeight: headerHeight[0],
        footerEnabled,
        animationsEnabled,
        parallaxEnabled
      }
    };

    const blob = new Blob([JSON.stringify(themeConfig, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tema-${selectedTheme.name}.json`;
    document.body.appendChild(a);
    a.click();
    URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando editor de temas..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con controles principales */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <PaintBucket className="w-8 h-8 text-[#003478]" />
            Editor de Temas
          </h1>
          <p className="text-gray-600 mt-1">
            Personaliza la apariencia de los portales cautivos
          </p>
        </div>

        <div className="flex space-x-2">
          <FordButton
            variant="outline"
            onClick={handlePreviewTheme}
            disabled={!selectedTheme}
          >
            <Eye className="w-4 h-4 mr-2" />
            Vista Previa
          </FordButton>
          <FordButton
            variant="outline"
            onClick={handleExportTheme}
            disabled={!selectedTheme}
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar
          </FordButton>
          <FordButton
            onClick={handleSaveTheme}
            disabled={!selectedTheme || saving}
          >
            {saving ? (
              <LoadingSpinner size="sm" message="Guardando..." />
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Guardar Cambios
              </>
            )}
          </FordButton>
        </div>
      </div>

      {/* Selector de tema */}
      <FordCard>
        <div className="p-4">
          <Label className="text-sm font-medium mb-2 block">
            Seleccionar Tema para Editar
          </Label>
          <Select
            value={selectedTheme?.id || ''}
            onValueChange={(value) => {
              const theme = themes.find(t => t.id === value);
              if (theme) selectTheme(theme);
            }}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Selecciona un tema" />
            </SelectTrigger>
            <SelectContent>
              {themes.map((theme) => (
                <SelectItem key={theme.id} value={theme.id}>
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: theme.primaryColor }}
                    />
                    <span>{theme.displayName}</span>
                    {theme.isActive && (
                      <span className="text-xs text-green-600">(Activo)</span>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </FordCard>

      {/* Editor principal */}
      {selectedTheme && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Panel de configuración */}
          <div className="lg:col-span-2">
            <FordCard>
              <div className="p-6">
                <Tabs defaultValue="colors" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="colors">
                      <Palette className="w-4 h-4 mr-2" />
                      Colores
                    </TabsTrigger>
                    <TabsTrigger value="layout">
                      <Layout className="w-4 h-4 mr-2" />
                      Layout
                    </TabsTrigger>
                    <TabsTrigger value="images">
                      <Image className="w-4 h-4 mr-2" />
                      Imágenes
                    </TabsTrigger>
                    <TabsTrigger value="advanced">
                      <Settings className="w-4 h-4 mr-2" />
                      Avanzado
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="colors" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="primaryColor">Color Primario</Label>
                        <div className="flex space-x-2">
                          <Input
                            id="primaryColor"
                            type="color"
                            value={primaryColor}
                            onChange={(e) => setPrimaryColor(e.target.value)}
                            className="w-16 h-10"
                          />
                          <Input
                            value={primaryColor}
                            onChange={(e) => setPrimaryColor(e.target.value)}
                            placeholder="#003478"
                            className="flex-1"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="secondaryColor">Color Secundario</Label>
                        <div className="flex space-x-2">
                          <Input
                            id="secondaryColor"
                            type="color"
                            value={secondaryColor}
                            onChange={(e) => setSecondaryColor(e.target.value)}
                            className="w-16 h-10"
                          />
                          <Input
                            value={secondaryColor}
                            onChange={(e) => setSecondaryColor(e.target.value)}
                            placeholder="#FFFFFF"
                            className="flex-1"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="accentColor">Color de Acento</Label>
                        <div className="flex space-x-2">
                          <Input
                            id="accentColor"
                            type="color"
                            value={accentColor}
                            onChange={(e) => setAccentColor(e.target.value)}
                            className="w-16 h-10"
                          />
                          <Input
                            value={accentColor}
                            onChange={(e) => setAccentColor(e.target.value)}
                            placeholder="#47A8E5"
                            className="flex-1"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Paleta de colores Ford predefinidos */}
                    <div className="mt-6">
                      <Label className="text-sm font-medium mb-3 block">
                        Paleta Ford Oficial
                      </Label>
                      <div className="grid grid-cols-8 gap-2">
                        {[
                          '#003478', '#081534', '#133A7C', '#2A6BAC',
                          '#47A8E5', '#FFFFFF', '#C6C6C6', '#000000'
                        ].map((color) => (
                          <button
                            key={color}
                            className="w-8 h-8 rounded-lg border-2 border-gray-300 hover:border-gray-400 transition-colors"
                            style={{ backgroundColor: color }}
                            onClick={() => setPrimaryColor(color)}
                            title={color}
                          />
                        ))}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="layout" className="space-y-4 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="logoPosition">Posición del Logo</Label>
                        <Select value={logoPosition} onValueChange={setLogoPosition}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="left">Izquierda</SelectItem>
                            <SelectItem value="center">Centro</SelectItem>
                            <SelectItem value="right">Derecha</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="headerHeight">
                          Altura del Header: {headerHeight[0]}px
                        </Label>
                        <Slider
                          value={headerHeight}
                          onValueChange={setHeaderHeight}
                          max={200}
                          min={60}
                          step={10}
                          className="w-full"
                        />
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch
                          id="footerEnabled"
                          checked={footerEnabled}
                          onCheckedChange={setFooterEnabled}
                        />
                        <Label htmlFor="footerEnabled">Mostrar Footer</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch
                          id="animationsEnabled"
                          checked={animationsEnabled}
                          onCheckedChange={setAnimationsEnabled}
                        />
                        <Label htmlFor="animationsEnabled">Habilitar Animaciones</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Switch
                          id="parallaxEnabled"
                          checked={parallaxEnabled}
                          onCheckedChange={setParallaxEnabled}
                        />
                        <Label htmlFor="parallaxEnabled">Efecto Parallax</Label>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="images" className="space-y-4 mt-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="backgroundImage">Imagen de Fondo</Label>
                        <Input
                          id="backgroundImage"
                          value={backgroundImage}
                          onChange={(e) => setBackgroundImage(e.target.value)}
                          placeholder="https://static.vecteezy.com/system/resources/previews/000/110/250/original/free-flat-web-user-interface-vector-background.jpg"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="logoImage">Logo Personalizado</Label>
                        <Input
                          id="logoImage"
                          value={logoImage}
                          onChange={(e) => setLogoImage(e.target.value)}
                          placeholder="https://i.pinimg.com/originals/c3/51/84/c351844f3be5fa5df32375cd320e6894.jpg"
                        />
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="advanced" className="space-y-4 mt-6">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="customCss">CSS Personalizado</Label>
                        <Textarea
                          id="customCss"
                          value={customCss}
                          onChange={(e) => setCustomCss(e.target.value)}
                          placeholder="/* CSS personalizado aquí */"
                          rows={8}
                          className="font-mono text-sm"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="customJs">JavaScript Personalizado</Label>
                        <Textarea
                          id="customJs"
                          value={customJs}
                          onChange={(e) => setCustomJs(e.target.value)}
                          placeholder="// JavaScript personalizado aquí"
                          rows={6}
                          className="font-mono text-sm"
                        />
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </FordCard>
          </div>

          {/* Vista previa en tiempo real */}
          <div className="lg:col-span-1">
            <FordCard>
              <div className="p-4">
                <Label className="text-sm font-medium mb-3 block">
                  Vista Previa
                </Label>
                <div 
                  className="rounded-lg border-2 border-gray-200 overflow-hidden"
                  style={{ 
                    height: '400px',
                    backgroundColor: secondaryColor 
                  }}
                >
                  {/* Header simulado */}
                  <div 
                    className="flex items-center px-4 text-white"
                    style={{ 
                      backgroundColor: primaryColor,
                      height: `${headerHeight[0]}px`
                    }}
                  >
                    <div className={`flex items-center space-x-2 ${
                      logoPosition === 'center' ? 'mx-auto' : 
                      logoPosition === 'right' ? 'ml-auto' : ''
                    }`}>
                      <div className="w-8 h-8 bg-white rounded-full opacity-80" />
                      <span className="font-bold">Ford Portal</span>
                    </div>
                  </div>

                  {/* Contenido simulado */}
                  <div className="p-4 space-y-3">
                    <div 
                      className="h-12 rounded-lg flex items-center px-4 text-white font-medium"
                      style={{ backgroundColor: accentColor }}
                    >
                      Botón de Ejemplo
                    </div>
                    <div className="bg-gray-100 h-20 rounded-lg p-3">
                      <div className="h-3 bg-gray-300 rounded mb-2" />
                      <div className="h-3 bg-gray-300 rounded w-3/4" />
                    </div>
                    <div className="bg-gray-100 h-16 rounded-lg" />
                  </div>

                  {/* Footer simulado */}
                  {footerEnabled && (
                    <div 
                      className="absolute bottom-0 left-0 right-0 h-12 flex items-center justify-center text-white text-sm"
                      style={{ backgroundColor: primaryColor }}
                    >
                      Footer de Ejemplo
                    </div>
                  )}
                </div>
              </div>
            </FordCard>
          </div>
        </div>
      )}
    </div>
  );
}
