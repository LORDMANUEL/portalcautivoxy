
'use client';

import Link from 'next/link';
import { AlertTriangle, Home, RefreshCw } from 'lucide-react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';

export default function PortalErrorPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-slate-100">
      <Header variant="public" />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <FordCard className="p-12 max-w-2xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Enlace No Válido
            </h1>
            
            <p className="text-lg text-gray-600 mb-8">
              El enlace del portal cautivo que intentas acceder no es válido, ha expirado o ha alcanzado su límite de usos.
            </p>
            
            <div className="space-y-4">
              <div className="text-sm text-gray-500 space-y-2">
                <p>Posibles causas:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>El enlace ha expirado</li>
                  <li>Se ha alcanzado el límite máximo de usos</li>
                  <li>El enlace ha sido desactivado</li>
                  <li>El enlace contiene errores tipográficos</li>
                </ul>
              </div>
              
              <div className="flex justify-center space-x-4 pt-4">
                <FordButton 
                  variant="outline"
                  onClick={() => window.location.reload()}
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reintentar
                </FordButton>
                
                <Link href="/admin/login">
                  <FordButton>
                    <Home className="w-4 h-4 mr-2" />
                    Ir al Portal de Administración
                  </FordButton>
                </Link>
              </div>
            </div>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>¿Eres administrador?</strong><br />
                Accede al portal de administración para generar un nuevo enlace o verificar el estado de los tokens existentes.
              </p>
            </div>
          </FordCard>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
