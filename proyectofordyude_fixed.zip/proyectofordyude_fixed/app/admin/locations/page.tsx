

import { Metadata } from 'next';
import { LocationsClient } from './_components/locations-client';

export const metadata: Metadata = {
  title: 'Ubicaciones/Routers - Administración Ford',
  description: 'Gestión de ubicaciones, salas y routers para portales cautivos Ford Yude Canahuati',
};

export default function LocationsPage() {
  return <LocationsClient />;
}
