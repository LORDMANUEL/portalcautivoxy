
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { 
  Link, 
  Copy, 
  Plus, 
  Eye, 
  EyeOff, 
  Trash2, 
  Calendar,
  Users,
  Settings,
  ExternalLink
} from 'lucide-react';
import { fordAssets } from '@/lib/ford-assets';

interface PortalToken {
  id: string;
  token: string;
  name: string;
  description?: string;
  themeId?: string;
  isActive: boolean;
  maxUses?: number;
  currentUses: number;
  expiresAt?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface Theme {
  id: string;
  name: string;
  displayName: string;
  isActive: boolean;
}

export default function PortalManagementPage() {
  const [tokens, setTokens] = useState<PortalToken[]>([]);
  const [themes, setThemes] = useState<Theme[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNewTokenForm, setShowNewTokenForm] = useState(false);
  const [newToken, setNewToken] = useState({
    name: '',
    description: '',
    themeId: '',
    maxUses: '',
    expiresAt: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchTokens();
    fetchThemes();
  }, []);

  const fetchTokens = async () => {
    try {
      const response = await fetch('/api/admin/portal-tokens');
      if (response.ok) {
        const data = await response.json();
        setTokens(data);
      }
    } catch (error) {
      console.error('Error fetching tokens:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchThemes = async () => {
    try {
      const response = await fetch('/api/admin/themes');
      if (response.ok) {
        const data = await response.json();
        setThemes(data);
      }
    } catch (error) {
      console.error('Error fetching themes:', error);
    }
  };

  const generateToken = async () => {
    try {
      const payload = {
        ...newToken,
        maxUses: newToken.maxUses ? parseInt(newToken.maxUses) : null,
        expiresAt: newToken.expiresAt ? new Date(newToken.expiresAt).toISOString() : null,
        themeId: newToken.themeId || null
      };

      const response = await fetch('/api/admin/portal-tokens', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        toast({
          title: "Token generado",
          description: "El link del formulario cautivo ha sido creado exitosamente"
        });
        setNewToken({ name: '', description: '', themeId: '', maxUses: '', expiresAt: '' });
        setShowNewTokenForm(false);
        fetchTokens();
      } else {
        throw new Error('Error al generar token');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo generar el token",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = (token: string) => {
    const url = `${window.location.origin}/portal/${token}`;
    navigator.clipboard.writeText(url);
    toast({
      title: "URL copiada",
      description: "El link del formulario cautivo ha sido copiado al portapapeles"
    });
  };

  const toggleTokenStatus = async (tokenId: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/portal-tokens/${tokenId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !isActive })
      });

      if (response.ok) {
        fetchTokens();
        toast({
          title: isActive ? "Token desactivado" : "Token activado",
          description: `El token ha sido ${isActive ? 'desactivado' : 'activado'} exitosamente`
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cambiar el estado del token",
        variant: "destructive"
      });
    }
  };

  const deleteToken = async (tokenId: string) => {
    if (!confirm('¿Estás seguro de que deseas eliminar este token?')) return;

    try {
      const response = await fetch(`/api/admin/portal-tokens/${tokenId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchTokens();
        toast({
          title: "Token eliminado",
          description: "El token ha sido eliminado exitosamente"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el token",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestión del Portal Cautivo</h1>
          <p className="text-gray-600">Genera y administra los links públicos del formulario cautivo</p>
        </div>
        <Button onClick={() => setShowNewTokenForm(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Token
        </Button>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Link className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Tokens Activos</p>
                <p className="text-2xl font-bold text-gray-900">
                  {tokens.filter(t => t.isActive).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Usos</p>
                <p className="text-2xl font-bold text-gray-900">
                  {tokens.reduce((sum, t) => sum + t.currentUses, 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Con Expiración</p>
                <p className="text-2xl font-bold text-gray-900">
                  {tokens.filter(t => t.expiresAt).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <Settings className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Con Límite</p>
                <p className="text-2xl font-bold text-gray-900">
                  {tokens.filter(t => t.maxUses).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Formulario de nuevo token */}
      {showNewTokenForm && (
        <Card>
          <CardHeader>
            <CardTitle>Generar Nuevo Token</CardTitle>
            <CardDescription>
              Crea un nuevo link público para el formulario cautivo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre del Token *</Label>
                <Input
                  id="name"
                  value={newToken.name}
                  onChange={(e) => setNewToken({...newToken, name: e.target.value})}
                  placeholder="Ej: Evento Navidad 2025"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="theme">Tema (Opcional)</Label>
                <Select value={newToken.themeId} onValueChange={(value) => setNewToken({...newToken, themeId: value})}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Seleccionar tema" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Sin tema específico</SelectItem>
                    {themes.filter(t => t.isActive).map((theme) => (
                      <SelectItem key={theme.id} value={theme.id}>
                        {theme.displayName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={newToken.description}
                onChange={(e) => setNewToken({...newToken, description: e.target.value})}
                placeholder="Describe el propósito de este token..."
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="maxUses">Límite de Usos (Opcional)</Label>
                <Input
                  id="maxUses"
                  type="number"
                  value={newToken.maxUses}
                  onChange={(e) => setNewToken({...newToken, maxUses: e.target.value})}
                  placeholder="Ej: 100"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="expiresAt">Fecha de Expiración (Opcional)</Label>
                <Input
                  id="expiresAt"
                  type="datetime-local"
                  value={newToken.expiresAt}
                  onChange={(e) => setNewToken({...newToken, expiresAt: e.target.value})}
                  className="mt-1"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowNewTokenForm(false)}>
                Cancelar
              </Button>
              <Button 
                onClick={generateToken}
                disabled={!newToken.name.trim()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Generar Token
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lista de tokens */}
      <Card>
        <CardHeader>
          <CardTitle>Tokens del Portal Cautivo</CardTitle>
          <CardDescription>
            Administra todos los links públicos del formulario cautivo
          </CardDescription>
        </CardHeader>
        <CardContent>
          {tokens.length === 0 ? (
            <div className="text-center py-8">
              <Link className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No hay tokens creados</p>
              <p className="text-sm text-gray-400">Crea tu primer token para generar un link público</p>
            </div>
          ) : (
            <div className="space-y-4">
              {tokens.map((token) => (
                <div key={token.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold text-gray-900">{token.name}</h3>
                        <Badge variant={token.isActive ? "default" : "secondary"}>
                          {token.isActive ? "Activo" : "Inactivo"}
                        </Badge>
                        {token.expiresAt && (
                          <Badge variant="outline">
                            <Calendar className="w-3 h-3 mr-1" />
                            Expira: {new Date(token.expiresAt).toLocaleDateString()}
                          </Badge>
                        )}
                      </div>
                      
                      {token.description && (
                        <p className="text-sm text-gray-600 mb-2">{token.description}</p>
                      )}
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>Usos: {token.currentUses}{token.maxUses ? `/${token.maxUses}` : ''}</span>
                        <span>Creado: {new Date(token.createdAt).toLocaleDateString()}</span>
                      </div>
                      
                      <div className="mt-2 p-2 bg-gray-100 rounded text-sm font-mono break-all">
                        {`${window.location.origin}/portal/${token.token}`}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(token.token)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`/portal/${token.token}`, '_blank')}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleTokenStatus(token.id, token.isActive)}
                      >
                        {token.isActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => deleteToken(token.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
