
/**
 * Middleware de autenticación para el Portal Ford Yude Canahuati
 * 
 * Este middleware protege las rutas administrativas del portal usando NextAuth.
 * Se ejecuta en cada request para verificar la autenticación del usuario
 * en rutas protegidas.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import { withAuth } from 'next-auth/middleware';

/**
 * Middleware principal que maneja la autenticación de rutas
 * 
 * Utiliza withAuth de NextAuth para proteger rutas administrativas.
 * Se ejecuta antes de cada request a rutas que coincidan con el matcher.
 */
export default withAuth(
  /**
   * Función de middleware personalizada
   * 
   * @param req - Request object de Next.js
   * @description Actualmente no implementa lógica personalizada adicional,
   * pero está disponible para agregar validaciones o transformaciones futuras
   */
  function middleware(req) {
    // Espacio para lógica de middleware personalizada futura
    // Por ejemplo: logging, rate limiting, transformaciones de request, etc.
  },
  {
    callbacks: {
      /**
       * Callback de autorización que determina si el usuario puede acceder a la ruta
       * 
       * @param param0 - Objeto con token de sesión y request
       * @param param0.token - Token JWT de la sesión actual (null si no hay sesión)
       * @param param0.req - Request object con información de la ruta solicitada
       * @returns boolean - true si el usuario está autorizado, false si no
       * 
       * @description
       * Lógica de autorización:
       * - Si la ruta empieza con /admin Y NO es /admin/login: requiere token válido
       * - Todas las demás rutas: acceso permitido sin autenticación
       */
      authorized: ({ token, req }) => {
        // Proteger solo rutas administrativas, excluyendo la página de login
        if (req.nextUrl.pathname.startsWith('/admin') && 
            !req.nextUrl.pathname.startsWith('/admin/login')) {
          return !!token; // Requiere token válido (usuario autenticado)
        }
        return true; // Permitir acceso a rutas públicas
      },
    },
  }
);

/**
 * Configuración del matcher para el middleware
 * 
 * Define qué rutas serán procesadas por este middleware.
 * Actualmente configurado para todas las rutas bajo /admin/
 * 
 * @constant {Object} config - Configuración del middleware
 * @property {string[]} matcher - Array de patrones de ruta a procesar
 */
export const config = {
  matcher: ['/admin/:path*'] // Aplicar middleware a todas las rutas administrativas
};
