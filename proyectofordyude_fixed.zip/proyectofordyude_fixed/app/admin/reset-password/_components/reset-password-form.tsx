
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Eye, EyeOff, Lock, CheckCircle, XCircle } from 'lucide-react';

export function ResetPasswordForm() {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState('');
  const [token, setToken] = useState('');
  
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const tokenParam = searchParams.get('token');
    const usernameParam = searchParams.get('username');
    
    if (!tokenParam || !usernameParam) {
      router.push('/admin/forgot-password');
      return;
    }
    
    setToken(tokenParam);
    setUsername(usernameParam);
  }, [searchParams, router]);

  const validatePassword = (pass: string) => {
    return {
      length: pass.length >= 6,
      hasLetter: /[a-zA-Z]/.test(pass),
      hasNumber: /\d/.test(pass)
    };
  };

  const validation = validatePassword(password);
  const isPasswordValid = validation.length && validation.hasLetter && validation.hasNumber;
  const passwordsMatch = password === confirmPassword && confirmPassword.length > 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isPasswordValid || !passwordsMatch) {
      return;
    }

    setLoading(true);

    try {
      // Simular actualización de contraseña (demo)
      const response = await fetch('/api/admin/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token,
          username,
          newPassword: password
        }),
      });

      if (response.ok) {
        alert('¡Contraseña actualizada exitosamente!');
        router.push('/admin/login?message=password-reset-success');
      } else {
        throw new Error('Error al actualizar la contraseña');
      }
    } catch (error) {
      alert('Error al actualizar la contraseña. Intenta nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  if (!token || !username) {
    return <div>Cargando...</div>;
  }

  return (
    <Card className="w-full">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <Lock className="h-5 w-5 text-green-600" />
          Restablecer Contraseña
        </CardTitle>
        <p className="text-sm text-gray-600">
          Usuario: <strong>{username}</strong>
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="password">Nueva Contraseña</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Ingresa tu nueva contraseña"
                required
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          <div>
            <Label htmlFor="confirmPassword">Confirmar Contraseña</Label>
            <div className="relative">
              <Input
                id="confirmPassword"
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirma tu nueva contraseña"
                required
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                {showConfirmPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          {/* Validación de contraseña */}
          <div className="bg-gray-50 p-3 rounded-lg space-y-2">
            <p className="text-sm font-medium text-gray-700">Requisitos de contraseña:</p>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm">
                {validation.length ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span className={validation.length ? 'text-green-700' : 'text-red-700'}>
                  Mínimo 6 caracteres
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {validation.hasLetter ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span className={validation.hasLetter ? 'text-green-700' : 'text-red-700'}>
                  Al menos una letra
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {validation.hasNumber ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500" />
                )}
                <span className={validation.hasNumber ? 'text-green-700' : 'text-red-700'}>
                  Al menos un número
                </span>
              </div>
              {confirmPassword.length > 0 && (
                <div className="flex items-center gap-2 text-sm">
                  {passwordsMatch ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                  <span className={passwordsMatch ? 'text-green-700' : 'text-red-700'}>
                    Las contraseñas coinciden
                  </span>
                </div>
              )}
            </div>
          </div>

          <Button
            type="submit"
            disabled={loading || !isPasswordValid || !passwordsMatch}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            {loading ? 'Actualizando...' : 'Actualizar Contraseña'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
