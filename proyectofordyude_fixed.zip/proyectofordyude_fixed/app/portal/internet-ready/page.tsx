
import { Metadata } from 'next';
import { InternetReadyClient } from './_components/internet-ready-client';

export const metadata: Metadata = {
  title: 'Ya tienes Internet - Ford Yude Canahuati',
  description: 'Ya tienes acceso completo a internet. Explora todo lo que Ford Yude Canahuati tiene para ofrecerte.',
};

export default function InternetReadyPage() {
  return <InternetReadyClient />;
}
