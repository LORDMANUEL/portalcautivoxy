

'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  UserCog,
  Plus,
  Edit,
  Trash2,
  Shield,
  Key,
  Crown,
  User,
  Eye,
  EyeOff,
  Search,
  Filter,
  MoreVertical,
  Calendar,
  Mail,
  MapPin,
  Clock
} from 'lucide-react';
import { FordButton } from '@/components/ui/ford-button';
import { FordCard } from '@/components/ui/ford-card';
import { LoadingSpinner } from '@/components/ui/loading-spinner';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';

interface Admin {
  id: string;
  username: string;
  email: string | null;
  name: string;
  role: string;
  isActive: boolean;
  lastLogin: string | null;
  locationId: string | null;
  createdAt: string;
  updatedAt: string;
  location?: {
    name: string;
    code: string;
  };
  roles: {
    role: {
      id: string;
      name: string;
      displayName: string;
      priority: number;
    };
  }[];
}

interface Role {
  id: string;
  name: string;
  displayName: string;
  description: string;
  priority: number;
  isActive: boolean;
  canManageUsers: boolean;
  canManageSystem: boolean;
}

interface Permission {
  id: string;
  name: string;
  module: string;
  action: string;
  description: string;
  isActive: boolean;
}

interface AdminFormData {
  username: string;
  email: string;
  name: string;
  password: string;
  confirmPassword: string;
  locationId: string;
  isActive: boolean;
  selectedRoles: string[];
}

// Roles predefinidos con colores
const roleStyles = {
  'SUPER_ADMIN': { color: 'bg-purple-100 text-purple-800', icon: Crown },
  'ADMIN': { color: 'bg-blue-100 text-blue-800', icon: Shield },
  'OPERATOR': { color: 'bg-green-100 text-green-800', icon: UserCog },
  'VIEWER': { color: 'bg-gray-100 text-gray-800', icon: Eye },
};

/**
 * Cliente para gestión de usuarios administradores
 * Permite crear, editar y gestionar usuarios con roles y permisos granulares
 */
export function UserManagementClient() {
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<Admin | null>(null);
  const [saving, setSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Formulario de admin
  const [formData, setFormData] = useState<AdminFormData>({
    username: '',
    email: '',
    name: '',
    password: '',
    confirmPassword: '',
    locationId: '',
    isActive: true,
    selectedRoles: []
  });

  useEffect(() => {
    fetchAdmins();
    fetchRoles();
    fetchPermissions();
    fetchLocations();
  }, []);

  /**
   * Obtiene todos los administradores
   */
  const fetchAdmins = async () => {
    try {
      const response = await fetch('/api/admin/user-management');
      if (response.ok) {
        const data = await response.json();
        setAdmins(data);
      } else {
        toast.error('Error al cargar los administradores');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Obtiene todos los roles disponibles
   */
  const fetchRoles = async () => {
    try {
      const response = await fetch('/api/admin/roles');
      if (response.ok) {
        const data = await response.json();
        setRoles(data);
      }
    } catch (error) {
      console.error('Error al cargar roles');
    }
  };

  /**
   * Obtiene todos los permisos disponibles
   */
  const fetchPermissions = async () => {
    try {
      const response = await fetch('/api/admin/permissions');
      if (response.ok) {
        const data = await response.json();
        setPermissions(data);
      }
    } catch (error) {
      console.error('Error al cargar permisos');
    }
  };

  /**
   * Obtiene las ubicaciones disponibles
   */
  const fetchLocations = async () => {
    try {
      const response = await fetch('/api/admin/locations');
      if (response.ok) {
        const data = await response.json();
        setLocations(data);
      }
    } catch (error) {
      console.error('Error al cargar ubicaciones');
    }
  };

  /**
   * Maneja los cambios en el formulario
   */
  const handleInputChange = (field: keyof AdminFormData, value: string | boolean | string[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  /**
   * Maneja la selección de roles
   */
  const handleRoleToggle = (roleId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedRoles: prev.selectedRoles.includes(roleId)
        ? prev.selectedRoles.filter(id => id !== roleId)
        : [...prev.selectedRoles, roleId]
    }));
  };

  /**
   * Guarda o actualiza un administrador
   */
  const handleSaveAdmin = async () => {
    if (!formData.username || !formData.name) {
      toast.error('Usuario y nombre son obligatorios');
      return;
    }

    if (!editingAdmin && (!formData.password || formData.password !== formData.confirmPassword)) {
      toast.error('Las contraseñas no coinciden');
      return;
    }

    if (formData.selectedRoles.length === 0) {
      toast.error('Debe asignar al menos un rol');
      return;
    }

    setSaving(true);
    try {
      const url = editingAdmin 
        ? `/api/admin/user-management/${editingAdmin.id}` 
        : '/api/admin/user-management';
      const method = editingAdmin ? 'PUT' : 'POST';

      const payload = {
        username: formData.username,
        email: formData.email || null,
        name: formData.name,
        locationId: formData.locationId === 'none' ? null : formData.locationId || null,
        isActive: formData.isActive,
        roleIds: formData.selectedRoles,
        ...((!editingAdmin || formData.password) && { password: formData.password })
      };

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success(editingAdmin ? 'Usuario actualizado correctamente' : 'Usuario creado correctamente');
        setIsModalOpen(false);
        setEditingAdmin(null);
        resetForm();
        fetchAdmins();
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || 'Error al guardar el usuario');
      }
    } catch (error) {
      toast.error('Error de conexión');
    } finally {
      setSaving(false);
    }
  };

  /**
   * Abre el modal para editar un admin
   */
  const handleEditAdmin = (admin: Admin) => {
    setEditingAdmin(admin);
    setFormData({
      username: admin.username,
      email: admin.email || '',
      name: admin.name,
      password: '',
      confirmPassword: '',
      locationId: admin.locationId || '',
      isActive: admin.isActive,
      selectedRoles: admin.roles.map(r => r.role.id)
    });
    setIsModalOpen(true);
  };

  /**
   * Elimina un administrador
   */
  const handleDeleteAdmin = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este administrador?')) return;

    try {
      const response = await fetch(`/api/admin/user-management/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.success('Administrador eliminado correctamente');
        fetchAdmins();
      } else {
        toast.error('Error al eliminar el administrador');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Activa/desactiva un administrador
   */
  const handleToggleAdmin = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch(`/api/admin/user-management/${id}/toggle`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ isActive: !isActive }),
      });

      if (response.ok) {
        toast.success(`Usuario ${!isActive ? 'activado' : 'desactivado'} correctamente`);
        fetchAdmins();
      } else {
        toast.error('Error al cambiar el estado del usuario');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
  };

  /**
   * Resetea el formulario
   */
  const resetForm = () => {
    setFormData({
      username: '',
      email: '',
      name: '',
      password: '',
      confirmPassword: '',
      locationId: '',
      isActive: true,
      selectedRoles: []
    });
    setShowPassword(false);
  };

  /**
   * Obtiene el rol principal del admin
   */
  const getPrimaryRole = (admin: Admin) => {
    if (admin.roles.length === 0) return null;
    return admin.roles.reduce((highest, current) => 
      current.role.priority > highest.role.priority ? current : highest
    ).role;
  };

  // Filtrar administradores
  const filteredAdmins = admins.filter(admin => {
    const matchesSearch = admin.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         admin.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         admin.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = filterRole === 'all' || filterRole === '' || admin.roles.some(r => r.role.name === filterRole);
    
    return matchesSearch && matchesRole;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" message="Cargando gestión de usuarios..." />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con controles */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-3">
            <UserCog className="w-8 h-8 text-[#003478]" />
            Gestión de Usuarios
          </h1>
          <p className="text-gray-600 mt-1">
            Gestiona usuarios administradores con roles y permisos
          </p>
        </div>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <FordButton 
              onClick={() => {
                setEditingAdmin(null);
                resetForm();
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Usuario
            </FordButton>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingAdmin ? 'Editar Usuario' : 'Nuevo Usuario Administrador'}
              </DialogTitle>
            </DialogHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              {/* Información básica */}
              <div className="space-y-2">
                <Label htmlFor="username">Nombre de Usuario *</Label>
                <Input
                  id="username"
                  value={formData.username}
                  onChange={(e) => handleInputChange('username', e.target.value)}
                  placeholder="admin123"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Nombre Completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Juan Pérez"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="juan.perez@yudecanahuati.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="locationId">Ubicación Asignada</Label>
                <Select
                  value={formData.locationId}
                  onValueChange={(value) => handleInputChange('locationId', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sin ubicación específica" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sin ubicación específica</SelectItem>
                    {locations.map((location) => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name} ({location.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Contraseña */}
              <div className="space-y-2">
                <Label htmlFor="password">
                  Contraseña {editingAdmin ? '(dejar vacío para no cambiar)' : '*'}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    placeholder={editingAdmin ? 'Nueva contraseña' : 'Contraseña'}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 transform -translate-y-1/2"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmar Contraseña</Label>
                <Input
                  id="confirmPassword"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  placeholder="Confirmar contraseña"
                />
              </div>

              {/* Estado activo */}
              <div className="flex items-center space-x-2 md:col-span-2">
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => handleInputChange('isActive', checked)}
                />
                <Label htmlFor="isActive">Usuario Activo</Label>
              </div>

              {/* Selección de roles */}
              <div className="md:col-span-2">
                <Label className="text-sm font-medium mb-3 block">
                  Roles y Permisos *
                </Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {roles.map((role) => {
                    const RoleIcon = roleStyles[role.name as keyof typeof roleStyles]?.icon || Shield;
                    const isSelected = formData.selectedRoles.includes(role.id);
                    
                    return (
                      <div
                        key={role.id}
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          isSelected 
                            ? 'border-[#003478] bg-blue-50' 
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handleRoleToggle(role.id)}
                      >
                        <div className="flex items-center space-x-3">
                          <Checkbox
                            checked={isSelected}
                            onChange={() => {}}
                          />
                          <RoleIcon className="w-5 h-5 text-[#003478]" />
                          <div>
                            <h4 className="font-medium text-gray-800">
                              {role.displayName}
                            </h4>
                            <p className="text-xs text-gray-600">
                              {role.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <FordButton
                variant="outline"
                onClick={() => {
                  setIsModalOpen(false);
                  setEditingAdmin(null);
                  resetForm();
                }}
              >
                Cancelar
              </FordButton>
              <FordButton onClick={handleSaveAdmin} disabled={saving}>
                {saving ? (
                  <LoadingSpinner size="sm" message="Guardando..." />
                ) : (
                  <>
                    <UserCog className="w-4 h-4 mr-2" />
                    {editingAdmin ? 'Actualizar' : 'Crear Usuario'}
                  </>
                )}
              </FordButton>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filtros */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar usuarios..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={filterRole} onValueChange={setFilterRole}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filtrar por rol" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los roles</SelectItem>
            {roles.map((role) => (
              <SelectItem key={role.id} value={role.name}>
                {role.displayName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Lista de administradores */}
      {filteredAdmins.length === 0 ? (
        <FordCard className="text-center py-12">
          <UserCog className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">
            {searchTerm || filterRole ? 'No se encontraron usuarios' : 'No hay usuarios administradores'}
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm || filterRole
              ? 'Intenta con otros filtros de búsqueda'
              : 'Crea tu primer usuario administrador'
            }
          </p>
        </FordCard>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredAdmins.map((admin) => {
            const primaryRole = getPrimaryRole(admin);
            const RoleIcon = primaryRole ? roleStyles[primaryRole.name as keyof typeof roleStyles]?.icon || Shield : User;
            
            return (
              <motion.div
                key={admin.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="group"
              >
                <FordCard className="h-full hover:shadow-lg transition-all duration-200">
                  <div className="p-6">
                    {/* Header con avatar y acciones */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-12 h-12">
                          <AvatarFallback className="bg-[#003478] text-white">
                            {admin.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-gray-800">
                            {admin.name}
                          </h3>
                          <p className="text-sm text-gray-600">
                            @{admin.username}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          admin.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {admin.isActive ? 'Activo' : 'Inactivo'}
                        </span>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <FordButton size="sm" variant="ghost">
                              <MoreVertical className="w-4 h-4" />
                            </FordButton>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditAdmin(admin)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleToggleAdmin(admin.id, admin.isActive)}
                            >
                              {admin.isActive ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                              {admin.isActive ? 'Desactivar' : 'Activar'}
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteAdmin(admin.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Eliminar
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    {/* Información de contacto */}
                    <div className="space-y-2 mb-4">
                      {admin.email && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Mail className="w-4 h-4 mr-2" />
                          <span className="truncate">{admin.email}</span>
                        </div>
                      )}
                      {admin.location && (
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="w-4 h-4 mr-2" />
                          <span>{admin.location.name}</span>
                        </div>
                      )}
                      {admin.lastLogin && (
                        <div className="flex items-center text-sm text-gray-600">
                          <Clock className="w-4 h-4 mr-2" />
                          <span>
                            Último acceso: {new Date(admin.lastLogin).toLocaleDateString()}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Roles asignados */}
                    <div className="space-y-2">
                      <Label className="text-xs text-gray-500">Roles:</Label>
                      <div className="flex flex-wrap gap-1">
                        {admin.roles.map((roleAssignment) => {
                          const role = roleAssignment.role;
                          const style = roleStyles[role.name as keyof typeof roleStyles];
                          
                          return (
                            <Badge
                              key={role.id}
                              className={`${style?.color || 'bg-gray-100 text-gray-800'} text-xs`}
                            >
                              {role.displayName}
                            </Badge>
                          );
                        })}
                      </div>
                    </div>

                    {/* Fecha de creación */}
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="flex items-center text-xs text-gray-500">
                        <Calendar className="w-3 h-3 mr-1" />
                        Creado: {new Date(admin.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </FordCard>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
