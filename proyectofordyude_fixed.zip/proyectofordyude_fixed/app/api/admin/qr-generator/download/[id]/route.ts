
/**
 * API Route para descargar vCard o QR
 * 
 * Funcionalidades:
 * - GET: Descargar archivo vCard o imagen QR
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { readFile } from 'fs/promises'
import { join } from 'path'

export const dynamic = "force-dynamic"

/**
 * Generar string vCard
 */
function generateVCardString(data: any): string {
  const vcard = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `FN:${data.advisorName}`,
    `EMAIL:${data.email}`,
    `TEL:${data.phone || ''}`,
    `ORG:${data.company}`,
    `TITLE:${data.position || ''}`,
    `ADR:;;${data.address || ''};;;`,
    `URL:${data.website || ''}`,
    'END:VCARD'
  ].join('\n')
  
  return vcard
}

/**
 * GET /api/admin/qr-generator/download/[id]
 * Descargar vCard o QR
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'vcard' // vcard | qr

    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    })

    if (!vcard) {
      return NextResponse.json(
        { success: false, message: 'vCard no encontrada' },
        { status: 404 }
      )
    }

    // Incrementar contador de descargas
    await prisma.vCard.update({
      where: { id: params.id },
      data: {
        downloadCount: vcard.downloadCount + 1
      }
    })

    if (type === 'qr' && vcard.qrCode) {
      // Descargar imagen QR
      try {
        const filePath = join(process.cwd(), 'public', vcard.qrCode)
        const fileBuffer = await readFile(filePath)
        
        return new NextResponse(fileBuffer, {
          headers: {
            'Content-Type': 'image/png',
            'Content-Disposition': `attachment; filename="QR_${vcard.advisorName.replace(/\s+/g, '_')}.png"`
          }
        })
      } catch (error) {
        return NextResponse.json(
          { success: false, message: 'Archivo QR no encontrado' },
          { status: 404 }
        )
      }
    } else {
      // Descargar archivo vCard
      const vcardString = generateVCardString(vcard)
      
      return new NextResponse(vcardString, {
        headers: {
          'Content-Type': 'text/vcard',
          'Content-Disposition': `attachment; filename="${vcard.advisorName.replace(/\s+/g, '_')}.vcf"`
        }
      })
    }

  } catch (error) {
    console.error('Error downloading vCard:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
