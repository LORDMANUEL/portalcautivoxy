
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/db';
import ContactClient from './_components/contact-client';

interface ContactPageProps {
  params: {
    id: string;
  };
}

/**
 * Página de contacto del vendedor - Accesible vía QR
 * Muestra información del asesor y permite descargar vCard
 */
export default async function ContactPage({ params }: ContactPageProps) {
  try {
    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    });

    if (!vcard || !vcard.isActive) {
      notFound();
    }

    // Convertir fechas a string para el componente cliente
    const vcardForClient = {
      ...vcard,
      createdAt: vcard.createdAt.toISOString(),
      updatedAt: vcard.updatedAt.toISOString()
    };

    return <ContactClient vcard={vcardForClient} />;
    
  } catch (error) {
    console.error('Error loading contact page:', error);
    notFound();
  }
}

export async function generateMetadata({ params }: ContactPageProps) {
  try {
    const vcard = await prisma.vCard.findUnique({
      where: { id: params.id }
    });

    if (!vcard) {
      return {
        title: 'Contacto no encontrado - Ford Yude Canahuati'
      };
    }

    return {
      title: `${vcard.advisorName} - ${vcard.position || 'Asesor de Servicio'} | Ford Yude Canahuati`,
      description: `Contacta con ${vcard.advisorName}, ${vcard.position || 'Asesor de Servicio'} en Ford Yude Canahuati. ${vcard.email}`,
      keywords: 'Ford, Honduras, San Pedro Sula, Asesor, Servicio, Contacto, vCard'
    };
  } catch (error) {
    return {
      title: 'Contacto - Ford Yude Canahuati'
    };
  }
}
