
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { AdminLayout } from './_components/admin-layout';

export default async function AdminRootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);

  // Allow access to login page without authentication
  if (!session) {
    return <>{children}</>;
  }

  // Authenticated admin routes use the admin layout
  return <AdminLayout>{children}</AdminLayout>;
}
