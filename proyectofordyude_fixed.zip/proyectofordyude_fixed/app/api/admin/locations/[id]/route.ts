

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * PUT /api/admin/locations/[id]
 * Actualiza una ubicación existente
 */
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const body = await request.json();
    const { 
      name, 
      code, 
      type, 
      address, 
      city, 
      country, 
      latitude, 
      longitude, 
      description,
      iconName,
      iconColor,
      isActive,
      routerConfig
    } = body;

    if (!name || !code) {
      return NextResponse.json({ error: 'Nombre y código son obligatorios' }, { status: 400 });
    }

    // Verificar que el código sea único (excluyendo la ubicación actual)
    const existingLocation = await prisma.location.findFirst({
      where: { 
        code,
        NOT: { id: params.id }
      }
    });

    if (existingLocation) {
      return NextResponse.json({ error: 'Ya existe una ubicación con este código' }, { status: 400 });
    }

    const location = await prisma.location.update({
      where: { id: params.id },
      data: {
        name,
        code,
        type: type || 'SHOWROOM',
        address: address || null,
        city: city || null,
        country: country || 'Honduras',
        latitude: latitude || null,
        longitude: longitude || null,
        description: description || null,
        iconName: iconName || 'building',
        iconColor: iconColor || '#003478',
        isActive: isActive !== false,
        routerConfig: routerConfig || null
      },
      include: {
        _count: {
          select: {
            portals: true,
            backups: true,
            admins: true
          }
        }
      }
    });

    return NextResponse.json(location);
  } catch (error) {
    console.error('Error al actualizar ubicación:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

/**
 * DELETE /api/admin/locations/[id]
 * Elimina una ubicación
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    // Verificar si la ubicación tiene datos relacionados
    const location = await prisma.location.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            portals: true,
            backups: true,
            admins: true
          }
        }
      }
    });

    if (!location) {
      return NextResponse.json({ error: 'Ubicación no encontrada' }, { status: 404 });
    }

    const totalRelated = location._count.portals + location._count.backups + location._count.admins;
    
    if (totalRelated > 0) {
      return NextResponse.json({ 
        error: 'No se puede eliminar la ubicación porque tiene datos relacionados' 
      }, { status: 400 });
    }

    await prisma.location.delete({
      where: { id: params.id }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error al eliminar ubicación:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}
