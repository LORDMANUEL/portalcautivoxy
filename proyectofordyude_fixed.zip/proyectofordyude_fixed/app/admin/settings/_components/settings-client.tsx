
'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Settings,
  Save,
  Upload,
  Palette,
  Network,
  Bell,
  Shield,
  Globe,
  Clock,
  MapPin,
  Mail,
  Phone,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';
import { FordCard } from '@/components/ui/ford-card';
import { FordButton } from '@/components/ui/ford-button';
import { toast } from 'react-hot-toast';

interface SystemSettings {
  // General
  siteName: string;
  siteDescription: string;
  logoUrl: string;
  faviconUrl: string;
  
  // Network
  routerIp: string;
  captivePortalUrl: string;
  dnsServers: string[];
  sessionTimeout: number;
  maxConcurrentUsers: number;
  
  // Theme
  primaryColor: string;
  secondaryColor: string;
  customCss: string;
  defaultTheme: string;
  
  // Notifications
  emailNotifications: boolean;
  smsNotifications: boolean;
  adminEmail: string;
  adminPhone: string;
  notifyNewConnections: boolean;
  notifyDisconnections: boolean;
  notifyErrors: boolean;
  
  // Security
  enableBruteForceProtection: boolean;
  maxLoginAttempts: number;
  lockoutDuration: number;
  requireTermsAcceptance: boolean;
  enableGeoBlocking: boolean;
  blockedCountries: string[];
  
  // Contact Info
  companyName: string;
  address: string;
  city: string;
  phone: string;
  email: string;
  website: string;
}

export function SettingsClient() {
  const [settings, setSettings] = useState<SystemSettings | null>(null);
  const [activeTab, setActiveTab] = useState('general');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockSettings: SystemSettings = {
      // General
      siteName: 'Ford Yude Canahuati - Portal Cautivo',
      siteDescription: 'Portal cautivo oficial de Ford Yude Canahuati Honduras',
      logoUrl: 'https://www.freepnglogos.com/uploads/large-ford-logo-0.png',
      faviconUrl: '/favicon.ico',
      
      // Network
      routerIp: '192.168.1.1',
      captivePortalUrl: 'https://proyectofordyude.abacus.ai',
      dnsServers: ['8.8.8.8', '8.8.4.4'],
      sessionTimeout: 120,
      maxConcurrentUsers: 100,
      
      // Theme
      primaryColor: '#003478',
      secondaryColor: '#FFFFFF',
      customCss: '/* CSS personalizado aquí */',
      defaultTheme: 'default',
      
      // Notifications
      emailNotifications: true,
      smsNotifications: false,
      adminEmail: 'admin@fordyude.hn',
      adminPhone: '+504 2550-0000',
      notifyNewConnections: true,
      notifyDisconnections: false,
      notifyErrors: true,
      
      // Security
      enableBruteForceProtection: true,
      maxLoginAttempts: 5,
      lockoutDuration: 30,
      requireTermsAcceptance: true,
      enableGeoBlocking: false,
      blockedCountries: [],
      
      // Contact Info
      companyName: 'Ford Yude Canahuati',
      address: 'San Pedro Sula, Honduras',
      city: 'San Pedro Sula',
      phone: '+504 2550-0000',
      email: 'info@fordyude.hn',
      website: 'https://fordyude.hn'
    };
    
    setSettings(mockSettings);
    setLoading(false);
  };

  const handleSave = async () => {
    if (!settings) return;
    
    setSaving(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      toast.success('Configuración guardada exitosamente');
    } catch (error) {
      toast.error('Error al guardar configuración');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setSettings(prev => prev ? { ...prev, [field]: value } : null);
  };

  const tabs = [
    { id: 'general', name: 'General', icon: Settings },
    { id: 'network', name: 'Red', icon: Network },
    { id: 'theme', name: 'Apariencia', icon: Palette },
    { id: 'notifications', name: 'Notificaciones', icon: Bell },
    { id: 'security', name: 'Seguridad', icon: Shield },
    { id: 'contact', name: 'Contacto', icon: MapPin }
  ];

  if (loading || !settings) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-gray-300 rounded w-48 animate-pulse" />
        <div className="grid lg:grid-cols-4 gap-6">
          <div className="h-64 bg-gray-200 rounded-lg animate-pulse" />
          <div className="lg:col-span-3 h-96 bg-gray-200 rounded-lg animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Configuración del Sistema</h1>
          <p className="text-gray-600">
            Ajustes avanzados del portal cautivo Ford Yude Canahuati
          </p>
        </div>
        <FordButton onClick={handleSave} isLoading={saving}>
          <Save className="w-4 h-4 mr-2" />
          Guardar Cambios
        </FordButton>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Tabs Sidebar */}
        <div className="lg:col-span-1">
          <FordCard className="p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-[#003478] text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    <span className="text-sm font-medium">{tab.name}</span>
                  </button>
                );
              })}
            </nav>
          </FordCard>
        </div>

        {/* Settings Content */}
        <div className="lg:col-span-3">
          <FordCard className="p-6">
            {/* General Settings */}
            {activeTab === 'general' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Configuración General</h2>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nombre del Sitio
                      </label>
                      <input
                        type="text"
                        value={settings.siteName}
                        onChange={(e) => handleInputChange('siteName', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        URL del Logo
                      </label>
                      <input
                        type="url"
                        value={settings.logoUrl}
                        onChange={(e) => handleInputChange('logoUrl', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Descripción del Sitio
                    </label>
                    <textarea
                      value={settings.siteDescription}
                      onChange={(e) => handleInputChange('siteDescription', e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Network Settings */}
            {activeTab === 'network' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Configuración de Red</h2>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        IP del Router
                      </label>
                      <input
                        type="text"
                        value={settings.routerIp}
                        onChange={(e) => handleInputChange('routerIp', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        URL del Portal Cautivo
                      </label>
                      <input
                        type="url"
                        value={settings.captivePortalUrl}
                        onChange={(e) => handleInputChange('captivePortalUrl', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Timeout de Sesión (minutos)
                      </label>
                      <input
                        type="number"
                        min="15"
                        max="480"
                        value={settings.sessionTimeout}
                        onChange={(e) => handleInputChange('sessionTimeout', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Máximo Usuarios Concurrentes
                      </label>
                      <input
                        type="number"
                        min="10"
                        max="1000"
                        value={settings.maxConcurrentUsers}
                        onChange={(e) => handleInputChange('maxConcurrentUsers', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Theme Settings */}
            {activeTab === 'theme' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Configuración de Apariencia</h2>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Color Primario
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="color"
                          value={settings.primaryColor}
                          onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                          className="w-12 h-10 border border-gray-300 rounded"
                        />
                        <input
                          type="text"
                          value={settings.primaryColor}
                          onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Color Secundario
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="color"
                          value={settings.secondaryColor}
                          onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                          className="w-12 h-10 border border-gray-300 rounded"
                        />
                        <input
                          type="text"
                          value={settings.secondaryColor}
                          onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tema por Defecto
                    </label>
                    <select
                      value={settings.defaultTheme}
                      onChange={(e) => handleInputChange('defaultTheme', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    >
                      <option value="default">Default</option>
                      <option value="summer">Verano</option>
                      <option value="mother">Día de la Madre</option>
                      <option value="independence">Independencia</option>
                      <option value="xmas">Navidad</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      CSS Personalizado
                    </label>
                    <textarea
                      value={settings.customCss}
                      onChange={(e) => handleInputChange('customCss', e.target.value)}
                      rows={6}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent font-mono text-sm"
                      placeholder="/* Agrega tu CSS personalizado aquí */"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Notifications Settings */}
            {activeTab === 'notifications' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Configuración de Notificaciones</h2>
                  
                  <div className="grid md:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email del Administrador
                      </label>
                      <input
                        type="email"
                        value={settings.adminEmail}
                        onChange={(e) => handleInputChange('adminEmail', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Teléfono del Administrador
                      </label>
                      <input
                        type="tel"
                        value={settings.adminPhone}
                        onChange={(e) => handleInputChange('adminPhone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="emailNotifications"
                        checked={settings.emailNotifications}
                        onChange={(e) => handleInputChange('emailNotifications', e.target.checked)}
                        className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                      />
                      <label htmlFor="emailNotifications" className="text-sm text-gray-700">
                        Habilitar notificaciones por email
                      </label>
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="notifyNewConnections"
                        checked={settings.notifyNewConnections}
                        onChange={(e) => handleInputChange('notifyNewConnections', e.target.checked)}
                        className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                      />
                      <label htmlFor="notifyNewConnections" className="text-sm text-gray-700">
                        Notificar nuevas conexiones
                      </label>
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="notifyErrors"
                        checked={settings.notifyErrors}
                        onChange={(e) => handleInputChange('notifyErrors', e.target.checked)}
                        className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                      />
                      <label htmlFor="notifyErrors" className="text-sm text-gray-700">
                        Notificar errores del sistema
                      </label>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Security Settings */}
            {activeTab === 'security' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Configuración de Seguridad</h2>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="enableBruteForceProtection"
                        checked={settings.enableBruteForceProtection}
                        onChange={(e) => handleInputChange('enableBruteForceProtection', e.target.checked)}
                        className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                      />
                      <label htmlFor="enableBruteForceProtection" className="text-sm text-gray-700">
                        Habilitar protección contra ataques de fuerza bruta
                      </label>
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="requireTermsAcceptance"
                        checked={settings.requireTermsAcceptance}
                        onChange={(e) => handleInputChange('requireTermsAcceptance', e.target.checked)}
                        className="w-4 h-4 text-[#003478] border-gray-300 rounded focus:ring-[#003478]"
                      />
                      <label htmlFor="requireTermsAcceptance" className="text-sm text-gray-700">
                        Requerir aceptación de términos y condiciones
                      </label>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Máximo Intentos de Login
                      </label>
                      <input
                        type="number"
                        min="3"
                        max="10"
                        value={settings.maxLoginAttempts}
                        onChange={(e) => handleInputChange('maxLoginAttempts', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Duración de Bloqueo (minutos)
                      </label>
                      <input
                        type="number"
                        min="5"
                        max="120"
                        value={settings.lockoutDuration}
                        onChange={(e) => handleInputChange('lockoutDuration', parseInt(e.target.value))}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Contact Settings */}
            {activeTab === 'contact' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Información de Contacto</h2>
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Nombre de la Empresa
                      </label>
                      <input
                        type="text"
                        value={settings.companyName}
                        onChange={(e) => handleInputChange('companyName', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Ciudad
                      </label>
                      <input
                        type="text"
                        value={settings.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Teléfono
                      </label>
                      <input
                        type="tel"
                        value={settings.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        value={settings.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Sitio Web
                      </label>
                      <input
                        type="url"
                        value={settings.website}
                        onChange={(e) => handleInputChange('website', e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dirección
                    </label>
                    <textarea
                      value={settings.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003478] focus:border-transparent"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </FordCard>
        </div>
      </div>
    </div>
  );
}
