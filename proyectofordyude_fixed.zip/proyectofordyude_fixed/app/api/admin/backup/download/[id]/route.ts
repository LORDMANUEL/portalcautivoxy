
/**
 * API Route para descargar backup
 * 
 * Funcionalidades:
 * - GET: Descargar archivo de backup
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { readFile } from 'fs/promises'
import { basename } from 'path'

export const dynamic = "force-dynamic"

/**
 * GET /api/admin/backup/download/[id]
 * Descargar archivo de backup
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json(
        { success: false, message: 'No autorizado' },
        { status: 401 }
      )
    }

    const backup = await prisma.backup.findUnique({
      where: { id: params.id }
    })

    if (!backup) {
      return NextResponse.json(
        { success: false, message: 'Backup no encontrado' },
        { status: 404 }
      )
    }

    if (!backup.filePath || backup.status !== 'COMPLETED') {
      return NextResponse.json(
        { success: false, message: 'Backup no disponible para descarga' },
        { status: 400 }
      )
    }

    try {
      const fileBuffer = await readFile(backup.filePath)
      const fileName = basename(backup.filePath)
      
      // Determinar tipo de contenido
      let contentType = 'application/octet-stream'
      if (fileName.endsWith('.sql')) {
        contentType = 'application/sql'
      } else if (fileName.endsWith('.gz')) {
        contentType = 'application/gzip'
      } else if (fileName.endsWith('.zip')) {
        contentType = 'application/zip'
      }

      return new NextResponse(fileBuffer, {
        headers: {
          'Content-Type': contentType,
          'Content-Disposition': `attachment; filename="${fileName}"`
        }
      })

    } catch (error) {
      return NextResponse.json(
        { success: false, message: 'Archivo de backup no encontrado' },
        { status: 404 }
      )
    }

  } catch (error) {
    console.error('Error downloading backup:', error)
    return NextResponse.json(
      { success: false, message: 'Error interno del servidor' },
      { status: 500 }
    )
  }
}
