
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Footer() {
  return (
    <motion.footer
      className="bg-[#003478] text-white py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo y descripción */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Image
                src="https://static.vecteezy.com/system/resources/previews/019/909/675/large_2x/ford-transparent-ford-free-free-png.png"
                alt="Ford Logo"
                width={60}
                height={30}
                className="object-contain"
              />
            </div>
            <p className="text-sm text-blue-100">
              Concesionario oficial Ford en Honduras. Más de 50 años ofreciendo 
              calidad, confianza y excelencia en el servicio automotriz.
            </p>
          </div>

          {/* Información de contacto */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contacto</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-blue-300" />
                <span>San Pedro Sula, Honduras</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-blue-300" />
                <span>+504 2550-0000</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-blue-300" />
                <span>info@fordyude.hn</span>
              </div>
            </div>
          </div>

          {/* Horarios */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Horarios</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-blue-300" />
                <div>
                  <p>Lun - Vie: 8:00 AM - 6:00 PM</p>
                  <p>Sábado: 8:00 AM - 5:00 PM</p>
                  <p>Domingo: Cerrado</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-blue-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-blue-200">
            © 2025 Ford Yude Canahuati. Todos los derechos reservados.
          </p>
          <p className="text-xs text-blue-300 mt-2 md:mt-0">
            Portal Cautivo v1.0
          </p>
        </div>
      </div>
    </motion.footer>
  );
}
