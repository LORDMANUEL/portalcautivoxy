
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export const dynamic = 'force-dynamic';

// Datos simulados de usuarios del portal cautivo
const generateMockUsers = () => {
  const portals = ['ford-general', 'quicklane-truck', 'quicklane-tegus', 'quicklane-sps'];
  const deviceTypes = ['mobile', 'tablet', 'desktop'];
  const themes = ['default', 'summer', 'yude-anniversary', 'quicklane'];
  
  const users = [];
  const now = new Date();
  
  for (let i = 1; i <= 250; i++) {
    const connectedAt = new Date(now.getTime() - Math.random() * 30 * 24 * 60 * 60 * 1000); // Últimos 30 días
    const sessionDuration = Math.floor(Math.random() * 120) + 5; // 5-125 minutos
    const isActive = Math.random() > 0.7; // 30% activos
    
    users.push({
      id: `user-${i}`,
      deviceId: `device-${Math.random().toString(36).substr(2, 9)}`,
      ipAddress: `192.168.1.${Math.floor(Math.random() * 254) + 1}`,
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      deviceName: `Device-${i}`,
      deviceType: deviceTypes[Math.floor(Math.random() * deviceTypes.length)],
      email: i % 3 === 0 ? `usuario${i}@email.com` : null,
      name: i % 4 === 0 ? `Usuario ${i}` : null,
      phone: i % 5 === 0 ? `+504 ${Math.floor(Math.random() * 9000) + 1000}-${Math.floor(Math.random() * 9000) + 1000}` : null,
      company: i % 6 === 0 ? 'Empresa Ejemplo' : null,
      portal: portals[Math.floor(Math.random() * portals.length)],
      theme: themes[Math.floor(Math.random() * themes.length)],
      connectedAt: connectedAt.toISOString(),
      disconnectedAt: isActive ? null : new Date(connectedAt.getTime() + sessionDuration * 60000).toISOString(),
      sessionDuration: isActive ? null : sessionDuration,
      location: i % 7 === 0 ? `14.${Math.random().toFixed(4)}, -87.${Math.random().toFixed(4)}` : null,
      isActive,
      pagesViewed: Math.floor(Math.random() * 15) + 1,
      formData: i % 8 === 0 ? {
        interests: ['vehiculos', 'servicios'],
        visitReason: 'Compra de vehículo',
        contactPreference: 'email',
        additionalInfo: 'Interesado en Ford F-150'
      } : undefined
    });
  }
  
  return users.sort((a, b) => new Date(b.connectedAt).getTime() - new Date(a.connectedAt).getTime());
};

/**
 * GET - Obtiene usuarios del portal cautivo
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
    }

    const users = generateMockUsers();
    return NextResponse.json(users);

  } catch (error) {
    console.error('Error:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
