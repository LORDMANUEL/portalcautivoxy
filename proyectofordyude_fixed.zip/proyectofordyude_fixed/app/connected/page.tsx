
import { Metadata } from 'next';
import { ConnectedClient } from './_components/connected-client';

export const metadata: Metadata = {
  title: 'Conectado - Ford Yude Canahuati',
  description: 'Bienvenido al WiFi de Ford Yude Canahuati. Disfruta de tu navegación.',
};

export default function ConnectedPage() {
  return <ConnectedClient />;
}
