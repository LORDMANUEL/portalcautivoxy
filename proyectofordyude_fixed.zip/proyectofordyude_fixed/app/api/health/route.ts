
/**
 * API Health Check para el Portal Ford Yude Canahuati
 * 
 * Este endpoint proporciona información sobre el estado de salud del sistema,
 * incluyendo conectividad de base de datos y estado general del servidor.
 * Útil para monitoreo, load balancers y herramientas de DevOps.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

/**
 * Fuerza el renderizado dinámico para obtener estado real en cada request
 * Evita que el resultado sea cacheado ya que necesitamos información actualizada
 */
export const dynamic = "force-dynamic";

/**
 * Endpoint GET para verificar el estado de salud del sistema
 * 
 * Realiza las siguientes verificaciones:
 * - Conectividad con la base de datos PostgreSQL
 * - Estado general del servidor Next.js
 * - Timestamp actual para validar respuesta
 * 
 * @returns Promise<NextResponse> - Objeto JSON con estado del sistema
 * 
 * @example
 * GET /api/health
 * 
 * Respuesta exitosa:
 * {
 *   "status": "healthy",
 *   "timestamp": "2024-01-15T10:30:45.123Z",
 *   "services": {
 *     "database": "connected",
 *     "server": "running"
 *   }
 * }
 * 
 * Respuesta de error:
 * {
 *   "status": "unhealthy",
 *   "timestamp": "2024-01-15T10:30:45.123Z",
 *   "error": "Database connection failed"
 * }
 */
export async function GET() {
  try {
    /**
     * Prueba de conectividad con la base de datos
     * Ejecuta una query simple que no afecta datos pero confirma conexión
     */
    await prisma.$queryRaw`SELECT 1`;
    
    /**
     * Respuesta exitosa con información de estado
     * Incluye timestamp para validar que la respuesta es fresca
     */
    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        server: 'running'
      }
    });
    
  } catch (error) {
    /**
     * Logging de errores para diagnóstico
     * Importante para detectar problemas de infraestructura
     */
    console.error('Health check failed:', error);
    
    /**
     * Respuesta de error con código HTTP 500
     * Indica que el sistema no está saludable
     */
    return NextResponse.json(
      {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        error: 'Database connection failed'
      },
      { status: 500 }
    );
  }
}
