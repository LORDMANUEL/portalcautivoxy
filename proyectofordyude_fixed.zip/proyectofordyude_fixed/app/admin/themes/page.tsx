
import { Metadata } from 'next';
import { ThemesClient } from './_components/themes-client';

export const metadata: Metadata = {
  title: 'Gestión de Temas - Admin Ford',
  description: 'Administrar temas del portal cautivo',
};

export default function AdminThemesPage() {
  return <ThemesClient />;
}
