
/**
 * Configuración de autenticación NextAuth para Ford Yude Canahuati Portal
 * 
 * Este archivo maneja toda la configuración de autenticación del sistema,
 * incluyendo autenticación por credenciales con username/password,
 * integración con Prisma para persistencia de sesiones y callbacks personalizados.
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 1.0.0
 */

import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { PrismaAdapter } from '@next-auth/prisma-adapter';
import { prisma } from './db';
import bcrypt from 'bcryptjs';

/**
 * Configuración principal de NextAuth para el portal Ford Yude Canahuati
 * 
 * Configura:
 * - Autenticación por credenciales (username/password)
 * - Integración con Prisma para persistencia de datos
 * - Estrategia JWT para sesiones
 * - Callbacks personalizados para roles y permisos
 * - Páginas personalizadas de login
 * 
 * @constant {NextAuthOptions} authOptions - Objeto de configuración completo
 */
export const authOptions: NextAuthOptions = {
  // Adaptador de Prisma para persistencia de sesiones y cuentas
  adapter: PrismaAdapter(prisma),
  
  providers: [
    /**
     * Proveedor de autenticación por credenciales
     * Permite login con username y password únicamente
     */
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        username: { label: 'Usuario', type: 'text' },
        password: { label: 'Contraseña', type: 'password' }
      },
      
      /**
       * Función de autorización que valida las credenciales del usuario
       * 
       * @param credentials - Objeto con username y password proporcionados
       * @returns Objeto del usuario si las credenciales son válidas, null si no
       */
      async authorize(credentials) {
        // Validación de presencia de credenciales
        if (!credentials?.username || !credentials?.password) {
          return null;
        }

        // Búsqueda del administrador en la base de datos por username
        const admin = await prisma.admin.findUnique({
          where: {
            username: credentials.username
          }
        });

        // Validación de existencia y estado activo del administrador
        if (!admin || !admin.isActive) {
          return null;
        }

        // Verificación de contraseña usando bcrypt
        const isPasswordValid = await bcrypt.compare(
          credentials.password,
          admin.password
        );

        if (!isPasswordValid) {
          return null;
        }

        // Actualización de último login para auditoría
        await prisma.admin.update({
          where: { id: admin.id },
          data: { lastLogin: new Date() }
        });

        // Retorno del objeto usuario para la sesión
        return {
          id: admin.id,
          email: admin.email || admin.username, // Fallback para compatibilidad
          name: admin.name,
          role: admin.role,
          username: admin.username,
        };
      }
    })
  ],
  
  // Configuración de sesión usando JWT
  session: {
    strategy: 'jwt'
  },
  
  callbacks: {
    /**
     * Callback JWT para agregar información adicional al token
     * 
     * @param param0 - Objeto con token actual y user (si está disponible)
     * @returns Token modificado con información de rol
     */
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as any).role;
      }
      return token;
    },
    
    /**
     * Callback de sesión para agregar información del token a la sesión
     * 
     * @param param0 - Objeto con session y token actuales
     * @returns Sesión modificada con ID y rol del usuario
     */
    async session({ session, token }) {
      if (token && session.user) {
        session.user.id = token.sub || '';
        session.user.role = token.role;
      }
      return session;
    }
  },
  
  // Configuración de páginas personalizadas
  pages: {
    signIn: '/admin/login', // Página de login personalizada
  }
};
