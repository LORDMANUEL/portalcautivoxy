
/**
 * Diálogo para Crear Usuario
 * 
 * @author Ford Yude Canahuati Development Team
 * @version 2.0.0
 */

'use client'

import { useState } from 'react'
import { toast } from 'react-hot-toast'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { Eye, EyeOff, X } from 'lucide-react'

const createUserSchema = z.object({
  username: z.string().min(3, 'Username debe tener al menos 3 caracteres'),
  email: z.string().email('Email inválido').optional().or(z.literal('')),
  name: z.string().min(2, 'Nombre debe tener al menos 2 caracteres'),
  password: z.string().min(6, 'Password debe tener al menos 6 caracteres'),
  locationId: z.string().optional(),
  roles: z.array(z.string()).default([])
})

type CreateUserForm = z.infer<typeof createUserSchema>

interface Location {
  id: string
  name: string
  code: string
  type: string
}

interface Role {
  id: string
  name: string
  displayName: string
  priority: number
}

interface CreateUserDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: () => void
  locations: Location[]
  roles: Role[]
}

export default function CreateUserDialog({
  open,
  onOpenChange,
  onSuccess,
  locations,
  roles
}: CreateUserDialogProps) {
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [selectedRoles, setSelectedRoles] = useState<string[]>([])

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    watch
  } = useForm<CreateUserForm>({
    resolver: zodResolver(createUserSchema),
    defaultValues: {
      roles: []
    }
  })

  const handleClose = () => {
    reset()
    setSelectedRoles([])
    setShowPassword(false)
    onOpenChange(false)
  }

  const onSubmit = async (data: CreateUserForm) => {
    try {
      setLoading(true)

      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...data,
          roles: selectedRoles,
          email: data.email || undefined
        })
      })

      const result = await response.json()

      if (result.success) {
        toast.success('Usuario creado exitosamente')
        onSuccess()
        handleClose()
      } else {
        toast.error(result.message || 'Error al crear usuario')
      }
    } catch (error) {
      console.error('Error creating user:', error)
      toast.error('Error al crear usuario')
    } finally {
      setLoading(false)
    }
  }

  const handleRoleToggle = (roleId: string) => {
    setSelectedRoles(prev => {
      const newRoles = prev.includes(roleId)
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
      
      setValue('roles', newRoles)
      return newRoles
    })
  }

  const removeRole = (roleId: string) => {
    setSelectedRoles(prev => {
      const newRoles = prev.filter(id => id !== roleId)
      setValue('roles', newRoles)
      return newRoles
    })
  }

  const getRoleColor = (priority: number) => {
    if (priority >= 90) return 'bg-red-100 text-red-800 border-red-200'
    if (priority >= 70) return 'bg-blue-100 text-blue-800 border-blue-200'  
    if (priority >= 50) return 'bg-green-100 text-green-800 border-green-200'
    return 'bg-gray-100 text-gray-800 border-gray-200'
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Crear Nuevo Usuario</DialogTitle>
          <DialogDescription>
            Crea un nuevo usuario administrador con roles y permisos específicos.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Username */}
            <div className="space-y-2">
              <Label htmlFor="username">Username *</Label>
              <Input
                id="username"
                {...register('username')}
                placeholder="Ingresa el username"
                disabled={loading}
              />
              {errors.username && (
                <p className="text-sm text-red-600">{errors.username.message}</p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                {...register('email')}
                placeholder="email@ejemplo.com"
                disabled={loading}
              />
              {errors.email && (
                <p className="text-sm text-red-600">{errors.email.message}</p>
              )}
            </div>
          </div>

          {/* Nombre completo */}
          <div className="space-y-2">
            <Label htmlFor="name">Nombre Completo *</Label>
            <Input
              id="name"
              {...register('name')}
              placeholder="Ingresa el nombre completo"
              disabled={loading}
            />
            {errors.name && (
              <p className="text-sm text-red-600">{errors.name.message}</p>
            )}
          </div>

          {/* Password */}
          <div className="space-y-2">
            <Label htmlFor="password">Contraseña *</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                {...register('password')}
                placeholder="Mínimo 6 caracteres"
                disabled={loading}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
            {errors.password && (
              <p className="text-sm text-red-600">{errors.password.message}</p>
            )}
          </div>

          {/* Ubicación */}
          <div className="space-y-2">
            <Label htmlFor="location">Ubicación</Label>
            <Select onValueChange={(value) => setValue('locationId', value || undefined)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una ubicación" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Sin ubicación específica</SelectItem>
                {locations.map((location) => (
                  <SelectItem key={location.id} value={location.id}>
                    {location.name} ({location.code}) - {location.type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Roles */}
          <div className="space-y-4">
            <Label>Roles del Usuario</Label>
            
            {/* Selected Roles */}
            {selectedRoles.length > 0 && (
              <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-md">
                {selectedRoles.map((roleId) => {
                  const role = roles.find(r => r.id === roleId)
                  if (!role) return null
                  
                  return (
                    <Badge
                      key={roleId}
                      variant="outline"
                      className={`${getRoleColor(role.priority)} flex items-center gap-1`}
                    >
                      {role.displayName}
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-auto p-0 ml-1 hover:bg-transparent"
                        onClick={() => removeRole(roleId)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </Badge>
                  )
                })}
              </div>
            )}

            {/* Available Roles */}
            <div className="space-y-2">
              <p className="text-sm text-gray-600">Roles disponibles:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {roles
                  .sort((a, b) => b.priority - a.priority)
                  .map((role) => (
                    <div key={role.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`role-${role.id}`}
                        checked={selectedRoles.includes(role.id)}
                        onCheckedChange={() => handleRoleToggle(role.id)}
                        disabled={loading}
                      />
                      <Label
                        htmlFor={`role-${role.id}`}
                        className="flex items-center gap-2 cursor-pointer"
                      >
                        <Badge
                          variant="outline"
                          className={getRoleColor(role.priority)}
                        >
                          {role.displayName}
                        </Badge>
                        <span className="text-sm text-gray-600">
                          ({role.name})
                        </span>
                      </Label>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-[#003478] hover:bg-[#002856]"
            >
              {loading ? 'Creando...' : 'Crear Usuario'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
