
import { Metadata } from 'next';
import { LogsClient } from './_components/logs-client';

export const metadata: Metadata = {
  title: 'Logs del Sistema - Admin Ford',
  description: 'Registro de actividad del portal cautivo',
};

export default function AdminLogsPage() {
  return <LogsClient />;
}
