
import { Metadata } from 'next';
import { CaptiveUsersClient } from './_components/captive-users-client';

export const metadata: Metadata = {
  title: 'Usuarios Portal Cautivo - Admin Ford',
  description: 'Reportes y análisis de usuarios del portal cautivo',
};

export default function CaptiveUsersPage() {
  return <CaptiveUsersClient />;
}
